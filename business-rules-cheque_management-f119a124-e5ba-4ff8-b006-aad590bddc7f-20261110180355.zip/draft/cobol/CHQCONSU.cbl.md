# CHQCONSU.cbl: Consulta de Chequeras de una Cuenta Corriente - Transaccion CH01

## Overview

CHQCONSU es un programa de pantalla interactiva (CICS online) del sistema SIDEP (Sistema Integrado de Depositos) del Banco Andes del Peru. Se ejecuta bajo el codigo de transaccion CH01 y presenta al usuario la pantalla CHQM1 del mapset CHQMAP1.

Su unica funcion es la consulta de chequeras asociadas a una cuenta corriente. Dado un numero de cuenta ingresado por el usuario, el programa verifica que la cuenta exista y sea de tipo corriente (producto 06), muestra el nombre del titular y el estado de la cuenta, lista las cinco chequeras mas recientes con su rango de numeracion, estado, fecha de emision, indicador de gratuidad y cantidad de hojas disponibles, y presenta un resumen de totales de cheques agrupados por estado (disponibles, pagados, rechazados y no pagados).

El programa es estrictamente de solo lectura: no modifica ningun dato en ninguna tabla de la base de datos ni en ninguna otra estructura. Pertenece al modulo CHQ (Cheques y Compensacion) del nucleo de SIDEP y consume dos tablas DB2 propias del dominio (CHQ_CHEQUERA y CHQ_CHEQUE), ademas del subprograma centralizado SDCMAEST, que es el unico punto de acceso autorizado a la tabla maestra de cuentas (CUENTA_MAESTRO).

El programa sigue el patron pseudo-conversacional de CICS: cada vez que responde al usuario, le devuelve el control al sistema con instruccion de relanzar la misma transaccion CH01 en la siguiente pulsacion de tecla, pasando el estado de la sesion a traves de una COMMAREA de 30 bytes.

## Process Flow

```mermaid
flowchart TD
    A("Inicio: CICS invoca CH01") --> B{"Primera entrada?<br/>(COMMAREA vacia)"}

    B -- "Si" --> C["Limpiar pantalla,<br/>mostrar fecha y hora,<br/>pedir numero de cuenta"]
    B -- "No" --> D["Recibir pantalla<br/>(leer tecla y datos)"]

    D --> E{"Tecla pulsada"}

    E -- "PF3: Salir" --> F["Mostrar mensaje de fin<br/>y cerrar transaccion"]
    E -- "PF5: Limpiar" --> C
    E -- "Tecla invalida" --> G["Mostrar aviso:<br/>use ENTER, PF3 o PF5"]
    E -- "ENTER: Consultar" --> H{"Numero de cuenta<br/>ingresado?"}

    H -- "No" --> I["Mostrar aviso:<br/>debe ingresar cuenta"]
    H -- "Si" --> J["Llamar a SDCMAEST<br/>para leer la cuenta"]

    J --> K{"Cuenta encontrada?"}
    K -- "No" --> L["Mostrar aviso:<br/>cuenta no existe"]
    K -- "Si" --> M{"Es cuenta<br/>corriente (prod. 06)?"}

    M -- "No" --> N["Mostrar aviso:<br/>no es cuenta corriente"]
    M -- "Si" --> O["Mostrar titular,<br/>estado y moneda"]

    O --> P["Abrir cursor DB2:<br/>5 chequeras mas recientes<br/>de CHQ_CHEQUERA"]
    P --> Q["Por cada chequera:<br/>contar hojas disponibles<br/>en CHQ_CHEQUE (estado DI)<br/>y armar linea de detalle"]
    Q --> R["Calcular totales globales<br/>de cheques por estado<br/>(DI, PA, RE, NP)<br/>desde CHQ_CHEQUE"]
    R --> S["Enviar pantalla<br/>con todos los datos"]

    C --> T["Retornar a CICS<br/>con COMMAREA<br/>(relanzar CH01)"]
    G --> T
    I --> T
    L --> T
    N --> T
    S --> T
    F --> U("Fin de sesion")
```

<!-- general-rule-start -->

## General Business Rules:

### Tipo de programa y mecanismo de activacion

CHQCONSU es un programa CICS online de solo consulta. Se activa cuando un usuario de terminal 3270 ejecuta el codigo de transaccion CH01. No existe ningun proceso batch ni llamada desde otro programa que lo invoque: el punto de entrada siempre es el usuario en pantalla.

El programa utiliza el patron pseudo-conversacional de CICS. Esto significa que, al terminar cada interaccion con el usuario, el programa cede el control al sistema operativo y le indica a CICS que vuelva a lanzar la transaccion CH01 en cuanto el usuario pulse una tecla. Para recordar el estado entre una interaccion y la siguiente, el programa guarda 30 bytes de informacion en una COMMAREA, que CICS le devuelve al relanzarlo.

La COMMAREA tiene tres campos:
- Un indicador de estado de un caracter: espacio en blanco significa primera entrada; la letra C significa que ya se mostro una consulta.
- El numero de cuenta de 14 caracteres que se consulto.
- Un relleno de 15 caracteres sin uso.

---

### Determinacion de primera entrada o reanudacion

Al inicio de cada ejecucion, el programa examina la longitud de la COMMAREA recibida (campo EIBCALEN del bloque de informacion del evento CICS). Si la longitud es cero, es la primera vez que el usuario ejecuta la transaccion en esta sesion. En caso contrario, ya hubo una interaccion previa y la COMMAREA contiene datos.

---

### Primera entrada: presentacion de la pantalla inicial

Cuando es la primera entrada, el programa limpia completamente la pantalla (pone la estructura de salida del mapa en valores bajos), obtiene la fecha y hora del sistema, las escribe en los campos de cabecera de la pantalla (MFECHAO y MHORAO en formato DD/MM/AAAA y HH:MM:SS respectivamente), y muestra el mensaje "DIGITE EL NUMERO DE CUENTA CORRIENTE Y PRESIONE ENTER" en la linea de mensajes (MENSAO). Luego envia la pantalla al terminal y retorna a CICS indicando que relance CH01.

---

### Procesamiento de la entrada del usuario

Cuando ya existe COMMAREA, el programa lee la pantalla enviada por el usuario (mapa CHQM1 del mapset CHQMAP1) y examina que tecla funcional fue pulsada:

- **PF3 (Salir):** el programa muestra el texto "FIN DE LA TRANSACCION CH01" en pantalla y ejecuta un retorno definitivo a CICS sin relanzar la transaccion, terminando la sesion.
- **PF5 (Limpiar):** el programa ejecuta el mismo flujo que la primera entrada, limpiando la pantalla y pidiendo el numero de cuenta nuevamente.
- **ENTER (Consultar):** el programa ejecuta el proceso principal de consulta descrito en las secciones siguientes.
- **Cualquier otra tecla:** el programa conserva el numero de cuenta que aparecia en pantalla, muestra el mensaje "TECLA NO VALIDA. USE ENTER, PF3 O PF5" y reenvia la pantalla.

---

### Validaciones previas a la consulta

Antes de acceder a la base de datos, el programa realiza dos validaciones sobre el campo de numero de cuenta (CTACONI) ingresado por el usuario:

1. Comprueba que el campo no este vacio: si la longitud indicada por el mapa (CTACONL) es cero o el contenido es espacios, muestra el mensaje "DEBE INGRESAR EL NUMERO DE CUENTA" y no continua.
2. Llama al subprograma SDCMAEST con la funcion de lectura ('LE') pasando el numero de cuenta en el campo SDC-MAE-CTA-NUMERO. Si el codigo de retorno no es '00' (valor SDU-RC-OK), significa que la cuenta no existe en la tabla CUENTA_MAESTRO, y el programa muestra el mensaje "CUENTA NO EXISTE".
3. Si la cuenta existe, verifica que el campo SDC-MAE-CTA-PRODUCTO sea igual a '06' (constante SDU-PROD-CORRIENTE). Si el producto es distinto de '06', muestra el mensaje "LA CUENTA NO ES CUENTA CORRIENTE" y no continua.

---

### Presentacion de datos de la cuenta

Si la cuenta pasa todas las validaciones, el programa extrae de la respuesta de SDCMAEST los siguientes datos y los coloca en los campos de salida de la pantalla:

- El nombre del titular (SDC-MAE-TIT-NOMBRE) se escribe en el campo NOMTITO (hasta 40 caracteres).
- El estado de la cuenta (SDC-MAE-CTA-ESTADO) se traduce a texto descriptivo y se escribe en ESTCTAO (hasta 15 caracteres). La traduccion es:
  - 'AC' -> 'ACTIVA'
  - 'BL' -> 'BLOQUEADA'
  - 'BJ' -> 'BLOQ. JUDICIAL'
  - 'CE' -> 'CERRADA'
  - 'IN' -> 'INACTIVA'
  - Cualquier otro valor -> se muestra el codigo tal como viene.
- El codigo de moneda (SDC-MAE-CTA-MONEDA, 3 caracteres) se escribe en MONCTAO.

---

### Listado de las cinco chequeras mas recientes

El programa consulta la tabla DB2 CHQ_CHEQUERA filtrando por el numero de cuenta (columna CTA_NUMERO) y ordenando por numero de chequera de mayor a menor (ORDER BY NUM_CHEQUERA DESC), limitando el resultado a las cinco primeras filas (FETCH FIRST 5 ROWS ONLY). Los campos recuperados por fila son: numero de chequera (NUM_CHEQUERA), numero inicial del talonario (NUM_INICIAL), numero final del talonario (NUM_FINAL), estado de la chequera (EST_CHEQUERA), fecha de emision en formato ISO (FEC_EMISION) y el indicador de gratuidad (IND_GRATUITA).

Para cada fila recuperada, el programa ejecuta una consulta adicional a la tabla CHQ_CHEQUE contando cuantos registros tienen el mismo numero de chequera (NUM_CHEQUERA) y el estado 'DI' (disponible). El resultado es la cantidad de hojas todavia no utilizadas de esa chequera.

Con todos esos datos, el programa construye una linea de detalle de 74 caracteres con el siguiente contenido y orden:
- Numero de chequera (9 digitos)
- Espacio separador
- Numero inicial del rango (8 digitos)
- Espacio separador
- Numero final del rango (8 digitos)
- Espacio separador
- Estado de la chequera (2 caracteres)
- Espacio separador
- Fecha de emision (10 caracteres en formato ISO)
- Espacio separador
- Indicador de gratuidad (1 caracter)
- Espacio separador
- Cantidad de hojas disponibles (numero de hasta 3 digitos con supresion de ceros a la izquierda)
- Relleno de 27 espacios

Esa linea se coloca en el campo de pantalla correspondiente segun el numero de orden de la chequera: la primera chequera va a LIN1O, la segunda a LIN2O, y asi hasta LIN5O.

Si al abrir el cursor de chequeras ocurre un error de base de datos (codigo SQL distinto de cero), el programa muestra el mensaje "ERROR DB2 AL CONSULTAR CHEQUERAS" y no intenta leer filas. Si la consulta no devuelve ninguna fila (contador de lineas queda en cero), el programa muestra el mensaje "LA CUENTA NO TIENE CHEQUERAS".

---

### Totales de cheques por estado

En una sola consulta SQL a la tabla CHQ_CHEQUE, el programa calcula cuatro contadores para todos los cheques de la cuenta (filtro por columna CTA_NUMERO), usando sumas condicionales:

- Total de cheques con estado 'DI' (disponibles): se escribe en TOTDISO.
- Total de cheques con estado 'PA' (pagados): se escribe en TOTPAGO.
- Total de cheques con estado 'RE' (rechazados): se escribe en TOTRECO.
- Total de cheques con estado 'NP' (no pagados): se escribe en TOTNOPO.

La funcion COALESCE garantiza que si no hay cheques de un estado determinado el resultado sea cero en lugar de nulo. Cada contador se formatea con supresion de ceros a la izquierda en un campo de 5 posiciones (mascara ZZZZ9) antes de enviarse a la pantalla. Si la consulta SQL devuelve un codigo de error distinto de cero, los campos de totales no se actualizan y quedan en blanco.

---

### Envio de la pantalla y retorno pseudo-conversacional

Despues de completar la consulta (o despues de cualquier mensaje de error), el programa envia la pantalla CHQM1 al terminal con la instruccion ERASE (borra el contenido anterior) y CURSOR (posiciona el cursor). Antes de retornar, guarda en la COMMAREA el estado 'C' (consulta mostrada) y el numero de cuenta consultado, e indica a CICS que relance la transaccion CH01 al proximo evento del usuario.

---

### Obtencion de fecha y hora

En cada interaccion que requiere mostrar la pantalla (primera entrada y cada consulta), el programa solicita a CICS la hora absoluta del sistema (ASKTIME) y la formatea como fecha en formato DD/MM/AAAA y hora en formato HH:MM:SS, colocando ambos valores en los campos de cabecera MFECHAO y MHORAO de la pantalla.

---

### Nota sobre la tecla PF12

El rotulo de la pantalla en la linea 22 del mapa BMS todavia menciona PF12 como acceso al menu principal. Sin embargo, desde enero de 2023 ese enlace fue eliminado del programa porque el menu ya no existe. El rotulo del mapa no fue corregido porque requiere un cambio en el fuente BMS que se pospuso. El programa ignora la pulsacion de PF12 como cualquier otra tecla no reconocida y muestra el aviso de tecla no valida.

<!-- general-rule-end -->

## Dependencies

El programa CHQCONSU tiene dependencias de varios tipos: copybooks de datos compartidos, un subprograma del nucleo del sistema, recursos CICS (mapa de pantalla y mecanismos de conversacion), y tablas DB2. A continuacion se describe cada una y se presenta la tabla de referencia.

**Copybooks incluidos en la seccion de datos**

El programa incorpora cinco copybooks mediante instrucciones COPY. Cada uno aporta definiciones de datos que el programa usa directamente en sus operaciones:

- **SDCMAEW** define la estructura de comunicacion con el subprograma SDCMAEST. Es un unico bloque de datos llamado SDC-AREA-MAESTRO que contiene todos los campos de entrada y salida de esa llamada: codigo de funcion, codigo de retorno, numero de cuenta, datos del titular, saldos, fechas y campos de auditoria. CHQCONSU usa este copybook tanto en la seccion de trabajo como en la llamada a SDCMAEST.
- **SDUCONST** define las constantes institucionales del sistema SIDEP: codigos de producto (por ejemplo, el codigo '06' para cuenta corriente, referenciado como SDU-PROD-CORRIENTE), codigos de moneda, estados de cuenta, tipos de documento de identidad, parametros tributarios y codigos de retorno estandar (por ejemplo, SDU-RC-OK con valor '00'). CHQCONSU lo usa para comparar el producto de la cuenta y evaluar el codigo de retorno de SDCMAEST.
- **CHQMAPW** define dos cosas en un mismo archivo: la estructura simbolica del mapa de pantalla CHQM1 (en sus versiones de entrada CHQM1I y de salida CHQM1O) y la estructura de la COMMAREA de la transaccion CH01. La estructura de salida CHQM1O contiene los campos CTACONO, NOMTITO, ESTCTAO, MONCTAO, LIN1O a LIN5O, TOTDISO, TOTPAGO, TOTRECO, TOTNOPO y MENSAO, que son los campos que el programa escribe antes de enviar la pantalla. La COMMAREA (CHQ-COMMAREA) tiene 30 bytes y guarda el estado de la conversacion (CHQ-CA-ESTADO) y el numero de cuenta de la ultima consulta (CHQ-CA-CUENTA). **Nota de modernizacion:** este copybook se mantiene a mano y no se genera automaticamente desde el BMS; si el mapa CHQMAP1 cambia, este archivo debe editarse manualmente para mantener la correspondencia.
- **DFHAID** es un copybook estandar de CICS que define los valores de las teclas de atencion (AID), en particular DFHENTER, DFHPF3 y DFHPF5, que el programa usa para determinar que tecla presiono el usuario.
- **DFHBMSCA** es otro copybook estandar de CICS que define atributos de campos de mapa. El programa lo incluye aunque no se observa uso explicito de sus constantes en la logica de negocio visible; su presencia es habitual en programas CICS con mapas BMS.

**Subprograma llamado**

El programa realiza una unica llamada a un subprograma externo:

- **SDCMAEST** es el punto de acceso centralizado a la tabla DB2 CUENTA_MAESTRO. CHQCONSU lo invoca con la funcion 'LE' (lectura) pasando el numero de cuenta en SDC-MAE-CTA-NUMERO. Si el codigo de retorno devuelto en SDC-MAE-COD-RETORNO es distinto de SDU-RC-OK ('00'), el programa muestra el mensaje 'CUENTA NO EXISTE' y abandona la consulta. Si el retorno es exitoso, el programa lee de la estructura de respuesta los campos SDC-MAE-TIT-NOMBRE (nombre del titular), SDC-MAE-CTA-ESTADO (estado de la cuenta), SDC-MAE-CTA-PRODUCTO (codigo de producto, que debe ser '06' para continuar) y SDC-MAE-CTA-MONEDA (moneda de la cuenta). El codigo fuente de SDCMAEST esta disponible como referencia y muestra que este subprograma ejecuta un SELECT sin bloqueo sobre la tabla CUENTA_MAESTRO en DB2.

**Recursos CICS**

- **Mapa CHQM1 del mapset CHQMAP1**: el programa envia y recibe datos de pantalla usando este mapa. El BMS fuente (CHQMAP1.bms) esta disponible como referencia. Define una pantalla de 24 lineas por 80 columnas para un terminal 3270-2, con campos de entrada para el numero de cuenta y campos protegidos de salida para el titular, estado, moneda, cinco lineas de detalle de chequeras y cuatro contadores de totales. El mapa debe estar ensamblado y cargado en la region CICS para que el programa funcione.
- **Transaccion CH01**: es el identificador de transaccion CICS bajo el cual corre CHQCONSU. El programa lo usa al retornar el control a CICS (instruccion RETURN con TRANSID), lo que implementa el patron pseudo-conversacional: CICS vuelve a invocar el programa con el mismo identificador cuando el usuario presiona una tecla.
- **COMMAREA de 30 bytes**: el programa pasa y recibe una COMMAREA de exactamente 30 bytes en cada ciclo de la transaccion. Su contenido esta definido en CHQMAPW (CHQ-COMMAREA). La longitud de la COMMAREA es fija en 30 bytes tanto en el RETURN como en la definicion del LINKAGE SECTION (DFHCOMMAREA).
- **EXEC CICS ASKTIME / FORMATTIME**: el programa llama a los servicios de tiempo de CICS para obtener la fecha y hora actuales, que muestra en la cabecera de la pantalla.

**Tablas DB2**

El programa accede directamente a dos tablas DB2 del dominio de cheques, sin pasar por ningun subprograma intermediario:

- **CHQ_CHEQUERA**: el programa declara un cursor llamado CUR_CHQRA sobre esta tabla. La consulta selecciona los campos NUM_CHEQUERA, NUM_INICIAL, NUM_FINAL, EST_CHEQUERA, FEC_EMISION (formateada en ISO) e IND_GRATUITA, filtrando por CTA_NUMERO igual al numero de cuenta ingresado, ordenados por NUM_CHEQUERA de forma descendente y limitados a las 5 primeras filas (FETCH FIRST 5 ROWS ONLY).
- **CHQ_CHEQUE**: el programa ejecuta dos tipos de consulta sobre esta tabla. La primera, ejecutada una vez por cada chequera recuperada, cuenta las filas con EST_CHEQUE = 'DI' (disponibles) para esa chequera. La segunda, ejecutada una sola vez al final, suma en una sola pasada los cheques agrupados por cuatro estados: 'DI' (disponibles), 'PA' (pagados), 'RE' (rechazados) y 'NP' (no pagados), usando expresiones CASE dentro de funciones SUM con COALESCE para evitar nulos, filtrando por CTA_NUMERO.

**Estructura SQL de comunicacion**

- **SQLCA** (SQL Communication Area): incluida mediante EXEC SQL INCLUDE SQLCA. El programa lee el campo SQLCODE de esta estructura despues de cada operacion DB2 para determinar si tuvo exito (valor 0) o si no se encontraron filas (valor distinto de 0 en el cursor).

| Dependencia | Descripcion | Tipo | Referencia | Relevancia para Modernizacion |
|---|---|---|---|---|
| SDCMAEW | Estructura de comunicacion con SDCMAEST: funcion, retorno, datos de cuenta, titular, saldos y auditoria | Copybook de datos compartidos | SDCMAEW.cpy | Cualquier cambio en este copybook afecta a todos los llamadores de SDCMAEST. Dos programas historicos (CTSCERTI y SDMPOSTA) replicaron el area a mano y no detectarian cambios en compilacion. |
| SDUCONST | Constantes institucionales: codigos de producto, moneda, estado, retorno y parametros operativos | Copybook de constantes | SDUCONST.cpy | Contiene valores que en una plataforma moderna serian parametros de configuracion o entradas de catalogo. SDU-PROD-CORRIENTE ('06') y SDU-RC-OK ('00') son criticos para la logica de validacion. |
| CHQMAPW | Mapa simbolico del mapa CHQM1 (entrada/salida) y estructura de la COMMAREA de CH01 | Copybook de mapa y COMMAREA | CHQMAPW.cpy | Escrito y mantenido a mano; no se genera desde el BMS. Si el BMS cambia, este archivo debe actualizarse manualmente o los campos quedaran desalineados. |
| DFHAID | Constantes de teclas de atencion CICS (AID values) | Copybook estandar CICS | DFHAID (libreria CICS) | En una modernizacion fuera de CICS, los valores de DFHENTER, DFHPF3 y DFHPF5 deben mapearse a los equivalentes del nuevo canal de interaccion. |
| DFHBMSCA | Atributos de campos de mapa BMS | Copybook estandar CICS | DFHBMSCA (libreria CICS) | Incluido pero sin uso explicito de sus constantes en la logica visible. Verificar en compilacion si algun campo de atributo lo referencia antes de eliminarlo. |
| SDCMAEST | Subprograma nucleo de acceso a CUENTA_MAESTRO; usado con funcion 'LE' para leer datos del titular, estado y producto de la cuenta | Subprograma COBOL (CALL estatico) | SDCMAEST.cbl | Es el punto unico de acceso al maestro de cuentas. En la modernizacion debe reemplazarse por el servicio equivalente de lectura de cuentas. Tiene aproximadamente 22 llamadores en el sistema. |
| CHQMAP1 / CHQM1 | Mapa BMS de 24x80 para terminal 3270-2; define la pantalla de consulta de chequeras con campos de entrada, detalle y totales | Recurso CICS - BMS Mapset | CHQMAP1.bms | Debe reemplazarse por una interfaz de usuario equivalente (web, API, etc.). El rotulo de PF12 al menu principal permanece en el BMS aunque esa funcionalidad fue eliminada en 2023. |
| Transaccion CH01 | Identificador de transaccion CICS bajo el que se ejecuta CHQCONSU; usado en el RETURN para implementar el ciclo pseudo-conversacional | Recurso CICS - Transaccion | Definicion en tabla de transacciones CICS | En la modernizacion, el ciclo pseudo-conversacional debe reemplazarse por el mecanismo de sesion del nuevo canal. |
| COMMAREA (30 bytes) | Area de 30 bytes que CICS pasa entre ciclos de la transaccion; contiene estado de la conversacion y numero de cuenta | Mecanismo CICS - COMMAREA | Definida en CHQMAPW.cpy (CHQ-COMMAREA) | El estado de sesion almacenado en la COMMAREA debe migrarse a un mecanismo de estado de sesion del nuevo entorno. |
| EXEC CICS ASKTIME / FORMATTIME | Servicios de tiempo de CICS para obtener fecha y hora del sistema en formato DD/MM/YYYY y HH:MM:SS | Servicio CICS | API estandar CICS | Reemplazar por llamada al sistema operativo o servicio de tiempo del nuevo entorno. |
| CHQ_CHEQUERA | Tabla DB2 del dominio de cheques; contiene una fila por chequera asignada a una cuenta, con numero, rango de hojas, estado, fecha de emision e indicador de gratuidad | Tabla DB2 (acceso directo, solo lectura) | Tabla DB2: CHQ_CHEQUERA | El programa accede directamente sin subprograma intermediario. En la modernizacion debe definirse si el acceso continua directo o pasa por una capa de servicio. |
| CHQ_CHEQUE | Tabla DB2 del dominio de cheques; contiene una fila por cheque individual, con numero de chequera, numero de cheque, estado y numero de cuenta | Tabla DB2 (acceso directo, solo lectura) | Tabla DB2: CHQ_CHEQUE | Accedida dos veces por ciclo de consulta: una vez por cada chequera para contar disponibles, y una vez para los totales globales. El acceso es de solo lectura. |
| SQLCA | Area de comunicacion SQL de DB2; el programa lee SQLCODE despues de cada operacion DB2 | Estructura DB2 estandar | EXEC SQL INCLUDE SQLCA | Estandar DB2. En la modernizacion, el manejo de errores SQL debe mapearse al mecanismo de excepciones del nuevo acceso a datos. |

## Data Structure

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| **WS-IDENTIFICACION** | | | | Group: program identification constants | | | Level 01 group | No | Internal |
| WS-NOM-PROGRAMA | Program Name | Alphanumeric | 8 | Literal constant holding the program name 'CHQCONSU' | Yes | 'CHQCONSU' | Used for logging and identification | No | Internal |
| WS-TRANSID | Transaction ID | Alphanumeric | 4 | CICS transaction code 'CH01' used when returning control to CICS | Yes | 'CH01' | Passed in CICS RETURN to keep the pseudo-conversational cycle | Yes | Internal |
| WS-PARRAFO-ACT | Active Paragraph | Alphanumeric | 20 | Name of the paragraph currently executing; used for diagnostics | No | Spaces | Diagnostic field; not displayed to the user | No | Internal |
| **WS-SWITCHES** | | | | Group: runtime control flags | | | Level 01 group | No | Internal |
| WS-RESP | CICS Response Code | Signed numeric (binary) | 8 digits | Holds the CICS response code returned by RECEIVE MAP | No | 0 | Compared after CICS commands to detect errors | Yes | Internal |
| SW-FIN-CURSOR | End-of-Cursor Switch | Alphanumeric | 1 | Flag that signals the DB2 cursor CUR_CHQRA is exhausted or has errored. Value 'S' means finished; 'N' means still open. The 88-level condition FIN-CURSOR is true when value is 'S' | No | 'N' | Controls the FETCH loop in 4000-LISTA-CHEQUERAS | Yes | Internal |
| SW-CUENTA-OK | Account Valid Switch | Alphanumeric | 1 | Flag reserved for account validation. The 88-level condition CUENTA-VALIDA is true when value is 'S'. Not actively set in the current version | No | 'N' | Declared but not used in current logic; may be a legacy artifact | Yes | Internal |
| WS-MSG-FIN | End Message | Alphanumeric | 30 | Fixed text 'FIN DE LA TRANSACCION CH01' displayed when the user exits via PF3 | Yes | 'FIN DE LA TRANSACCION CH01    ' | Sent as plain text before final CICS RETURN with no TRANSID | No | Internal |
| **WS-TRABAJO** | | | | Group: general working fields | | | Level 01 group | No | Internal |
| WS-IND-LINEA | Line Index | Numeric (unsigned) | 1 digit | Counter tracking how many checkbook detail lines have been loaded (0 to 5) | No | 0 | Controls the FETCH loop limit and selects which map line (LIN1O..LIN5O) receives each detail row | Yes | Internal |
| WS-DISP-ED | Display Edit Work Field | Numeric (edited, zero-suppressed) | 5 digits (ZZZZ9) | Temporary editing field used to format integer counts before moving them to the map totals fields. Suppresses leading zeros | No | N/A | Reused for all four total fields (TOTDISO, TOTPAGO, TOTRECO, TOTNOPO) | Yes | Internal |
| WS-ABSTIME | Absolute Time | Signed packed decimal | 15 digits | Receives the raw CICS system time (absolute time in milliseconds since epoch) from ASKTIME | No | N/A | Intermediate value passed immediately to FORMATTIME | No | Internal |
| WS-FECHA-ED | Formatted Date | Alphanumeric | 10 | Current date formatted as DD/MM/YYYY by CICS FORMATTIME | No | N/A | Displayed in map field MFECHAO | Yes | Operational |
| WS-HORA-ED | Formatted Time | Alphanumeric | 8 | Current time formatted as HH:MM:SS by CICS FORMATTIME | No | N/A | Displayed in map field MHORAO | Yes | Operational |
| **WS-LINEA-DET** | | | | Group: single checkbook detail line (74 bytes, matches map column header layout) | | | Level 01 group. Assembled once per FETCH row, then copied to the appropriate LINnO map field | Yes | Internal |
| WL-CHEQUERA | Checkbook Number | Numeric (unsigned) | 9 digits | Checkbook identifier, sourced from HV-NUM-CHEQUERA | Yes | N/A | Leftmost column of the detail line | Yes | Business |
| WL-DESDE | First Check Number | Numeric (unsigned) | 8 digits | First check number in the checkbook range, sourced from HV-NUM-INICIAL | Yes | N/A | Separated from WL-CHEQUERA by one space | Yes | Business |
| WL-HASTA | Last Check Number | Numeric (unsigned) | 8 digits | Last check number in the checkbook range, sourced from HV-NUM-FINAL | Yes | N/A | Separated from WL-DESDE by one space | Yes | Business |
| WL-ESTADO | Checkbook Status Code | Alphanumeric | 2 | Two-character status code of the checkbook, sourced from HV-EST-CHEQUERA | Yes | N/A | Raw code; not translated to a description in the list | Yes | Business |
| WL-EMISION | Issue Date | Alphanumeric | 10 | Checkbook issue date in ISO format (YYYY-MM-DD), sourced from HV-FEC-EMISION | Yes | N/A | Produced by DB2 CHAR(FEC_EMISION, ISO) | Yes | Business |
| WL-GRATIS | Free-of-Charge Indicator | Alphanumeric | 1 | Flag indicating whether the checkbook was issued free of charge, sourced from HV-IND-GRATUITA | Yes | N/A | Single character; business meaning of specific values not defined in this program | Yes | Business |
| WL-DISP | Available Checks (display) | Numeric (edited, zero-suppressed) | 3 digits (ZZ9) | Count of checks with status 'DI' (available) in this checkbook, sourced from HV-DISPONIBLES | Yes | N/A | Right-aligned, leading zeros suppressed | Yes | Business |
| **WS-HOST-VARIABLES** | | | | Group: DB2 host variables used in SQL statements | | | Level 01 group | Yes | Internal |
| HV-CUENTA | Account Number (host) | Alphanumeric | 14 | Account number passed to DB2 queries; loaded from map input field CTACONI | Yes | N/A | Used as the WHERE predicate in both CUR_CHQRA and the totals query | Yes | Business |
| HV-NUM-CHEQUERA | Checkbook Number (host) | Signed packed decimal | 9 digits | Receives NUM_CHEQUERA from CUR_CHQRA FETCH; also used as WHERE key in the per-checkbook COUNT query | Yes | N/A | Packed decimal (COMP-3) | Yes | Business |
| HV-NUM-INICIAL | First Check Number (host) | Signed packed decimal | 8 digits | Receives NUM_INICIAL from CUR_CHQRA FETCH | Yes | N/A | Packed decimal (COMP-3) | Yes | Business |
| HV-NUM-FINAL | Last Check Number (host) | Signed packed decimal | 8 digits | Receives NUM_FINAL from CUR_CHQRA FETCH | Yes | N/A | Packed decimal (COMP-3) | Yes | Business |
| HV-EST-CHEQUERA | Checkbook Status (host) | Alphanumeric | 2 | Receives EST_CHEQUERA from CUR_CHQRA FETCH | Yes | N/A | Raw two-character code from CHQ_CHEQUERA | Yes | Business |
| HV-FEC-EMISION | Issue Date (host) | Alphanumeric | 10 | Receives the formatted issue date from CUR_CHQRA FETCH (produced by CHAR(FEC_EMISION, ISO)) | Yes | N/A | Format YYYY-MM-DD | Yes | Business |
| HV-IND-GRATUITA | Free-of-Charge Indicator (host) | Alphanumeric | 1 | Receives IND_GRATUITA from CUR_CHQRA FETCH | Yes | N/A | Single character flag | Yes | Business |
| HV-DISPONIBLES | Available Checks Count (host) | Signed numeric (binary, COMP) | 9 digits | Receives the COUNT(*) of checks with EST_CHEQUE = 'DI' for one checkbook | Yes | N/A | Binary integer (COMP); result of the scalar SELECT in 4100-ARMA-LINEA | Yes | Business |
| HV-TOT-DISP | Total Available Checks | Signed numeric (binary, COMP) | 9 digits | Receives the total count of checks with EST_CHEQUE = 'DI' across all checkbooks for the account | Yes | N/A | Result of the COALESCE/SUM conditional in 5000-TOTALES | Yes | Business |
| HV-TOT-PAG | Total Paid Checks | Signed numeric (binary, COMP) | 9 digits | Receives the total count of checks with EST_CHEQUE = 'PA' (paid) | Yes | N/A | Result of the COALESCE/SUM conditional in 5000-TOTALES | Yes | Business |
| HV-TOT-REC | Total Rejected Checks | Signed numeric (binary, COMP) | 9 digits | Receives the total count of checks with EST_CHEQUE = 'RE' (rejected/returned) | Yes | N/A | Result of the COALESCE/SUM conditional in 5000-TOTALES | Yes | Business |
| HV-TOT-NOP | Total Non-Payment Checks | Signed numeric (binary, COMP) | 9 digits | Receives the total count of checks with EST_CHEQUE = 'NP' (non-payment) | Yes | N/A | Result of the COALESCE/SUM conditional in 5000-TOTALES | Yes | Business |
| **DFHCOMMAREA** | CICS Communication Area | Alphanumeric | 30 | The CICS communication area received on every non-first invocation. Its content is mapped to CHQ-COMMAREA (defined in CHQMAPW) | Yes | N/A | EIBCALEN = 0 on first entry; > 0 on subsequent entries | Yes | Internal |
| **CHQ-COMMAREA** | Commarea (logical view) | Group | 30 | Logical layout of DFHCOMMAREA, defined in copybook CHQMAPW | Yes | Spaces | Passed back to CICS on every RETURN to preserve state across interactions | Yes | Internal |
| CHQ-CA-ESTADO | Conversation State | Alphanumeric | 1 | Tracks the conversation phase. Space = first entry; 'C' = a query result is currently displayed | No | Space | Set to 'C' after a successful account query | Yes | Internal |
| CHQ-CA-CUENTA | Account Number (commarea) | Alphanumeric | 14 | The account number carried across interactions so it can be redisplayed after a round-trip | No | Spaces | Loaded from HV-CUENTA after a successful query | Yes | Business |
| CHQ-CA-FILLER | Commarea Filler | Alphanumeric | 15 | Unused padding to fill the 30-byte commarea | No | N/A | Reserved for future use | No | Internal |
| **CHQM1I** | Map Input Area | Group | N/A | Symbolic input layout of BMS map CHQM1 from CHQMAP1, defined in copybook CHQMAPW. Each named field below has a length subfield (suffix L, binary signed 4-digit), an attribute subfield (suffix F/A), and a data subfield (suffix I) | Yes | N/A | Produced by CICS RECEIVE MAP into CHQM1I | Yes | Internal |
| CTACONL | Account Number Input Length | Signed numeric (binary) | 4 digits | Number of characters actually keyed by the user in the account number field. Zero means the field was left blank | No | N/A | Checked before processing: if zero or CTACONI = spaces, the program rejects the entry | Yes | Business |
| CTACONI | Account Number Input | Alphanumeric | 14 | Account number as typed by the user on the screen | Yes | N/A | Editable field (UNPROT, IC). Copied to HV-CUENTA for DB2 queries | Yes | Business |
| MFECHAI | Date Input | Alphanumeric | 10 | Date field as received from the map (protected; user cannot modify) | No | N/A | Not used as input; display only | No | Operational |
| MHORAI | Time Input | Alphanumeric | 8 | Time field as received from the map (protected; user cannot modify) | No | N/A | Not used as input; display only | No | Operational |
| MENSAI | Message Input | Alphanumeric | 79 | Message line as received from the map (protected; user cannot modify) | No | N/A | Not used as input; display only | No | Operational |
| **CHQM1O** | Map Output Area | Group | N/A | Symbolic output layout of BMS map CHQM1; REDEFINES CHQM1I. Each output field has only a data subfield (suffix O). Written by the program and sent to the terminal via CICS SEND MAP | Yes | N/A | Initialized to LOW-VALUES before each send to clear the screen | Yes | Internal |
| MFECHAO | Date Output | Alphanumeric | 10 | Current date (DD/MM/YYYY) displayed in the map header | No | N/A | Loaded from WS-FECHA-ED | Yes | Operational |
| MHORAO | Time Output | Alphanumeric | 8 | Current time (HH:MM:SS) displayed in the map header | No | N/A | Loaded from WS-HORA-ED | Yes | Operational |
| CTACONO | Account Number Output | Alphanumeric | 14 | Account number echoed back to the screen after input | No | N/A | Copied from CTACONI so the user sees the value they entered | Yes | Business |
| NOMTITO | Account Holder Name Output | Alphanumeric | 40 | Full name of the account holder, sourced from SDC-MAE-TIT-NOMBRE | No | N/A | Displayed in the TITULAR row of the map | Yes | Business |
| ESTCTAO | Account Status Output | Alphanumeric | 15 | Translated description of the account status (e.g., 'ACTIVA', 'BLOQUEADA', 'CERRADA') | No | N/A | Derived by 3100-DESCRIBE-ESTADO from SDC-MAE-CTA-ESTADO | Yes | Business |
| MONCTAO | Currency Code Output | Alphanumeric | 3 | ISO numeric currency code of the account (e.g., '604' for Soles, '840' for Dollars), sourced from SDC-MAE-CTA-MONEDA | No | N/A | Displayed alongside the account status | Yes | Business |
| LIN1O | Checkbook Detail Line 1 Output | Alphanumeric | 74 | First (most recent) checkbook detail line. Contains: checkbook number (9), space, first check (8), space, last check (8), space, status (2), space, issue date (10), space, free indicator (1), space, available count (3), trailing spaces (27) | No | N/A | Filled only when at least 1 checkbook is found | Yes | Business |
| LIN2O | Checkbook Detail Line 2 Output | Alphanumeric | 74 | Second checkbook detail line; same layout as LIN1O | No | N/A | Filled only when at least 2 checkbooks are found | Yes | Business |
| LIN3O | Checkbook Detail Line 3 Output | Alphanumeric | 74 | Third checkbook detail line; same layout as LIN1O | No | N/A | Filled only when at least 3 checkbooks are found | Yes | Business |
| LIN4O | Checkbook Detail Line 4 Output | Alphanumeric | 74 | Fourth checkbook detail line; same layout as LIN1O | No | N/A | Filled only when at least 4 checkbooks are found | Yes | Business |
| LIN5O | Checkbook Detail Line 5 Output | Alphanumeric | 74 | Fifth checkbook detail line; same layout as LIN1O | No | N/A | Filled only when 5 checkbooks are found | Yes | Business |
| TOTDISO | Total Available Checks Output | Alphanumeric (edited) | 5 | Count of checks with status 'DI' (available) across all checkbooks of the account, formatted with leading zero suppression | No | N/A | Sourced from HV-TOT-DISP via WS-DISP-ED | Yes | Business |
| TOTPAGO | Total Paid Checks Output | Alphanumeric (edited) | 5 | Count of checks with status 'PA' (paid), formatted with leading zero suppression | No | N/A | Sourced from HV-TOT-PAG via WS-DISP-ED | Yes | Business |
| TOTRECO | Total Rejected Checks Output | Alphanumeric (edited) | 5 | Count of checks with status 'RE' (rejected/returned), formatted with leading zero suppression | No | N/A | Sourced from HV-TOT-REC via WS-DISP-ED | Yes | Business |
| TOTNOPO | Total Non-Payment Checks Output | Alphanumeric (edited) | 5 | Count of checks with status 'NP' (non-payment), formatted with leading zero suppression | No | N/A | Sourced from HV-TOT-NOP via WS-DISP-ED | Yes | Business |
| MENSAO | Message Output | Alphanumeric | 79 | Operator message line at the bottom of the screen. Displays instructions, errors, or status messages | No | N/A | Displayed in red with blinking highlight per BMS definition | Yes | Operational |
| **SDC-AREA-MAESTRO** | Master Account Communication Area | Group | N/A | Complete parameter block passed to and from the SDCMAEST subroutine. Defined in copybook SDCMAEW. All subfields below belong to this group | Yes | N/A | CHQCONSU uses only function 'LE' (read). The remaining functions ('AC', 'BL', 'CR') exist in SDCMAEST but are not invoked by this program | Yes | Internal |
| SDC-MAE-FUNCION | Function Code | Alphanumeric | 2 | Instruction to SDCMAEST. CHQCONSU always sets this to 'LE' (read without lock). Other valid values: 'AC' (update balances), 'BL' (block), 'CR' (create) | Yes | N/A | Must be set before every CALL to SDCMAEST | Yes | Business |
| SDC-MAE-COD-RETORNO | Return Code | Alphanumeric | 2 | Result code returned by SDCMAEST. '00' = success (SDU-RC-OK); '08' = not found (SDU-RC-NO-ENCONTRADO); '90' = DB2 error (SDU-RC-ERROR-BD). See SDUCONST for full list | Yes | N/A | CHQCONSU checks this immediately after the CALL; any value other than '00' causes an error message and aborts the query | Yes | Business |
| SDC-MAE-MENSAJE | Return Message | Alphanumeric | 60 | Descriptive message set by SDCMAEST explaining the return code | No | Spaces | Not displayed directly to the user by CHQCONSU | Yes | Operational |
| SDC-MAE-SQLCODE | SQL Code from SDCMAEST | Signed numeric (binary) | 9 digits | DB2 SQLCODE captured inside SDCMAEST when a database error occurs | No | 0 | Useful for diagnosing DB2 failures; not displayed by CHQCONSU | Yes | Internal |
| SDC-MAE-CTA-NUMERO | Account Number | Alphanumeric | 14 | Account number sent to SDCMAEST as the lookup key | Yes | N/A | Loaded from HV-CUENTA before the CALL | Yes | Business |
| SDC-MAE-CTA-PRODUCTO | Product Code | Alphanumeric | 2 | Product code returned by SDCMAEST. CHQCONSU validates that this equals SDU-PROD-CORRIENTE ('06'). If not, the query is rejected with the message 'LA CUENTA NO ES CUENTA CORRIENTE' | Yes | N/A | '01'=Savings, '02'=Savings-Plus, '03'=CTS, '04'=Payroll, '05'=Term, '06'=Current, '07'=Digital (from SDUCONST) | Yes | Business |
| SDC-MAE-CTA-MONEDA | Currency Code | Alphanumeric | 3 | ISO numeric currency code returned by SDCMAEST and displayed in MONCTAO | No | N/A | '604'=Soles, '840'=Dollars, '978'=Euros (from SDUCONST) | Yes | Business |
| SDC-MAE-CTA-ESTADO | Account Status Code | Alphanumeric | 2 | Two-character status code returned by SDCMAEST. Used by 3100-DESCRIBE-ESTADO to derive the display description | No | N/A | 'AC'=Active, 'BL'=Blocked, 'BJ'=Judicial Block, 'CE'=Closed, 'IN'=Inactive (from SDUCONST) | Yes | Business |
| SDC-MAE-CTA-SUB-ESTADO | Account Sub-Status | Alphanumeric | 2 | Secondary status code; returned by SDCMAEST but not used by CHQCONSU | No | N/A | Available for future use | No | Business |
| SDC-MAE-CTA-TIPO-TENENCIA | Ownership Type | Alphanumeric | 1 | Type of account ownership; returned by SDCMAEST but not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-CTA-CENTRO-COSTO | Cost Center | Alphanumeric | 6 | Cost center code; returned by SDCMAEST but not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-TIT-CODIGO-UNICO | Holder Unique Code | Alphanumeric | 10 | Unique customer identifier; returned by SDCMAEST but not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-TIT-TIPO-DOI | Holder ID Type | Alphanumeric | 1 | Type of identity document. '1'=DNI, '4'=Foreign Card, '6'=RUC, '7'=Passport, '9'=Birth Certificate (from SDUCONST) | No | N/A | Returned by SDCMAEST but not used by CHQCONSU | No | Business |
| SDC-MAE-TIT-NUM-DOI | Holder ID Number | Alphanumeric | 12 | Identity document number; returned by SDCMAEST but not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-TIT-NOMBRE | Holder Name | Alphanumeric | 60 | Full name of the account holder returned by SDCMAEST. Copied to map field NOMTITO | Yes | N/A | Displayed in the TITULAR row | Yes | Business |
| SDC-MAE-TIT-APE-PATERNO | Holder Paternal Surname | Alphanumeric | 30 | Paternal surname; returned by SDCMAEST but not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-TIT-APE-MATERNO | Holder Maternal Surname | Alphanumeric | 30 | Maternal surname; returned by SDCMAEST but not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-TIT-FEC-NACIMIENTO | Holder Date of Birth | Alphanumeric | 8 | Date of birth (YYYYMMDD); returned but not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-TIT-DIRECCION | Holder Address | Alphanumeric | 80 | Postal address; returned but not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-TIT-TELEFONO | Holder Phone | Alphanumeric | 15 | Phone number; returned but not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-TIT-CELULAR | Holder Mobile | Alphanumeric | 15 | Mobile number; returned but not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-TIT-CORREO | Holder Email | Alphanumeric | 50 | Email address; returned but not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-SAL-CONTABLE | Book Balance | Signed packed decimal | 13 integer + 2 decimal digits | Accounting balance returned by SDCMAEST; not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-SAL-DISPONIBLE | Available Balance | Signed packed decimal | 13 integer + 2 decimal digits | Available balance; not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-SAL-RETENIDO | Retained Balance | Signed packed decimal | 13 integer + 2 decimal digits | Retained/held balance; not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-SAL-INTANGIBLE | Intangible Balance | Signed packed decimal | 13 integer + 2 decimal digits | Intangible/non-disposable balance; not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-INT-DEVENGADO | Accrued Interest | Signed packed decimal | 11 integer + 4 decimal digits | Accrued interest; not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-INT-CAPITALIZADO | Capitalized Interest | Signed packed decimal | 11 integer + 2 decimal digits | Capitalized interest; not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-INT-TEA-VIGENTE | Current Annual Rate (TEA) | Signed packed decimal | 3 integer + 4 decimal digits | Current effective annual interest rate; not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-FEC-APERTURA | Opening Date | Alphanumeric | 8 | Account opening date (YYYYMMDD); not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-FEC-ULT-MOVIM | Last Movement Date | Alphanumeric | 8 | Date of the last transaction (YYYYMMDD); not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-FEC-ULT-CAPIT | Last Capitalization Date | Alphanumeric | 8 | Not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-FEC-CIERRE | Closing Date | Alphanumeric | 8 | Not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-FEC-ULT-BLOQUEO | Last Block Date | Alphanumeric | 8 | Not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-AUD-USUARIO | Audit User | Alphanumeric | 8 | User ID of the operator; not populated by CHQCONSU (read-only program) | No | N/A | Required by SDCMAEST for write functions only | No | Internal |
| SDC-MAE-AUD-TERMINAL | Audit Terminal | Alphanumeric | 8 | Terminal ID; not populated by CHQCONSU | No | N/A | Required by SDCMAEST for write functions only | No | Internal |
| SDC-MAE-AUD-CANAL | Audit Channel | Alphanumeric | 2 | Channel code (e.g., 'VE'=Teller, 'BA'=Batch); not populated by CHQCONSU | No | N/A | Required by SDCMAEST for write functions only | No | Internal |
| SDC-MAE-AUD-PROGRAMA | Audit Program | Alphanumeric | 8 | Calling program name for audit trail; not populated by CHQCONSU | No | N/A | Required by SDCMAEST for write functions only | No | Internal |
| SDC-MAE-IND-EXONERA-ITF | ITF Exemption Indicator | Alphanumeric | 1 | ITF tax exemption flag; not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-IND-TIENE-RETENCION | Has Retention Indicator | Alphanumeric | 1 | Indicates whether the account has a retention; not used by CHQCONSU | No | N/A | Not displayed | No | Business |
| SDC-MAE-IMP-CARGO | Debit Amount | Signed packed decimal | 13 integer + 2 decimal digits | Amount to debit; input for function 'AC' only. Not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-IMP-ABONO | Credit Amount | Signed packed decimal | 13 integer + 2 decimal digits | Amount to credit; input for function 'AC' only. Not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-IMP-DEVENGO | Accrual Amount | Signed packed decimal | 11 integer + 4 decimal digits | Accrual to apply; input for function 'AC' only. Not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-NUEVO-ESTADO | New Status Code | Alphanumeric | 2 | Target status for function 'BL'; not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-MOTIVO-BLOQUEO | Block Reason Code | Alphanumeric | 4 | Reason for blocking; not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-CTS-RUC-EMPLEADOR | CTS Employer RUC | Alphanumeric | 11 | Employer tax ID for CTS product; not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-CTS-RAZON-EMPLEAD | CTS Employer Name | Alphanumeric | 40 | Employer business name for CTS product; not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-CTS-SUELDO-BRUTO | CTS Gross Salary | Signed packed decimal | 9 integer + 2 decimal digits | Gross salary for CTS product; not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-CTS-MTO-INTANGIBLE | CTS Intangible Amount | Signed packed decimal | 11 integer + 2 decimal digits | Not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-CTS-MTO-DISPONIBLE | CTS Available Amount | Signed packed decimal | 11 integer + 2 decimal digits | Not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-CTS-FEC-INGRESO | CTS Hire Date | Alphanumeric | 8 | Not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-CTS-IND-CESADO | CTS Terminated Indicator | Alphanumeric | 1 | Not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-SUE-RUC-EMPLEADOR | Payroll Employer RUC | Alphanumeric | 11 | Not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-SUE-HABER-BRUTO | Payroll Gross Salary | Signed packed decimal | 9 integer + 2 decimal digits | Not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-SUE-MTO-INEMBARG | Payroll Non-Attachable Amount | Signed packed decimal | 9 integer + 2 decimal digits | Not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-DIG-NIVEL-KYC | Digital Account KYC Level | Alphanumeric | 1 | KYC compliance level for digital account product; not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-DIG-TOPE-SALDO | Digital Account Balance Ceiling | Signed packed decimal | 9 integer + 2 decimal digits | Not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-DIG-TOPE-OPER-MES | Digital Account Monthly Transaction Ceiling | Signed packed decimal | 9 integer + 2 decimal digits | Not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |
| SDC-MAE-DIG-ACUM-OPER-MES | Digital Account Monthly Transaction Accumulator | Signed packed decimal | 9 integer + 2 decimal digits | Not used by CHQCONSU | No | N/A | Not relevant for this program | No | Business |

**DB2 Tables Referenced**

The following table summarizes the two DB2 tables read by this program. Neither is modified.

| Table Name | Column Name | Data Type | Description | Used In |
|------------|-------------|-----------|-------------|---------|
| CHQ_CHEQUERA | CTA_NUMERO | Character (14) | Account number; WHERE filter in CUR_CHQRA | 4000-LISTA-CHEQUERAS |
| CHQ_CHEQUERA | NUM_CHEQUERA | Numeric | Checkbook identifier; ORDER BY DESC, FETCH FIRST 5 ROWS | 4000-LISTA-CHEQUERAS |
| CHQ_CHEQUERA | NUM_INICIAL | Numeric | First check number in the range | 4000-LISTA-CHEQUERAS |
| CHQ_CHEQUERA | NUM_FINAL | Numeric | Last check number in the range | 4000-LISTA-CHEQUERAS |
| CHQ_CHEQUERA | EST_CHEQUERA | Character (2) | Status code of the checkbook | 4000-LISTA-CHEQUERAS |
| CHQ_CHEQUERA | FEC_EMISION | Date | Issue date; retrieved as CHAR(FEC_EMISION, ISO) producing YYYY-MM-DD | 4000-LISTA-CHEQUERAS |
| CHQ_CHEQUERA | IND_GRATUITA | Character (1) | Free-of-charge indicator | 4000-LISTA-CHEQUERAS |
| CHQ_CHEQUE | NUM_CHEQUERA | Numeric | Foreign key to CHQ_CHEQUERA; WHERE filter in per-checkbook COUNT | 4100-ARMA-LINEA |
| CHQ_CHEQUE | EST_CHEQUE | Character (2) | Check status. Values used: 'DI'=Available, 'PA'=Paid, 'RE'=Rejected, 'NP'=Non-Payment | 4100-ARMA-LINEA, 5000-TOTALES |
| CHQ_CHEQUE | CTA_NUMERO | Character (14) | Account number; WHERE filter in the totals query | 5000-TOTALES |
| CUENTA_MAESTRO | NUM_CUENTA | Character (14) | Account number; primary key lookup in SDCMAEST | 3000-CONSULTA (via SDCMAEST) |
| CUENTA_MAESTRO | COD_PRODUCTO | Character (2) | Product code; validated to be '06' (current account) | 3000-CONSULTA (via SDCMAEST) |
| CUENTA_MAESTRO | COD_MONEDA | Character (3) | Currency code; displayed in MONCTAO | 3000-CONSULTA (via SDCMAEST) |
| CUENTA_MAESTRO | ESTADO | Character (2) | Account status code; translated to a description by 3100-DESCRIBE-ESTADO | 3000-CONSULTA (via SDCMAEST) |
| CUENTA_MAESTRO | NOMBRE | Character (60) | Account holder name; displayed in NOMTITO | 3000-CONSULTA (via SDCMAEST) |

## Detailed Rules

<!-- rule-start -->
### 1. Regla / Operacion - 0000-PRINCIPAL (Punto de entrada y control del flujo)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para Modernizacion

**Algoritmo**

El programa comienza su ejecución siempre por este bloque. Su única responsabilidad es decidir si la pantalla se está abriendo por primera vez o si el usuario ya la había visto antes y acaba de responder a ella.

Para tomar esa decisión, el programa examina el valor del campo del sistema llamado EIBCALEN, que contiene la longitud del área de comunicación (COMMAREA) que el sistema CICS pasó al programa al invocarlo.

1. Verificar si la longitud de la COMMAREA entrante (EIBCALEN) es igual a cero.
2. Si EIBCALEN es igual a cero, significa que no había datos previos: es la primera vez que el usuario accede a la transacción. En ese caso se ejecuta el bloque **1000-PRIMERA-ENTRADA**.
3. Si EIBCALEN es distinto de cero, significa que existe una COMMAREA con datos de la interacción anterior. En ese caso, el contenido completo de DFHCOMMAREA (área de comunicación de 30 bytes recibida del sistema CICS) se copia íntegramente al campo interno CHQ-COMMAREA, y a continuación se ejecuta el bloque **2000-PROCESA-ENTRADA**.
4. Independientemente de cuál de los dos caminos se tome, al finalizar siempre se ejecuta el bloque **8000-RETORNA**, el cual devuelve el control a CICS indicando que la próxima pulsación de tecla del usuario debe volver a invocar la misma transacción (identificada con el código **CH01**), pasando como COMMAREA el campo CHQ-COMMAREA con una longitud de **30 bytes**.

> **Nota sobre CHQ-COMMAREA:** este campo de 30 bytes está definido en el copybook CHQMAPW y se compone de tres subcampos: CHQ-CA-ESTADO (1 byte, donde el valor en blanco indica primera entrada y el valor **'C'** indica que ya se mostró una consulta), CHQ-CA-CUENTA (14 bytes, número de cuenta de la última consulta realizada) y CHQ-CA-FILLER (15 bytes de relleno). Su contenido es establecido por el bloque **3000-CONSULTA** al completar una consulta exitosa, y es limpiado a espacios por el bloque **1000-PRIMERA-ENTRADA**.
<!-- rule-end -->

<!-- rule-start -->
### 2. Regla / Operacion - 1000-PRIMERA-ENTRADA (Inicializacion de la pantalla en blanco)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para Modernizacion

**Algoritmo**

1. Limpiar completamente el area de salida del mapa escribiendo el valor LOW-VALUES (el valor binario más bajo posible, equivalente a "todo en cero binario") en todos los campos del área de salida del mapa (CHQM1O). Esto borra cualquier dato residual en la pantalla.
2. Limpiar el área de comunicación entre ciclos de la transacción (CHQ-COMMAREA) escribiendo espacios en blanco en todos sus campos. Esta área tiene una longitud de 30 bytes y contiene: el campo de estado de la transacción (CHQ-CA-ESTADO, 1 byte), el número de cuenta de la última consulta realizada (CHQ-CA-CUENTA, 14 bytes) y un campo de relleno (CHQ-CA-FILLER, 15 bytes).
3. Ejecutar el bloque 6000-FECHA-HORA para obtener la fecha y hora actuales del sistema mediante CICS (instrucción ASKTIME), formatear la fecha en formato DD/MM/YYYY (campo MFECHAO, 10 caracteres) y la hora en formato HH:MM:SS (campo MHORAO, 8 caracteres), y escribir ambos valores en los campos correspondientes del mapa de salida.
4. Escribir el texto exacto `'DIGITE EL NUMERO DE CUENTA CORRIENTE Y PRESIONE ENTER'` en el campo de mensaje de la pantalla (MENSAO), que tiene una longitud de 79 caracteres y se muestra en la línea 24 del mapa.
5. Ejecutar el bloque 7000-ENVIA-MAPA, que envía el mapa CHQM1 del mapset CHQMAP1 al terminal del usuario utilizando el área de salida CHQM1O, con las opciones ERASE (borra la pantalla antes de escribir) y CURSOR (posiciona el cursor según lo definido en el mapa BMS, es decir, en el campo de entrada del número de cuenta CTACON).

> **Nota de contexto:** Este bloque es invocado en dos situaciones distintas: (a) cuando es la primera entrada a la transacción, es decir, cuando la longitud del área de comunicación EIBCALEN es igual a cero, y (b) cuando el usuario presiona la tecla PF5 durante una sesión ya iniciada, lo que provoca que la pantalla se limpie y se reinicie como si fuera la primera vez.
<!-- rule-end -->

<!-- rule-start -->
### 3. Regla / Operacion - 2000-PROCESA-ENTRADA (Recepcion de la pantalla y despacho segun tecla)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para Modernizacion

**Algoritmo**

Este bloque recibe los datos que el usuario escribió en la pantalla y decide qué acción tomar según la tecla de función que el usuario presionó.

El programa primero solicita al sistema CICS que lea el mapa CHQM1 del mapset CHQMAP1 y deposite los datos recibidos en el área de entrada CHQM1I. El resultado de esa operación se almacena en WS-RESP, aunque este campo no se evalúa posteriormente en este bloque.

A continuación se examina el identificador de la tecla presionada (EIBAID) y se actúa de la siguiente manera:

- Si el usuario presionó PF3: se ejecuta 8900-TERMINA, que cierra la transacción completamente.
- Si el usuario presionó PF5: se ejecuta 1000-PRIMERA-ENTRADA, que limpia la pantalla y vuelve al estado inicial.
- Si el usuario presionó ENTER: se ejecuta la secuencia 3000-CONSULTA hasta 3000-EXIT, que realiza la consulta de chequeras.
- Si el usuario presionó cualquier otra tecla: se limpia el área de salida CHQM1O con LOW-VALUES, se conserva en la pantalla el número de cuenta que el usuario había escrito (copiando CTACONI a CTACONO), se escribe el mensaje `'TECLA NO VALIDA. USE ENTER, PF3 O PF5'` en el campo MENSAO, y se envía la pantalla de vuelta al usuario mediante 7000-ENVIA-MAPA.

1. Invocar la lectura del mapa CHQM1 del mapset CHQMAP1 hacia el área CHQM1I. Guardar el código de respuesta en WS-RESP (este valor no se usa después en este bloque).
2. Evaluar el valor de EIBAID (identificador de la tecla presionada):
   - Caso DFHPF3 (tecla PF3): ejecutar 8900-TERMINA.
   - Caso DFHPF5 (tecla PF5): ejecutar 1000-PRIMERA-ENTRADA.
   - Caso DFHENTER (tecla ENTER): ejecutar 3000-CONSULTA hasta 3000-EXIT.
   - Cualquier otro valor (cláusula WHEN OTHER): limpiar CHQM1O con LOW-VALUES; copiar el campo CTACONI (número de cuenta ingresado por el usuario, 14 caracteres) al campo de salida CTACONO; escribir el mensaje literal `'TECLA NO VALIDA. USE ENTER, PF3 O PF5'` en MENSAO; ejecutar 7000-ENVIA-MAPA.
3. Nótese que el bloque no contempla las teclas PF1, PF2, PF4, PF6 a PF12 ni ninguna otra tecla de atención de forma individual: todas ellas caen en el caso WHEN OTHER y producen el mismo mensaje de tecla no válida. En particular, la tecla PF12 que en versiones anteriores del programa enlazaba al menú principal ya no tiene tratamiento especial desde enero de 2023, cuando dicho enlace fue eliminado; cualquier pulsación de PF12 es tratada como tecla no válida.
<!-- rule-end -->

<!-- rule-start -->
### 4. Regla / Operacion - 3000-CONSULTA (Orquestacion principal de la consulta de chequeras)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para Modernizacion

**Algoritmo**

1. Limpiar el area de salida del mapa escribiendo LOW-VALUES en todos los campos de CHQM1O.
2. Copiar el numero de cuenta ingresado por el usuario (campo CTACONI, 14 caracteres) al campo de salida CTACONO, para que la pantalla lo siga mostrando tras cualquier error.
3. Ejecutar el bloque 6000-FECHA-HORA para obtener la fecha y hora actuales del sistema mediante CICS ASKTIME y CICS FORMATTIME, y escribirlas en los campos de pantalla MFECHAO (fecha en formato DD/MM/YYYY, 10 caracteres) y MHORAO (hora en formato HH:MM:SS, 8 caracteres).
4. Validar que el usuario haya ingresado un numero de cuenta: si el campo CTACONL (longitud del dato ingresado por el usuario, campo binario del mapa de entrada CHQM1I) es igual a cero, **O** si el campo CTACONI contiene solo espacios, entonces escribir el mensaje 'DEBE INGRESAR EL NUMERO DE CUENTA' en el campo de pantalla MENSAO, ejecutar el bloque 7000-ENVIA-MAPA para enviar la pantalla y saltar inmediatamente al punto de salida 3000-EXIT, sin continuar con ningun paso posterior.
5. Si la validacion fue exitosa, copiar CTACONI al campo HV-CUENTA (variable de host DB2, 14 caracteres, que se usara tanto para la llamada a SDCMAEST como para las consultas SQL posteriores a las tablas CHQ_CHEQUERA y CHQ_CHEQUE).
6. Preparar la llamada al subprograma SDCMAEST con los siguientes valores en el area de comunicacion SDC-AREA-MAESTRO:
   - Escribir el codigo de funcion 'LE' (lectura sin bloqueo) en el campo SDC-MAE-FUNCION.
   - Copiar HV-CUENTA al campo SDC-MAE-CTA-NUMERO.
   - Escribir espacios en SDC-MAE-COD-RETORNO para limpiar cualquier resultado de una llamada anterior.
7. Llamar al subprograma SDCMAEST pasando el area SDC-AREA-MAESTRO como unico parametro. SDCMAEST realizara una lectura directa (SELECT sin bloqueo) sobre la tabla DB2 CUENTA_MAESTRO filtrando por NUM_CUENTA igual al numero de cuenta proporcionado, y devolvera todos los datos del titular y de la cuenta en los campos del area SDC-AREA-MAESTRO.
8. Verificar el codigo de retorno en el campo SDC-MAE-COD-RETORNO. Si es distinto del valor SDU-RC-OK (constante con valor '00' definida en SDUCONST), entonces escribir el mensaje 'CUENTA NO EXISTE' en el campo MENSAO, ejecutar 7000-ENVIA-MAPA y saltar a 3000-EXIT. Este caso cubre tanto la cuenta no encontrada (SQLCODE +100 en SDCMAEST, que devuelve SDU-RC-NO-ENCONTRADO = '08') como cualquier error de base de datos (que devuelve SDU-RC-ERROR-BD = '90').
9. Si la cuenta existe (SDC-MAE-COD-RETORNO = '00'), verificar que el campo SDC-MAE-CTA-PRODUCTO sea igual a SDU-PROD-CORRIENTE (constante con valor '06' definida en SDUCONST, correspondiente al producto Cuenta Corriente). Si SDC-MAE-CTA-PRODUCTO **no** es igual a '06', escribir el mensaje 'LA CUENTA NO ES CUENTA CORRIENTE' en MENSAO, ejecutar 7000-ENVIA-MAPA y saltar a 3000-EXIT. Cualquier otro codigo de producto ('01' Ahorro, '02' Ahorro Gana, '03' CTS, '04' Sueldo, '05' Plazo Fijo, '07' Digital, '08' Ahorro Programado) sera rechazado con este mensaje.
10. Si la cuenta es de producto corriente ('06'), continuar con la siguiente secuencia de acciones en el orden exacto indicado:
    - Copiar el campo SDC-MAE-TIT-NOMBRE (nombre del titular, 60 caracteres) al campo de pantalla NOMTITO.
    - Ejecutar el bloque 3100-DESCRIBE-ESTADO, que traduce el codigo de dos caracteres del campo SDC-MAE-CTA-ESTADO a un texto descriptivo y lo escribe en el campo de pantalla ESTCTAO (15 caracteres), segun la siguiente tabla exhaustiva de valores:
      - 'AC' → 'ACTIVA'
      - 'BL' → 'BLOQUEADA'
      - 'BJ' → 'BLOQ. JUDICIAL'
      - 'CE' → 'CERRADA'
      - 'IN' → 'INACTIVA'
      - Cualquier otro valor → se copia el propio codigo de estado tal cual desde SDC-MAE-CTA-ESTADO hacia ESTCTAO.
    - Copiar el campo SDC-MAE-CTA-MONEDA (codigo de moneda ISO, 3 caracteres; por ejemplo '604' para Soles, '840' para Dolares, '978' para Euros segun SDUCONST) al campo de pantalla MONCTAO.
    - Ejecutar el bloque 4000-LISTA-CHEQUERAS para consultar la tabla CHQ_CHEQUERA mediante el cursor CUR_CHQRA, obtener hasta 5 chequeras y mostrarlas en los campos de pantalla LIN1O a LIN5O.
    - Ejecutar el bloque 5000-TOTALES para consultar la tabla CHQ_CHEQUE y obtener los conteos de cheques por estado, mostrando los resultados en los campos de pantalla TOTDISO, TOTPAGO, TOTRECO y TOTNOPO.
    - Escribir el valor 'C' en el campo CHQ-CA-ESTADO de la COMMAREA (indicando que se ha completado y mostrado una consulta, en contraposicion al valor espacio que indica primera entrada).
    - Copiar HV-CUENTA al campo CHQ-CA-CUENTA de la COMMAREA (14 caracteres), para preservar el numero de cuenta consultado entre ciclos pseudo-conversacionales.
    - Ejecutar el bloque 7000-ENVIA-MAPA, que emite el mapa CHQM1 del mapset CHQMAP1 mediante CICS SEND MAP con las opciones ERASE y CURSOR, enviando la pantalla completa con todos los datos al terminal del usuario.
11. El punto 3000-EXIT es unicamente el punto de salida del bloque mediante una instruccion EXIT; no realiza ninguna accion por si mismo. Todos los caminos de error de los pasos 4, 8 y 9 terminan saltando a este punto tras enviar la pantalla con el mensaje de error correspondiente.
<!-- rule-end -->

<!-- rule-start -->
### 5. Regla / Operacion - 3100-DESCRIBE-ESTADO (Traduccion del codigo de estado de cuenta a texto)
<!-- reviewed -->

_Reviewed_

Este bloque convierte el código de dos letras que representa el estado de la cuenta corriente en un texto descriptivo legible para el usuario, y lo coloca en el campo de pantalla `ESTCTAO` (15 caracteres).

**Estado de la regla:** Relevante para Modernización

**Algoritmo**

Evaluar el valor del campo `SDC-MAE-CTA-ESTADO` (obtenido de la subrutina `SDCMAEST` tras la lectura exitosa de la tabla `CUENTA_MAESTRO`) y asignar el texto correspondiente al campo de salida del mapa `ESTCTAO` según la siguiente tabla:

| Código | Texto a mostrar en `ESTCTAO` |
|--------|------------------------------|
| `AC`   | `ACTIVA`                     |
| `BL`   | `BLOQUEADA`                  |
| `BJ`   | `BLOQ. JUDICIAL`             |
| `CE`   | `CERRADA`                    |
| `IN`   | `INACTIVA`                   |
| Cualquier otro valor | Copiar el propio valor del código directamente a `ESTCTAO`, sin transformación |

Si el código no coincide con ninguno de los cinco valores listados, se traslada el contenido íntegro de `SDC-MAE-CTA-ESTADO` al campo `ESTCTAO` tal como viene del maestro.

Este procesamiento se ejecuta siempre que la consulta de la cuenta sea exitosa, es decir, únicamente cuando `SDCMAEST` retorna código de retorno `SDU-RC-OK` (`'00'`) **y** el producto de la cuenta es igual a `SDU-PROD-CORRIENTE` (`'06'`). Si cualquiera de esas dos condiciones previas falla, este bloque no se invoca y la transacción muestra un mensaje de error al usuario sin llegar a poblar `ESTCTAO`.

La traducción del estado se realiza dentro del flujo del párrafo `3000-CONSULTA`, inmediatamente después de mover el nombre del titular (`SDC-MAE-TIT-NOMBRE`) al campo de pantalla `NOMTITO`, y antes de poblar el campo de moneda (`SDC-MAE-CTA-MONEDA` → `MONCTAO`), listar las chequeras y calcular los totales por estado de cheque.
<!-- rule-end -->

<!-- rule-start -->
### 6. Regla / Operacion - 4000-LISTA-CHEQUERAS (Obtencion y presentacion de las 5 chequeras mas recientes)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para Modernizacion

**Algoritmo**

La consulta a la tabla DB2 `CHQ_CHEQUERA` se realiza mediante el cursor `CUR_CHQRA`, declarado en la sección de datos del programa. Ese cursor selecciona los campos `NUM_CHEQUERA`, `NUM_INICIAL`, `NUM_FINAL`, `EST_CHEQUERA`, la fecha de emisión formateada en ISO mediante la función `CHAR(FEC_EMISION, ISO)`, e `IND_GRATUITA`, todos de la tabla `CHQ_CHEQUERA` con alias `C`, filtrando por `CTA_NUMERO` igual al valor de la variable de host `HV-CUENTA`, ordenando por `NUM_CHEQUERA` de forma descendente, y limitando el resultado a un máximo de 5 filas mediante `FETCH FIRST 5 ROWS ONLY`.

1. Poner a cero el contador de líneas `WS-IND-LINEA`.
2. Poner el indicador de fin de cursor `SW-FIN-CURSOR` en `'N'` (no finalizado).
3. Abrir el cursor `CUR_CHQRA`.
4. Si el código de resultado SQL (`SQLCODE`) al abrir el cursor es distinto de cero, escribir el mensaje `'ERROR DB2 AL CONSULTAR CHEQUERAS'` en el campo de pantalla `MENSAO` y poner `SW-FIN-CURSOR` en `'S'` para no intentar leer ninguna fila.
5. Repetir el siguiente ciclo mientras `SW-FIN-CURSOR` sea `'N'` **y** el contador `WS-IND-LINEA` sea menor que 5 (condición de parada: `FIN-CURSOR` activado, es decir `SW-FIN-CURSOR = 'S'`, **o** `WS-IND-LINEA >= 5`):
   - a. Leer la siguiente fila del cursor `CUR_CHQRA`, depositando los valores recuperados en las variables de host: `HV-NUM-CHEQUERA`, `HV-NUM-INICIAL`, `HV-NUM-FINAL`, `HV-EST-CHEQUERA`, `HV-FEC-EMISION`, `HV-IND-GRATUITA`.
   - b. Si `SQLCODE` es igual a 0 (lectura exitosa): sumar 1 a `WS-IND-LINEA` y ejecutar el bloque **4100-ARMA-LINEA** descrito a continuación.
   - c. Si `SQLCODE` es distinto de 0 (fin de datos u otro error): poner `SW-FIN-CURSOR` en `'S'` para terminar el ciclo.
6. Cerrar el cursor `CUR_CHQRA`.
7. Si `WS-IND-LINEA` sigue siendo cero (no se leyó ninguna fila), escribir el mensaje `'LA CUENTA NO TIENE CHEQUERAS'` en el campo de pantalla `MENSAO`.

**Bloque 4100-ARMA-LINEA** (ejecutado una vez por cada fila leída del cursor):

- a. Realizar una consulta SQL directa (SELECT escalar) a la tabla `CHQ_CHEQUE` para contar cuántos cheques de la chequera actual tienen estado `'DI'` (disponible). El filtro aplica dos condiciones: `NUM_CHEQUERA` igual a `HV-NUM-CHEQUERA` **y** `EST_CHEQUE` igual a `'DI'`. El resultado se deposita en la variable de host `HV-DISPONIBLES`.
- b. Construir la línea de detalle `WS-LINEA-DET` transfiriendo los siguientes valores a sus respectivos subcampos:
  - `HV-NUM-CHEQUERA` → `WL-CHEQUERA`
  - `HV-NUM-INICIAL` → `WL-DESDE`
  - `HV-NUM-FINAL` → `WL-HASTA`
  - `HV-EST-CHEQUERA` → `WL-ESTADO`
  - `HV-FEC-EMISION` → `WL-EMISION`
  - `HV-IND-GRATUITA` → `WL-GRATIS`
  - `HV-DISPONIBLES` → `WL-DISP` (campo de pantalla con edición numérica `ZZ9`)
- c. Colocar la línea de detalle completa `WS-LINEA-DET` en el campo de pantalla correspondiente según el valor actual de `WS-IND-LINEA`:
  - Si `WS-IND-LINEA` es 1 → copiar `WS-LINEA-DET` a `LIN1O`
  - Si `WS-IND-LINEA` es 2 → copiar `WS-LINEA-DET` a `LIN2O`
  - Si `WS-IND-LINEA` es 3 → copiar `WS-LINEA-DET` a `LIN3O`
  - Si `WS-IND-LINEA` es 4 → copiar `WS-LINEA-DET` a `LIN4O`
  - Si `WS-IND-LINEA` es 5 → copiar `WS-LINEA-DET` a `LIN5O`
<!-- rule-end -->

<!-- rule-start -->
### 7. Regla / Operacion - 4100-ARMA-LINEA (Construccion de una linea de detalle de chequera)
<!-- reviewed -->

_Reviewed_

Este bloque construye una línea de texto de 74 caracteres con los datos de una chequera individual y la coloca en el campo de pantalla correspondiente según el número de orden de la línea (1 a 5). Antes de armar la línea, consulta la base de datos para contar cuántos cheques de esa chequera tienen estado 'DI' (disponible).

**Estado de la regla:** Relevante para Modernización

**Algoritmo**

1. Ejecutar una consulta SQL a la tabla CHQ_CHEQUE: contar todas las filas (`COUNT(*)`) donde NUM_CHEQUERA sea igual al valor de HV-NUM-CHEQUERA Y donde EST_CHEQUE sea igual a `'DI'`. El resultado (un número entero) se almacena directamente en HV-DISPONIBLES mediante la cláusula `INTO`. No se verifica el SQLCODE de esta consulta; si falla, HV-DISPONIBLES quedará con el valor que tuviera antes de la ejecución.
2. Construir la línea de detalle WS-LINEA-DET (74 caracteres) copiando los siguientes campos en las posiciones correspondientes, en este orden exacto:
   - WL-CHEQUERA (9 dígitos numéricos): recibe el valor de HV-NUM-CHEQUERA (número de la chequera).
   - Un espacio separador fijo (1 carácter, definido como FILLER con valor SPACE).
   - WL-DESDE (8 dígitos numéricos): recibe el valor de HV-NUM-INICIAL (primer número de cheque del rango).
   - Un espacio separador fijo (1 carácter, definido como FILLER con valor SPACE).
   - WL-HASTA (8 dígitos numéricos): recibe el valor de HV-NUM-FINAL (último número de cheque del rango).
   - Un espacio separador fijo (1 carácter, definido como FILLER con valor SPACE).
   - WL-ESTADO (2 caracteres alfanuméricos): recibe el valor de HV-EST-CHEQUERA (estado de la chequera).
   - Un espacio separador fijo (1 carácter, definido como FILLER con valor SPACE).
   - WL-EMISION (10 caracteres): recibe el valor de HV-FEC-EMISION (fecha de emisión en formato ISO, tal como fue recuperada del cursor con `CHAR(C.FEC_EMISION, ISO)`).
   - Un espacio separador fijo (1 carácter, definido como FILLER con valor SPACE).
   - WL-GRATIS (1 carácter): recibe el valor de HV-IND-GRATUITA (indicador de chequera gratuita).
   - Un espacio separador fijo (1 carácter, definido como FILLER con valor SPACE).
   - WL-DISP (3 dígitos con supresión de ceros a la izquierda, formato ZZ9): recibe el valor de HV-DISPONIBLES (cantidad de cheques disponibles contados en el paso 1). Nótese que HV-DISPONIBLES está definido como entero binario con signo (`PIC S9(09) COMP`), mientras que WL-DISP es un campo de edición de 3 posiciones (`PIC ZZ9`); la conversión al formato de pantalla se produce implícitamente en la instrucción de movimiento.
   - 27 espacios de relleno fijos al final (definidos como FILLER con valor SPACES), completando los 74 caracteres totales de la línea.
3. Según el valor actual del contador WS-IND-LINEA (que ya fue incrementado en 1 por el párrafo llamador 4000-LISTA-CHEQUERAS antes de invocar este bloque), copiar la estructura completa WS-LINEA-DET al campo de pantalla del mapa de salida CHQM1O que corresponda:
   - Si WS-IND-LINEA es 1: copiar WS-LINEA-DET a LIN1O.
   - Si WS-IND-LINEA es 2: copiar WS-LINEA-DET a LIN2O.
   - Si WS-IND-LINEA es 3: copiar WS-LINEA-DET a LIN3O.
   - Si WS-IND-LINEA es 4: copiar WS-LINEA-DET a LIN4O.
   - Si WS-IND-LINEA es 5: copiar WS-LINEA-DET a LIN5O.
   - Si WS-IND-LINEA tiene cualquier otro valor, no se realiza ninguna acción (no existe rama para otros valores en la evaluación).
<!-- rule-end -->

<!-- rule-start -->
### 8. Regla / Operacion - 5000-TOTALES (Calculo y presentacion de totales de cheques por estado)
<!-- reviewed -->

_Reviewed_

Este bloque obtiene en una sola consulta SQL los totales de cheques de la cuenta agrupados por cuatro estados posibles, y los muestra en la pantalla. No realiza cálculos aritméticos propios: toda la suma la hace la base de datos.

Nota histórica presente en el código: el rótulo de la tecla PF12 (que enlazaba al menú principal) sigue apareciendo en el mapa de pantalla aunque la funcionalidad fue eliminada en enero de 2023. El comentario en el código indica que el archivo de definición de pantalla (BMS) no debe modificarse hasta la próxima ventana de cambios.

**Estado de la regla:** Relevante para Modernización

**Algoritmo**

1. Ejecutar la siguiente consulta SQL sobre la tabla **CHQ_CHEQUE**, filtrando por el campo **CTA_NUMERO** igual al valor de la variable de anfitrión **HV-CUENTA** (número de cuenta corriente consultada, de 14 caracteres). La consulta obtiene cuatro totales en una sola pasada mediante sumas condicionales con la función COALESCE para tratar nulos:
   - Calcular la suma condicional de cheques con estado **'DI'** (disponibles): para cada fila, si **EST_CHEQUE** es igual a `'DI'` sumar 1, de lo contrario sumar 0; si el resultado total es nulo, usar 0. Almacenar en **HV-TOT-DISP**.
   - Calcular la suma condicional de cheques con estado **'PA'** (pagados): para cada fila, si **EST_CHEQUE** es igual a `'PA'` sumar 1, de lo contrario sumar 0; si el resultado total es nulo, usar 0. Almacenar en **HV-TOT-PAG**.
   - Calcular la suma condicional de cheques con estado **'RE'** (rechazados): para cada fila, si **EST_CHEQUE** es igual a `'RE'` sumar 1, de lo contrario sumar 0; si el resultado total es nulo, usar 0. Almacenar en **HV-TOT-REC**.
   - Calcular la suma condicional de cheques con estado **'NP'** (no pagados): para cada fila, si **EST_CHEQUE** es igual a `'NP'` sumar 1, de lo contrario sumar 0; si el resultado total es nulo, usar 0. Almacenar en **HV-TOT-NOP**.

2. Si **SQLCODE** es igual a 0 (consulta exitosa), realizar los siguientes pasos para formatear y presentar cada uno de los cuatro totales. El campo auxiliar **WS-DISP-ED** tiene formato **ZZZZ9** (5 posiciones numéricas con supresión de ceros a la izquierda, dejando siempre al menos un dígito). El proceso de volcado al mapa se realiza en dos pasos intermedios para cada total, usando WS-DISP-ED como campo de edición transitorio:
   - Copiar **HV-TOT-DISP** a **WS-DISP-ED**; luego copiar **WS-DISP-ED** al campo de pantalla **TOTDISO** (5 caracteres, correspondiente a "Cheques Disponibles" en la línea 17 del mapa).
   - Copiar **HV-TOT-PAG** a **WS-DISP-ED**; luego copiar **WS-DISP-ED** al campo de pantalla **TOTPAGO** (5 caracteres, correspondiente a "Pagados" en la línea 17 del mapa).
   - Copiar **HV-TOT-REC** a **WS-DISP-ED**; luego copiar **WS-DISP-ED** al campo de pantalla **TOTRECO** (5 caracteres, correspondiente a "Cheques Rechazados" en la línea 18 del mapa).
   - Copiar **HV-TOT-NOP** a **WS-DISP-ED**; luego copiar **WS-DISP-ED** al campo de pantalla **TOTNOPO** (5 caracteres, correspondiente a "No Pago" en la línea 18 del mapa).

3. Si **SQLCODE** es distinto de 0, no se realiza ninguna acción: los cuatro campos de totales en pantalla (**TOTDISO**, **TOTPAGO**, **TOTRECO** y **TOTNOPO**) quedan sin datos. No se emite ningún mensaje de error al operador ni se interrumpe el flujo: el programa continúa hacia el envío del mapa con los campos de totales vacíos.
<!-- rule-end -->

<!-- rule-start -->
### 9. Regla / Operacion - 6000-FECHA-HORA (Obtencion y formateo de fecha y hora actuales)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para Modernizacion

**Algoritmo**

1. Solicitar al sistema CICS la hora absoluta actual mediante la instrucción `ASKTIME` y almacenarla en el campo `WS-ABSTIME` (un entero de 15 dígitos en formato comprimido COMP-3).
2. Solicitar al sistema CICS que convierta `WS-ABSTIME` a formato legible mediante la instrucción `FORMATTIME`, con las siguientes especificaciones:
   - La fecha se formatea como DD/MM/YYYY (día, barra oblicua como separador, mes, barra oblicua, año de cuatro dígitos), utilizando la opción `DDMMYYYY` con separador de fecha `/`, y se almacena en `WS-FECHA-ED` (10 caracteres).
   - La hora se formatea como HH:MM:SS (hora, dos puntos como separador, minutos, dos puntos, segundos), utilizando la opción `TIME` con separador de hora `:`, y se almacena en `WS-HORA-ED` (8 caracteres).
3. Copiar el contenido de `WS-FECHA-ED` al campo de salida de pantalla `MFECHAO`.
4. Copiar el contenido de `WS-HORA-ED` al campo de salida de pantalla `MHORAO`.

> **Nota de contexto:** Este bloque es invocado en dos situaciones distintas dentro del programa: durante la primera entrada a la transacción (párrafo `1000-PRIMERA-ENTRADA`) y al inicio de cada consulta de cuenta (párrafo `3000-CONSULTA`), garantizando que la fecha y hora mostradas en pantalla reflejen siempre el momento real de cada interacción.
<!-- rule-end -->

<!-- rule-start -->
### 10. Regla / Operacion - 7000-ENVIA-MAPA (Envio de la pantalla al terminal)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para Modernizacion

**Algoritmo**

1. Enviar al terminal el mapa **CHQM1** del mapset **CHQMAP1**, usando como fuente de datos el área de salida **CHQM1O**. La operación se realiza mediante un comando CICS SEND MAP con las siguientes características:
   - La pantalla del terminal se borra completamente antes de mostrar el nuevo contenido (opción ERASE).
   - El cursor se posiciona automáticamente en el campo que tenga el atributo de cursor activo definido en el mapa (opción CURSOR). Según la definición del BMS del mapset CHQMAP1, el campo **CTACON** es el único campo de entrada del mapa y tiene definido el atributo **IC** (Insert Cursor), por lo que el cursor siempre quedará posicionado en ese campo tras cada envío.

2. Este procedimiento es invocado desde múltiples puntos del programa y no produce ninguna modificación de datos; su única función es presentar el estado actual del área de salida CHQM1O en la pantalla del usuario. Los contextos desde los que se invoca este envío son los siguientes:
   - Durante la **primera entrada** (párrafo 1000), tras inicializar el mapa con valores bajos y colocar el mensaje de solicitud de número de cuenta en el campo MENSAO.
   - Ante una **tecla no válida** (rama OTHER del EVALUATE sobre EIBAID en el párrafo 2000), tras mostrar el número de cuenta recibido en CTACONO y colocar el mensaje de error correspondiente en MENSAO.
   - Ante cualquier **condición de error o validación fallida** dentro del párrafo de consulta 3000, incluyendo: cuenta no ingresada, cuenta no encontrada en el maestro y cuenta cuyo producto no sea cuenta corriente (código **'06'**, constante SDU-PROD-CORRIENTE).
   - Al **finalizar exitosamente la consulta** (párrafo 3000), tras haber cargado en CHQM1O el nombre del titular, el estado de la cuenta, la moneda, las líneas de detalle de chequeras y los totales de cheques por estado.
<!-- rule-end -->

<!-- rule-start -->
### 11. Regla / Operacion - 8000-RETORNA (Retorno pseudo-conversacional al sistema CICS)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para Modernizacion

**Algoritmo**

1. Indicar al sistema CICS que, al recibir la siguiente entrada del usuario en este terminal, se debe iniciar la transacción con identificador **'CH01'**.
2. Pasar como área de comunicación (COMMAREA) el contenido del campo **CHQ-COMMAREA**, con una longitud fija de **30 bytes**.
   - CHQ-COMMAREA es una estructura de 30 bytes definida en el copybook CHQMAPW con los siguientes campos:
     - **CHQ-CA-ESTADO** (1 byte): indica la fase de la conversación. El valor espacio (' ') corresponde a la primera entrada; el valor **'C'** indica que ya se mostró una consulta.
     - **CHQ-CA-CUENTA** (14 bytes): número de cuenta corriente consultado en la última operación.
     - **CHQ-CA-FILLER** (15 bytes): relleno sin uso funcional.
   - En la siguiente invocación del programa, si EIBCALEN es distinto de cero, el sistema mueve el contenido recibido de DFHCOMMAREA hacia CHQ-COMMAREA antes de procesar la entrada del usuario, lo que permite recuperar el estado y la cuenta de la interacción anterior.
3. El bloque **8000-RETORNA** es invocado siempre como el último paso del flujo principal (párrafo **0000-PRINCIPAL**), independientemente de la rama que se haya ejecutado: primera entrada, procesamiento de tecla o consulta completada. No existe ninguna ruta de ejecución normal del programa que omita este retorno, salvo el párrafo **8900-TERMINA**, que emite un mensaje de fin de transacción, libera el teclado y ejecuta un RETURN sin TRANSID ni COMMAREA, terminando definitivamente la sesión cuando el usuario presiona PF3.
4. El programa termina su ejecución. El control vuelve al sistema CICS.
<!-- rule-end -->

<!-- rule-start -->
### 12. Regla / Operacion - 8900-TERMINA (Cierre definitivo de la transaccion)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para Modernizacion

**Algoritmo**

1. Enviar al terminal el texto `FIN DE LA TRANSACCION CH01    ` (exactamente 30 caracteres, incluyendo los espacios de relleno al final) como mensaje de texto libre, indicando explícitamente la longitud de 30 caracteres. La pantalla del terminal se borra completamente (ERASE) y el teclado se desbloquea (FREEKB) para que el usuario pueda operar libremente en el terminal.
2. Ejecutar un retorno al sistema CICS sin especificar ninguna transacción a continuar ni ninguna COMMAREA (instrucción RETURN sin TRANSID ni COMMAREA). Esto cierra la sesión de la transacción CH01 de forma definitiva; el sistema CICS no volverá a invocar este programa de manera automática. Para iniciar una nueva consulta, el usuario deberá lanzar la transacción CH01 manualmente desde el terminal.
<!-- rule-end -->

<!-- rule-start -->
### 13. Regla / Operacion - Cursor CUR_CHQRA (Definicion de la consulta de chequeras)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para Modernizacion

Esta es la declaración del cursor de base de datos DB2 denominado `CUR_CHQRA`, que se usa en el bloque 4000-LISTA-CHEQUERAS para recorrer las chequeras de una cuenta. No es un bloque de lógica ejecutable por sí solo; define la consulta que se abre y se lee en ese bloque.

La consulta accede a la tabla `CHQ_CHEQUERA` (con alias `C`) y recupera exactamente los siguientes seis campos, en este orden:

1. `NUM_CHEQUERA` — número identificador de la chequera.
2. `NUM_INICIAL` — primer número del rango de cheques de la chequera.
3. `NUM_FINAL` — último número del rango de cheques de la chequera.
4. `EST_CHEQUERA` — código de estado de la chequera (dos caracteres).
5. `FEC_EMISION` convertida a cadena de texto mediante la función `CHAR` con formato `ISO` — esto produce una cadena de diez caracteres con el formato `AAAA-MM-DD`. Este valor se recibe en la variable de host `HV-FEC-EMISION` (definida como `PIC X(10)`), y posteriormente se mueve al campo `WL-EMISION` de la línea de detalle.
6. `IND_GRATUITA` — indicador de si la chequera es gratuita (un carácter).

El filtro aplicado es: el campo `CTA_NUMERO` de la tabla `CHQ_CHEQUERA` debe ser igual al valor de la variable de host `HV-CUENTA`, que contiene el número de cuenta corriente ingresado por el usuario en el campo `CTACONI` del mapa y copiado a dicha variable de host en el bloque 3000-CONSULTA.

El resultado se ordena por `NUM_CHEQUERA` de forma descendente (la chequera con el número más alto, considerada la más reciente, aparece primero).

La cantidad máxima de filas que el cursor puede devolver está limitada a **5** mediante la cláusula `FETCH FIRST 5 ROWS ONLY`, lo cual es consistente con el diseño del mapa CHQM1 que dispone exactamente de cinco líneas de detalle (`LIN1` a `LIN5`).

**Algoritmo**

La consulta equivalente en SQL estándar es:

Seleccionar `NUM_CHEQUERA`, `NUM_INICIAL`, `NUM_FINAL`, `EST_CHEQUERA`, la fecha de emisión convertida a texto en formato ISO mediante `CHAR(FEC_EMISION, ISO)` (produciendo una cadena de diez caracteres `AAAA-MM-DD`), e `IND_GRATUITA` desde la tabla `CHQ_CHEQUERA`, donde el campo `CTA_NUMERO` sea igual al número de cuenta proporcionado como parámetro, ordenado por `NUM_CHEQUERA` de mayor a menor, devolviendo como máximo 5 filas.

Este cursor es abierto (`OPEN`) al inicio del bloque 4000-LISTA-CHEQUERAS. Cada lectura individual (`FETCH`) se realiza en el bloque 4100-ARMA-LINEA y deposita los valores recuperados en las variables de host `HV-NUM-CHEQUERA`, `HV-NUM-INICIAL`, `HV-NUM-FINAL`, `HV-EST-CHEQUERA`, `HV-FEC-EMISION` e `HV-IND-GRATUITA`, respectivamente. El cursor se cierra (`CLOSE`) al finalizar el recorrido, independientemente de si se alcanzaron las 5 filas o si se encontró el fin del resultado antes.
<!-- rule-end -->

<!-- rule-start -->
### 14. Regla / Operacion - Estructura de la COMMAREA CHQ-COMMAREA (Estado entre invocaciones)
<!-- reviewed -->

_Reviewed_

**Business Rule for Review:**

La COMMAREA es el mecanismo que permite al programa recordar información entre una invocación y la siguiente, dado que el programa termina y se reinicia en cada interacción del usuario (diseño pseudo-conversacional). Tiene una longitud fija de 30 bytes y se divide en tres campos:

- **CHQ-CA-ESTADO** (1 carácter): indica en qué punto del flujo se encuentra la transacción. El valor `' '` (espacio) corresponde a la primera entrada, situación que se produce cuando EIBCALEN es igual a cero y el programa nunca ha escrito nada en la COMMAREA. El valor `'C'` significa que ya se mostró una consulta exitosa al usuario. Este campo es escrito por el programa en el párrafo 3000-CONSULTA, exclusivamente cuando la consulta completa fue exitosa, es decir, después de validar la cuenta, leer el maestro, listar las chequeras y calcular los totales, justo antes de invocar 7000-ENVIA-MAPA.
- **CHQ-CA-CUENTA** (14 caracteres): contiene el número de cuenta que se consultó en la interacción anterior. Es escrito por el programa en el párrafo 3000-CONSULTA al mismo tiempo que CHQ-CA-ESTADO, tomando el valor de la variable de trabajo HV-CUENTA (que a su vez fue cargada desde el campo de entrada del mapa CTACONI).
- **CHQ-CA-FILLER** (15 caracteres): espacio reservado sin uso definido actualmente, que completa los 30 bytes totales de la COMMAREA.

**Estado de la regla:** Relevante para Modernización

**Algoritmo**

El ciclo de vida de la COMMAREA sigue los pasos siguientes en cada interacción:

1. **Primera invocación** (EIBCALEN igual a cero): el programa ejecuta 1000-PRIMERA-ENTRADA, donde inicializa CHQ-COMMAREA con espacios mediante `MOVE SPACES TO CHQ-COMMAREA`. En este caso la COMMAREA no se lee desde DFHCOMMAREA porque no existe contenido previo.

2. **Invocaciones posteriores** (EIBCALEN distinto de cero): el programa copia los 30 bytes de DFHCOMMAREA hacia CHQ-COMMAREA mediante `MOVE DFHCOMMAREA TO CHQ-COMMAREA`, recuperando así el estado preservado por CICS desde la interacción anterior. A continuación ejecuta 2000-PROCESA-ENTRADA.

3. **Escritura al finalizar una consulta exitosa**: dentro de 3000-CONSULTA, una vez completado todo el procesamiento (validación de cuenta, lectura del maestro, listado de las cinco chequeras más recientes y cálculo de totales por estado), el programa escribe `'C'` en CHQ-CA-ESTADO y el valor de HV-CUENTA en CHQ-CA-CUENTA. Estas escrituras no se producen si la consulta termina con error en cualquier punto previo del párrafo 3000-CONSULTA (cuenta no ingresada, cuenta no existente, cuenta que no es de tipo corriente —producto `'06'`—, o error de base de datos al abrir el cursor).

4. **Devolución a CICS al finalizar cada invocación**: el párrafo 8000-RETORNA, que es ejecutado siempre al final del flujo principal independientemente de la tecla pulsada o del resultado de la consulta, devuelve CHQ-COMMAREA a CICS mediante `EXEC CICS RETURN TRANSID('CH01') COMMAREA(CHQ-COMMAREA) LENGTH(30)`, lo que garantiza que CICS conserve el estado durante 30 bytes hasta la próxima interacción del usuario. La única excepción es la pulsación de PF3, que ejecuta 8900-TERMINA con un `EXEC CICS RETURN` sin COMMAREA ni TRANSID, terminando definitivamente la transacción sin preservar estado alguno.
<!-- rule-end -->

---

## Extraction metadata

- **Main file:** cobol/CHQCONSU.cbl
- **Created:** 2026-11-08 15:59:28 UTC
- **Started:** 2026-11-08 15:59:28 UTC
- **Duration:** 00:43:46
- **LLM:** us.anthropic.claude-sonnet-4-6 (us.anthropic.claude-sonnet-4-6)
- **Context window:** 200000 tokens · **Max output:** 64000 tokens
- **Extraction prompt:** business_rules_extraction_cobol · **Reviewer prompt:** business_rules_reviewer_cobol
- **Token usage:** 479561 total (443213 input, 36348 output)

### Reference files (5)
Intended for the extraction; any excluded below were not submitted:
- bms/CHQMAP1.bms
- cobol/SDCMAEST.cbl
- copybook/CHQMAPW.cpy
- copybook/SDCMAEW.cpy
- copybook/SDUCONST.cpy
