# CHQCHEQR.cbl: Emision de Chequeras en Lote - CHQCHEQR

## Overview

CHQCHEQR es un programa batch del sistema SIDEP (Sistema Integrado de Depositos) del Banco Andes del Peru, perteneciente al modulo CHQ (Cheques y Compensacion). Se ejecuta bajo el JCL identificado como CHQJD010, paso CHQCHEQR.

Su funcion es procesar todas las solicitudes de chequeras que se encuentran en estado pendiente (codigo 'SO') en la tabla CHQ_SOLICITUD. Por cada solicitud valida, el programa verifica que la cuenta corriente asociada exista y este activa, controla que no se supere el limite de chequeras vigentes por cuenta, calcula el costo de emision (incluyendo IGV), realiza el cobro debitando la cuenta del cliente a traves del motor de posteo SDMPOSTA, genera los registros de la chequera y de cada uno de sus 25 cheques numerados en las tablas CHQ_CHEQUERA y CHQ_CHEQUE, actualiza el estado de la solicitud y envia una notificacion al cliente mediante el servicio NTFENCOL.

El programa es tolerante a fallos parciales: una solicitud que no pasa las validaciones o cuya cuenta no tiene saldo suficiente se rechaza individualmente y se marca con un codigo de rechazo, sin detener el procesamiento de las demas solicitudes. Incorpora un mecanismo de checkpoint y reinicio (BCTCHECK) que permite reanudar el proceso desde el ultimo punto confirmado en caso de interrupcion, evitando reprocesar solicitudes ya emitidas.

Al finalizar, el programa emite un resumen estadistico con el total de solicitudes leidas, emitidas, rechazadas, chequeras generadas, chequeras gratuitas, hojas generadas y monto total cobrado.

## Process Flow

```mermaid
flowchart TD
    A("Inicio del programa")
    B["Leer tarjeta de parametros JCL<br/>(fecha de proceso, modo simulacion)"]
    C["Leer archivo de parametros PARM/CHQPARM<br/>(costos por moneda, frecuencia de checkpoint)"]
    D["Consultar punto de reinicio<br/>(BCTCHECK funcion RS)"]
    E["Abrir cursor de solicitudes pendientes<br/>CHQ_SOLICITUD donde EST_SOLICITUD = 'SO'"]
    F["Leer siguiente solicitud<br/>(FETCH del cursor)"]
    G{"Hay mas<br/>solicitudes?"}
    H["Validar solicitud<br/>(cantidad, cuenta, estado, limite vigentes)"]
    I{"Solicitud<br/>valida?"}
    J["Calcular costo de emision<br/>(costo base + IGV 18%)"]
    K["Cobrar costo en cuenta<br/>(SDMPOSTA - debito)"]
    L{"Cobro<br/>exitoso?"}
    M["Generar chequeras y cheques<br/>(INSERT en CHQ_CHEQUERA y CHQ_CHEQUE,<br/>25 hojas por chequera)"]
    N["Actualizar solicitud a estado 'EM'<br/>(CHQ_SOLICITUD)"]
    O["Notificar al cliente<br/>(NTFENCOL - SMS plantilla CHQ001)"]
    P["Marcar solicitud rechazada 'RE'<br/>con codigo de rechazo<br/>(CHQ_SOLICITUD)"]
    Q["Checkpoint periodico<br/>(BCTCHECK funcion CK + COMMIT)"]
    R["Cerrar cursor<br/>Registrar fin en BCTCHECK<br/>Mostrar totales<br/>COMMIT final"]
    S("Fin del programa")

    A --> B
    B --> C
    C --> D
    D --> E
    E --> F
    F --> G
    G -->|"No - fin de datos"| R
    G -->|"Si"| H
    H --> I
    I -->|"No"| P
    I -->|"Si"| J
    J --> K
    K --> L
    L -->|"No"| P
    L -->|"Si"| M
    M --> N
    N --> O
    O --> Q
    P --> Q
    Q --> F
    R --> S
```

<!-- general-rule-start -->

## General Business Rules:

### Tipo de programa y forma de ejecucion

CHQCHEQR es un programa batch. Es invocado por el JCL CHQJD010 en el paso denominado CHQCHEQR. No es llamado por otros programas; es un punto de entrada autonomo que se lanza desde el planificador de trabajos del mainframe. Recibe una tarjeta de parametros de 80 bytes por la entrada estandar (SYSIN) y lee un archivo de parametros de dominio (DD PARMCHQ, miembro PARM/CHQPARM).

### Parametros de entrada

Al arrancar, el programa lee la tarjeta de parametros del JCL (estructura SDB-PARM-TARJETA). Los campos relevantes son:

- **Fecha de proceso** (posiciones 1 a 8, formato AAAAMMDD): si viene en blanco, se toma la fecha del sistema operativo.
- **Modo de simulacion** (posicion 9): si contiene la letra 'S', el programa ejecuta todas las validaciones y calculos pero no realiza ningun INSERT, UPDATE ni cobro real. Es util para verificar el resultado de la corrida sin afectar la base de datos.

A continuacion lee el archivo PARM/CHQPARM, que puede contener los siguientes parametros con sus valores por defecto si el archivo no existe o no contiene el parametro:

| Clave del parametro | Descripcion | Valor por defecto |
|---|---|---|
| COSTO-CHQRA-PEN | Costo unitario de una chequera en soles | 20.00 |
| COSTO-CHQRA-USD | Costo unitario de una chequera en dolares | 6.00 |
| BCT-FREC-CHECK | Numero de solicitudes entre cada checkpoint | 50 |

El archivo de parametros tiene registros con una clave de 18 caracteres y un valor de 12 caracteres en formato numerico con punto decimal (ejemplo: "000000020.00"). Las lineas cuya clave comienza con asterisco son comentarios y se ignoran. Si el valor no contiene un punto decimal en la posicion esperada, el registro tambien se ignora. El valor numerico se calcula sumando la parte entera mas la parte decimal dividida entre 100.

### Mecanismo de checkpoint y reinicio

Antes de abrir el cursor de solicitudes, el programa consulta al servicio BCTCHECK con la funcion 'RS' (leer punto de reinicio). Si existe un checkpoint previo para el programa CHQCHEQR en la fecha de proceso actual, el numero de la ultima solicitud procesada se recupera y se usa como filtro en el cursor: solo se seleccionan solicitudes con numero mayor al del checkpoint. Esto permite que, si el trabajo fue interrumpido, se retome desde donde se detuvo sin reprocesar solicitudes ya emitidas.

Durante el procesamiento, cada vez que se acumulan tantas solicitudes como indica el parametro BCT-FREC-CHECK (por defecto 50), el programa llama a BCTCHECK con la funcion 'CK' guardando el numero de la solicitud actual como clave del checkpoint, y a continuacion ejecuta un COMMIT en la base de datos DB2. Al finalizar el proceso completo, llama a BCTCHECK con la funcion 'FN' para marcar el trabajo como terminado y ejecuta un COMMIT final.

### Seleccion de solicitudes a procesar

El programa abre un cursor DB2 sobre la tabla CHQ_SOLICITUD seleccionando todas las filas donde el estado (EST_SOLICITUD) sea igual a 'SO' (solicitado) y cuyo numero de solicitud sea mayor al punto de reinicio (si existe). Las columnas recuperadas son: numero de solicitud, numero de cuenta, cantidad de chequeras solicitadas, fecha de solicitud, canal y usuario. Las filas se procesan en orden ascendente de numero de solicitud.

### Validacion de la solicitud (reglas de negocio RN-CHQ-01, RN-CHQ-02, RN-CHQ-03)

Por cada solicitud leida se realizan las siguientes validaciones en orden. Si alguna falla, se asigna un codigo de rechazo y se abandona el resto de las validaciones de esa solicitud:

**RN-CHQ-03 - Cantidad de chequeras por solicitud:**
La cantidad solicitada debe ser un valor entre 1 y 3 (el maximo esta definido en la constante CHQ-MAX-CHEQ-X-SOLIC del copybook CHQCONW, valor 3). Si la cantidad es menor que 1 o mayor que 3, se asigna el codigo de rechazo '50'.

**RN-CHQ-01 - Validacion de la cuenta corriente:**
Se invoca al servicio SDCMAEST con la funcion 'LE' (lectura) para consultar la tabla CUENTA_MAESTRO. Se verifican tres condiciones en cascada:
- Si la cuenta no existe, codigo de rechazo '10'.
- Si la cuenta existe pero su producto no es cuenta corriente (codigo de producto '06' segun la constante SDU-PROD-CORRIENTE), codigo de rechazo '20'.
- Si la cuenta es corriente pero su estado no es activo (codigo 'AC' segun SDU-EST-ACTIVA), codigo de rechazo '30'.

Si la cuenta pasa todas estas validaciones, se guarda la moneda de la cuenta para usarla en el calculo del costo.

**Conteo de chequeras existentes:**
Se realizan dos consultas a la tabla CHQ_CHEQUERA para la cuenta en cuestion:
1. Cuenta total de chequeras historicas (cualquier estado): resultado almacenado como cantidad de chequeras previas.
2. Cuenta de chequeras en estado 'EM' (emitida) o 'EN' (entregada): resultado almacenado como cantidad de chequeras vigentes.

Si alguna de estas consultas falla por error de base de datos, se asigna el codigo de rechazo '90'.

**RN-CHQ-02 - Limite de chequeras vigentes:**
La suma de las chequeras vigentes mas la cantidad solicitada en la solicitud actual no puede superar 2 (constante CHQ-MAX-CHEQ-PENDIENTES). Si se supera, codigo de rechazo '40'.

### Calculo del costo de emision (regla de negocio RN-CHQ-04)

El calculo se realiza sobre la cantidad de chequeras que se van a cobrar, que puede diferir de la cantidad solicitada por la siguiente regla:

**Primera chequera gratuita:** Si la cuenta no tiene ninguna chequera historica previa (la cantidad de chequeras previas es cero), la primera chequera de la solicitud es gratuita. En ese caso, la cantidad a cobrar es igual a la cantidad solicitada menos 1. Si ya tiene chequeras previas, se cobra la totalidad de las solicitadas.

**Costo segun moneda:**
- Si la moneda de la cuenta es soles (codigo '604'), se aplica el costo unitario en soles (COSTO-CHQRA-PEN, por defecto 20.00).
- Para cualquier otra moneda (en la practica, dolares, codigo '840'), se aplica el costo unitario en dolares (COSTO-CHQRA-USD, por defecto 6.00).

**Calculo paso a paso:**
1. Costo base = costo unitario multiplicado por la cantidad a cobrar.
2. IGV = costo base multiplicado por 0.18 (tasa del 18%, constante CHQ-PCT-IGV), redondeado.
3. Costo total = costo base mas IGV.

Si el costo total resulta cero (unica chequera y es gratuita), se omite el paso de cobro.

### Cobro del costo (paso 5000)

Si el costo total es mayor que cero, se llama al motor de posteo SDMPOSTA para realizar un debito en la cuenta del cliente. Los parametros del posteo son:

- Empresa: 1.
- Cuenta: la cuenta de la solicitud.
- Tipo de operacion: cobro de comision (SDU-OP-COBRO-COMISION, codigo '060').
- Signo: 'D' (debito, cargo a la cuenta).
- Importe: el costo total calculado (base mas IGV).
- Fecha de proceso y fecha valor: la fecha de proceso del programa.
- Canal: batch (SDU-CAN-BATCH, codigo 'BA').
- Terminal: nombre del programa ('CHQCHEQR').
- Usuario: 'BATCH'.
- Glosa: 'COSTO CHEQUERA SOLIC ' seguido del numero de solicitud (9 digitos).
- Referencia y numero de documento: numero de solicitud.
- Tipo de documento: 'CQ'.
- Lote: 0.
- Batch ID: 'CHQJD010'.
- Indicador de forzar: 'N' (no forzar; se valida saldo disponible).
- Indicador de exoneracion de ITF: 'N'.
- Indicador de solo validar: 'S' si el programa esta en modo simulacion, 'N' en caso contrario.

Si SDMPOSTA devuelve un codigo de saldo insuficiente (codigo 0040), se asigna el codigo de rechazo '60' a la solicitud. Si devuelve cualquier otro error, se asigna el codigo de rechazo '90' y se registra el error en el log. En ambos casos la solicitud se rechaza sin emitir chequera. Si el cobro es exitoso, el importe cobrado se acumula al total cobrado del programa.

### Emision de chequeras y numeracion de cheques (regla de negocio RN-CHQ-05)

Este paso se omite completamente si el programa esta en modo simulacion.

**Numeracion correlativa:** Antes de generar las chequeras, se consulta el maximo numero de cheque existente en la tabla CHQ_CHEQUE para la cuenta (MAX de NUM_CHEQUE). Si no existe ningun cheque previo, el maximo es cero. A partir de ese valor, los numeros de cheque se asignan de forma correlativa y creciente.

**Por cada chequera a generar** (se itera tantas veces como indica la cantidad solicitada):

1. Se obtiene el maximo numero de chequera existente en toda la tabla CHQ_CHEQUERA (MAX de NUM_CHEQUERA a nivel global, no solo de la cuenta). El numero de la nueva chequera es ese maximo mas 1.
2. El numero inicial de la chequera es el ultimo numero de cheque utilizado mas 1.
3. El numero final de la chequera es el numero inicial mas 24 (25 hojas en total, constante CHQ-HOJAS-CHEQUERA).
4. Se determina si la chequera es gratuita: solo la primera chequera de la solicitud (indice 1) y solo si la cuenta no tenia chequeras previas recibe el indicador de gratuita ('S'). Las demas reciben 'N'.
5. Se inserta un registro en CHQ_CHEQUERA con los siguientes valores:
   - NUM_CHEQUERA: numero asignado.
   - CTA_NUMERO: numero de cuenta.
   - NUM_SOLICITUD: numero de la solicitud.
   - NUM_INICIAL: primer numero de cheque.
   - NUM_FINAL: ultimo numero de cheque.
   - CANT_HOJAS: 25 (valor fijo).
   - EST_CHEQUERA: 'EM' (emitida).
   - FEC_EMISION: fecha de proceso.
   - IND_GRATUITA: 'S' o 'N' segun corresponda.
   - COD_MONEDA: moneda de la cuenta.

6. A continuacion se generan los 25 cheques individuales iterando desde 1 hasta 25. Por cada hoja se incrementa en 1 el contador de numero de cheque actual y se inserta un registro en CHQ_CHEQUE con:
   - CTA_NUMERO: numero de cuenta.
   - NUM_CHEQUE: numero correlativo asignado.
   - NUM_CHEQUERA: numero de la chequera padre.
   - EST_CHEQUE: 'DI' (disponible).
   - MON_IMPORTE: 0 (el importe se completara cuando el cheque sea presentado).

### Actualizacion de la solicitud

Si el proceso de emision fue exitoso, se actualiza la fila correspondiente en CHQ_SOLICITUD con:
- EST_SOLICITUD: 'EM' (emitida).
- MON_COSTO_BASE: costo base calculado.
- MON_IGV: IGV calculado.
- MON_COSTO_TOTAL: costo total calculado.
- FEC_PROCESO: fecha de proceso.

Si la solicitud fue rechazada en cualquier etapa, se actualiza con:
- EST_SOLICITUD: 'RE' (rechazada).
- COD_RECHAZO: el codigo de rechazo asignado durante la validacion o el cobro.
- FEC_PROCESO: fecha de proceso.

Ambas actualizaciones se omiten en modo simulacion.

### Codigos de rechazo

| Codigo | Motivo |
|---|---|
| 10 | La cuenta no existe en el maestro |
| 20 | La cuenta no es de tipo corriente |
| 30 | La cuenta no esta activa |
| 40 | Se superaria el limite de 2 chequeras vigentes |
| 50 | La cantidad solicitada esta fuera del rango permitido (1 a 3) |
| 60 | Saldo insuficiente para cobrar el costo de la chequera |
| 90 | Error tecnico (base de datos u otro error del sistema) |

### Notificacion al cliente

Tras emitir exitosamente las chequeras, se llama al servicio NTFENCOL con la funcion 'EN' para encolar una notificacion al cliente. Los parametros son:

- Canal: 'SM' (SMS).
- Plantilla: 'CHQ001'.
- Codigo unico del titular: obtenido del maestro de cuentas (SDC-MAE-TIT-CODIGO-UNICO).
- Parametros del mensaje: la cantidad de chequeras emitidas (campo {1}) y el numero de solicitud (campo {2}), separados por el caracter '|'.
- Prioridad: 5 (baja).

Si NTFENCOL devuelve un error, este se registra en el log con codigo 'A0001' (advertencia), pero no se revierte ninguna operacion ya realizada. La notificacion fallida no invalida la emision.

### Registro de errores

Todos los errores se registran mediante el servicio SDULOGER, que escribe en el archivo VSAM LOGSIDEP. Cada registro de error incluye el nombre del programa, el parrafo donde ocurrio el error, el codigo de error interno, la descripcion del error, el numero de cuenta afectada, el usuario ('BATCH'), el canal ('BA'), la fecha de proceso y el codigo SQLCODE de DB2 cuando corresponde.

### Resumen de cierre y codigo de retorno

Al finalizar, el programa muestra por la salida estandar los siguientes contadores:

- Solicitudes leidas.
- Solicitudes emitidas.
- Solicitudes rechazadas.
- Chequeras generadas.
- Chequeras gratuitas.
- Hojas generadas.
- Total cobrado (suma de todos los cargos realizados exitosamente).

Si el programa se ejecuto en modo simulacion, se muestra un mensaje adicional indicando ese hecho.

El codigo de retorno del trabajo (RETURN-CODE) se establece segun las siguientes reglas:
- 0: proceso completado sin rechazos ni errores graves.
- 4: proceso completado pero con al menos una solicitud rechazada.
- 12: error irrecuperable al leer el cursor de solicitudes (FETCH).
- 16: error al abrir el cursor de solicitudes.

<!-- general-rule-end -->

## Dependencies

El programa CHQCHEQR depende de un conjunto de subrutinas compartidas del core SIDEP, tablas DB2, un archivo secuencial de parametros, un archivo VSAM de log y copybooks de interfaz. Todas las dependencias son internas al sistema SIDEP; no existe ninguna API externa ni paquete de terceros. A continuacion se describe cada grupo y luego se presenta la tabla consolidada.

**Subrutinas llamadas dinamicamente**

El programa invoca cuatro subrutinas mediante instrucciones CALL en tiempo de ejecucion. Ninguna de ellas es compilada dentro de CHQCHEQR; se resuelven en el momento de la ejecucion del paso JCL.

- SDCMAEST es el unico punto de acceso al maestro de cuentas (tabla DB2 CUENTA_MAESTRO). CHQCHEQR la llama con la funcion 'LE' (lectura) para verificar que la cuenta existe, que es de producto corriente (codigo '06' segun SDUCONST), que esta activa (estado 'AC') y para obtener su moneda. La interfaz de comunicacion es el area SDC-AREA-MAESTRO definida en el copybook SDCMAEW. El codigo de retorno SDC-MAE-COD-RETORNO se compara contra SDU-RC-OK ('00') para determinar si la llamada tuvo exito.

- SDMPOSTA es el motor de posteo de movimientos. CHQCHEQR la llama para cobrar el costo de la chequera mediante un cargo a la cuenta corriente del cliente. La operacion se clasifica con el tipo SDU-OP-COBRO-COMISION, signo 'D' (debito), canal SDU-CAN-BATCH y lote identificado como 'CHQJD010'. El indicador POS-IND-SOLO-VALIDA se pone en 'S' cuando el programa corre en modo simulacion, con lo que SDMPOSTA valida disponibilidad pero no aplica el movimiento. Si POS-COD-RETORNO devuelve el codigo POS-SALDO-INSUF (0040), la solicitud se rechaza con codigo '60'; cualquier otro codigo de error distinto de cero produce rechazo con codigo '90' y registra el error. La interfaz es AREA-POSTEO definida en SDMPOSTW.

- NTFENCOL encola una notificacion al cliente una vez que la chequera ha sido emitida. CHQCHEQR la llama con funcion 'EN', canal 'SM' (SMS), plantilla 'CHQ001' y prioridad 5 (baja). Los parametros del mensaje son la cantidad de chequeras emitidas y el numero de solicitud, separados por el caracter '|'. El codigo unico del titular (SDC-MAE-TIT-CODIGO-UNICO) identifica al destinatario. Si NTFENCOL devuelve un codigo de retorno distinto de cero, el error se registra en el log pero no se revierte ninguna operacion ya realizada; la emision de la chequera queda vigente. La interfaz es NTF-AREA-ENCOLA definida en NTFIFCW.

- BCTCHECK gestiona los puntos de reinicio del proceso batch. CHQCHEQR la llama tres veces: al inicio con funcion 'RS' para leer el ultimo numero de solicitud procesado en una ejecucion anterior interrumpida; periodicamente con funcion 'CK' para grabar el numero de solicitud en curso como nuevo punto de reinicio (cada N solicitudes, siendo N el parametro WS-FREC-CHECKPOINT, por defecto 50); y al cierre con funcion 'FN' para marcar el proceso como finalizado. El commit de base de datos que confirma cada punto de reinicio lo emite el propio CHQCHEQR inmediatamente despues de cada llamada 'CK'. BCTCHECK no hace commit por si mismo. La interfaz es BCT-AREA-CHECK definida en BCTIFCW.

- SDULOGER es la subrutina centralizada de registro de errores y auditoria. CHQCHEQR la llama cada vez que detecta un error, pasandole el area SDU-AREA-LOG (definida en SDULOGW) con nivel 'E', el nombre del programa, el parrafo activo, el codigo de error interno y la glosa. SDULOGER escribe en el archivo VSAM LOGSIDEP. Si ese archivo no esta disponible, SDULOGER degrada silenciosamente a DISPLAY y devuelve codigo '00' al llamador; CHQCHEQR no detecta ese fallo.

**Tablas DB2**

El programa accede directamente a tres tablas del esquema DB2 del dominio CHQ y a una tabla del modulo BCT (a traves de BCTCHECK).

- CHQ_SOLICITUD: tabla principal de entrada. El programa abre un cursor (CUR_SOLIC) sobre ella filtrando las filas con EST_SOLICITUD = 'SO' (solicitud pendiente) y NUM_SOLICITUD mayor al punto de reinicio. Lee los campos NUM_SOLICITUD, CTA_NUMERO, CANT_CHEQUERAS, FEC_SOLICITUD, CANAL y COD_USUARIO. Al finalizar el procesamiento de cada solicitud exitosa, actualiza EST_SOLICITUD a 'EM', graba los importes de costo (MON_COSTO_BASE, MON_IGV, MON_COSTO_TOTAL) y la fecha de proceso. Si la solicitud es rechazada, actualiza EST_SOLICITUD a 'RE' y graba el codigo de rechazo y la fecha.

- CHQ_CHEQUERA: tabla de cabeceras de chequeras. El programa la consulta dos veces por solicitud para contar el total de chequeras existentes de la cuenta (COUNT sin filtro de estado) y las que estan en estado 'EM' o 'EN' (vigentes). Luego inserta una fila por cada chequera emitida, con los campos NUM_CHEQUERA (maximo global mas uno), CTA_NUMERO, NUM_SOLICITUD, NUM_INICIAL, NUM_FINAL, CANT_HOJAS (siempre 25), EST_CHEQUERA ('EM'), FEC_EMISION, IND_GRATUITA y COD_MONEDA.

- CHQ_CHEQUE: tabla de hojas individuales de cheque. El programa consulta el maximo NUM_CHEQUE existente para la cuenta y luego inserta 25 filas por cada chequera generada, con EST_CHEQUE = 'DI' (disponible) y MON_IMPORTE = 0. Los numeros se asignan de forma correlativa por cuenta, continuando desde el ultimo numero registrado.

- BCT_CHECKPOINT: accedida exclusivamente a traves de BCTCHECK. Almacena el ultimo numero de solicitud procesado, el contador de registros y el estado del proceso ('E' en ejecucion, 'F' finalizado) por programa y fecha de proceso.

- CUENTA_MAESTRO: accedida exclusivamente a traves de SDCMAEST (funcion 'LE'). Proporciona producto, moneda, estado y codigo unico del titular de la cuenta.

- SIDEP.MOVIMIENTO: accedida exclusivamente a traves de SDMPOSTA. Recibe el registro del cargo por costo de chequera.

- NTF_PLANTILLA: accedida exclusivamente a traves de NTFENCOL. Proporciona el texto de la plantilla 'CHQ001' para construir el mensaje SMS.

**Archivos de datos**

- ARCH-PARM (nombre DD: PARMCHQ): archivo secuencial de longitud fija (80 bytes por registro: 18 de clave, 12 de valor, 50 de relleno). Contiene los parametros de dominio COSTO-CHQRA-PEN, COSTO-CHQRA-USD y BCT-FREC-CHECK. Si el archivo no esta disponible al momento de la apertura, el programa muestra un aviso y continua con los valores por defecto incorporados en el codigo (S/. 20.00, USD 6.00 y frecuencia de checkpoint cada 50 solicitudes). La ausencia del archivo no es un error fatal.

- LOGSIDEP (nombre DD: LOGSIDEP): archivo VSAM de acceso indexado utilizado por SDULOGER para registrar errores y eventos de auditoria. CHQCHEQR no lo abre ni lo cierra directamente; lo gestiona SDULOGER, que mantiene el archivo abierto durante toda la ejecucion.

- NTFCOLA (nombre DD: NTFCOLA): archivo VSAM de acceso indexado utilizado por NTFENCOL como cola de notificaciones pendientes de envio. CHQCHEQR no lo accede directamente. El envio real de los mensajes lo realiza el programa NTFENVIO en un proceso batch separado.

**Copybooks incluidos**

Los copybooks se incorporan en tiempo de compilacion mediante instrucciones COPY y definen las estructuras de datos que el programa comparte con las subrutinas.

- SDBPARMW: define el area SDB-PARM-TARJETA (80 bytes) que recibe la tarjeta de parametros del JCL via SYSIN, incluyendo la fecha de proceso y el indicador de modo (P/S/R).
- SDULOGW: define SDU-AREA-LOG, el area de comunicacion con SDULOGER.
- SDUCONST: define las constantes institucionales del sistema: codigos de producto (SDU-PROD-CORRIENTE = '06'), codigos de moneda (SDU-MON-SOLES = '604'), estados de cuenta (SDU-EST-ACTIVA = 'AC'), codigos de canal (SDU-CAN-BATCH = 'BA') y codigos de operacion (SDU-OP-COBRO-COMISION = '060').
- SDMPOSTW: define AREA-POSTEO, el area de entrada y salida de SDMPOSTA.
- SDCMAEW: define SDC-AREA-MAESTRO, el area de comunicacion con SDCMAEST.
- CHQCONW: define las constantes propias del dominio de cheques: CHQ-HOJAS-CHEQUERA (25), CHQ-MAX-CHEQ-PENDIENTES (2), CHQ-MAX-CHEQ-X-SOLIC (3), CHQ-PCT-IGV (0.18), estados de chequera y cheque, y codigos de rechazo.
- NTFIFCW: define NTF-AREA-ENCOLA, el area de comunicacion con NTFENCOL.
- BCTIFCW: define BCT-AREA-CHECK, el area de comunicacion con BCTCHECK.
- SQLCA: estructura estandar DB2 que recibe el codigo de retorno (SQLCODE) de cada instruccion SQL ejecutada.

**Codigo inactivo relevante para la modernizacion**

Existe un bloque de codigo comentado denominado 7900-RENOVAR-AGOTADAS que contenia logica para actualizar automaticamente a estado 'AG' (agotada) las chequeras sin cheques disponibles. Segun el comentario del propio codigo, esta funcionalidad fue desactivada en 2018 por solicitud del area de Marketing. El bloque no se compila ni se ejecuta. La modernizacion debe decidir si esta regla debe reactivarse, eliminarse definitivamente o implementarse de otra forma.

---

| Dependencia | Descripcion | Tipo | Referencia | Relevancia para la Modernizacion |
|---|---|---|---|---|
| SDCMAEST | Subrutina hub de acceso al maestro de cuentas. Se llama con funcion 'LE' para validar existencia, producto, estado y moneda de la cuenta. | Subrutina CALL | SDCMAEST.cbl | Debe reemplazarse por un servicio o repositorio de cuentas. El area de comunicacion SDCMAEW tiene 22 llamadores; cualquier cambio de estructura impacta a todo el core. |
| SDMPOSTA | Motor de posteo de movimientos. Aplica el cargo por costo de chequera sobre la cuenta corriente. | Subrutina CALL | SDMPOSTA.cbl | Punto critico: es la unica via autorizada para afectar saldos. Tiene 10 llamadores internos y 3 canales externos. Debe exponerse como servicio transaccional con soporte de rollback. |
| NTFENCOL | Subrutina de encolado de notificaciones. Encola el aviso SMS al cliente con plantilla 'CHQ001'. | Subrutina CALL | NTFENCOL.cbl | Un fallo no revierte la emision. La modernizacion debe definir si la notificacion debe ser parte de la transaccion o un proceso asincrono desacoplado. |
| BCTCHECK | Subrutina de checkpoint y reinicio batch. Graba y lee el punto de reinicio en BCT_CHECKPOINT. | Subrutina CALL | BCTCHECK.cbl | Debe reemplazarse por el mecanismo de reinicio de la plataforma batch destino (por ejemplo, Spring Batch JobRepository). El commit lo emite el llamador, no BCTCHECK. |
| SDULOGER | Subrutina centralizada de log y auditoria. Escribe en el VSAM LOGSIDEP. | Subrutina CALL | SDULOGER.cbl | Si el VSAM falla, SDULOGER degrada a DISPLAY sin avisar al llamador. La modernizacion debe garantizar la disponibilidad del log o usar un mecanismo con confirmacion de escritura. |
| CHQ_SOLICITUD | Tabla DB2 de solicitudes de chequera. Fuente de entrada del proceso y destino de la actualizacion de estado. | Tabla DB2 | Esquema CHQ, tabla CHQ_SOLICITUD | Tabla central del dominio. Debe migrarse con sus indices y restricciones de estado. |
| CHQ_CHEQUERA | Tabla DB2 de cabeceras de chequeras emitidas. | Tabla DB2 | Esquema CHQ, tabla CHQ_CHEQUERA | Se insertan registros en este proceso. El numero de chequera se genera con MAX+1 sin secuencia DB2; esto es propenso a duplicados en ejecuciones paralelas. |
| CHQ_CHEQUE | Tabla DB2 de hojas individuales de cheque. | Tabla DB2 | Esquema CHQ, tabla CHQ_CHEQUE | Se insertan 25 filas por chequera. La numeracion correlativa por cuenta tambien usa MAX+1 sin secuencia; mismo riesgo que CHQ_CHEQUERA. |
| BCT_CHECKPOINT | Tabla DB2 de puntos de reinicio batch. Gestionada exclusivamente por BCTCHECK. | Tabla DB2 | Esquema BCT, tabla BCT_CHECKPOINT | Puede eliminarse si la plataforma batch destino tiene su propio mecanismo de reinicio. |
| CUENTA_MAESTRO | Tabla DB2 del maestro de cuentas. Accedida solo a traves de SDCMAEST. | Tabla DB2 | Esquema SIDEP, tabla CUENTA_MAESTRO | No se accede directamente desde CHQCHEQR. El riesgo esta en SDCMAEST y en los programas que replicaron el area a mano (CTSCERTI, SDMPOSTA). |
| SIDEP.MOVIMIENTO | Tabla DB2 de movimientos contables. Accedida solo a traves de SDMPOSTA. | Tabla DB2 | Esquema SIDEP, tabla MOVIMIENTO | No se accede directamente. La modernizacion debe asegurar que el posteo sea atomico con la emision de la chequera. |
| NTF_PLANTILLA | Tabla DB2 de plantillas de notificacion. Accedida solo a traves de NTFENCOL. | Tabla DB2 | Esquema NTF, tabla NTF_PLANTILLA | La plantilla 'CHQ001' debe existir, estar activa y configurada para canal 'SM'. Su ausencia no aborta el proceso pero deja al cliente sin aviso. |
| ARCH-PARM / PARMCHQ | Archivo secuencial de parametros del dominio CHQ. Contiene costos de chequera por moneda y frecuencia de checkpoint. | Archivo secuencial QSAM (DD: PARMCHQ) | Miembro PARM/CHQPARM del JCL CHQJD010 | Si no existe, el programa usa valores por defecto incorporados en el codigo. La modernizacion debe externalizar estos parametros a una tabla de configuracion o a un servicio de parametros. |
| LOGSIDEP | Archivo VSAM indexado de log y auditoria del sistema SIDEP. | Archivo VSAM (DD: LOGSIDEP) | VSAM LOGSIDEP | Debe reemplazarse por el sistema de logging de la plataforma destino. La degradacion silenciosa actual es un riesgo de auditoria. |
| NTFCOLA | Archivo VSAM indexado que actua como cola de notificaciones pendientes. | Archivo VSAM (DD: NTFCOLA) | VSAM NTFCOLA | Debe reemplazarse por una cola de mensajes (por ejemplo, MQ o Kafka). El programa NTFENVIO que consume esta cola es una dependencia indirecta. |
| SDBPARMW | Copybook que define la tarjeta de parametros del JCL (80 bytes via SYSIN). | Copybook | SDBPARMW.cpy | Define la forma en que el JCL pasa la fecha de proceso y el modo de ejecucion. Debe mapearse a los parametros de entrada del job en la plataforma destino. |
| SDULOGW | Copybook que define el area de comunicacion con SDULOGER. | Copybook | SDULOGW.cpy | Incluido por casi todo el core. Cualquier cambio impacta a todos los programas que lo usan. |
| SDUCONST | Copybook de constantes institucionales: productos, monedas, estados, canales y codigos de retorno estandar. | Copybook | SDUCONST.cpy | Debe convertirse en una capa de constantes o enumeraciones en la plataforma destino. Los valores estan cableados y no son configurables en tiempo de ejecucion. |
| SDMPOSTW | Copybook que define el area de entrada y salida de SDMPOSTA. | Copybook | SDMPOSTW.cpy | Cualquier cambio obliga a recompilar todo el sistema. Alta criticidad en la modernizacion. |
| SDCMAEW | Copybook que define el area de comunicacion con SDCMAEST. | Copybook | SDCMAEW.cpy | Advertencia documentada: CTSCERTI y SDMPOSTA replicaron esta area a mano y no detectarian cambios de estructura en compilacion. |
| CHQCONW | Copybook de constantes del dominio CHQ: numero de hojas, limites de chequeras, porcentaje de IGV, estados y motivos de rechazo. | Copybook | CHQCONW.cpy | Los plazos de presentacion (30/60 dias) y el tope de rechazos por fondos insuficientes (3) estan cableados aqui y no son parametrizables. Hay una tarea pendiente documentada (SD-2019-441). |
| NTFIFCW | Copybook que define el area de comunicacion con NTFENCOL. | Copybook | NTFIFCW.cpy | Define los codigos de retorno y los canales validos (SM, EM, PU). |
| BCTIFCW | Copybook que define el area de comunicacion con BCTCHECK. | Copybook | BCTIFCW.cpy | Define las funciones CK, RS, FN y RE y sus codigos de retorno. |
| JCL CHQJD010 (paso CHQCHEQR) | Trabajo batch que ejecuta el programa. Define los DD PARMCHQ (parametros), SYSIN (tarjeta de control) y los datasets de log y VSAM. | JCL | CHQJD010, paso CHQCHEQR | El nombre del lote 'CHQJD010' queda grabado en cada movimiento contable generado por SDMPOSTA. Debe preservarse o mapearse al identificador equivalente en la plataforma destino. |

## Data Structure

La siguiente tabla describe todos los campos de datos utilizados por el programa CHQCHEQR y sus modulos de apoyo, organizados por origen. Los campos provienen de la seccion de almacenamiento de trabajo (WORKING-STORAGE), la seccion de enlace (LINKAGE SECTION) de las subrutinas, los registros de archivos secuenciales (FD) y los copybooks de interfaz incluidos en el fuente.

---

### Archivo de parametros (FD ARCH-PARM / REG-PARM)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| REG-PARM | REG-PARM | Group (record) | 80 bytes | Registro completo de una linea del archivo de parametros PARM/CHQPARM. | N/A | N/A | Archivo secuencial de formato fijo. Cada registro tiene 80 bytes. | Si | Configuracion |
| PRM-CLAVE | PRM-CLAVE | Alphanumerico | 18 | Nombre de la clave del parametro. Si el primer caracter es asterisco (*), el registro se trata como comentario y se ignora. | Si | N/A | Claves reconocidas: COSTO-CHQRA-PEN, COSTO-CHQRA-USD, BCT-FREC-CHECK. | Si | Configuracion |
| PRM-VALOR | PRM-VALOR | Alphanumerico | 12 | Valor del parametro en formato texto. Debe contener un punto decimal en la posicion 10 (WS-PV-PUNTO) para ser valido. | Si | N/A | Se redefine internamente como parte entera (9 digitos) + punto + parte decimal (2 digitos). | Si | Configuracion |
| FILLER | FILLER | Alphanumerico | 50 | Relleno sin uso en el registro de parametros. | No | N/A | No se utiliza en ninguna logica de negocio. | No | N/A |

---

### Identificacion del programa (WS-IDENTIFICACION)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| WS-NOM-PROGRAMA | WS-NOM-PROGRAMA | Alphanumerico | 8 | Nombre del programa en ejecucion. Se usa en llamadas a SDULOGER y BCTCHECK. | Si | 'CHQCHEQR' | Valor fijo. | No | Auditoria |
| WS-PARRAFO-ACT | WS-PARRAFO-ACT | Alphanumerico | 20 | Nombre del parrafo o rutina que se esta ejecutando en el momento de un error. Se actualiza al inicio de cada bloque logico. | No | Espacios | Facilita la localizacion del error en el log. | Si | Auditoria |
| WS-COD-ERROR | WS-COD-ERROR | Alphanumerico | 6 | Codigo de error interno que se envia a SDULOGER. Ejemplos: E0001 a E0009, A0001. | No | Espacios | Prefijo E = error; A = advertencia. | Si | Auditoria |
| WS-GLOSA-ERROR | WS-GLOSA-ERROR | Alphanumerico | 120 | Descripcion textual del error o advertencia que se envia a SDULOGER. | No | Espacios | N/A | Si | Auditoria |

---

### Indicadores (WS-SWITCHES)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| WS-FS-PARM | WS-FS-PARM | Alphanumerico | 2 | Codigo de estado del archivo de parametros ARCH-PARM tras cada operacion de apertura o lectura. '00' indica exito. | No | Espacios | Si no es '00' al abrir, se usan los valores por defecto de WORKING-STORAGE y no se considera error fatal. | Si | Control |
| SW-FIN-CURSOR | SW-FIN-CURSOR | Alphanumerico | 1 | Indicador de fin del cursor CUR_SOLIC. Valor 'S' (condicion FIN-CURSOR) detiene el bucle principal de procesamiento. | Si | 'N' | Se activa cuando el FETCH devuelve SQLCODE +100 (sin mas filas) o cuando ocurre un error al abrir el cursor. | Si | Control |
| SW-FIN-PARM | SW-FIN-PARM | Alphanumerico | 1 | Indicador de fin del archivo de parametros. Valor 'S' (condicion FIN-PARM) detiene la lectura del archivo. | Si | 'N' | N/A | No | Control |
| SW-SOLIC-OK | SW-SOLIC-OK | Alphanumerico | 1 | Indicador de validez de la solicitud en curso. Valor 'S' (condicion SOLIC-VALIDA) permite continuar con el cobro y la emision. Valor 'N' deriva al rechazo. | Si | 'S' | Se pone a 'N' en cualquiera de las validaciones de negocio o si el cobro falla. | Si | Control |
| SW-SIMULA | SW-SIMULA | Alphanumerico | 1 | Indicador de modo simulacion. Valor 'S' (condicion MODO-SIMULA) hace que el programa valide sin ejecutar posteos ni inserciones en base de datos. | Si | 'N' | Se activa si el campo SDB-PRM-MODO de la tarjeta de parametros del JCL contiene 'S'. | Si | Control |
| SW-ES-PEN | SW-ES-PEN | Alphanumerico | 1 | Indicador de moneda soles (PEN). Valor 'S' si la cuenta es en soles; 'N' si es en dolares u otra moneda. | No | 'S' | Se usa al seleccionar el costo unitario de la chequera segun moneda. | Si | Control |

---

### Contadores de proceso (WS-CONTADORES)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| WS-CNT-LEIDAS | WS-CNT-LEIDAS | Numerico decimal empaquetado con signo | 9 enteros | Cantidad total de solicitudes leidas del cursor CUR_SOLIC durante la corrida. | No | 0 | Se incrementa en 1 por cada FETCH exitoso procesado. | Si | Estadistica |
| WS-CNT-EMITIDAS | WS-CNT-EMITIDAS | Numerico decimal empaquetado con signo | 9 enteros | Cantidad de solicitudes procesadas exitosamente (chequeras emitidas). | No | 0 | N/A | Si | Estadistica |
| WS-CNT-RECHAZADAS | WS-CNT-RECHAZADAS | Numerico decimal empaquetado con signo | 9 enteros | Cantidad de solicitudes rechazadas por cualquier motivo de validacion o cobro. | No | 0 | Si este contador es mayor que cero al cierre, el RETURN-CODE del programa se establece en 4. | Si | Estadistica |
| WS-CNT-CHEQUERAS | WS-CNT-CHEQUERAS | Numerico decimal empaquetado con signo | 9 enteros | Cantidad total de registros insertados en la tabla CHQ_CHEQUERA. | No | 0 | N/A | Si | Estadistica |
| WS-CNT-GRATUITAS | WS-CNT-GRATUITAS | Numerico decimal empaquetado con signo | 9 enteros | Cantidad de chequeras marcadas como gratuitas (IND_GRATUITA = 'S'). | No | 0 | N/A | Si | Estadistica |
| WS-CNT-HOJAS | WS-CNT-HOJAS | Numerico decimal empaquetado con signo | 9 enteros | Cantidad total de registros insertados en la tabla CHQ_CHEQUE (hojas individuales). | No | 0 | N/A | Si | Estadistica |
| WS-TOT-COBRADO | WS-TOT-COBRADO | Numerico decimal empaquetado con signo | 13 enteros, 2 decimales | Suma acumulada de los importes totales (base + IGV) cobrados exitosamente via SDMPOSTA durante la corrida. | No | 0 | N/A | Si | Financiero |
| WS-CNT-DESDE-CHECK | WS-CNT-DESDE-CHECK | Numerico decimal empaquetado con signo | 5 enteros | Contador de solicitudes procesadas desde el ultimo checkpoint. Cuando alcanza WS-FREC-CHECKPOINT se ejecuta un nuevo checkpoint y se reinicia a cero. | No | 0 | N/A | Si | Control |

---

### Parametros de dominio (WS-PARAMETROS)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| WS-COSTO-CHQRA-PEN | WS-COSTO-CHQRA-PEN | Numerico decimal empaquetado con signo | 9 enteros, 2 decimales | Costo unitario de una chequera en soles (PEN), antes de IGV. Se lee del archivo PARM/CHQPARM con la clave COSTO-CHQRA-PEN. | No | +20.00 | Si el archivo de parametros no esta disponible o la clave no existe, se usa el valor por defecto. | Si | Financiero |
| WS-COSTO-CHQRA-USD | WS-COSTO-CHQRA-USD | Numerico decimal empaquetado con signo | 9 enteros, 2 decimales | Costo unitario de una chequera en dolares (USD), antes de IGV. Se lee del archivo PARM/CHQPARM con la clave COSTO-CHQRA-USD. | No | +6.00 | Mismo comportamiento que WS-COSTO-CHQRA-PEN. | Si | Financiero |
| WS-FREC-CHECKPOINT | WS-FREC-CHECKPOINT | Numerico decimal empaquetado con signo | 5 enteros | Frecuencia de checkpoint: numero de solicitudes procesadas entre cada llamada a BCTCHECK con funcion 'CK'. Se lee del archivo PARM/CHQPARM con la clave BCT-FREC-CHECK. | No | +50 | Solo se usa la parte entera del valor leido del archivo (WS-PV-ENT). | Si | Control |

---

### Area de lectura del valor de parametro (WS-VALOR-PARM)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| WS-PV-TEXTO | WS-PV-TEXTO | Alphanumerico | 12 | Copia del campo PRM-VALOR del registro de parametros, usada para analizar su contenido. | No | N/A | Se redefine como WS-PV-PARTES. | No | Configuracion |
| WS-PV-ENT | WS-PV-ENT | Numerico sin signo | 9 enteros | Parte entera del valor del parametro (posiciones 1 a 9 de WS-PV-TEXTO). | No | N/A | Subgrupo de WS-PV-PARTES, que redefine WS-PV-TEXTO. | Si | Configuracion |
| WS-PV-PUNTO | WS-PV-PUNTO | Alphanumerico | 1 | Caracter en la posicion 10 de WS-PV-TEXTO. Debe ser '.' para que el registro sea valido; de lo contrario se descarta. | No | N/A | Subgrupo de WS-PV-PARTES. | Si | Configuracion |
| WS-PV-DEC | WS-PV-DEC | Numerico sin signo | 2 enteros | Parte decimal del valor del parametro (posiciones 11 y 12 de WS-PV-TEXTO). | No | N/A | Subgrupo de WS-PV-PARTES. | Si | Configuracion |
| WS-PV-NUMERO | WS-PV-NUMERO | Numerico decimal empaquetado con signo | 9 enteros, 2 decimales | Valor numerico resultante de combinar WS-PV-ENT y WS-PV-DEC: WS-PV-ENT + (WS-PV-DEC / 100). | No | N/A | Es el valor que finalmente se asigna al parametro de destino (costo o frecuencia). | Si | Configuracion |

---

### Fechas de proceso (WS-FECHAS / WS-FECHA-ISO)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| WS-FEC-PROCESO | WS-FEC-PROCESO | Alphanumerico | 8 | Fecha de proceso en formato AAAAMMDD. Se toma de SDB-PRM-FECHA-PROCESO si viene informada; de lo contrario se obtiene del sistema operativo. | Si | Fecha del sistema | Sirve de base para todas las fechas que se pasan a DB2 y a las subrutinas. | Si | Operacional |
| WS-FECHA-TRAB | WS-FECHA-TRAB | Alphanumerico | 8 | Copia de WS-FEC-PROCESO que se descompone en anio, mes y dia para construir WS-FECHA-ISO. | No | N/A | Se redefine como WS-FECHA-TRAB-N. | No | Operacional |
| WS-FT-ANIO | WS-FT-ANIO | Alphanumerico | 4 | Anio de la fecha de trabajo (posiciones 1 a 4 de WS-FECHA-TRAB). | No | N/A | Subgrupo de WS-FECHA-TRAB-N. | No | Operacional |
| WS-FT-MES | WS-FT-MES | Alphanumerico | 2 | Mes de la fecha de trabajo (posiciones 5 y 6 de WS-FECHA-TRAB). | No | N/A | Subgrupo de WS-FECHA-TRAB-N. | No | Operacional |
| WS-FT-DIA | WS-FT-DIA | Alphanumerico | 2 | Dia de la fecha de trabajo (posiciones 7 y 8 de WS-FECHA-TRAB). | No | N/A | Subgrupo de WS-FECHA-TRAB-N. | No | Operacional |
| WS-FECHA-ISO | WS-FECHA-ISO | Group (record) | 10 | Fecha de proceso en formato ISO (AAAA-MM-DD) para uso en columnas DATE de DB2. | Si | N/A | Se construye copiando WS-FT-ANIO, WS-FT-MES y WS-FT-DIA con guiones intercalados como literales. | Si | Operacional |
| WS-FI-ANIO | WS-FI-ANIO | Alphanumerico | 4 | Anio de la fecha ISO (posiciones 1 a 4). | No | N/A | Subgrupo de WS-FECHA-ISO. | No | Operacional |
| WS-FI-MES | WS-FI-MES | Alphanumerico | 2 | Mes de la fecha ISO (posiciones 6 y 7). | No | N/A | Subgrupo de WS-FECHA-ISO. | No | Operacional |
| WS-FI-DIA | WS-FI-DIA | Alphanumerico | 2 | Dia de la fecha ISO (posiciones 9 y 10). | No | N/A | Subgrupo de WS-FECHA-ISO. | No | Operacional |

---

### Calculo del costo (WS-CALCULO-COSTO)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| WS-CANT-PREVIAS | WS-CANT-PREVIAS | Numerico decimal empaquetado con signo | 5 enteros | Cantidad total de chequeras que la cuenta ya tiene registradas en CHQ_CHEQUERA (cualquier estado). Se usa para determinar si aplica la gratuidad. | No | 0 | Si es cero, la primera chequera de la solicitud es gratuita. | Si | Negocio |
| WS-CANT-VIGENTES | WS-CANT-VIGENTES | Numerico decimal empaquetado con signo | 5 enteros | Cantidad de chequeras de la cuenta en estado 'EM' (emitida) o 'EN' (entregada). Se usa para validar el limite de 2 chequeras vigentes. | No | 0 | N/A | Si | Negocio |
| WS-CANT-GRATIS | WS-CANT-GRATIS | Numerico decimal empaquetado con signo | 3 enteros | Cantidad de chequeras gratuitas dentro de la solicitud actual. Puede ser 0 o 1. Es 1 solo si WS-CANT-PREVIAS es 0. | No | 0 | N/A | Si | Financiero |
| WS-CANT-PAGADAS | WS-CANT-PAGADAS | Numerico decimal empaquetado con signo | 3 enteros | Cantidad de chequeras de la solicitud que tienen costo: HV-CANT-CHEQUERAS menos WS-CANT-GRATIS. | No | N/A | Resultado de: HV-CANT-CHEQUERAS - WS-CANT-GRATIS. | Si | Financiero |
| WS-COSTO-UNITARIO | WS-COSTO-UNITARIO | Numerico decimal empaquetado con signo | 9 enteros, 2 decimales | Costo unitario por chequera segun la moneda de la cuenta: WS-COSTO-CHQRA-PEN si es soles, WS-COSTO-CHQRA-USD si es dolares. | No | N/A | N/A | Si | Financiero |
| WS-COSTO-BASE | WS-COSTO-BASE | Numerico decimal empaquetado con signo | 9 enteros, 2 decimales | Costo total sin IGV: WS-COSTO-UNITARIO multiplicado por WS-CANT-PAGADAS. | No | N/A | N/A | Si | Financiero |
| WS-COSTO-IGV | WS-COSTO-IGV | Numerico decimal empaquetado con signo | 9 enteros, 2 decimales | Importe del IGV: WS-COSTO-BASE multiplicado por CHQ-PCT-IGV (0.18). Se redondea con la regla ROUNDED del compilador. | No | N/A | Tasa de IGV definida en CHQCONW como constante 0.18. | Si | Financiero |
| WS-COSTO-TOTAL | WS-COSTO-TOTAL | Numerico decimal empaquetado con signo | 9 enteros, 2 decimales | Importe total a cobrar: WS-COSTO-BASE + WS-COSTO-IGV. Es el importe que se pasa a SDMPOSTA. | No | N/A | Si es cero (primera chequera gratuita y solo se solicita una), no se llama a SDMPOSTA. | Si | Financiero |

---

### Numeracion de chequeras y cheques (WS-NUMERACION)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| WS-NUM-CHEQUE-ACT | WS-NUM-CHEQUE-ACT | Numerico decimal empaquetado con signo | 8 enteros | Ultimo numero de cheque asignado en la sesion. Se inicializa con el maximo existente en CHQ_CHEQUE para la cuenta y se incrementa en 1 por cada hoja generada. | No | 0 | Garantiza la correlatividad de la numeracion de cheques dentro de la cuenta. | Si | Negocio |
| WS-NUM-CHEQUERA-ACT | WS-NUM-CHEQUERA-ACT | Numerico decimal empaquetado con signo | 9 enteros | No se usa en la logica activa del programa (el numero de chequera se calcula directamente en HV-NUM-CHEQUERA). | No | 0 | Campo declarado pero sin uso activo. Puede eliminarse en la modernizacion. | No | N/A |
| WS-IND-CHEQUERA | WS-IND-CHEQUERA | Numerico decimal empaquetado con signo | 3 enteros | Indice del bucle de generacion de chequeras. Recorre desde 1 hasta HV-CANT-CHEQUERAS. | No | 0 | N/A | No | Control |
| WS-IND-HOJA | WS-IND-HOJA | Numerico decimal empaquetado con signo | 3 enteros | Indice del bucle de generacion de hojas dentro de una chequera. Recorre desde 1 hasta CHQ-HOJAS-CHEQUERA (25). | No | 0 | N/A | No | Control |
| WS-NUM-INICIAL | WS-NUM-INICIAL | Numerico decimal empaquetado con signo | 8 enteros | Primer numero de cheque de la chequera en curso. No se usa directamente; el calculo equivalente se hace en HV-NUM-INICIAL. | No | 0 | Campo declarado pero sin uso activo. Puede eliminarse. | No | N/A |
| WS-NUM-FINAL | WS-NUM-FINAL | Numerico decimal empaquetado con signo | 8 enteros | Ultimo numero de cheque de la chequera en curso. No se usa directamente; el calculo equivalente se hace en HV-NUM-FINAL. | No | 0 | Campo declarado pero sin uso activo. Puede eliminarse. | No | N/A |
| WS-IND-GRATUITA | WS-IND-GRATUITA | Alphanumerico | 1 | Indicador auxiliar de gratuidad. No se usa directamente; la logica activa usa HV-IND-GRATUITA. | No | 'N' | Campo declarado pero sin uso activo. | No | N/A |

---

### Variables auxiliares de presentacion

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| WS-NUM-SOL-DISP | WS-NUM-SOL-DISP | Numerico sin signo | 9 | Copia editable de HV-NUM-SOLICITUD para uso en mensajes de DISPLAY, en la glosa del posteo y en la clave del checkpoint. | No | 0 | N/A | No | Auditoria |
| WS-CANT-DISP | WS-CANT-DISP | Numerico sin signo | 2 | Copia de HV-CANT-CHEQUERAS para insertar en el campo NTF-PARAMETROS antes de llamar a NTFENCOL. | No | 0 | N/A | No | Operacional |

---

### Variables host para DB2 (WS-HOST-VARIABLES)

Estas variables son los parametros de intercambio entre el programa y las sentencias SQL embebidas. Sus valores se toman de las tablas CHQ_SOLICITUD, CHQ_CHEQUERA y CHQ_CHEQUE, o se construyen en el programa para insertar o actualizar dichas tablas.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| HV-NUM-SOLICITUD | HV-NUM-SOLICITUD | Numerico decimal empaquetado con signo | 9 enteros | Numero identificador de la solicitud de chequera. Clave primaria de CHQ_SOLICITUD. Se obtiene del cursor CUR_SOLIC. | Si | N/A | Se usa como clave en los UPDATE de CHQ_SOLICITUD y como referencia en el posteo. | Si | Negocio |
| HV-CUENTA | HV-CUENTA | Alphanumerico | 14 | Numero de cuenta corriente asociada a la solicitud. Se obtiene del cursor CUR_SOLIC. | Si | N/A | Se usa como clave en todas las consultas e inserciones de CHQ_CHEQUERA y CHQ_CHEQUE, y como entrada a SDCMAEST y SDMPOSTA. | Si | Negocio |
| HV-CANT-CHEQUERAS | HV-CANT-CHEQUERAS | Numerico binario con signo | 4 enteros | Cantidad de chequeras solicitadas en la solicitud. Debe estar entre 1 y CHQ-MAX-CHEQ-X-SOLIC (3). | Si | N/A | Controla el numero de iteraciones del bucle de generacion de chequeras. | Si | Negocio |
| HV-FEC-SOLICITUD | HV-FEC-SOLICITUD | Alphanumerico | 10 | Fecha en que se origino la solicitud, en formato ISO (AAAA-MM-DD). Se obtiene del cursor CUR_SOLIC. | No | N/A | Se usa solo informativamente; no interviene en calculos. | No | Operacional |
| HV-CANAL | HV-CANAL | Alphanumerico | 2 | Canal por el que se origino la solicitud (por ejemplo, 'WE' para web, 'VE' para ventanilla). Se obtiene del cursor CUR_SOLIC. | No | N/A | N/A | No | Operacional |
| HV-USUARIO | HV-USUARIO | Alphanumerico | 8 | Usuario que registro la solicitud. Se obtiene del cursor CUR_SOLIC. | No | N/A | N/A | No | Auditoria |
| HV-COD-RECHAZO | HV-COD-RECHAZO | Alphanumerico | 2 | Codigo de motivo de rechazo que se graba en CHQ_SOLICITUD cuando la solicitud no puede procesarse. Valores posibles: '10' (cuenta no existe), '20' (no es cuenta corriente), '30' (cuenta no activa), '40' (excede limite de vigentes), '50' (cantidad invalida), '60' (saldo insuficiente), '90' (error tecnico). | No | Espacios | Se inicializa a espacios al comienzo de cada solicitud. | Si | Negocio |
| HV-FEC-PROCESO | HV-FEC-PROCESO | Alphanumerico | 10 | Fecha de proceso en formato ISO (AAAA-MM-DD). Se construye a partir de WS-FEC-PROCESO y se usa en los INSERT y UPDATE de CHQ_SOLICITUD y CHQ_CHEQUERA. | Si | N/A | N/A | Si | Operacional |
| HV-COSTO-BASE | HV-COSTO-BASE | Numerico decimal empaquetado con signo | 9 enteros, 2 decimales | Costo sin IGV que se graba en la columna MON_COSTO_BASE de CHQ_SOLICITUD al actualizar la solicitud a estado 'EM'. | No | N/A | Copia de WS-COSTO-BASE. | Si | Financiero |
| HV-COSTO-IGV | HV-COSTO-IGV | Numerico decimal empaquetado con signo | 9 enteros, 2 decimales | Importe del IGV que se graba en la columna MON_IGV de CHQ_SOLICITUD. | No | N/A | Copia de WS-COSTO-IGV. | Si | Financiero |
| HV-COSTO-TOTAL | HV-COSTO-TOTAL | Numerico decimal empaquetado con signo | 9 enteros, 2 decimales | Importe total (base + IGV) que se graba en la columna MON_COSTO_TOTAL de CHQ_SOLICITUD. | No | N/A | Copia de WS-COSTO-TOTAL. | Si | Financiero |
| HV-NUM-REINICIO | HV-NUM-REINICIO | Numerico decimal empaquetado con signo | 9 enteros | Numero de solicitud a partir del cual se reanuda el procesamiento tras un reinicio por checkpoint. El cursor CUR_SOLIC filtra solicitudes con NUM_SOLICITUD mayor que este valor. | No | 0 | Si BCTCHECK no devuelve punto de reinicio, permanece en 0 y el cursor procesa todas las solicitudes pendientes. | Si | Control |
| HV-NUM-CHEQUERA | HV-NUM-CHEQUERA | Numerico decimal empaquetado con signo | 9 enteros | Numero correlativo global de la nueva chequera. Se calcula como el maximo actual en CHQ_CHEQUERA mas 1. | Si | N/A | N/A | Si | Negocio |
| HV-NUM-INICIAL | HV-NUM-INICIAL | Numerico decimal empaquetado con signo | 8 enteros | Primer numero de cheque de la chequera: WS-NUM-CHEQUE-ACT + 1 antes de generar las hojas. Se graba en CHQ_CHEQUERA.NUM_INICIAL. | Si | N/A | N/A | Si | Negocio |
| HV-NUM-FINAL | HV-NUM-FINAL | Numerico decimal empaquetado con signo | 8 enteros | Ultimo numero de cheque de la chequera: WS-NUM-CHEQUE-ACT + CHQ-HOJAS-CHEQUERA (25). Se graba en CHQ_CHEQUERA.NUM_FINAL. | Si | N/A | N/A | Si | Negocio |
| HV-NUM-CHEQUE | HV-NUM-CHEQUE | Numerico decimal empaquetado con signo | 8 enteros | Numero del cheque individual que se esta insertando en CHQ_CHEQUE. Se incrementa en 1 en cada iteracion del bucle de hojas. | Si | N/A | N/A | Si | Negocio |
| HV-MAX-CHEQUE | HV-MAX-CHEQUE | Numerico decimal empaquetado con signo | 8 enteros | Maximo numero de cheque existente en CHQ_CHEQUE para la cuenta. Se obtiene con MAX(NUM_CHEQUE) antes de generar las chequeras de la solicitud. Si no hay cheques previos, COALESCE devuelve 0. | No | 0 (via COALESCE) | N/A | Si | Negocio |
| HV-MAX-CHEQUERA | HV-MAX-CHEQUERA | Numerico decimal empaquetado con signo | 9 enteros | Maximo numero de chequera existente en CHQ_CHEQUERA (sin filtro de cuenta). Se obtiene con MAX(NUM_CHEQUERA) antes de insertar cada nueva chequera. Si no hay chequeras, COALESCE devuelve 0. | No | 0 (via COALESCE) | El numero de chequera es global, no por cuenta. | Si | Negocio |
| HV-IND-GRATUITA | HV-IND-GRATUITA | Alphanumerico | 1 | Indicador de gratuidad de la chequera que se esta insertando. Valor 'S' si es la primera chequera de la primera solicitud de la cuenta; 'N' en cualquier otro caso. Se graba en CHQ_CHEQUERA.IND_GRATUITA. | Si | N/A | Solo puede ser 'S' cuando WS-IND-CHEQUERA = 1 y WS-CANT-GRATIS = 1. | Si | Negocio |
| HV-MONEDA | HV-MONEDA | Alphanumerico | 3 | Codigo de moneda de la cuenta corriente, obtenido de SDCMAEST (SDC-MAE-CTA-MONEDA). Valores del sistema: '604' para soles, '840' para dolares. Se graba en CHQ_CHEQUERA.COD_MONEDA. | Si | N/A | N/A | Si | Negocio |
| HV-CONTEO | HV-CONTEO | Numerico binario con signo | 9 enteros | Variable auxiliar para recibir resultados de COUNT(*) en las consultas de conteo de chequeras. Se copia a WS-CANT-PREVIAS o WS-CANT-VIGENTES segun el contexto. | No | N/A | N/A | No | Control |

---

### Tarjeta de parametros del JCL (copybook SDBPARMW - SDB-PARM-AREA)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| SDB-PARM-TARJETA | SDB-PARM-TARJETA | Alphanumerico | 80 | Registro completo de la tarjeta de parametros leida de SYSIN al inicio del programa. | Si | N/A | Debe tener exactamente 80 bytes segun la advertencia del copybook. | Si | Configuracion |
| SDB-PRM-FECHA-PROCESO | SDB-PRM-FECHA-PROCESO | Alphanumerico | 8 | Fecha de proceso en formato AAAAMMDD. Si viene en blanco, el programa usa la fecha del sistema operativo. | No | Espacios | Posiciones 1 a 8 de SDB-PARM-TARJETA. | Si | Configuracion |
| SDB-PRM-MODO | SDB-PRM-MODO | Alphanumerico | 1 | Modo de ejecucion. 'S' activa el modo simulacion (SW-SIMULA = 'S'). Los valores documentados son P=Produccion, S=Simulacion, R=Reproceso. | No | N/A | Posicion 9 de SDB-PARM-TARJETA. Solo 'S' tiene efecto en CHQCHEQR. | Si | Configuracion |
| SDB-PRM-TIPO-CORRIDA | SDB-PRM-TIPO-CORRIDA | Alphanumerico | 2 | Tipo de corrida (DI=Diaria, ME=Mensual, SE=Semestral, EV=Eventual). No se usa en la logica de CHQCHEQR. | No | N/A | Posiciones 10 y 11. | No | Configuracion |
| SDB-PRM-PRODUCTO | SDB-PRM-PRODUCTO | Alphanumerico | 2 | Filtro de producto. No se usa en CHQCHEQR. | No | N/A | N/A | No | Configuracion |
| SDB-PRM-MONEDA | SDB-PRM-MONEDA | Alphanumerico | 3 | Filtro de moneda. No se usa en CHQCHEQR. | No | N/A | N/A | No | Configuracion |
| SDB-PRM-AGENCIA-DESDE | SDB-PRM-AGENCIA-DESDE | Alphanumerico | 3 | Agencia inicial del rango. No se usa en CHQCHEQR. | No | N/A | N/A | No | Configuracion |
| SDB-PRM-AGENCIA-HASTA | SDB-PRM-AGENCIA-HASTA | Alphanumerico | 3 | Agencia final del rango. No se usa en CHQCHEQR. | No | N/A | N/A | No | Configuracion |
| SDB-PRM-PERIODO | SDB-PRM-PERIODO | Alphanumerico | 6 | Periodo de proceso (AAAAMM o AAAASS). No se usa en CHQCHEQR. | No | N/A | N/A | No | Configuracion |
| SDB-PRM-COD-EMPRESA | SDB-PRM-COD-EMPRESA | Alphanumerico | 11 | Codigo de empresa. No se usa directamente en CHQCHEQR; se pasa a SDMPOSTA via POS-EMPRESA con valor fijo 1. | No | N/A | N/A | No | Configuracion |
| SDB-PRM-IND-DETALLE | SDB-PRM-IND-DETALLE | Alphanumerico | 1 | Indicador de nivel de detalle en salida. No se usa en CHQCHEQR. | No | N/A | N/A | No | Configuracion |
| SDB-PRM-IND-REIMPRIME | SDB-PRM-IND-REIMPRIME | Alphanumerico | 1 | Indicador de reimpresion. No se usa en CHQCHEQR. | No | N/A | N/A | No | Configuracion |
| SDB-PRM-IND-COMMIT | SDB-PRM-IND-COMMIT | Alphanumerico | 1 | Indicador de commit. No se usa en CHQCHEQR (el commit lo controla BCTCHECK). | No | N/A | N/A | No | Configuracion |
| SDB-PRM-FREC-COMMIT | SDB-PRM-FREC-COMMIT | Numerico sin signo | 5 | Frecuencia de commit. No se usa en CHQCHEQR. | No | N/A | N/A | No | Configuracion |
| SDB-PRM-LIM-REGISTROS | SDB-PRM-LIM-REGISTROS | Numerico sin signo | 7 | Limite de registros a procesar. No se usa en CHQCHEQR. | No | N/A | N/A | No | Configuracion |
| SDB-PRM-USUARIO | SDB-PRM-USUARIO | Alphanumerico | 8 | Usuario que lanza el proceso. No se usa en CHQCHEQR. | No | N/A | N/A | No | Configuracion |

---

### Interfaz de checkpoint (copybook BCTIFCW - BCT-AREA-CHECK)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| BCT-FUNCION | BCT-FUNCION | Alphanumerico | 2 | Funcion a ejecutar en BCTCHECK. Valores usados por CHQCHEQR: 'RS' (leer punto de reinicio al inicio), 'CK' (grabar checkpoint periodico), 'FN' (marcar proceso finalizado al cierre). | Si | N/A | N/A | Si | Control |
| BCT-PROGRAMA | BCT-PROGRAMA | Alphanumerico | 8 | Nombre del programa que llama a BCTCHECK. Se informa con WS-NOM-PROGRAMA ('CHQCHEQR'). | Si | N/A | N/A | No | Control |
| BCT-FEC-PROCESO | BCT-FEC-PROCESO | Numerico sin signo | 8 | Fecha de proceso en formato AAAAMMDD. Junto con BCT-PROGRAMA forma la clave del registro en BCT_CHECKPOINT. | Si | N/A | N/A | Si | Control |
| BCT-CLAVE-ULT | BCT-CLAVE-ULT | Alphanumerico | 40 | Clave del ultimo registro procesado antes del checkpoint. CHQCHEQR almacena en los primeros 9 bytes el numero de solicitud (HV-NUM-SOLICITUD). Al reiniciar, este valor se copia a HV-NUM-REINICIO. | No | Espacios | Solo los primeros 9 caracteres tienen significado para CHQCHEQR. | Si | Control |
| BCT-CONTADOR | BCT-CONTADOR | Numerico decimal empaquetado con signo | 9 enteros | Contador de registros procesados hasta el checkpoint. CHQCHEQR informa WS-CNT-LEIDAS. | No | N/A | N/A | No | Control |
| BCT-COD-RETORNO | BCT-COD-RETORNO | Numerico sin signo | 4 | Codigo de retorno de BCTCHECK. 0000 = OK (con punto de reinicio activo en 'RS'); 0004 = ya finalizado; 0008 = sin checkpoint previo; 0012 = dato invalido; 0016 = checkpoint finalizado no admite 'CK'; 0090 = error DB2. | Si | N/A | N/A | Si | Control |
| BCT-MENSAJE | BCT-MENSAJE | Alphanumerico | 60 | Mensaje descriptivo devuelto por BCTCHECK. | No | N/A | N/A | No | Control |

---

### Interfaz de notificaciones (copybook NTFIFCW - NTF-AREA-ENCOLA)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| NTF-FUNCION | NTF-FUNCION | Alphanumerico | 2 | Funcion a ejecutar en NTFENCOL. CHQCHEQR siempre informa 'EN' (encolar notificacion). | Si | N/A | N/A | Si | Control |
| NTF-CANAL | NTF-CANAL | Alphanumerico | 2 | Canal de envio de la notificacion. CHQCHEQR informa 'SM' (SMS). Valores validos: 'SM'=SMS, 'EM'=correo, 'PU'=push. | Si | N/A | N/A | Si | Operacional |
| NTF-COD-PLANTILLA | NTF-COD-PLANTILLA | Alphanumerico | 6 | Codigo de la plantilla del mensaje. CHQCHEQR informa 'CHQ001'. La plantilla debe existir en NTF_PLANTILLA, estar activa y corresponder al canal 'SM'. | Si | N/A | N/A | Si | Operacional |
| NTF-COD-UNICO | NTF-COD-UNICO | Alphanumerico | 10 | Codigo unico del titular de la cuenta (SDC-MAE-TIT-CODIGO-UNICO). Identifica al destinatario de la notificacion. | Si | N/A | N/A | Si | Negocio |
| NTF-PARAMETROS | NTF-PARAMETROS | Alphanumerico | 100 | Valores de sustitucion para las variables {1} y {2} de la plantilla, separados por '|'. CHQCHEQR construye: cantidad de chequeras (WS-CANT-DISP, 2 caracteres) + '|' + numero de solicitud (WS-NUM-SOL-DISP, 9 caracteres). | No | Espacios | N/A | Si | Operacional |
| NTF-PRIORIDAD | NTF-PRIORIDAD | Numerico sin signo | 1 | Prioridad de envio: 1 (urgente) a 5 (baja). Cero = usar la prioridad por defecto de la plantilla. CHQCHEQR informa 5. | No | N/A | N/A | No | Operacional |
| NTF-COD-RETORNO | NTF-COD-RETORNO | Numerico sin signo | 4 | Codigo de retorno de NTFENCOL. 0000 = OK; 0004 = encolada con advertencia; 0008 = plantilla no existe; 0012 = dato invalido; 0016 = plantilla inactiva; 0032 = clave duplicada; 0090 = error DB2; 0092 = error VSAM. Un retorno distinto de 0000 solo genera un aviso en el log; no revierte la emision. | No | N/A | N/A | Si | Control |
| NTF-MENSAJE | NTF-MENSAJE | Alphanumerico | 60 | Mensaje descriptivo devuelto por NTFENCOL. | No | N/A | N/A | No | Control |

---

### Interfaz del maestro de cuentas (copybook SDCMAEW - SDC-AREA-MAESTRO)

Solo se listan los campos que CHQCHEQR lee o utiliza activamente.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| SDC-MAE-FUNCION | SDC-MAE-FUNCION | Alphanumerico | 2 | Funcion solicitada a SDCMAEST. CHQCHEQR siempre informa 'LE' (lectura sin bloqueo). | Si | N/A | N/A | Si | Control |
| SDC-MAE-COD-RETORNO | SDC-MAE-COD-RETORNO | Alphanumerico | 2 | Codigo de retorno de SDCMAEST. '00' = cuenta encontrada y datos devueltos. Cualquier otro valor indica que la cuenta no existe o hay error, y la solicitud se rechaza con codigo '10'. | Si | N/A | Corresponde a SDU-RC-OK ('00') del copybook SDUCONST. | Si | Control |
| SDC-MAE-CTA-NUMERO | SDC-MAE-CTA-NUMERO | Alphanumerico | 14 | Numero de cuenta a consultar. CHQCHEQR informa HV-CUENTA. | Si | N/A | N/A | Si | Negocio |
| SDC-MAE-CTA-PRODUCTO | SDC-MAE-CTA-PRODUCTO | Alphanumerico | 2 | Codigo de producto de la cuenta. Debe ser '06' (SDU-PROD-CORRIENTE) para que la solicitud sea valida. Si no lo es, se rechaza con codigo '20'. | Si | N/A | N/A | Si | Negocio |
| SDC-MAE-CTA-MONEDA | SDC-MAE-CTA-MONEDA | Alphanumerico | 3 | Codigo de moneda de la cuenta ('604' = soles, '840' = dolares). Se copia a HV-MONEDA y determina el costo unitario de la chequera. | Si | N/A | N/A | Si | Negocio |
| SDC-MAE-CTA-ESTADO | SDC-MAE-CTA-ESTADO | Alphanumerico | 2 | Estado de la cuenta. Debe ser 'AC' (SDU-EST-ACTIVA) para que la solicitud sea valida. Si no lo es, se rechaza con codigo '30'. | Si | N/A | N/A | Si | Negocio |
| SDC-MAE-TIT-CODIGO-UNICO | SDC-MAE-TIT-CODIGO-UNICO | Alphanumerico | 10 | Codigo unico del titular de la cuenta. Se usa como NTF-COD-UNICO al encolar la notificacion al cliente. | Si | N/A | N/A | Si | Negocio |

---

### Interfaz del motor de posteo (copybook SDMPOSTW - AREA-POSTEO)

Solo se listan los campos que CHQCHEQR informa como entrada o lee como salida.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| POS-EMPRESA | POS-EMPRESA | Numerico sin signo | 3 | Codigo de empresa. CHQCHEQR informa el valor fijo 1. | Si | N/A | N/A | Si | Negocio |
| POS-CUENTA | POS-CUENTA | Alphanumerico | 20 | Numero de cuenta a debitar. CHQCHEQR informa HV-CUENTA (14 caracteres, alineado a la izquierda). | Si | N/A | N/A | Si | Negocio |
| POS-PRODUCTO | POS-PRODUCTO | Alphanumerico | 2 | Codigo de producto de la cuenta. CHQCHEQR informa SDC-MAE-CTA-PRODUCTO. | Si | N/A | N/A | No | Negocio |
| POS-MONEDA | POS-MONEDA | Numerico sin signo | 3 | Codigo de moneda. CHQCHEQR informa SDC-MAE-CTA-MONEDA. | Si | N/A | N/A | Si | Negocio |
| POS-TIPO-OPERACION | POS-TIPO-OPERACION | Alphanumerico | 4 | Tipo de operacion. CHQCHEQR informa SDU-OP-COBRO-COMISION ('060'). | Si | N/A | N/A | Si | Negocio |
| POS-SIGNO | POS-SIGNO | Alphanumerico | 1 | Signo del movimiento. CHQCHEQR informa 'D' (debito / cargo). | Si | N/A | N/A | Si | Negocio |
| POS-IMPORTE | POS-IMPORTE | Numerico decimal empaquetado con signo | 13 enteros, 2 decimales | Importe a cobrar: WS-COSTO-TOTAL (base + IGV). | Si | N/A | N/A | Si | Financiero |
| POS-FECHA-PROCESO | POS-FECHA-PROCESO | Numerico sin signo | 8 | Fecha de proceso en formato AAAAMMDD. | Si | N/A | N/A | Si | Operacional |
| POS-FECHA-VALOR | POS-FECHA-VALOR | Numerico sin signo | 8 | Fecha valor. CHQCHEQR informa la misma fecha de proceso. | Si | N/A | N/A | No | Operacional |
| POS-CANAL | POS-CANAL | Alphanumerico | 3 | Canal de la operacion. CHQCHEQR informa SDU-CAN-BATCH ('BA'). | Si | N/A | N/A | No | Operacional |
| POS-SUCURSAL | POS-SUCURSAL | Numerico sin signo | 4 | Sucursal. CHQCHEQR informa 0. | No | 0 | N/A | No | Operacional |
| POS-TERMINAL | POS-TERMINAL | Alphanumerico | 8 | Terminal. CHQCHEQR informa WS-NOM-PROGRAMA ('CHQCHEQR'). | No | N/A | N/A | No | Auditoria |
| POS-USUARIO | POS-USUARIO | Alphanumerico | 8 | Usuario que origina el posteo. CHQCHEQR informa 'BATCH'. | Si | N/A | N/A | No | Auditoria |
| POS-SUPERVISOR | POS-SUPERVISOR | Alphanumerico | 8 | Supervisor. CHQCHEQR informa espacios. | No | Espacios | N/A | No | Auditoria |
| POS-GLOSA | POS-GLOSA | Alphanumerico | 40 | Descripcion del movimiento. CHQCHEQR construye 'COSTO CHEQUERA SOLIC ' seguido del numero de solicitud (9 digitos en posiciones 22 a 30). | No | N/A | N/A | Si | Auditoria |
| POS-REFERENCIA | POS-REFERENCIA | Alphanumerico | 20 | Referencia del movimiento. CHQCHEQR informa el numero de solicitud (WS-NUM-SOL-DISP). | No | N/A | N/A | Si | Auditoria |
| POS-DOC-TIPO | POS-DOC-TIPO | Alphanumerico | 2 | Tipo de documento. CHQCHEQR informa 'CQ'. | No | N/A | N/A | No | Operacional |
| POS-DOC-NUMERO | POS-DOC-NUMERO | Alphanumerico | 15 | Numero de documento. CHQCHEQR informa el numero de solicitud. | No | N/A | N/A | No | Operacional |
| POS-LOTE | POS-LOTE | Numerico sin signo | 6 | Numero de lote. CHQCHEQR informa 0. | No | 0 | N/A | No | Operacional |
| POS-BATCH-ID | POS-BATCH-ID | Alphanumerico | 8 | Identificador del job batch. CHQCHEQR informa 'CHQJD010'. | No | N/A | N/A | No | Operacional |
| POS-IND-FORZAR | POS-IND-FORZAR | Alphanumerico | 1 | Indicador de forzado (omitir validacion de saldo). CHQCHEQR informa 'N'. | Si | N/A | N/A | Si | Control |
| POS-IND-EXONERA-ITF | POS-IND-EXONERA-ITF | Alphanumerico | 1 | Indicador de exoneracion de ITF. CHQCHEQR informa 'N'. | Si | N/A | N/A | Si | Control |
| POS-IND-SOLO-VALIDA | POS-IND-SOLO-VALIDA | Alphanumerico | 1 | Si es 'S', SDMPOSTA solo valida sin registrar el movimiento. CHQCHEQR informa 'S' en modo simulacion y 'N' en produccion. | Si | N/A | N/A | Si | Control |
| POS-COD-RETORNO | POS-COD-RETORNO | Numerico sin signo | 4 | Codigo de retorno de SDMPOSTA. 0000 = posteo exitoso. 0040 (POS-SALDO-INSUF) = saldo insuficiente, genera rechazo con codigo '60'. Cualquier otro valor distinto de 0000 genera rechazo con codigo '90' y log de error. | Si | N/A | N/A | Si | Control |
| POS-MENSAJE | POS-MENSAJE | Alphanumerico | 70 | Mensaje descriptivo devuelto por SDMPOSTA en caso de error. | No | N/A | N/A | No | Control |

---

### Interfaz del logger (copybook SDULOGW - SDU-AREA-LOG)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| SDU-LG-NIVEL | SDU-LG-NIVEL | Alphanumerico | 1 | Nivel de severidad del registro. CHQCHEQR informa 'E' (error) en todos sus registros de log. Valores posibles: 'I'=informativo, 'A'=advertencia, 'E'=error, 'F'=fatal, 'D'=debug. | Si | N/A | N/A | Si | Auditoria |
| SDU-LG-PROGRAMA | SDU-LG-PROGRAMA | Alphanumerico | 8 | Nombre del programa que genera el registro. CHQCHEQR informa WS-NOM-PROGRAMA. | Si | N/A | N/A | No | Auditoria |
| SDU-LG-PARRAFO | SDU-LG-PARRAFO | Alphanumerico | 20 | Nombre del parrafo donde se detecto el error. Se toma de WS-PARRAFO-ACT. | No | N/A | N/A | No | Auditoria |
| SDU-LG-COD-ERROR | SDU-LG-COD-ERROR | Alphanumerico | 6 | Codigo de error interno. Se toma de WS-COD-ERROR. | No | N/A | N/A | Si | Auditoria |
| SDU-LG-GLOSA | SDU-LG-GLOSA | Alphanumerico | 120 | Descripcion del error. Se toma de WS-GLOSA-ERROR. | No | N/A | N/A | Si | Auditoria |
| SDU-LG-CUENTA | SDU-LG-CUENTA | Alphanumerico | 14 | Numero de cuenta asociada al error. Se toma de HV-CUENTA. | No | N/A | N/A | No | Auditoria |
| SDU-LG-DOI | SDU-LG-DOI | Alphanumerico | 12 | Documento de identidad del titular. CHQCHEQR informa espacios (no disponible en este programa). | No | Espacios | N/A | No | Auditoria |
| SDU-LG-IMPORTE | SDU-LG-IMPORTE | Numerico decimal empaquetado con signo | 13 enteros, 2 decimales | Importe asociado al evento. CHQCHEQR informa 0. | No | 0 | N/A | No | Auditoria |
| SDU-LG-USUARIO | SDU-LG-USUARIO | Alphanumerico | 8 | Usuario que origina el evento. CHQCHEQR informa 'BATCH'. | No | N/A | N/A | No | Auditoria |
| SDU-LG-TERMINAL | SDU-LG-TERMINAL | Alphanumerico | 8 | Terminal. CHQCHEQR informa WS-NOM-PROGRAMA. | No | N/A | N/A | No | Auditoria |
| SDU-LG-CANAL | SDU-LG-CANAL | Alphanumerico | 2 | Canal. CHQCHEQR informa SDU-CAN-BATCH ('BA'). | No | N/A | N/A | No | Auditoria |
| SDU-LG-FECHA | SDU-LG-FECHA | Alphanumerico | 8 | Fecha del evento en formato AAAAMMDD. Se toma de WS-FEC-PROCESO. | No | N/A | N/A | No | Auditoria |
| SDU-LG-SQLCODE | SDU-LG-SQLCODE | Numerico binario con signo | 9 enteros | SQLCODE de DB2 en el momento del error. | No | N/A | N/A | Si | Auditoria |
| SDU-LG-COD-RETORNO | SDU-LG-COD-RETORNO | Alphanumerico | 2 | Codigo de retorno del programa en el momento del log. SDULOGER lo usa internamente para validacion. | No | N/A | N/A | No | Auditoria |

---

### Constantes del dominio de cheques (copybook CHQCONW - CHQ-CONSTANTES)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| CHQ-DIAS-PLAZO-LOCAL | CHQ-DIAS-PLAZO-LOCAL | Numerico sin signo | 3 | Plazo de presentacion de un cheque en la misma plaza: 30 dias calendario (Ley 27287). No se usa en CHQCHEQR. | N/A | 30 | Constante fija, no parametrizable. | Si | Negocio |
| CHQ-DIAS-PLAZO-PLAZA | CHQ-DIAS-PLAZO-PLAZA | Numerico sin signo | 3 | Plazo de presentacion de un cheque en otra plaza del pais: 60 dias calendario (Ley 27287). No se usa en CHQCHEQR. | N/A | 60 | Constante fija, no parametrizable. | Si | Negocio |
| CHQ-DIAS-CADUCIDAD | CHQ-DIAS-CADUCIDAD | Numerico sin signo | 3 | Dias tras los cuales un cheque caduca y no se paga sin orden expresa: 180 dias. No se usa en CHQCHEQR. | N/A | 180 | Constante fija, no parametrizable. | Si | Negocio |
| CHQ-MAX-RECHAZOS-SF | CHQ-MAX-RECHAZOS-SF | Numerico sin signo | 2 | Numero maximo de rechazos por falta de fondos en 12 meses antes de bloquear la cuenta: 3. No se usa en CHQCHEQR. | N/A | 3 | Constante fija, no parametrizable. | Si | Negocio |
| CHQ-DIAS-VENTANA-RECH | CHQ-DIAS-VENTANA-RECH | Numerico sin signo | 3 | Ventana de tiempo en dias para contar rechazos por falta de fondos: 365. No se usa en CHQCHEQR. | N/A | 365 | Constante fija, no parametrizable. | Si | Negocio |
| CHQ-HOJAS-CHEQUERA | CHQ-HOJAS-CHEQUERA | Numerico sin signo | 3 | Numero de hojas (cheques) por chequera: 25. Se usa en CHQCHEQR para calcular HV-NUM-FINAL y controlar el bucle de generacion de hojas. | Si | 25 | Constante fija. Fue 50 hasta 1999. | Si | Negocio |
| CHQ-MAX-CHEQ-PENDIENTES | CHQ-MAX-CHEQ-PENDIENTES | Numerico sin signo | 1 | Maximo de chequeras vigentes (estado 'EM' o 'EN') permitidas por cuenta al mismo tiempo: 2. Se usa en la validacion RN-CHQ-02. | Si | 2 | Constante fija, no parametrizable. | Si | Negocio |
| CHQ-MAX-CHEQ-X-SOLIC | CHQ-MAX-CHEQ-X-SOLIC | Numerico sin signo | 1 | Maximo de chequeras que se pueden solicitar en una sola solicitud: 3. Se usa en la validacion RN-CHQ-03. | Si | 3 | Constante fija, no parametrizable. | Si | Negocio |
| CHQ-COD-BANCO-PROPIO | CHQ-COD-BANCO-PROPIO | Alphanumerico | 3 | Codigo del banco propio: '049'. No se usa en CHQCHEQR. | N/A | '049' | N/A | No | Configuracion |
| CHQ-PCT-IGV | CHQ-PCT-IGV | Numerico sin signo | 1 entero, 2 decimales | Tasa del IGV aplicada al costo de la chequera: 0.18 (18%). Se usa en el calculo WS-COSTO-IGV = WS-COSTO-BASE * CHQ-PCT-IGV. | Si | 0.18 | Constante fija, no parametrizable. Si la tasa cambia, requiere modificacion del copybook. | Si | Financiero |
| CHQ-DIAS-VIG-GERENCIA | CHQ-DIAS-VIG-GERENCIA | Numerico sin signo | 3 | Dias de vigencia del cheque de gerencia: 180. No se usa en CHQCHEQR. | N/A | 180 | N/A | No | Negocio |

---

### Constantes del sistema SIDEP (copybook SDUCONST - seleccion de campos usados en CHQCHEQR)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| SDU-PROD-CORRIENTE | SDU-PROD-CORRIENTE | Alphanumerico | 2 | Codigo del producto cuenta corriente: '06'. Se usa para validar que la cuenta de la solicitud sea de este tipo. | Si | '06' | N/A | Si | Negocio |
| SDU-MON-SOLES | SDU-MON-SOLES | Alphanumerico | 3 | Codigo ISO de moneda soles: '604'. Se usa para determinar si se aplica el costo en PEN o en USD. | Si | '604' | N/A | Si | Negocio |
| SDU-EST-ACTIVA | SDU-EST-ACTIVA | Alphanumerico | 2 | Estado de cuenta activa: 'AC'. Se usa para validar que la cuenta este activa antes de emitir. | Si | 'AC' | N/A | Si | Negocio |
| SDU-OP-COBRO-COMISION | SDU-OP-COBRO-COMISION | Alphanumerico | 3 | Codigo de tipo de operacion cobro de comision: '060'. Se informa a SDMPOSTA como POS-TIPO-OPERACION. | Si | '060' | N/A | Si | Negocio |
| SDU-CAN-BATCH | SDU-CAN-BATCH | Alphanumerico | 2 | Codigo de canal batch: 'BA'. Se informa a SDMPOSTA y a SDULOGER. | Si | 'BA' | N/A | No | Operacional |
| SDU-RC-OK | SDU-RC-OK | Alphanumerico | 2 | Codigo de retorno estandar OK: '00'. Se usa para evaluar la respuesta de SDCMAEST. | Si | '00' | N/A | No | Control |

---

### Tablas DB2 accedidas directamente por CHQCHEQR

#### CHQ_SOLICITUD

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| NUM_SOLICITUD | NUM_SOLICITUD | Numerico | 9 enteros | Numero identificador de la solicitud. Clave primaria. Se lee via cursor y se usa como clave en los UPDATE. | Si | N/A | N/A | Si | Negocio |
| CTA_NUMERO | CTA_NUMERO | Alphanumerico | 14 | Numero de cuenta corriente asociada a la solicitud. | Si | N/A | N/A | Si | Negocio |
| CANT_CHEQUERAS | CANT_CHEQUERAS | Numerico | 4 enteros | Cantidad de chequeras solicitadas. Debe estar entre 1 y 3. | Si | N/A | N/A | Si | Negocio |
| FEC_SOLICITUD | FEC_SOLICITUD | Fecha (ISO) | 10 | Fecha en que se registro la solicitud. Se lee pero no se modifica. | Si | N/A | Se lee con la funcion CHAR(..., ISO) de DB2. | No | Operacional |
| CANAL | CANAL | Alphanumerico | 2 | Canal de origen de la solicitud. | No | N/A | N/A | No | Operacional |
| COD_USUARIO | COD_USUARIO | Alphanumerico | 8 | Usuario que registro la solicitud. | No | N/A | N/A | No | Auditoria |
| EST_SOLICITUD | EST_SOLICITUD | Alphanumerico | 2 | Estado de la solicitud. El cursor filtra por 'SO' (solicitada). Se actualiza a 'EM' (emitida) si el proceso es exitoso, o a 'RE' (rechazada) si falla. | Si | N/A | N/A | Si | Negocio |
| COD_RECHAZO | COD_RECHAZO | Alphanumerico | 2 | Codigo de motivo de rechazo. Se graba cuando EST_SOLICITUD pasa a 'RE'. | No | N/A | N/A | Si | Negocio |
| MON_COSTO_BASE | MON_COSTO_BASE | Numerico decimal | 9 enteros, 2 decimales | Costo sin IGV calculado por el proceso. Se graba al actualizar a 'EM'. | No | N/A | N/A | Si | Financiero |
| MON_IGV | MON_IGV | Numerico decimal | 9 enteros, 2 decimales | Importe del IGV calculado. Se graba al actualizar a 'EM'. | No | N/A | N/A | Si | Financiero |
| MON_COSTO_TOTAL | MON_COSTO_TOTAL | Numerico decimal | 9 enteros, 2 decimales | Importe total cobrado (base + IGV). Se graba al actualizar a 'EM'. | No | N/A | N/A | Si | Financiero |
| FEC_PROCESO | FEC_PROCESO | Fecha (ISO) | 10 | Fecha en que el proceso batch emitio o rechazo la solicitud. Se graba en ambos casos. | No | N/A | N/A | Si | Operacional |

#### CHQ_CHEQUERA

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| NUM_CHEQUERA | NUM_CHEQUERA | Numerico | 9 enteros | Numero correlativo global de la chequera. Se calcula como MAX(NUM_CHEQUERA) + 1 sobre toda la tabla. | Si | N/A | La numeracion es global, no por cuenta. | Si | Negocio |
| CTA_NUMERO | CTA_NUMERO | Alphanumerico | 14 | Numero de cuenta corriente propietaria de la chequera. | Si | N/A | N/A | Si | Negocio |
| NUM_SOLICITUD | NUM_SOLICITUD | Numerico | 9 enteros | Numero de solicitud que origino la emision. | Si | N/A | N/A | Si | Negocio |
| NUM_INICIAL | NUM_INICIAL | Numerico | 8 enteros | Primer numero de cheque de la chequera. | Si | N/A | N/A | Si | Negocio |
| NUM_FINAL | NUM_FINAL | Numerico | 8 enteros | Ultimo numero de cheque de la chequera. Siempre es NUM_INICIAL + 24. | Si | N/A | N/A | Si | Negocio |
| CANT_HOJAS | CANT_HOJAS | Numerico | N/A | Cantidad de hojas de la chequera. Siempre se inserta con el valor literal 25. | Si | 25 | Valor fijo en el INSERT. | Si | Negocio |
| EST_CHEQUERA | EST_CHEQUERA | Alphanumerico | 2 | Estado inicial de la chequera al emitirse: 'EM' (emitida). | Si | 'EM' | Valor fijo en el INSERT. | Si | Negocio |
| FEC_EMISION | FEC_EMISION | Fecha (ISO) | 10 | Fecha de emision de la chequera: HV-FEC-PROCESO. | Si | N/A | N/A | Si | Operacional |
| IND_GRATUITA | IND_GRATUITA | Alphanumerico | 1 | Indicador de gratuidad: 'S' si es la primera chequera de la primera solicitud de la cuenta; 'N' en cualquier otro caso. | Si | N/A | N/A | Si | Negocio |
| COD_MONEDA | COD_MONEDA | Alphanumerico | 3 | Codigo de moneda de la cuenta: '604' o '840'. | Si | N/A | N/A | Si | Negocio |

La tabla CHQ_CHEQUERA tambien se consulta con dos COUNT(*): el primero sin filtro de estado para obtener el total de chequeras previas de la cuenta (WS-CANT-PREVIAS), y el segundo filtrando estados 'EM' y 'EN' para obtener las vigentes (WS-CANT-VIGENTES).

#### CHQ_CHEQUE

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| CTA_NUMERO | CTA_NUMERO | Alphanumerico | 14 | Numero de cuenta propietaria del cheque. | Si | N/A | N/A | Si | Negocio |
| NUM_CHEQUE | NUM_CHEQUE | Numerico | 8 enteros | Numero correlativo del cheque dentro de la cuenta. Se incrementa secuencialmente a partir del maximo existente. | Si | N/A | N/A | Si | Negocio |
| NUM_CHEQUERA | NUM_CHEQUERA | Numerico | 9 enteros | Numero de la chequera a la que pertenece el cheque. | Si | N/A | N/A | Si | Negocio |
| EST_CHEQUE | EST_CHEQUE | Alphanumerico | 2 | Estado inicial del cheque al crearse: 'DI' (disponible). | Si | 'DI' | Valor fijo en el INSERT. | Si | Negocio |
| MON_IMPORTE | MON_IMPORTE | Numerico decimal | N/A | Importe del cheque al momento de la emision: 0 (el cheque aun no ha sido usado). | Si | 0 | Valor fijo en el INSERT. | Si | Financiero |

La tabla CHQ_CHEQUE tambien se consulta con MAX(NUM_CHEQUE) para obtener el ultimo numero asignado a la cuenta antes de generar las nuevas hojas.

## Detailed Rules

<!-- rule-start -->
### 1. Regla / Operacion - 0000-PRINCIPAL (Control Principal del Programa)
<!-- reviewed -->

_Reviewed_

El programa comienza aquí. Su única responsabilidad es orquestar la ejecución en tres fases en orden fijo:

1. Ejecuta la fase de inicio (1000-INICIO).
2. Repite la fase de procesamiento de solicitudes (2000-PROCESA-SOLICITUDES) mientras la bandera de fin de cursor no esté activa. La bandera se activa cuando no hay más solicitudes que leer o cuando ocurre un error fatal en el cursor.
3. Ejecuta la fase de cierre (8000-CIERRE).
4. Devuelve el control al sistema operativo mediante la instrucción GOBACK.

**Estado de la Regla:** Relevante para Modernización

**Algoritmo**

1. Llamar a 1000-INICIO.
2. Mientras la bandera SW-FIN-CURSOR sea distinta de 'S' (condición de nivel 88 denominada FIN-CURSOR), llamar a 2000-PROCESA-SOLICITUDES.
3. Llamar a 8000-CIERRE.
4. Terminar el programa devolviendo el control al sistema operativo (GOBACK). El programa no establece ningún código de retorno en este punto; los códigos de retorno (4 o 16) son fijados dentro de las fases de procesamiento y cierre según el resultado de la ejecución.
<!-- rule-end -->

<!-- rule-start -->
### 2. Regla / Operacion - 1000-INICIO (Inicializacion del Proceso Batch)
<!-- reviewed -->

_Reviewed_

**Rule Status:** Relevante para Modernizacion

Este bloque prepara todas las condiciones necesarias antes de comenzar a procesar solicitudes. Realiza las siguientes acciones en orden:

- Lee la tarjeta de parametros del JCL desde la entrada estandar (SYSIN). Esta tarjeta tiene 80 bytes y contiene, entre otros campos, la fecha de proceso en los primeros 8 bytes (formato AAAAMMDD) y el modo de ejecucion en el byte 9 ('S' indica simulacion).
- Si el campo de fecha de proceso de la tarjeta esta en blanco, obtiene la fecha del sistema operativo en formato AAAAMMDD y la usa como fecha de proceso. Si no esta en blanco, usa la fecha de la tarjeta.
- Si el modo de la tarjeta es 'S', activa la bandera de simulacion (SW-SIMULA = 'S'). En modo simulacion, el programa valida todo pero no escribe nada en la base de datos ni cobra nada.
- Convierte la fecha de proceso al formato ISO de DB2 (AAAA-MM-DD) llamando a 8100-FECHA-A-ISO, y guarda el resultado en HV-FEC-PROCESO para usarlo en las sentencias SQL. La conversion consiste en copiar los primeros 4 caracteres de WS-FECHA-TRAB (año) a WS-FI-ANIO, los caracteres 5-6 (mes) a WS-FI-MES y los caracteres 7-8 (dia) a WS-FI-DIA; los separadores guion son literales fijos en la estructura WS-FECHA-ISO.
- Lee los parametros de configuracion del archivo PARM/CHQPARM llamando a 1100-LEER-PARM. Si el archivo no esta disponible, el programa continua usando los valores por defecto definidos en WORKING-STORAGE: costo de chequera en soles (WS-COSTO-CHQRA-PEN) con valor 20.00, costo en dolares (WS-COSTO-CHQRA-USD) con valor 6.00, y frecuencia de checkpoint (WS-FREC-CHECKPOINT) con valor 50. La no disponibilidad del archivo no es un error; solo se muestra un mensaje informativo.
- Consulta el punto de reinicio del proceso llamando a la subrutina BCTCHECK con funcion 'RS' (leer reinicio), pasando el nombre del programa (WS-NOM-PROGRAMA = 'CHQCHEQR') en BCT-PROGRAMA, la fecha de proceso (WS-FEC-PROCESO) en BCT-FEC-PROCESO, y blancos en BCT-CLAVE-ULT. Si BCTCHECK devuelve codigo de retorno 0000 y la clave del ultimo punto (BCT-CLAVE-ULT) no esta en blanco, extrae los primeros 9 caracteres de BCT-CLAVE-ULT, los mueve a WS-NUM-SOL-DISP (campo de 9 digitos) y de ahi a HV-NUM-REINICIO. Esto hace que el cursor CUR_SOLIC, cuya clausula WHERE incluye la condicion `NUM_SOLICITUD > HV-NUM-REINICIO`, omita todas las solicitudes con numero menor o igual a ese valor, reanudando el proceso desde donde se interrumpio. Se muestra por consola un mensaje indicando el numero de solicitud desde el que se reinicia. Si BCTCHECK devuelve cualquier otro codigo (por ejemplo, 0008 indicando que no existe checkpoint previo, o 0004 indicando que el proceso ya finalizo), HV-NUM-REINICIO permanece en cero y el cursor procesa todas las solicitudes pendientes desde el inicio.
- Abre el cursor CUR_SOLIC sobre la tabla CHQ_SOLICITUD. Si el cursor no se puede abrir (SQLCODE distinto de cero), registra el error con codigo 'E0001' y mensaje 'NO SE PUDO ABRIR CURSOR DE SOLICITUDES' llamando a 9900-REGISTRA-ERROR, activa la bandera de fin de cursor (SW-FIN-CURSOR = 'S') y establece el codigo de retorno del programa en 16. Si el cursor se abre correctamente (SQLCODE = 0), llama inmediatamente a 2100-FETCH-SOLICITUD para leer la primera fila.

**Algoritmo**

1. Leer la tarjeta de parametros de SYSIN en SDB-PARM-TARJETA.
2. Si SDB-PRM-FECHA-PROCESO esta en blanco, asignar la fecha del sistema (formato AAAAMMDD) a WS-FEC-PROCESO. Si no esta en blanco, copiar SDB-PRM-FECHA-PROCESO a WS-FEC-PROCESO.
3. Si SDB-PRM-MODO = 'S', asignar 'S' a SW-SIMULA.
4. Copiar WS-FEC-PROCESO a WS-FECHA-TRAB. Llamar a 8100-FECHA-A-ISO, que descompone WS-FECHA-TRAB en sus partes año (WS-FT-ANIO), mes (WS-FT-MES) y dia (WS-FT-DIA) y las copia respectivamente a WS-FI-ANIO, WS-FI-MES y WS-FI-DIA dentro de la estructura WS-FECHA-ISO (que incluye guiones literales como separadores). Copiar WS-FECHA-ISO a HV-FEC-PROCESO.
5. Llamar a 1100-LEER-PARM para leer el archivo PARM/CHQPARM. Si el archivo no esta disponible, mostrar mensaje informativo y continuar con los valores por defecto: WS-COSTO-CHQRA-PEN = 20.00, WS-COSTO-CHQRA-USD = 6.00, WS-FREC-CHECKPOINT = 50.
6. Preparar la llamada a BCTCHECK: asignar 'RS' a BCT-FUNCION, el valor de WS-NOM-PROGRAMA ('CHQCHEQR') a BCT-PROGRAMA, WS-FEC-PROCESO a BCT-FEC-PROCESO, y blancos a BCT-CLAVE-ULT. Llamar a BCTCHECK pasando BCT-AREA-CHECK.
7. Si BCT-COD-RETORNO = 0000 y BCT-CLAVE-ULT no esta en blanco: copiar los primeros 9 caracteres de BCT-CLAVE-ULT a WS-NUM-SOL-DISP (campo de 9 digitos), copiar WS-NUM-SOL-DISP a HV-NUM-REINICIO, y mostrar por consola el mensaje 'CHQCHEQR REINICIO DESDE SOLIC.' seguido del valor de WS-NUM-SOL-DISP. Si BCT-COD-RETORNO es distinto de 0000 o BCT-CLAVE-ULT esta en blanco, HV-NUM-REINICIO permanece en cero y no se muestra mensaje.
8. Ejecutar OPEN sobre el cursor CUR_SOLIC. El cursor selecciona de CHQ_SOLICITUD los campos NUM_SOLICITUD, CTA_NUMERO, CANT_CHEQUERAS, FEC_SOLICITUD (en formato ISO), CANAL y COD_USUARIO, filtrando por EST_SOLICITUD = 'SO' y NUM_SOLICITUD > HV-NUM-REINICIO, ordenado por NUM_SOLICITUD ascendente.
9. Si SQLCODE no es 0: asignar 'E0001' a WS-COD-ERROR, asignar el texto 'NO SE PUDO ABRIR CURSOR DE SOLICITUDES' a WS-GLOSA-ERROR, llamar a 9900-REGISTRA-ERROR, asignar 'S' a SW-FIN-CURSOR, asignar 16 a RETURN-CODE.
10. Si SQLCODE es 0: llamar a 2100-FETCH-SOLICITUD para leer la primera fila del cursor en las variables HV-NUM-SOLICITUD, HV-CUENTA, HV-CANT-CHEQUERAS, HV-FEC-SOLICITUD, HV-CANAL y HV-USUARIO.
<!-- rule-end -->

<!-- rule-start -->
### 3. Regla / Operacion - 1100-LEER-PARM (Lectura del Archivo de Parametros)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

1. Abrir el archivo ARCH-PARM en modo lectura.
2. Si el estado del archivo (WS-FS-PARM) no es '00' al intentar abrirlo: mostrar el aviso "CHQCHEQR PARM NO DISPONIBLE, SE USAN DEFECTOS" y salir del párrafo sin error, quedando activos los valores por defecto incorporados en el código: costo de chequera en soles (WS-COSTO-CHQRA-PEN) = 20.00, costo de chequera en dólares (WS-COSTO-CHQRA-USD) = 6.00, y frecuencia de checkpoint (WS-FREC-CHECKPOINT) = 50. La falta del archivo de parámetros no es un error que detenga el proceso.
3. Si el archivo se abre correctamente, repetir mientras no se haya llegado al fin del archivo (SW-FIN-PARM distinto de 'S'):
   a. Leer un registro de ARCH-PARM.
   b. Si se llega al fin del archivo, establecer SW-FIN-PARM = 'S' y no llamar a 1110-APLICA-PARM.
   c. Si se lee un registro correctamente, llamar a 1110-APLICA-PARM para aplicar el parámetro leído. La lógica de ese subpárrafo es la siguiente:
      - Si el primer carácter del campo PRM-CLAVE es un asterisco (`*`), el registro se trata como comentario y se ignora sin procesar.
      - Se mueve el campo PRM-VALOR (12 bytes) a WS-PV-TEXTO. Si el décimo carácter de ese texto (WS-PV-PUNTO) no es un punto (`.`), el registro se ignora sin procesar.
      - Si el formato es válido, se calcula el valor numérico: WS-PV-NUMERO = WS-PV-ENT + (WS-PV-DEC / 100), donde WS-PV-ENT son los primeros 9 caracteres interpretados como entero y WS-PV-DEC son los 2 caracteres finales interpretados como parte decimal.
      - Se evalúa el campo PRM-CLAVE del registro para determinar qué parámetro actualizar:
        - Si PRM-CLAVE es `'COSTO-CHQRA-PEN'`: se mueve WS-PV-NUMERO a WS-COSTO-CHQRA-PEN (costo unitario de chequera en soles).
        - Si PRM-CLAVE es `'COSTO-CHQRA-USD'`: se mueve WS-PV-NUMERO a WS-COSTO-CHQRA-USD (costo unitario de chequera en dólares).
        - Si PRM-CLAVE es `'BCT-FREC-CHECK'`: se mueve WS-PV-ENT (solo la parte entera, sin decimales) a WS-FREC-CHECKPOINT (frecuencia de checkpoint).
        - Cualquier otra clave no reconocida se ignora sin error.
4. Al finalizar la lectura de todos los registros, cerrar el archivo ARCH-PARM.
<!-- rule-end -->

<!-- rule-start -->
### 4. Regla / Operacion - 1110-APLICA-PARM (Aplicacion de un Parametro Individual)
<!-- reviewed -->

_Reviewed_

Procesa un registro del archivo de parametros `PARM/CHQPARM`. Cada registro tiene tres campos: `PRM-CLAVE` (18 caracteres), `PRM-VALOR` (12 caracteres) y un campo de relleno de 50 caracteres que es ignorado.

La logica de interpretacion es:

- Si el primer caracter de `PRM-CLAVE` es `'*'`, el registro es un comentario y se ignora completamente, sin procesar ningun campo adicional.
- El campo `PRM-VALOR` se copia integro a la variable de trabajo `WS-PV-TEXTO` (12 caracteres), que se redefine de la siguiente manera: los primeros 9 caracteres forman la parte entera (`WS-PV-ENT`), el caracter 10 es el separador decimal (`WS-PV-PUNTO`) y los ultimos 2 caracteres son la parte decimal (`WS-PV-DEC`). Si el caracter 10 no es exactamente un punto (`'.'`), el registro se ignora completamente sin error.
- Si el formato es valido, se calcula el valor numerico almacenado en `WS-PV-NUMERO` mediante la formula: `WS-PV-NUMERO = WS-PV-ENT + (WS-PV-DEC / 100)`. Por ejemplo, si la parte entera es `000000020` y la parte decimal es `00`, el resultado es `20.00`.
- Segun el valor exacto de `PRM-CLAVE` se actualiza la variable de parametro correspondiente en `WS-PARAMETROS`:
  - `'COSTO-CHQRA-PEN'`: actualiza `WS-COSTO-CHQRA-PEN` con el valor calculado `WS-PV-NUMERO`. Este parametro representa el costo unitario de la chequera en soles y tiene un valor por defecto de `20.00`.
  - `'COSTO-CHQRA-USD'`: actualiza `WS-COSTO-CHQRA-USD` con el valor calculado `WS-PV-NUMERO`. Este parametro representa el costo unitario de la chequera en dolares y tiene un valor por defecto de `6.00`.
  - `'BCT-FREC-CHECK'`: actualiza `WS-FREC-CHECKPOINT` con **unicamente la parte entera** `WS-PV-ENT`, descartando los decimales. Este parametro controla cada cuantas solicitudes procesadas se graba un punto de control (checkpoint) y tiene un valor por defecto de `50`.
  - Cualquier otra clave no reconocida: se ignora sin error ni mensaje.

Si el archivo de parametros `PARM/CHQPARM` no esta disponible al momento de abrirlo, no se ejecuta ningun registro de este parrafo y los tres parametros conservan sus valores por defecto definidos en `WORKING-STORAGE`.

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

1. Si el primer caracter de `PRM-CLAVE` es `'*'`, salir sin hacer nada (registro de comentario).
2. Copiar `PRM-VALOR` a `WS-PV-TEXTO`.
3. Si `WS-PV-PUNTO` (caracter 10 de `WS-PV-TEXTO`) no es `'.'`, salir sin hacer nada (formato invalido).
4. Calcular: `WS-PV-NUMERO = WS-PV-ENT + (WS-PV-DEC / 100)`.
5. Evaluar `PRM-CLAVE`:
   - Si es `'COSTO-CHQRA-PEN'`: asignar `WS-PV-NUMERO` a `WS-COSTO-CHQRA-PEN`.
   - Si es `'COSTO-CHQRA-USD'`: asignar `WS-PV-NUMERO` a `WS-COSTO-CHQRA-USD`.
   - Si es `'BCT-FREC-CHECK'`: asignar unicamente `WS-PV-ENT` (parte entera, sin decimales) a `WS-FREC-CHECKPOINT`.
   - Cualquier otro valor de clave: no hacer nada (instruccion `CONTINUE` implicita).
<!-- rule-end -->

<!-- rule-start -->
### 5. Regla / Operacion - 2000-PROCESA-SOLICITUDES (Ciclo Principal de Procesamiento)
<!-- reviewed -->

_Reviewed_

Este bloque es el corazón del programa. Se ejecuta una vez por cada solicitud leída del cursor. Recibe la solicitud que ya fue cargada en las variables de host por la llamada previa a 2100-FETCH-SOLICITUD y la procesa completamente antes de pasar a la siguiente.

La secuencia exacta para cada solicitud es:

1. Incrementar el contador de solicitudes leídas (WS-CNT-LEIDAS) en 1.
2. Copiar el número de solicitud actual (HV-NUM-SOLICITUD) a WS-NUM-SOL-DISP para uso en mensajes y referencias.
3. Inicializar la bandera de solicitud válida en 'S' (SW-SOLIC-OK = 'S') y limpiar el código de rechazo (HV-COD-RECHAZO = espacios).
4. Ejecutar las validaciones de negocio invocando el bloque 3000-VALIDAR-SOLICITUD hasta su punto de salida 3000-EXIT (el bloque se ejecuta en su totalidad mediante PERFORM THRU).
5. Si la solicitud es válida (SW-SOLIC-OK = 'S'): calcular el costo invocando 4000-CALCULAR-COSTO y, a continuación, cobrar el costo invocando 5000-COBRAR-COSTO hasta su punto de salida 5000-EXIT. El cobro puede invalidar la solicitud si no hay saldo suficiente u ocurre un error de posteo, modificando SW-SOLIC-OK a 'N'.
6. Se evalúa nuevamente el valor de SW-SOLIC-OK de forma independiente al paso anterior. Si en ese momento SW-SOLIC-OK = 'S':
   - Emitir las chequeras físicamente en la base de datos invocando 6000-EMITIR-CHEQUERAS.
   - Actualizar el estado de la solicitud a emitida invocando 7000-ACTUALIZAR-SOLICITUD.
   - Enviar notificación al cliente invocando 7500-NOTIFICAR-CLIENTE.
   - Incrementar WS-CNT-EMITIDAS en 1.
7. Si SW-SOLIC-OK no es 'S' (es decir, la condición SOLIC-VALIDA no se cumple):
   - Registrar el rechazo de la solicitud en la base de datos invocando 7100-RECHAZAR-SOLICITUD.
   - Incrementar WS-CNT-RECHAZADAS en 1.
8. Ejecutar el checkpoint periódico invocando 7800-CHECKPOINT, independientemente del resultado de la solicitud.
9. Leer la siguiente solicitud del cursor invocando 2100-FETCH-SOLICITUD, lo que actualiza las variables de host para la próxima iteración o activa la bandera de fin de cursor (SW-FIN-CURSOR = 'S'), deteniendo el ciclo principal.

**Estado de la Regla:** Relevante para Modernización

**Algoritmo**

1. WS-CNT-LEIDAS = WS-CNT-LEIDAS + 1.
2. WS-NUM-SOL-DISP = HV-NUM-SOLICITUD.
3. SW-SOLIC-OK = 'S'. HV-COD-RECHAZO = espacios.
4. Invocar 3000-VALIDAR-SOLICITUD THRU 3000-EXIT.
5. Si SW-SOLIC-OK = 'S' (condición SOLIC-VALIDA activa):
   - Invocar 4000-CALCULAR-COSTO.
   - Invocar 5000-COBRAR-COSTO THRU 5000-EXIT. Este paso puede cambiar SW-SOLIC-OK a 'N' si el posteo falla por saldo insuficiente (código de rechazo '60') o por error técnico en SDMPOSTA (código de rechazo '90').
6. Si SW-SOLIC-OK = 'S' (segunda evaluación independiente, tras el posible rechazo en el cobro):
   - Invocar 6000-EMITIR-CHEQUERAS.
   - Invocar 7000-ACTUALIZAR-SOLICITUD.
   - Invocar 7500-NOTIFICAR-CLIENTE.
   - WS-CNT-EMITIDAS = WS-CNT-EMITIDAS + 1.
7. Si SW-SOLIC-OK ≠ 'S' (condición SOLIC-VALIDA no activa):
   - Invocar 7100-RECHAZAR-SOLICITUD.
   - WS-CNT-RECHAZADAS = WS-CNT-RECHAZADAS + 1.
8. Invocar 7800-CHECKPOINT (siempre, independientemente del resultado de la solicitud).
9. Invocar 2100-FETCH-SOLICITUD (siempre, para avanzar al siguiente registro del cursor o señalizar el fin del procesamiento).
<!-- rule-end -->

<!-- rule-start -->
### 6. Regla / Operacion - 2100-FETCH-SOLICITUD (Lectura de la Siguiente Solicitud del Cursor)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

Lee la siguiente fila del cursor CUR_SOLIC y carga los datos en las variables de host. El cursor selecciona de la tabla CHQ_SOLICITUD todas las filas donde el estado de la solicitud es exactamente `'SO'` (solicitada/pendiente) y el número de solicitud es estrictamente mayor que el valor de HV-NUM-REINICIO (que en una ejecución normal vale cero, y en un reinicio contiene el último número de solicitud procesado antes de la interrupción, recuperado previamente mediante BCTCHECK con función `'RS'`). Los resultados se ordenan por número de solicitud de menor a mayor.

Los campos recuperados por cada lectura son: número de solicitud (HV-NUM-SOLICITUD), número de cuenta (HV-CUENTA), cantidad de chequeras solicitadas (HV-CANT-CHEQUERAS), fecha de solicitud en formato ISO de DB2 obtenida mediante la función `CHAR(S.FEC_SOLICITUD, ISO)` (HV-FEC-SOLICITUD), canal (HV-CANAL) y usuario (HV-USUARIO).

El comportamiento según el resultado del FETCH es:

- SQLCODE = 0: lectura exitosa, continuar normalmente sin acción adicional.
- SQLCODE = +100: no hay más filas disponibles en el cursor (fin del resultado). Activar SW-FIN-CURSOR = `'S'`. El ciclo principal dejará de ejecutarse al detectar esta condición.
- Cualquier otro SQLCODE: error inesperado al leer el cursor. Registrar el error y terminar el ciclo.

Cabe destacar que este párrafo es invocado en dos momentos distintos del flujo: una primera vez al final de la inicialización (párrafo 1000-INICIO), inmediatamente después de abrir el cursor, para posicionarse en la primera fila antes de entrar al ciclo principal; y luego al final de cada iteración del ciclo principal (párrafo 2000-PROCESA-SOLICITUDES), para avanzar a la siguiente solicitud.

**Algoritmo**

1. Ejecutar FETCH sobre CUR_SOLIC cargando los resultados en las siguientes variables de host, en este orden: HV-NUM-SOLICITUD, HV-CUENTA, HV-CANT-CHEQUERAS, HV-FEC-SOLICITUD, HV-CANAL, HV-USUARIO.
2. Evaluar SQLCODE:
   - Si es 0: no realizar ninguna acción adicional; continuar el procesamiento normal.
   - Si es +100: asignar `'S'` a SW-FIN-CURSOR; el ciclo principal finalizará en su próxima evaluación de la condición FIN-CURSOR.
   - Cualquier otro valor: asignar `'E0002'` a WS-COD-ERROR; asignar el texto `'ERROR EN FETCH DE CHQ_SOLICITUD'` a WS-GLOSA-ERROR; invocar el párrafo 9900-REGISTRA-ERROR para registrar el error en el log SDULOGER; asignar `'S'` a SW-FIN-CURSOR; asignar el valor `12` a RETURN-CODE.
<!-- rule-end -->

<!-- rule-start -->
### 7. Regla / Operacion - 3000-VALIDAR-SOLICITUD (RN-CHQ-01, RN-CHQ-02, RN-CHQ-03: Validacion de la Solicitud)
<!-- reviewed -->

_Reviewed_

Aplica tres reglas de negocio en secuencia para determinar si una solicitud puede ser procesada. Si cualquier validación falla, se asigna un código de rechazo a HV-COD-RECHAZO, se pone SW-SOLIC-OK = 'N' y se abandona el resto de las validaciones inmediatamente.

**Validación 1 - RN-CHQ-03: Cantidad de chequeras por solicitud**

La cantidad de chequeras solicitadas (HV-CANT-CHEQUERAS) debe ser mayor o igual a 1 y menor o igual al máximo permitido por solicitud. Ese máximo está definido en la constante CHQ-MAX-CHEQ-X-SOLIC del copybook CHQCONW, cuyo valor es 3. Si la cantidad está fuera del rango [1, 3], se asigna el código de rechazo '50'.

**Validación 2 - RN-CHQ-01: La cuenta debe existir, ser corriente y estar activa**

Se llama a la subrutina SDCMAEST con función 'LE' (lectura) pasando el número de cuenta HV-CUENTA en el campo SDC-MAE-CTA-NUMERO, y con SDC-MAE-COD-RETORNO inicializado a espacios antes de la llamada. SDCMAEST consulta la tabla CUENTA_MAESTRO y devuelve todos los datos de la cuenta.

- Si SDCMAEST devuelve un código de retorno distinto de SDU-RC-OK ('00'), la cuenta no existe o hubo un error de base de datos. Código de rechazo: '10'.
- Si el campo SDC-MAE-CTA-PRODUCTO devuelto no es igual a SDU-PROD-CORRIENTE ('06'), la cuenta no es una cuenta corriente. Código de rechazo: '20'.
- Si el campo SDC-MAE-CTA-ESTADO devuelto no es igual a SDU-EST-ACTIVA ('AC'), la cuenta no está activa. Código de rechazo: '30'.

Si la cuenta pasa estas tres verificaciones, se guarda la moneda de la cuenta (SDC-MAE-CTA-MONEDA) en HV-MONEDA para usarla en el cálculo del costo.

**Validación 3 - Conteo de chequeras previas y vigentes (3200-CONTAR-CHEQUERAS)**

Se ejecuta el subproceso 3200-CONTAR-CHEQUERAS, que realiza dos consultas SQL sobre la tabla CHQ_CHEQUERA filtrando por el número de cuenta (CTA_NUMERO = HV-CUENTA):

- **Primera consulta:** cuenta el total de chequeras que existen para la cuenta, sin importar su estado. El resultado se almacena en WS-CANT-PREVIAS. Si esta consulta falla (SQLCODE distinto de cero), se asigna el código de rechazo '90', se pone SW-SOLIC-OK = 'N' y se registra el error con código 'E0003'. No se ejecuta la segunda consulta.
- **Segunda consulta:** cuenta únicamente las chequeras cuyo estado sea 'EM' (emitida) o 'EN' (entregada), que son las consideradas vigentes. El resultado se almacena en WS-CANT-VIGENTES. Si esta consulta falla (SQLCODE distinto de cero), se asigna el código de rechazo '90' y se pone SW-SOLIC-OK = 'N'.

Si 3200-CONTAR-CHEQUERAS dejó SW-SOLIC-OK en 'N', se abandona la validación sin continuar.

**Validación 4 - RN-CHQ-02: Límite de chequeras vigentes por cuenta**

Si WS-CANT-VIGENTES más HV-CANT-CHEQUERAS supera el máximo de chequeras pendientes permitidas, definido en CHQ-MAX-CHEQ-PENDIENTES del copybook CHQCONW con valor 2, se rechaza la solicitud con código '40'. A diferencia de las validaciones anteriores, esta condición no utiliza un salto inmediato; simplemente asigna el código de rechazo y pone SW-SOLIC-OK = 'N' sin un salto explícito al final del párrafo.

**Rule Status:** Relevante para Modernización

**Algoritmo**

1. Si HV-CANT-CHEQUERAS < 1 o HV-CANT-CHEQUERAS > 3: HV-COD-RECHAZO = '50'; SW-SOLIC-OK = 'N'; salir.
2. Mover 'LE' a SDC-MAE-FUNCION; mover HV-CUENTA a SDC-MAE-CTA-NUMERO; mover espacios a SDC-MAE-COD-RETORNO; llamar a SDCMAEST.
3. Si SDC-MAE-COD-RETORNO != '00': HV-COD-RECHAZO = '10'; SW-SOLIC-OK = 'N'; salir.
4. Si SDC-MAE-CTA-PRODUCTO != '06': HV-COD-RECHAZO = '20'; SW-SOLIC-OK = 'N'; salir.
5. Si SDC-MAE-CTA-ESTADO != 'AC': HV-COD-RECHAZO = '30'; SW-SOLIC-OK = 'N'; salir.
6. HV-MONEDA = SDC-MAE-CTA-MONEDA.
7. Ejecutar 3200-CONTAR-CHEQUERAS:
   - 7a. Consultar en CHQ_CHEQUERA el total de chequeras para CTA_NUMERO = HV-CUENTA (sin filtro de estado); guardar el resultado en WS-CANT-PREVIAS. Si SQLCODE != 0: HV-COD-RECHAZO = '90'; SW-SOLIC-OK = 'N'; registrar error 'E0003'; salir de 3200.
   - 7b. Consultar en CHQ_CHEQUERA el total de chequeras para CTA_NUMERO = HV-CUENTA cuyo EST_CHEQUERA sea 'EM' o 'EN'; guardar el resultado en WS-CANT-VIGENTES. Si SQLCODE != 0: HV-COD-RECHAZO = '90'; SW-SOLIC-OK = 'N'.
8. Si SW-SOLIC-OK != 'S': salir.
9. Si WS-CANT-VIGENTES + HV-CANT-CHEQUERAS > 2: HV-COD-RECHAZO = '40'; SW-SOLIC-OK = 'N'.
<!-- rule-end -->

<!-- rule-start -->
### 8. Regla / Operacion - 3200-CONTAR-CHEQUERAS (Conteo de Chequeras Previas y Vigentes)
<!-- reviewed -->

_Reviewed_

**Rule Status:** Relevante para Modernizacion

Realiza dos consultas de conteo sobre la tabla CHQ_CHEQUERA para la cuenta en proceso (HV-CUENTA).

**Primera consulta:** Cuenta el total de chequeras que existen para la cuenta, sin filtro de estado. El resultado se guarda en WS-CANT-PREVIAS. Este valor se usa luego en 4000-CALCULAR-COSTO para determinar si la primera chequera es gratuita: si WS-CANT-PREVIAS es cero, significa que la cuenta nunca ha tenido una chequera y la primera que se emita en esta solicitud sera gratuita.

Si esta primera consulta falla (SQLCODE distinto de cero), se asigna el codigo de rechazo '90', se pone SW-SOLIC-OK = 'N', se establece WS-COD-ERROR = 'E0003' con el texto 'ERROR CONTANDO CHEQUERAS PREVIAS' y se invoca a 9900-REGISTRA-ERROR para dejar constancia en el log. No se ejecuta la segunda consulta.

**Segunda consulta:** Cuenta solo las chequeras que estan en estado 'EM' (emitida) o 'EN' (entregada), que son las chequeras vigentes. El resultado se guarda en WS-CANT-VIGENTES. Este valor se usa en 3000-VALIDAR-SOLICITUD para verificar el limite de chequeras activas.

Si esta segunda consulta falla (SQLCODE distinto de cero), se asigna el codigo de rechazo '90' y se pone SW-SOLIC-OK = 'N'. A diferencia del fallo de la primera consulta, en este caso no se registra error en el log ni se asigna codigo de error en WS-COD-ERROR; el programa simplemente marca la solicitud como invalida con el codigo de rechazo '90'.

**Algoritmo**

1. Ejecutar: SELECT COUNT(\*) FROM CHQ\_CHEQUERA WHERE CTA\_NUMERO = HV-CUENTA. Cargar el resultado en HV-CONTEO.
2. Si SQLCODE distinto de cero: asignar 'E0003' a WS-COD-ERROR; asignar 'ERROR CONTANDO CHEQUERAS PREVIAS' a WS-GLOSA-ERROR; invocar a 9900-REGISTRA-ERROR; asignar '90' a HV-COD-RECHAZO; asignar 'N' a SW-SOLIC-OK; salir sin ejecutar la segunda consulta.
3. Mover HV-CONTEO a WS-CANT-PREVIAS.
4. Ejecutar: SELECT COUNT(\*) FROM CHQ\_CHEQUERA WHERE CTA\_NUMERO = HV-CUENTA AND EST\_CHEQUERA IN ('EM', 'EN'). Cargar el resultado en HV-CONTEO.
5. Si SQLCODE distinto de cero: asignar '90' a HV-COD-RECHAZO; asignar 'N' a SW-SOLIC-OK; salir. No se registra error en el log en este paso.
6. Mover HV-CONTEO a WS-CANT-VIGENTES.
<!-- rule-end -->

<!-- rule-start -->
### 9. Regla / Operacion - 4000-CALCULAR-COSTO (RN-CHQ-04: Calculo del Costo de la Chequera)
<!-- reviewed -->

_Reviewed_

Calcula el costo total que se cobrará al cliente por las chequeras solicitadas. La regla de negocio central es que la primera chequera de la vida de una cuenta es gratuita. El IGV es el 18% sobre el costo base.

**Paso 1: Determinar cantidad gratuita**

Si `WS-CANT-PREVIAS` es cero (la cuenta nunca ha tenido ninguna chequera registrada en `CHQ_CHEQUERA`, independientemente de su estado), entonces `WS-CANT-GRATIS = 1`. En cualquier otro caso, `WS-CANT-GRATIS = 0`. El valor de `WS-CANT-PREVIAS` proviene del conteo total de filas en `CHQ_CHEQUERA` para la cuenta, sin filtro de estado, obtenido en el párrafo `3200-CONTAR-CHEQUERAS` antes de llegar a este cálculo.

**Paso 2: Calcular cantidad pagada**

`WS-CANT-PAGADAS = HV-CANT-CHEQUERAS - WS-CANT-GRATIS`.

Ejemplo: si se solicitan 2 chequeras y la cuenta no tiene previas, `WS-CANT-PAGADAS = 2 - 1 = 1`. Solo se cobra una.

**Paso 3: Determinar el costo unitario según moneda**

Si `HV-MONEDA` es igual a `SDU-MON-SOLES` (valor `'604'`), el costo unitario es `WS-COSTO-CHQRA-PEN` (valor por defecto 20.00 soles, configurable mediante el parámetro de clave `COSTO-CHQRA-PEN` en el miembro `PARM/CHQPARM`). Adicionalmente se establece `SW-ES-PEN = 'S'`.

Si la moneda es cualquier otra distinta de `'604'` (en la práctica, dólares `'840'`), el costo unitario es `WS-COSTO-CHQRA-USD` (valor por defecto 6.00 dólares, configurable mediante el parámetro de clave `COSTO-CHQRA-USD` en el mismo miembro de parámetros). Se establece `SW-ES-PEN = 'N'`.

**Paso 4: Calcular costo base**

`WS-COSTO-BASE = WS-COSTO-UNITARIO * WS-CANT-PAGADAS`.

**Paso 5: Calcular IGV**

`WS-COSTO-IGV = WS-COSTO-BASE * CHQ-PCT-IGV`, con la cláusula `ROUNDED` aplicada por el compilador (redondeo half-up a dos decimales). `CHQ-PCT-IGV` tiene el valor fijo `0.18` (18%), definido en el copybook `CHQCONW` y no es configurable por parámetro.

**Paso 6: Calcular costo total**

`WS-COSTO-TOTAL = WS-COSTO-BASE + WS-COSTO-IGV`. Esta suma no lleva redondeo explícito.

**Nota sobre el caso de costo cero:** Si `WS-CANT-PREVIAS = 0` y `HV-CANT-CHEQUERAS = 1`, entonces `WS-CANT-PAGADAS = 0`, lo que produce `WS-COSTO-BASE = 0`, `WS-COSTO-IGV = 0` y `WS-COSTO-TOTAL = 0`. En ese caso, el párrafo `5000-COBRAR-COSTO` detecta que `WS-COSTO-TOTAL = 0` y omite completamente la llamada a `SDMPOSTA`, sin generar ningún movimiento de cobro.

**Estado de la Regla:** Relevante para Modernización

**Algoritmo**

1. Si `WS-CANT-PREVIAS = 0`: `WS-CANT-GRATIS = 1`. Si no: `WS-CANT-GRATIS = 0`.
2. `WS-CANT-PAGADAS = HV-CANT-CHEQUERAS - WS-CANT-GRATIS`.
3. Si `HV-MONEDA = '604'`: `WS-COSTO-UNITARIO = WS-COSTO-CHQRA-PEN` (defecto 20.00, clave `COSTO-CHQRA-PEN`); `SW-ES-PEN = 'S'`. Si no: `WS-COSTO-UNITARIO = WS-COSTO-CHQRA-USD` (defecto 6.00, clave `COSTO-CHQRA-USD`); `SW-ES-PEN = 'N'`.
4. `WS-COSTO-BASE = WS-COSTO-UNITARIO * WS-CANT-PAGADAS`.
5. `WS-COSTO-IGV = redondear(WS-COSTO-BASE * 0.18)` al centavo más cercano (redondeo half-up de 2 decimales, cláusula `ROUNDED` del compilador). El factor `0.18` es fijo en `CHQCONW` y no es parametrizable.
6. `WS-COSTO-TOTAL = WS-COSTO-BASE + WS-COSTO-IGV` (sin redondeo adicional).
7. Si `WS-COSTO-TOTAL = 0`, el cobro vía `SDMPOSTA` se omite por completo en el paso siguiente.
<!-- rule-end -->

<!-- rule-start -->
### 10. Regla / Operacion - 5000-COBRAR-COSTO (Cobro del Costo via SDMPOSTA)
<!-- reviewed -->

_Reviewed_

**Rule Status:** Relevante para Modernizacion

Realiza el cargo en la cuenta del cliente por el costo total de las chequeras calculado en el paso anterior. Si el costo total es cero (chequera completamente gratuita), no se realiza ninguna llamada a SDMPOSTA y se sale inmediatamente.

Si el costo es mayor que cero, se prepara la llamada a SDMPOSTA (motor de posteo de movimientos) con los siguientes valores:

- **Empresa:** 1 (valor fijo).
- **Cuenta:** HV-CUENTA.
- **Producto:** SDC-MAE-CTA-PRODUCTO (obtenido de la lectura del maestro en 3000-VALIDAR-SOLICITUD).
- **Moneda:** SDC-MAE-CTA-MONEDA (obtenido igualmente de la lectura del maestro).
- **Tipo de operacion:** SDU-OP-COBRO-COMISION (código '060'), que representa un cobro de comisión.
- **Signo:** 'D' (débito, cargo a la cuenta).
- **Importe:** WS-COSTO-TOTAL (el costo total incluyendo IGV).
- **Fecha de proceso:** WS-FEC-PROCESO.
- **Fecha valor:** WS-FEC-PROCESO (mismo valor que la fecha de proceso).
- **Canal:** SDU-CAN-BATCH (valor '`BA`').
- **Sucursal:** 0 (ceros).
- **Terminal:** nombre del programa ('`CHQCHEQR`').
- **Usuario:** '`BATCH`'.
- **Supervisor:** espacios.
- **Glosa:** el texto fijo '`COSTO CHEQUERA SOLIC `' (21 caracteres) seguido del número de solicitud (WS-NUM-SOL-DISP, 9 dígitos) colocado a partir de la posición 22 del campo de glosa de 40 caracteres.
- **Referencia:** número de solicitud (WS-NUM-SOL-DISP).
- **Tipo de documento:** '`CQ`'.
- **Número de documento:** número de solicitud (WS-NUM-SOL-DISP).
- **Lote:** 0 (ceros).
- **Batch ID:** '`CHQJD010`'.
- **Indicador de forzar:** '`N`' (no forzar; se valida disponibilidad de saldo).
- **Indicador de exonerar ITF:** '`N`' (el cobro de comisión de chequera paga ITF normalmente).
- **Indicador de solo validar:** '`S`' si el programa está en modo simulación (SW-SIMULA = 'S'); '`N`' si es ejecución en producción. En modo simulación SDMPOSTA solo valida sin efectuar el débito real.

Después de llamar a SDMPOSTA, se evalúa el código de retorno (POS-COD-RETORNO):

- Si POS-COD-RETORNO **no es 0000**: la solicitud se invalida asignando '`N`' a SW-SOLIC-OK. Dentro de este caso se distinguen dos situaciones:
  - Si el código indica saldo insuficiente (POS-SALDO-INSUF, código 0040): se asigna el código de rechazo '`60`' en HV-COD-RECHAZO. No se registra error en el log.
  - Si es cualquier otro código de error distinto de 0040: se asigna el código de rechazo '`90`' en HV-COD-RECHAZO, se carga '`E0004`' en WS-COD-ERROR, se copia el mensaje devuelto por SDMPOSTA (POS-MENSAJE) en WS-GLOSA-ERROR y se invoca a 9900-REGISTRA-ERROR para dejar constancia en el log.
- Si POS-COD-RETORNO **es 0000** (posteo exitoso): se acumula WS-COSTO-TOTAL en el contador WS-TOT-COBRADO (WS-TOT-COBRADO = WS-TOT-COBRADO + WS-COSTO-TOTAL).

**Algoritmo**

1. Si WS-COSTO-TOTAL = 0: salir sin efectuar ninguna llamada a SDMPOSTA.
2. Preparar AREA-POSTEO con todos los valores descritos anteriormente:
   - POS-EMPRESA = 1.
   - POS-CUENTA = HV-CUENTA.
   - POS-PRODUCTO = SDC-MAE-CTA-PRODUCTO.
   - POS-MONEDA = SDC-MAE-CTA-MONEDA.
   - POS-TIPO-OPERACION = SDU-OP-COBRO-COMISION ('`060`').
   - POS-SIGNO = '`D`'.
   - POS-IMPORTE = WS-COSTO-TOTAL.
   - POS-FECHA-PROCESO = WS-FEC-PROCESO.
   - POS-FECHA-VALOR = WS-FEC-PROCESO.
   - POS-CANAL = SDU-CAN-BATCH ('`BA`').
   - POS-SUCURSAL = 0.
   - POS-TERMINAL = '`CHQCHEQR`'.
   - POS-USUARIO = '`BATCH`'.
   - POS-SUPERVISOR = espacios.
   - POS-GLOSA = '`COSTO CHEQUERA SOLIC `' + WS-NUM-SOL-DISP en posiciones 22 a 30.
   - POS-REFERENCIA = WS-NUM-SOL-DISP.
   - POS-DOC-TIPO = '`CQ`'.
   - POS-DOC-NUMERO = WS-NUM-SOL-DISP.
   - POS-LOTE = 0.
   - POS-BATCH-ID = '`CHQJD010`'.
   - POS-IND-FORZAR = '`N`'.
   - POS-IND-EXONERA-ITF = '`N`'.
3. Si SW-SIMULA = 'S': POS-IND-SOLO-VALIDA = '`S`'. Si no: POS-IND-SOLO-VALIDA = '`N`'.
4. Llamar a SDMPOSTA con AREA-POSTEO.
5. Si POS-COD-RETORNO ≠ 0000: SW-SOLIC-OK = '`N`'.
   - Si POS-SALDO-INSUF (código 0040): HV-COD-RECHAZO = '`60`'.
   - Si cualquier otro error (distinto de 0040): HV-COD-RECHAZO = '`90`'; WS-COD-ERROR = '`E0004`'; WS-GLOSA-ERROR = POS-MENSAJE; invocar 9900-REGISTRA-ERROR.
6. Si POS-COD-RETORNO = 0000: WS-TOT-COBRADO = WS-TOT-COBRADO + WS-COSTO-TOTAL.
<!-- rule-end -->

<!-- rule-start -->
### 11. Regla / Operacion - 6000-EMITIR-CHEQUERAS (RN-CHQ-05: Generacion de las Chequeras en Base de Datos)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

Genera los registros de chequera y de cheque individual en la base de datos para todas las chequeras solicitadas. En modo simulación, no hace nada y sale inmediatamente.

Primero obtiene el número de cheque más alto que ya existe en la tabla CHQ_CHEQUE para la cuenta (`SELECT COALESCE(MAX(NUM_CHEQUE), 0) FROM CHQ_CHEQUE WHERE CTA_NUMERO = HV-CUENTA`). Si no existe ninguno, la función COALESCE devuelve 0. Este valor se guarda en WS-NUM-CHEQUE-ACT y sirve como punto de partida para la numeración correlativa de todas las hojas que se van a generar en esta ejecución.

Si esta consulta falla (SQLCODE distinto de cero), se registra el error E0005 con la glosa `'ERROR OBTENIENDO ULTIMO NUMERO DE CHEQUE'` y se sale sin generar nada.

Luego itera desde 1 hasta HV-CANT-CHEQUERAS (la cantidad solicitada), invocando a la rutina de generación de chequera individual una vez por cada chequera a emitir. El índice del ciclo (WS-IND-CHEQUERA) se pasa implícitamente a dicha rutina y es fundamental para determinar si la chequera que se está generando es la primera de la solicitud (lo que condiciona si se marca como gratuita).

Cada invocación a la rutina de generación de chequera individual realiza los siguientes pasos:

1. Obtiene el número de chequera más alto existente en la tabla CHQ_CHEQUERA a nivel global (sin filtro por cuenta): `SELECT COALESCE(MAX(NUM_CHEQUERA), 0) FROM CHQ_CHEQUERA`. El nuevo número de chequera será ese máximo más 1 (HV-NUM-CHEQUERA = HV-MAX-CHEQUERA + 1).
2. Calcula el rango de hojas de la nueva chequera:
   - Número inicial: HV-NUM-INICIAL = WS-NUM-CHEQUE-ACT + 1
   - Número final: HV-NUM-FINAL = WS-NUM-CHEQUE-ACT + 25 (el valor de CHQ-HOJAS-CHEQUERA, constante definida en el copybook CHQCONW)
3. Determina si la chequera se marca como gratuita: únicamente si WS-IND-CHEQUERA es igual a 1 (es la primera chequera del ciclo de la solicitud actual) **y además** WS-CANT-GRATIS es igual a 1 (lo que significa que la cuenta no tenía ninguna chequera previa en CHQ_CHEQUERA antes de esta ejecución). Si se cumple esta doble condición, se asigna HV-IND-GRATUITA = 'S' y se incrementa el contador WS-CNT-GRATUITAS en 1. En cualquier otro caso, HV-IND-GRATUITA = 'N'.
4. Inserta un registro en la tabla CHQ_CHEQUERA con los siguientes valores:
   - NUM_CHEQUERA = HV-NUM-CHEQUERA
   - CTA_NUMERO = HV-CUENTA
   - NUM_SOLICITUD = HV-NUM-SOLICITUD
   - NUM_INICIAL = HV-NUM-INICIAL
   - NUM_FINAL = HV-NUM-FINAL
   - CANT_HOJAS = 25 (literal fijo)
   - EST_CHEQUERA = 'EM'
   - FEC_EMISION = HV-FEC-PROCESO
   - IND_GRATUITA = HV-IND-GRATUITA
   - COD_MONEDA = HV-MONEDA
5. Si el INSERT falla (SQLCODE distinto de cero), se registra el error E0006 con la glosa `'ERROR INSERTANDO CHQ_CHEQUERA'` y se sale de la rutina de generación de chequera individual sin generar las hojas. Si el INSERT tiene éxito, se incrementa el contador WS-CNT-CHEQUERAS en 1.
6. Si el INSERT fue exitoso, se generan las 25 hojas individuales de la chequera iterando desde 1 hasta 25 (CHQ-HOJAS-CHEQUERA). En cada iteración:
   - Se incrementa WS-NUM-CHEQUE-ACT en 1.
   - Se asigna HV-NUM-CHEQUE = WS-NUM-CHEQUE-ACT.
   - Se inserta un registro en la tabla CHQ_CHEQUE con los valores: CTA_NUMERO = HV-CUENTA, NUM_CHEQUE = HV-NUM-CHEQUE, NUM_CHEQUERA = HV-NUM-CHEQUERA, EST_CHEQUE = 'DI', MON_IMPORTE = 0.
   - Si el INSERT falla (SQLCODE distinto de cero), se registra el error E0007 con la glosa `'ERROR INSERTANDO CHQ_CHEQUE'`. Si tiene éxito, se incrementa el contador WS-CNT-HOJAS en 1.
   - El ciclo de hojas continúa independientemente de si algún INSERT individual de hoja falló (no hay salida anticipada del ciclo ante errores de hoja).

Dado que WS-NUM-CHEQUE-ACT se actualiza de forma acumulativa hoja a hoja a lo largo de todo el ciclo externo, la numeración de cheques es estrictamente correlativa y continua entre todas las chequeras generadas para la misma solicitud.

**Algoritmo**

1. Si el modo de simulación está activo (SW-SIMULA = 'S'): salir sin realizar ninguna acción.
2. Ejecutar: `SELECT COALESCE(MAX(NUM_CHEQUE), 0) INTO HV-MAX-CHEQUE FROM CHQ_CHEQUE WHERE CTA_NUMERO = HV-CUENTA`.
3. Si SQLCODE ≠ 0: registrar error E0006 con glosa `'ERROR OBTENIENDO ULTIMO NUMERO DE CHEQUE'` invocando a la rutina de registro de errores; salir.
4. Asignar WS-NUM-CHEQUE-ACT = HV-MAX-CHEQUE.
5. Para WS-IND-CHEQUERA desde 1 hasta HV-CANT-CHEQUERAS (incrementando de 1 en 1), ejecutar los pasos 5.1 a 5.6:
   - **5.1** Ejecutar: `SELECT COALESCE(MAX(NUM_CHEQUERA), 0) INTO HV-MAX-CHEQUERA FROM CHQ_CHEQUERA` (sin filtro por cuenta; es el máximo global).
   - **5.2** Calcular: HV-NUM-CHEQUERA = HV-MAX-CHEQUERA + 1; HV-NUM-INICIAL = WS-NUM-CHEQUE-ACT + 1; HV-NUM-FINAL = WS-NUM-CHEQUE-ACT + 25.
   - **5.3** Determinar indicador de gratuidad: si WS-IND-CHEQUERA = 1 y WS-CANT-GRATIS = 1, entonces HV-IND-GRATUITA = 'S' y sumar 1 a WS-CNT-GRATUITAS; en caso contrario, HV-IND-GRATUITA = 'N'.
   - **5.4** Insertar en CHQ_CHEQUERA: (NUM_CHEQUERA, CTA_NUMERO, NUM_SOLICITUD, NUM_INICIAL, NUM_FINAL, CANT_HOJAS, EST_CHEQUERA, FEC_EMISION, IND_GRATUITA, COD_MONEDA) con valores (HV-NUM-CHEQUERA, HV-CUENTA, HV-NUM-SOLICITUD, HV-NUM-INICIAL, HV-NUM-FINAL, 25, 'EM', HV-FEC-PROCESO, HV-IND-GRATUITA, HV-MONEDA). Si SQLCODE ≠ 0: registrar error E0006 con glosa `'ERROR INSERTANDO CHQ_CHEQUERA'`; salir del paso 5 para esta chequera (no se generan sus hojas). Si SQLCODE = 0: sumar 1 a WS-CNT-CHEQUERAS.
   - **5.5** Para WS-IND-HOJA desde 1 hasta 25 (CHQ-HOJAS-CHEQUERA, incrementando de 1 en 1):
     - Sumar 1 a WS-NUM-CHEQUE-ACT.
     - Asignar HV-NUM-CHEQUE = WS-NUM-CHEQUE-ACT.
     - Insertar en CHQ_CHEQUE: (CTA_NUMERO, NUM_CHEQUE, NUM_CHEQUERA, EST_CHEQUE, MON_IMPORTE) con valores (HV-CUENTA, HV-NUM-CHEQUE, HV-NUM-CHEQUERA, 'DI', 0). Si SQLCODE ≠ 0: registrar error E0007 con glosa `'ERROR INSERTANDO CHQ_CHEQUE'`. Si SQLCODE = 0: sumar 1 a WS-CNT-HOJAS. El ciclo continúa en ambos casos.
<!-- rule-end -->

<!-- rule-start -->
### 12. Regla / Operacion - 6100-GENERA-CHEQUERA (Insercion de una Chequera Individual)
<!-- reviewed -->

_Reviewed_

Crea un registro de chequera en la tabla CHQ_CHEQUERA y luego genera sus 25 hojas individuales en la tabla CHQ_CHEQUE.

**Paso 1: Obtener el numero de chequera siguiente**

Consulta el maximo numero de chequera existente en toda la tabla CHQ_CHEQUERA (sin filtro de cuenta ni de estado): `SELECT COALESCE(MAX(NUM_CHEQUERA), 0) INTO HV-MAX-CHEQUERA FROM CHQ_CHEQUERA`. El numero de la nueva chequera es `HV-NUM-CHEQUERA = HV-MAX-CHEQUERA + 1`. Este es un numero global correlativo para todas las cuentas del banco. No se verifica el SQLCODE de esta consulta antes de continuar; si falla, el programa prosigue con el valor que hubiera en HV-MAX-CHEQUERA.

**Paso 2: Calcular el rango de numeracion de hojas**

El numero inicial de la chequera es el siguiente al ultimo cheque emitido para la cuenta: `HV-NUM-INICIAL = WS-NUM-CHEQUE-ACT + 1`.

El numero final es: `HV-NUM-FINAL = WS-NUM-CHEQUE-ACT + CHQ-HOJAS-CHEQUERA`. CHQ-HOJAS-CHEQUERA vale 25 (definido en CHQCONW como valor fijo). Es decir, cada chequera abarca exactamente 25 numeros consecutivos. Nótese que WS-NUM-CHEQUE-ACT es un acumulador compartido entre todas las chequeras de la solicitud: se inicializa en 6000-EMITIR-CHEQUERAS con el maximo numero de cheque ya existente para la cuenta (obtenido con `SELECT COALESCE(MAX(NUM_CHEQUE), 0)`) y se incrementa de uno en uno dentro de 6200-GENERA-HOJAS a medida que se insertan las hojas, de modo que cada chequera sucesiva de la misma solicitud continua la numeracion donde terminó la anterior.

**Paso 3: Determinar si la chequera es gratuita (RN-CHQ-04)**

Solo la primera chequera de la solicitud (WS-IND-CHEQUERA = 1) puede ser gratuita, y únicamente si WS-CANT-GRATIS = 1 (condición que solo se cumple cuando la cuenta no tenía ninguna chequera previa en CHQ_CHEQUERA, es decir, WS-CANT-PREVIAS era igual a cero al momento del cálculo de costos). Si ambas condiciones se cumplen simultáneamente, se asigna `HV-IND-GRATUITA = 'S'` y se incrementa el contador `WS-CNT-GRATUITAS` en 1. En cualquier otro caso (chequera de índice mayor que 1, o cuenta que ya tenía chequeras previas), se asigna `HV-IND-GRATUITA = 'N'`.

**Paso 4: Insertar el registro de chequera**

Se inserta en CHQ_CHEQUERA con los siguientes valores:
- NUM_CHEQUERA: HV-NUM-CHEQUERA (numero global unico).
- CTA_NUMERO: HV-CUENTA.
- NUM_SOLICITUD: HV-NUM-SOLICITUD.
- NUM_INICIAL: HV-NUM-INICIAL (primer numero de cheque de esta chequera).
- NUM_FINAL: HV-NUM-FINAL (ultimo numero de cheque de esta chequera).
- CANT_HOJAS: 25 (literal fijo en el INSERT, no una variable).
- EST_CHEQUERA: 'EM' (emitida, literal fijo).
- FEC_EMISION: HV-FEC-PROCESO (fecha de proceso en formato ISO AAAA-MM-DD).
- IND_GRATUITA: HV-IND-GRATUITA ('S' o 'N').
- COD_MONEDA: HV-MONEDA (moneda obtenida del maestro de cuenta en la validación).

Si el INSERT falla (SQLCODE distinto de cero), se asigna el código de error interno `'E0006'` y la glosa `'ERROR INSERTANDO CHQ_CHEQUERA'`, se llama a la rutina de registro de errores (9900-REGISTRA-ERROR) y se sale del párrafo sin incrementar el contador de chequeras ni generar las hojas. Si el INSERT tiene éxito (SQLCODE = 0), se incrementa `WS-CNT-CHEQUERAS` en 1 y se invoca a continuación el párrafo 6200-GENERA-HOJAS para crear las 25 hojas individuales en CHQ_CHEQUE.

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

1. `SELECT COALESCE(MAX(NUM_CHEQUERA), 0) INTO HV-MAX-CHEQUERA FROM CHQ_CHEQUERA` (sin filtro; correlativo global de banco; no se evalúa SQLCODE en este paso).
2. `HV-NUM-CHEQUERA = HV-MAX-CHEQUERA + 1`.
3. `HV-NUM-INICIAL = WS-NUM-CHEQUE-ACT + 1`.
4. `HV-NUM-FINAL = WS-NUM-CHEQUE-ACT + 25`.
5. Si `WS-IND-CHEQUERA = 1` Y `WS-CANT-GRATIS = 1`: `HV-IND-GRATUITA = 'S'`; `WS-CNT-GRATUITAS = WS-CNT-GRATUITAS + 1`. En caso contrario: `HV-IND-GRATUITA = 'N'`.
6. `INSERT INTO CHQ_CHEQUERA (NUM_CHEQUERA, CTA_NUMERO, NUM_SOLICITUD, NUM_INICIAL, NUM_FINAL, CANT_HOJAS, EST_CHEQUERA, FEC_EMISION, IND_GRATUITA, COD_MONEDA) VALUES (HV-NUM-CHEQUERA, HV-CUENTA, HV-NUM-SOLICITUD, HV-NUM-INICIAL, HV-NUM-FINAL, 25, 'EM', HV-FEC-PROCESO, HV-IND-GRATUITA, HV-MONEDA)`.
7. Si `SQLCODE != 0`: `WS-COD-ERROR = 'E0006'`; `WS-GLOSA-ERROR = 'ERROR INSERTANDO CHQ_CHEQUERA'`; llamar a 9900-REGISTRA-ERROR; salir del párrafo (no se incrementa WS-CNT-CHEQUERAS ni se generan hojas).
8. `WS-CNT-CHEQUERAS = WS-CNT-CHEQUERAS + 1`.
9. Llamar a 6200-GENERA-HOJAS para insertar las 25 hojas individuales en CHQ_CHEQUE con estado inicial `'DI'` (disponible) e importe `0`.
<!-- rule-end -->

<!-- rule-start -->
### 13. Regla / Operacion - 6200-GENERA-HOJAS (Insercion de las Hojas Individuales de la Chequera)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

Genera los 25 registros de cheque individual en la tabla `CHQ_CHEQUE` para la chequera recién creada. Itera exactamente 25 veces, controlado por el índice `WS-IND-HOJA` que varía desde 1 hasta el valor de la constante `CHQ-HOJAS-CHEQUERA` (definida como 25 en el copybook `CHQCONW`).

En cada iteración:

1. Se incrementa `WS-NUM-CHEQUE-ACT` en 1. Este contador es **global a toda la solicitud**: avanza de forma continua a través de todas las chequeras que se emitan para una misma solicitud, garantizando la numeración correlativa sin huecos entre chequeras consecutivas. Su valor inicial, antes de comenzar el lazo de chequeras, se obtiene consultando `COALESCE(MAX(NUM_CHEQUE), 0)` sobre la tabla `CHQ_CHEQUE` filtrada por `CTA_NUMERO = HV-CUENTA` (párrafo `6000-EMITIR-CHEQUERAS`), de modo que la numeración continúa desde el último cheque ya existente para esa cuenta, o desde 0 si no tiene ninguno.
2. Se copia `WS-NUM-CHEQUE-ACT` a `HV-NUM-CHEQUE`.
3. Se inserta un registro en `CHQ_CHEQUE` con los siguientes valores exactos:
   - `CTA_NUMERO`: `HV-CUENTA`
   - `NUM_CHEQUE`: `HV-NUM-CHEQUE` (número correlativo de la hoja)
   - `NUM_CHEQUERA`: `HV-NUM-CHEQUERA` (número de la chequera a la que pertenece, obtenido en el párrafo `6100-GENERA-CHEQUERA`)
   - `EST_CHEQUE`: `'DI'` (disponible)
   - `MON_IMPORTE`: `0` (importe inicial cero; el cheque aún no ha sido utilizado)
4. Si el `INSERT` falla (`SQLCODE` distinto de cero): se asigna `'E0007'` a `WS-COD-ERROR`, se asigna el literal `'ERROR INSERTANDO CHQ_CHEQUE'` a `WS-GLOSA-ERROR` y se invoca al párrafo `9900-REGISTRA-ERROR`. El lazo **continúa** con la siguiente hoja sin interrumpirse.
5. Si el `INSERT` tiene éxito (`SQLCODE = 0`): se incrementa el contador global `WS-CNT-HOJAS` en 1.

El proceso continúa con la siguiente hoja independientemente de si una inserción individual falló. Esto significa que podría quedar una chequera con menos de 25 hojas si alguna inserción falla, situación que debería ser tratada como una alerta crítica en la modernización.

**Algoritmo**

1. Para `WS-IND-HOJA` desde 1 hasta `CHQ-HOJAS-CHEQUERA` (valor 25), incrementando de 1 en 1:
   - a. `WS-NUM-CHEQUE-ACT` = `WS-NUM-CHEQUE-ACT` + 1.
   - b. `HV-NUM-CHEQUE` = `WS-NUM-CHEQUE-ACT`.
   - c. `INSERT INTO CHQ_CHEQUE (CTA_NUMERO, NUM_CHEQUE, NUM_CHEQUERA, EST_CHEQUE, MON_IMPORTE) VALUES (HV-CUENTA, HV-NUM-CHEQUE, HV-NUM-CHEQUERA, 'DI', 0)`.
   - d. Si `SQLCODE` ≠ 0: asignar `'E0007'` a `WS-COD-ERROR`; asignar `'ERROR INSERTANDO CHQ_CHEQUE'` a `WS-GLOSA-ERROR`; invocar `9900-REGISTRA-ERROR`. El ciclo continúa con la siguiente hoja sin abortar.
   - e. Si `SQLCODE` = 0: `WS-CNT-HOJAS` = `WS-CNT-HOJAS` + 1.
<!-- rule-end -->

<!-- rule-start -->
### 14. Regla / Operacion - 7000-ACTUALIZAR-SOLICITUD (Actualizacion del Estado de la Solicitud a Emitida)
<!-- reviewed -->

_Reviewed_

**Regla de Negocio:** Actualización del Estado de la Solicitud a Emitida

Actualiza el registro de la solicitud en la tabla `CHQ_SOLICITUD` para reflejar que fue procesada exitosamente. En modo simulación, no realiza ninguna acción y termina inmediatamente.

Antes de ejecutar la actualización, copia los tres valores calculados de costo desde las variables de trabajo a las variables de host correspondientes: el costo base sin IGV se copia de `WS-COSTO-BASE` a `HV-COSTO-BASE`, el IGV calculado se copia de `WS-COSTO-IGV` a `HV-COSTO-IGV`, y el costo total (base más IGV) se copia de `WS-COSTO-TOTAL` a `HV-COSTO-TOTAL`. A continuación ejecuta un `UPDATE` sobre `CHQ_SOLICITUD` para la solicitud actual, identificada por `NUM_SOLICITUD = HV-NUM-SOLICITUD`, con los siguientes cambios:

- **EST_SOLICITUD:** se establece en `'EM'` (emitida).
- **MON_COSTO_BASE:** se actualiza con el valor de `HV-COSTO-BASE` (costo base sin IGV).
- **MON_IGV:** se actualiza con el valor de `HV-COSTO-IGV` (IGV calculado).
- **MON_COSTO_TOTAL:** se actualiza con el valor de `HV-COSTO-TOTAL` (costo base más IGV).
- **FEC_PROCESO:** se actualiza con la fecha de proceso en formato ISO `AAAA-MM-DD`, contenida en `HV-FEC-PROCESO`, la cual fue preparada al inicio del proceso a partir de la fecha de proceso del parámetro de ejecución.

Si el `UPDATE` falla (SQLCODE distinto de cero), se registra el error con código `'E0008'` y glosa `'ERROR ACTUALIZANDO CHQ_SOLICITUD'` mediante la rutina centralizada de registro de errores (`9900-REGISTRA-ERROR`). El proceso continúa de todas formas sin revertir ninguna operación previa, lo que significa que podría quedar una solicitud con estado `'SO'` aun cuando sus chequeras ya fueron generadas en `CHQ_CHEQUERA` y `CHQ_CHEQUE`, y el cobro ya fue debitado de la cuenta vía `SDMPOSTA`. Esto constituye un riesgo operativo que la modernización debe contemplar.

**Estado de la Regla:** Relevante para Modernización

**Algoritmo**

1. Si el modo de ejecución es simulación (`SW-SIMULA = 'S'`): salir sin realizar ninguna acción.
2. Copiar valores de costo calculados a variables de host:
   - `HV-COSTO-BASE` ← `WS-COSTO-BASE`
   - `HV-COSTO-IGV` ← `WS-COSTO-IGV`
   - `HV-COSTO-TOTAL` ← `WS-COSTO-TOTAL`
3. Ejecutar `UPDATE CHQ_SOLICITUD` con los siguientes valores, filtrando por `NUM_SOLICITUD = HV-NUM-SOLICITUD`:
   - `EST_SOLICITUD` = `'EM'`
   - `MON_COSTO_BASE` = `HV-COSTO-BASE`
   - `MON_IGV` = `HV-COSTO-IGV`
   - `MON_COSTO_TOTAL` = `HV-COSTO-TOTAL`
   - `FEC_PROCESO` = `HV-FEC-PROCESO` (fecha en formato ISO `AAAA-MM-DD`)
4. Si `SQLCODE` es distinto de cero: establecer `WS-COD-ERROR` = `'E0008'`, establecer `WS-GLOSA-ERROR` = `'ERROR ACTUALIZANDO CHQ_SOLICITUD'`, llamar a la rutina de registro de errores. El proceso continúa sin revertir las operaciones ya realizadas (chequeras generadas y cobro efectuado).
<!-- rule-end -->

<!-- rule-start -->
### 15. Regla / Operacion - 7100-RECHAZAR-SOLICITUD (Actualizacion del Estado de la Solicitud a Rechazada)
<!-- reviewed -->

_Reviewed_

Actualiza el registro de la solicitud en la tabla CHQ_SOLICITUD para reflejar que fue rechazada. En modo simulación, no realiza ninguna acción.

Ejecuta un UPDATE sobre CHQ_SOLICITUD para la solicitud actual, identificada por NUM_SOLICITUD igual al valor de la variable de host HV-NUM-SOLICITUD, con los siguientes cambios:

- **EST_SOLICITUD:** cambia a 'RE' (rechazada).
- **COD_RECHAZO:** se actualiza con el código de rechazo asignado durante la validación o el cobro (HV-COD-RECHAZO). Los posibles valores son:
  - '10': la cuenta no fue encontrada en el maestro (SDCMAEST devolvió código de retorno distinto de OK).
  - '20': la cuenta no es de producto corriente (SDU-PROD-CORRIENTE, código '06').
  - '30': la cuenta no está en estado activo (SDU-EST-ACTIVA, código 'AC').
  - '40': la suma de chequeras vigentes con estado 'EM' o 'EN' más la cantidad solicitada supera el límite máximo de chequeras pendientes (CHQ-MAX-CHEQ-PENDIENTES, valor 2).
  - '50': la cantidad de chequeras solicitadas es menor que 1 o mayor que el máximo permitido por solicitud (CHQ-MAX-CHEQ-X-SOLIC, valor 3).
  - '60': saldo disponible insuficiente para cubrir el costo total del cobro, según lo reportado por SDMPOSTA (POS-SALDO-INSUF).
  - '90': error técnico, ya sea en la consulta de conteo de chequeras previas o vigentes en CHQ_CHEQUERA, o en el cobro vía SDMPOSTA por una causa distinta a saldo insuficiente.
- **FEC_PROCESO:** se actualiza con la fecha de proceso en formato ISO (HV-FEC-PROCESO), que corresponde a la fecha de proceso del batch convertida al formato AAAA-MM-DD.

Si el UPDATE falla (SQLCODE distinto de cero), se asigna el código de error 'E0009' a WS-COD-ERROR, el texto 'ERROR RECHAZANDO CHQ_SOLICITUD' a WS-GLOSA-ERROR y se invoca al procedimiento de registro de errores 9900-REGISTRA-ERROR, que escribe el evento en el VSAM LOGSIDEP mediante SDULOGER.

**Estado de la Regla:** Relevante para Modernización

**Algoritmo**

1. Si el indicador de modo simulación (SW-SIMULA) tiene el valor 'S', salir sin ejecutar ninguna acción.
2. Ejecutar UPDATE sobre CHQ_SOLICITUD estableciendo EST_SOLICITUD = 'RE', COD_RECHAZO = HV-COD-RECHAZO y FEC_PROCESO = HV-FEC-PROCESO, para el registro cuyo NUM_SOLICITUD coincida con HV-NUM-SOLICITUD.
3. Si SQLCODE es distinto de cero: asignar 'E0009' a WS-COD-ERROR; asignar 'ERROR RECHAZANDO CHQ_SOLICITUD' a WS-GLOSA-ERROR; invocar a 9900-REGISTRA-ERROR.
<!-- rule-end -->

<!-- rule-start -->
### 16. Regla / Operacion - 7500-NOTIFICAR-CLIENTE (Envio de Notificacion al Cliente)
<!-- reviewed -->

_Reviewed_

Encola una notificación para avisar al cliente que su chequera está lista para ser recogida. En modo simulación, no hace nada.

Se llama a la subrutina NTFENCOL con función 'EN' (encolar) y los siguientes parámetros:

- Canal: 'SM' (SMS).
- Código de plantilla: 'CHQ001'.
- Código único del cliente: el valor del campo SDC-MAE-TIT-CODIGO-UNICO, obtenido previamente durante la validación de la cuenta en 3000-VALIDAR-SOLICITUD mediante la llamada a SDCMAEST con función 'LE', y colocado directamente en NTF-COD-UNICO.
- Parámetros del mensaje: antes de construir la cadena, el campo NTF-PARAMETROS se inicializa a espacios. A continuación, el valor de HV-CANT-CHEQUERAS se mueve al campo de trabajo WS-CANT-DISP (definido como numérico de 2 dígitos, PIC 9(02)), y el número de solicitud se toma de WS-NUM-SOL-DISP (numérico de 9 dígitos, PIC 9(09)). La cadena se construye mediante una instrucción STRING delimitada por tamaño (SIZE), concatenando WS-CANT-DISP, el carácter separador '|' y WS-NUM-SOL-DISP, y el resultado se almacena en NTF-PARAMETROS. La plantilla 'CHQ001' utiliza dos variables: {1} se reemplaza por la cantidad de chequeras y {2} por el número de solicitud.
- Prioridad: 5 (baja).

Si NTFENCOL devuelve un código de retorno distinto de 0000, se registra el error con código 'A0001' y glosa 'NTFENCOL NO ENCOLO AVISO DE CHEQUERA' mediante la rutina 9900-REGISTRA-ERROR. El fallo de la notificación no revierte ni cancela la emisión de la chequera ni el cobro realizado. El proceso continúa normalmente.

**Estado de la Regla:** Relevante para Modernización

**Algoritmo**

1. Si el indicador SW-SIMULA tiene valor 'S' (modo simulación activo): salir sin ejecutar ninguna acción.
2. Asignar los campos de entrada de NTFENCOL: NTF-FUNCION = 'EN'; NTF-CANAL = 'SM'; NTF-COD-PLANTILLA = 'CHQ001'.
3. Asignar NTF-COD-UNICO con el valor de SDC-MAE-TIT-CODIGO-UNICO (código único del titular, obtenido de la lectura del maestro de cuentas).
4. Mover HV-CANT-CHEQUERAS al campo WS-CANT-DISP (PIC 9(02), 2 dígitos).
5. Inicializar NTF-PARAMETROS a espacios.
6. Construir NTF-PARAMETROS mediante concatenación por tamaño (DELIMITED BY SIZE) en el siguiente orden: WS-CANT-DISP (2 caracteres) + '|' (1 carácter) + WS-NUM-SOL-DISP (9 caracteres). El resultado se almacena en NTF-PARAMETROS (campo de 100 caracteres).
7. Asignar NTF-PRIORIDAD = 5.
8. Llamar a la subrutina NTFENCOL pasando el área NTF-AREA-ENCOLA.
9. Si NTF-COD-RETORNO es distinto de 0000: asignar WS-COD-ERROR = 'A0001'; asignar WS-GLOSA-ERROR = 'NTFENCOL NO ENCOLO AVISO DE CHEQUERA'; invocar la rutina 9900-REGISTRA-ERROR para registrar el aviso en el log. No se modifica el estado de la solicitud, no se revierte la emisión de las chequeras ni el cobro efectuado.
<!-- rule-end -->

<!-- rule-start -->
### 17. Regla / Operacion - 7800-CHECKPOINT (Grabacion Periodica del Punto de Reinicio)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

Cada vez que se termina de procesar una solicitud (exitosa o rechazada), se incrementa el contador WS-CNT-DESDE-CHECK en 1. Cuando ese contador alcanza o supera el valor de WS-FREC-CHECKPOINT (por defecto 50, configurable mediante el parámetro de clave 'BCT-FREC-CHECK' en el fichero PARM/CHQPARM), se ejecuta un checkpoint.

El checkpoint consiste en:

1. Reiniciar el contador WS-CNT-DESDE-CHECK a cero.
2. Cargar WS-NUM-SOL-DISP con el valor de HV-NUM-SOLICITUD (el número de la solicitud que acaba de procesarse).
3. Llamar a BCTCHECK con función 'CK' (grabar checkpoint), pasando el nombre del programa (WS-NOM-PROGRAMA, cuyo valor es 'CHQCHEQR'), la fecha de proceso (WS-FEC-PROCESO), el campo BCT-CLAVE-ULT inicializado previamente a espacios y con los primeros 9 caracteres rellenados con WS-NUM-SOL-DISP, y el contador de solicitudes leídas (WS-CNT-LEIDAS) como valor del contador BCT-CONTADOR.
4. Ejecutar un COMMIT WORK sobre la base de datos DB2. Esto confirma todas las inserciones y actualizaciones realizadas desde el último checkpoint, libera los bloqueos y hace los cambios permanentes. Si el proceso se interrumpe antes del siguiente checkpoint, puede reiniciarse desde el número de solicitud grabado en el checkpoint sin reprocesar las anteriores.

El parámetro WS-FREC-CHECKPOINT se carga desde el fichero PARM/CHQPARM mediante la clave 'BCT-FREC-CHECK'; en ese caso se toma únicamente la parte entera del valor leído (WS-PV-ENT), no el valor decimal completo, a diferencia de los parámetros de coste que sí usan la parte decimal. Si el fichero de parámetros no está disponible o la clave no aparece, se conserva el valor por defecto de 50.

**Algoritmo**

1. WS-CNT-DESDE-CHECK = WS-CNT-DESDE-CHECK + 1.
2. Si WS-CNT-DESDE-CHECK >= WS-FREC-CHECKPOINT:
   - a. WS-CNT-DESDE-CHECK = 0.
   - b. BCT-FUNCION = 'CK'.
   - c. BCT-PROGRAMA = WS-NOM-PROGRAMA (valor 'CHQCHEQR').
   - d. BCT-FEC-PROCESO = WS-FEC-PROCESO.
   - e. WS-NUM-SOL-DISP = HV-NUM-SOLICITUD.
   - f. BCT-CLAVE-ULT = espacios.
   - g. BCT-CLAVE-ULT (posiciones 1 a 9) = WS-NUM-SOL-DISP.
   - h. BCT-CONTADOR = WS-CNT-LEIDAS.
   - i. Llamar a BCTCHECK con BCT-AREA-CHECK.
   - j. Ejecutar COMMIT WORK en DB2.
3. Si WS-CNT-DESDE-CHECK < WS-FREC-CHECKPOINT, no se realiza ninguna acción adicional y el procesamiento continúa con la siguiente solicitud.
<!-- rule-end -->

<!-- rule-start -->
### 18. Regla / Operacion - 8000-CIERRE (Cierre y Resumen del Proceso)
<!-- reviewed -->

_Reviewed_

**Rule Status:** Relevante para Modernizacion

Ejecuta las tareas de finalización del proceso en el siguiente orden:

1. Cierra el cursor CUR_SOLIC mediante la instrucción SQL CLOSE.
2. Llama a BCTCHECK con función 'FN' (finalizar), pasando los siguientes datos: nombre del programa ('CHQCHEQR'), la fecha de proceso (WS-FEC-PROCESO) y el contador de solicitudes leídas (WS-CNT-LEIDAS). Esto marca el proceso como completado en la tabla BCT_CHECKPOINT, impidiendo que un reinicio accidental lo reprocese. A diferencia de la llamada periódica de checkpoint, en esta llamada no se informa ninguna clave de último registro procesado.
3. Muestra en la salida estándar un resumen del proceso con los siguientes contadores, en este orden exacto:
   - Una línea en blanco.
   - Encabezado: 'CHQCHEQR - EMISION DE CHEQUERAS  FECHA ' seguido de WS-FEC-PROCESO.
   - Solicitudes leídas (WS-CNT-LEIDAS).
   - Solicitudes emitidas (WS-CNT-EMITIDAS).
   - Solicitudes rechazadas (WS-CNT-RECHAZADAS).
   - Chequeras generadas (WS-CNT-CHEQUERAS).
   - Chequeras gratuitas (WS-CNT-GRATUITAS).
   - Hojas generadas (WS-CNT-HOJAS).
   - Total cobrado (WS-TOT-COBRADO), que es la suma acumulada del costo total de cada solicitud cobrada exitosamente a lo largo del proceso.
4. Si el indicador de modo simulación está activo (SW-SIMULA = 'S'), muestra el aviso '*** CORRIDA EN MODO SIMULACION ***'.
5. Si el contador de rechazadas (WS-CNT-RECHAZADAS) es mayor que cero **y** el RETURN-CODE actual es igual a 0, establece RETURN-CODE = 4. Esto indica al JCL que el proceso terminó con advertencias (hubo rechazos) pero sin error fatal. Si RETURN-CODE ya tiene un valor distinto de 0 (por ejemplo, 12 o 16 asignado ante un error previo), no se modifica.
6. Ejecuta un COMMIT WORK final para confirmar todos los cambios pendientes desde el último checkpoint.

**Algoritmo**

1. Ejecutar SQL CLOSE sobre CUR_SOLIC.
2. Preparar la llamada a BCTCHECK para finalización: BCT-FUNCION = 'FN', BCT-PROGRAMA = 'CHQCHEQR', BCT-FEC-PROCESO = WS-FEC-PROCESO, BCT-CONTADOR = WS-CNT-LEIDAS. Llamar a BCTCHECK. No se informa BCT-CLAVE-ULT en esta llamada (queda con el valor que tuviera).
3. Mostrar en la salida estándar, en este orden: una línea en blanco, el encabezado con la fecha de proceso, y cada uno de los siete contadores de resumen: solicitudes leídas, solicitudes emitidas, solicitudes rechazadas, chequeras generadas, chequeras gratuitas, hojas generadas y total cobrado.
4. Evaluar SW-SIMULA: si SW-SIMULA = 'S', mostrar el aviso de corrida en modo simulación.
5. Evaluar WS-CNT-RECHAZADAS y RETURN-CODE: si WS-CNT-RECHAZADAS > 0 y RETURN-CODE = 0, entonces establecer RETURN-CODE = 4. Si RETURN-CODE ya es distinto de 0, no modificarlo.
6. Ejecutar SQL COMMIT WORK para confirmar los cambios pendientes.
<!-- rule-end -->

<!-- rule-start -->
### 19. Regla / Operacion - 8100-FECHA-A-ISO (Conversion de Fecha a Formato ISO)
<!-- reviewed -->

_Reviewed_

Convierte la fecha de trabajo almacenada en WS-FECHA-TRAB (formato AAAAMMDD, 8 caracteres compactos) al formato ISO de DB2 (AAAA-MM-DD, 10 caracteres con guiones) y guarda el resultado en WS-FECHA-ISO.

La estructura WS-FECHA-TRAB-N es una redefinición de WS-FECHA-TRAB que permite acceder a sus partes: WS-FT-ANIO (4 caracteres), WS-FT-MES (2 caracteres), WS-FT-DIA (2 caracteres). La estructura WS-FECHA-ISO tiene sus propios campos separados por literales de guion ya incorporados en la definición: WS-FI-ANIO, un guion fijo, WS-FI-MES, un guion fijo, WS-FI-DIA.

La conversión es una simple copia de partes:
- WS-FI-ANIO recibe el contenido de WS-FT-ANIO.
- WS-FI-MES recibe el contenido de WS-FT-MES.
- WS-FI-DIA recibe el contenido de WS-FT-DIA.

Los guiones entre las partes son literales fijos en la definición de WS-FECHA-ISO, por lo que no es necesario copiarlos explícitamente.

Una vez construida, WS-FECHA-ISO se utiliza inmediatamente en el párrafo de inicio (1000-INICIO) para cargar la variable de host HV-FEC-PROCESO, que es la fecha de proceso en formato ISO que se emplea en todas las operaciones SQL del programa (inserciones en CHQ_CHEQUERA, actualizaciones de CHQ_SOLICITUD, tanto en emisiones como en rechazos).

**Estado de la Regla:** Relevante para Modernización

**Algoritmo**

1. Copiar WS-FT-ANIO (posiciones 1 a 4 de WS-FECHA-TRAB) en WS-FI-ANIO.
2. Copiar WS-FT-MES (posiciones 5 y 6 de WS-FECHA-TRAB) en WS-FI-MES.
3. Copiar WS-FT-DIA (posiciones 7 y 8 de WS-FECHA-TRAB) en WS-FI-DIA.
4. El resultado en WS-FECHA-ISO tiene la forma 'AAAA-MM-DD' porque los guiones separadores son parte fija de la definición de esa estructura.
5. El valor resultante de WS-FECHA-ISO se mueve a la variable de host HV-FEC-PROCESO, que es la que se usa en todas las sentencias SQL del programa para registrar la fecha de proceso.
<!-- rule-end -->

<!-- rule-start -->
### 20. Regla / Operacion - 9900-REGISTRA-ERROR (Registro Centralizado de Errores)
<!-- reviewed -->

_Reviewed_

Prepara y envia una entrada al logger centralizado SDULOGER. Se llama cada vez que ocurre un error o una condicion de advertencia que debe quedar registrada en el archivo VSAM LOGSIDEP.

Los campos que se preparan antes de llamar a SDULOGER son:

- **Nivel:** 'E' (error). Este valor es fijo; el parrafo 9900-REGISTRA-ERROR siempre registra con nivel de error, independientemente de si el codigo de error corresponde a un aviso (por ejemplo, 'A0001').
- **Programa:** nombre del programa ('CHQCHEQR'), tomado de la variable WS-NOM-PROGRAMA.
- **Parrafo:** WS-PARRAFO-ACT (el nombre del bloque logico que estaba activo cuando ocurrio el error).
- **Codigo de error:** WS-COD-ERROR (por ejemplo 'E0001', 'E0004', 'A0001').
- **Glosa:** WS-GLOSA-ERROR (descripcion del error).
- **Cuenta:** HV-CUENTA (la cuenta que se estaba procesando).
- **DOI:** espacios (no se registra el documento de identidad en este programa).
- **Importe:** 0.
- **Usuario:** 'BATCH' (literal fijo).
- **Terminal:** nombre del programa ('CHQCHEQR'), tomado de la variable WS-NOM-PROGRAMA.
- **Canal:** SDU-CAN-BATCH, cuyo valor definido en SDUCONST es 'BA'.
- **Fecha:** WS-FEC-PROCESO (fecha de proceso del batch, en formato AAAAMMDD).
- **SQLCODE:** el valor actual de SQLCODE al momento del error (puede ser 0 si el error no es de base de datos).

La subrutina SDULOGER escribe el registro en el archivo VSAM LOGSIDEP, cuya clave fisica se compone de: fecha del sistema + hora + nombre de programa + contador secuencial interno de SDULOGER. Si el VSAM no esta disponible, SDULOGER se degrada silenciosamente a mostrar el error por pantalla mediante DISPLAY, sin notificar al llamador ni alterar el codigo de retorno devuelto a CHQCHEQR.

**Rule Status:** Relevante para Modernizacion

**Algoritmo**

1. Mover 'E' a SDU-LG-NIVEL.
2. Mover WS-NOM-PROGRAMA ('CHQCHEQR') a SDU-LG-PROGRAMA.
3. Mover WS-PARRAFO-ACT a SDU-LG-PARRAFO.
4. Mover WS-COD-ERROR a SDU-LG-COD-ERROR.
5. Mover WS-GLOSA-ERROR a SDU-LG-GLOSA.
6. Mover HV-CUENTA a SDU-LG-CUENTA.
7. Mover espacios a SDU-LG-DOI.
8. Mover cero a SDU-LG-IMPORTE.
9. Mover 'BATCH' a SDU-LG-USUARIO.
10. Mover WS-NOM-PROGRAMA ('CHQCHEQR') a SDU-LG-TERMINAL.
11. Mover SDU-CAN-BATCH ('BA') a SDU-LG-CANAL.
12. Mover WS-FEC-PROCESO a SDU-LG-FECHA.
13. Mover el valor actual de SQLCODE a SDU-LG-SQLCODE.
14. Llamar a SDULOGER pasando SDU-AREA-LOG como unico parametro.
<!-- rule-end -->

<!-- rule-start -->
### 21. Regla / Operacion - Codigo Muerto: 7900-RENOVAR-AGOTADAS
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Irrelevante para Modernizacion

**Algoritmo**

No aplica. El bloque está inactivo y no debe ser reimplementado a menos que el negocio lo solicite explícitamente.

El código fuente contiene, completamente comentado, el siguiente bloque de sentencia SQL que nunca se ejecuta:

```
UPDATE CHQ_CHEQUERA SET EST_CHEQUERA = 'AG'
 WHERE NOT EXISTS (SELECT 1 FROM CHQ_CHEQUE
                    WHERE EST_CHEQUE = 'DI')
```

Esta sentencia actualizaría a estado `'AG'` (agotada) todas las filas de la tabla `CHQ_CHEQUERA` para las que no exista ningún cheque en estado `'DI'` (disponible) en la tabla `CHQ_CHEQUE`. Nótese que la subconsulta correlacionada carece de la condición de unión entre `CHQ_CHEQUERA` y `CHQ_CHEQUE` por número de chequera, lo que significa que, de haberse ejecutado, habría marcado como agotadas **todas** las chequeras del sistema en el momento en que existiera al menos un cheque no disponible en cualquier cuenta, no únicamente las chequeras sin hojas disponibles propias.

La lógica fue desactivada en 2018 por decisión del área de Marketing y no fue eliminada del código fuente. El programa no realiza ninguna acción equivalente en su lugar: el estado `'AG'` no se asigna en ningún otro punto del programa `CHQCHEQR`.

El bloque no se compila, no se ejecuta y no tiene ninguna referencia activa en el programa.
<!-- rule-end -->

---

## Extraction metadata

- **Main file:** cobol/CHQCHEQR.cbl
- **Created:** 2026-11-08 15:59:28 UTC
- **Started:** 2026-11-08 16:08:17 UTC
- **Duration:** 01:06:24
- **LLM:** us.anthropic.claude-sonnet-4-6 (us.anthropic.claude-sonnet-4-6)
- **Context window:** 200000 tokens · **Max output:** 64000 tokens
- **Extraction prompt:** business_rules_extraction_cobol · **Reviewer prompt:** business_rules_reviewer_cobol
- **Token usage:** 1654710 total (1584508 input, 70202 output)

### Reference files (13)
Intended for the extraction; any excluded below were not submitted:
- cobol/BCTCHECK.cbl
- cobol/NTFENCOL.cbl
- cobol/SDCMAEST.cbl
- cobol/SDMPOSTA.cbl
- cobol/SDULOGER.cbl
- copybook/BCTIFCW.cpy
- copybook/CHQCONW.cpy
- copybook/NTFIFCW.cpy
- copybook/SDBPARMW.cpy
- copybook/SDCMAEW.cpy
- copybook/SDMPOSTW.cpy
- copybook/SDUCONST.cpy
- copybook/SDULOGW.cpy
