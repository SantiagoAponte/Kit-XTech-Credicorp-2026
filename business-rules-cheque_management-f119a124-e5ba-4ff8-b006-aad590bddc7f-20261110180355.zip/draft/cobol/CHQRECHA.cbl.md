# CHQRECHA.cbl: Liquidacion de Cheques Rechazados - Calculo de Multa, Comision y Reincidencia

## Overview

CHQRECHA es un programa batch del sistema SIDEP (Sistema Integrado de Depositos) del Banco Andes del Peru, perteneciente al modulo de Cheques y Compensacion (CHQ). Se ejecuta como un paso del trabajo JCL identificado como CHQJD010 (paso CHQRECHA), de forma programada dentro del ciclo de procesamiento nocturno del banco.

Su proposito central es la liquidacion de cheques rechazados: para cada rechazo registrado en la base de datos que aun no ha sido cobrado o que esta pendiente de cobro, el programa determina los cargos que corresponden segun el motivo del rechazo (multa por falta de fondos y/o comision de rechazo), calcula los importes en la moneda de la cuenta del girador aplicando el tipo de cambio vigente cuando corresponde, ejecuta el cobro a la cuenta giradora a traves del motor de posteo del core (SDMPOSTA), reintenta cobros fallidos de corridas anteriores, escala a estado de mora los cobros que llevan mas de 30 dias pendientes, aplica la regla de reincidencia (tres rechazos por falta de fondos en los ultimos 365 dias provocan el bloqueo de la cuenta y la anulacion de las chequeras vigentes) y notifica al girador por SMS mediante la cola de notificaciones (NTFENCOL).

Al finalizar, el programa emite un resumen estadistico con los totales de rechazos procesados, cobrados, pendientes, pasados a mora, sin cargo y cuentas bloqueadas, ademas de los importes acumulados de multas, comisiones e IGV.

## Process Flow

```mermaid
flowchart TD
    inicio("Inicio del programa")
    leer_parm[["Leer parametros de ejecucion<br/>(fecha de proceso, tarjeta JCL,<br/>archivo PARMCHQ)"]]
    calc_ventana["Calcular fecha limite de ventana<br/>de reincidencia<br/>(fecha de proceso menos 365 dias)"]
    abrir_cursor[["Abrir cursor DB2 sobre<br/>CHQ_RECHAZO con IND_COBRO = 'X' o 'P'"]]
    fetch["Leer siguiente rechazo del cursor"]
    fin_cursor{"Fin del<br/>cursor?"}
    leer_girador[["Leer datos de la cuenta giradora<br/>(SDCMAEST funcion 'LE')"]]
    determina_cargos{"Determinar cargos<br/>segun motivo de rechazo<br/>y estado de la cuenta"}
    sin_cargo["Registrar como sin cargo<br/>(motivos 03-07, 09, 10 o<br/>cuenta cerrada/inexistente)"]
    calcula_importes["Calcular multa, comision e IGV<br/>en la moneda de la cuenta<br/>(con tipo de cambio si es USD)"]
    cobrar[["Intentar cobro a la cuenta<br/>via SDMPOSTA"]]
    cobro_ok{"Cobro<br/>exitoso?"}
    marca_cobrado["Marcar como cobrado 'C'<br/>Acumular multa, comision e IGV"]
    evalua_pendiente{"Dias desde<br/>rechazo > 30?"}
    marca_mora["Marcar como mora 'M'"]
    marca_pendiente["Marcar como pendiente 'P'"]
    hay_error{"Error grave<br/>en el registro?"}
    reincidencia{"Motivo 01 y<br/>primera vez 'X'?"}
    cuenta_sf["Contar rechazos por falta<br/>de fondos en los ultimos<br/>365 dias para la cuenta"]
    tres_sf{"3 o mas<br/>rechazos?"}
    bloquear[["Bloquear cuenta (SDCMAEST 'BL')<br/>Anular cheques disponibles<br/>Bloquear chequeras vigentes<br/>Notificar por correo (NTFENCOL 'CHQ003')"]]
    actualiza_rechazo[["Actualizar CHQ_RECHAZO con<br/>importes y nuevo estado de cobro"]]
    notificar{"Primera vez<br/>'X' y cuenta<br/>encontrada?"}
    sms[["Encolar SMS al girador<br/>(NTFENCOL 'CHQ002'<br/>numero de cheque y motivo)"]]
    cierre["Cerrar cursor DB2<br/>Mostrar resumen estadistico<br/>Confirmar transaccion (COMMIT)"]
    fin_programa("Fin del programa")

    inicio --> leer_parm
    leer_parm --> calc_ventana
    calc_ventana --> abrir_cursor
    abrir_cursor --> fetch
    fetch --> fin_cursor
    fin_cursor --> |"Si"| cierre
    fin_cursor --> |"No"| leer_girador
    leer_girador --> determina_cargos
    determina_cargos --> |"Sin cargo"| sin_cargo
    determina_cargos --> |"Con multa y/o comision"| calcula_importes
    sin_cargo --> hay_error
    calcula_importes --> cobrar
    cobrar --> cobro_ok
    cobro_ok --> |"Si"| marca_cobrado
    cobro_ok --> |"No: saldo insuf.<br/>o cuenta bloqueada"| evalua_pendiente
    cobro_ok --> |"Error grave"| hay_error
    evalua_pendiente --> |"Si"| marca_mora
    evalua_pendiente --> |"No"| marca_pendiente
    marca_cobrado --> hay_error
    marca_mora --> hay_error
    marca_pendiente --> hay_error
    hay_error --> |"Si"| fetch
    hay_error --> |"No"| reincidencia
    reincidencia --> |"No"| actualiza_rechazo
    reincidencia --> |"Si"| cuenta_sf
    cuenta_sf --> tres_sf
    tres_sf --> |"Si y cuenta activa"| bloquear
    tres_sf --> |"No"| actualiza_rechazo
    bloquear --> actualiza_rechazo
    actualiza_rechazo --> notificar
    notificar --> |"Si"| sms
    notificar --> |"No"| fetch
    sms --> fetch
    cierre --> fin_programa
```

<!-- general-rule-start -->

## General Business Rules:

### Tipo de programa y forma de ejecucion

CHQRECHA es un programa batch COBOL con acceso a DB2. Lo lanza el scheduler del banco a traves del trabajo JCL CHQJD010, paso CHQRECHA. Recibe una tarjeta de parametros de 80 bytes por la entrada estandar (SYSIN) con la fecha de proceso en formato AAAAMMDD en las primeras ocho posiciones. Si ese campo viene en blanco, el programa toma la fecha del sistema operativo. Tambien lee un archivo secuencial de parametros (DD PARMCHQ) con valores numericos que pueden sobreescribir los valores por defecto de comision y porcentaje de multa.

### Parametros de ejecucion y valores por defecto

Al arrancar, el programa intenta abrir el archivo de parametros PARMCHQ. Cada registro de ese archivo contiene una clave de 18 caracteres y un valor de 12 caracteres en formato entero-punto-decimal (nueve digitos enteros, un punto literal, dos decimales). El programa reconoce tres claves:

- `COM-RECHAZO-PEN`: comision de rechazo en soles. Valor por defecto: 25.00 soles.
- `COM-RECHAZO-USD`: comision de rechazo en dolares. Valor por defecto: 8.00 dolares.
- `MULTA-PCT`: porcentaje de multa por falta de fondos. Valor por defecto: 5.00 %.

Si el archivo no puede abrirse o no contiene alguna de las claves, se conservan los valores por defecto indicados.

### Calculo de la fecha limite de la ventana de reincidencia

Inmediatamente despues de leer los parametros, el programa calcula la fecha que delimita la ventana de 365 dias hacia atras desde la fecha de proceso. Para ello llama a la rutina de fechas SDUFECHA con la funcion `SUMADIAS`, pasando como numero de dias el valor de la constante `CHQ-DIAS-VENTANA-RECH` (365) multiplicado por -1, es decir, -365. La fecha resultante se almacena y se usa mas adelante para contar rechazos por falta de fondos dentro de ese periodo.

### Seleccion de registros a procesar

El programa abre un cursor sobre la tabla `CHQ_RECHAZO` y recupera todos los registros cuyo campo `IND_COBRO` tenga el valor `'X'` (rechazo nuevo, primera vez que se procesa) o `'P'` (pendiente de cobro de una corrida anterior). Los registros se ordenan por `NUM_RECHAZO` de forma ascendente. Para cada registro recuperado se leen los campos: numero de rechazo, numero de lote, numero de secuencia, numero de cuenta del girador, numero de cheque, codigo de motivo, importe del cheque, codigo de moneda y fecha de rechazo.

### Lectura de los datos de la cuenta giradora

Para cada rechazo, el programa llama a la subrutina SDCMAEST con la funcion `'LE'` (lectura) informando el numero de cuenta del girador. SDCMAEST consulta la tabla `CUENTA_MAESTRO` y devuelve, entre otros datos, el estado actual de la cuenta (`SDC-MAE-CTA-ESTADO`) y el codigo unico del titular (`SDC-MAE-TIT-CODIGO-UNICO`), que se necesitara para las notificaciones.

### Regla de negocio RN-CHQ-30 / RN-CHQ-32: determinacion de cargos segun motivo

Antes de calcular cualquier importe, el programa determina si corresponde aplicar cargos. Las reglas son:

- Si la cuenta giradora no existe en el maestro o si su estado es `'CE'` (cerrada), no se aplica ningun cargo. El registro queda sin cargo.
- Si el motivo de rechazo es `'01'` (sin fondos): se aplica multa Y comision.
- Si el motivo es `'02'` (firma incorrecta) o `'08'` (defecto formal): se aplica solo comision, sin multa.
- Para cualquier otro motivo (`'03'` cuenta cerrada, `'04'` cuenta bloqueada, `'05'` orden de no pago, `'06'` vencido, `'07'` no emitido, `'09'` ya pagado, `'10'` cuenta inexistente): no se aplica ningun cargo. El rechazo no es imputable al girador o la cuenta no puede cobrarse.

### Calculo de importes: multa, comision e IGV

Este calculo solo se ejecuta cuando hay al menos un cargo que aplicar (multa o comision o ambas).

**Conversion a soles para la multa:**

- Si la moneda de la cuenta es soles (`'604'`): el importe del cheque en soles es directamente el campo `MON_CHEQUE` del registro de rechazo.
- Si la moneda es dolares u otra moneda extranjera: el programa llama a TESTCAMB con la funcion `'TC'`, informando la moneda de la cuenta como moneda origen, soles como moneda destino y el segmento `'MA'` (masivo). TESTCAMB devuelve el tipo de cambio de compra (`TES-TC-COMPRA`) y el de venta (`TES-TC-VENTA`). El importe en soles se calcula multiplicando el importe del cheque por el tipo de cambio de compra, con redondeo aritmetico estandar (half-up) a dos decimales.

**Calculo de la multa (solo para motivo `'01'`):**

1. Multa base en soles = importe del cheque en soles * porcentaje de multa / 100. El porcentaje de multa proviene del parametro `MULTA-PCT` (por defecto 5.00 %). El resultado se redondea a dos decimales.
2. Se calcula el piso: 1 % de la UIT vigente. La UIT vigente es la constante `SDU-UIT-VIGENTE` definida en SDUCONST, actualmente 4,300.00 soles. Piso = 4,300.00 * 0.01 = 43.00 soles (redondeado).
3. Se calcula el techo: 5 veces la UIT vigente. Techo = 4,300.00 * 5 = 21,500.00 soles (redondeado).
4. Si la multa base calculada es menor que el piso, se usa el piso. Si es mayor que el techo, se usa el techo.
5. Si la cuenta es en dolares: la multa en dolares = multa en soles / tipo de cambio de venta, con redondeo a dos decimales. Si la cuenta es en soles, la multa en soles es el importe final.

La multa no lleva IGV (criterio de la autoridad tributaria, aplicado desde 2005).

**Calculo de la comision:**

- Si la cuenta es en soles: comision = valor del parametro `COM-RECHAZO-PEN` (por defecto 25.00 soles).
- Si la cuenta es en dolares: comision = valor del parametro `COM-RECHAZO-USD` (por defecto 8.00 dolares).

**Calculo del IGV sobre la comision:**

IGV = comision * tasa de IGV. La tasa de IGV es la constante `CHQ-PCT-IGV` definida en CHQCONW, actualmente 0.18 (18 %). El resultado se redondea a dos decimales. El IGV se aplica unicamente sobre la comision, no sobre la multa.

**Total del cargo:**

Total cargo = multa + comision + IGV.

### Cobro a la cuenta giradora via SDMPOSTA

El programa llama a la subrutina SDMPOSTA para debitar el total del cargo de la cuenta giradora. El posteo se configura de la siguiente manera:

- Empresa: 1.
- Cuenta: numero de cuenta del girador.
- Tipo de operacion: `SDU-OP-COBRO-COMISION` (codigo `'060'`).
- Signo: `'D'` (debito / cargo).
- Importe: total del cargo (multa + comision + IGV).
- Glosa: `'MULTA/COM RECHAZO CHQ '` seguido del numero de cheque en ocho digitos.
- Referencia y numero de documento: numero de cheque.
- Tipo de documento: `'CH'`.
- Canal: batch (`SDU-CAN-BATCH`).
- Identificador de batch: `'CHQJD010'`.
- Los indicadores de forzar cobro, exonerar ITF y solo validar se envian en `'N'`.

SDMPOSTA valida el saldo disponible, registra el movimiento en la tabla de movimientos, actualiza el saldo del maestro y genera el asiento contable correspondiente. El ITF sobre la operacion lo calcula y registra SDMPOSTA de forma autonoma.

**Resultado del cobro:**

- Si SDMPOSTA devuelve codigo de retorno 0000 (exito): el estado del cobro se marca como `'C'` (cobrado). Se acumulan los totales de multas, comisiones e IGV en los contadores del programa.
- Si SDMPOSTA devuelve codigo 0040 (saldo insuficiente) o 0020 (cuenta bloqueada para cargos): se ejecuta la logica de pendiente descrita a continuacion.
- Cualquier otro codigo de error de SDMPOSTA se registra como error grave en la bitacora y el registro se omite del resto del procesamiento.

### Regla de negocio RN-CHQ-33: escalacion a mora por antiguedad del pendiente

Cuando el cobro no puede realizarse por saldo insuficiente o cuenta bloqueada, el programa calcula la diferencia en dias calendario entre la fecha de rechazo (`FEC_RECHAZO`) y la fecha de proceso actual, llamando a SDUFECHA con la funcion `'DIFDIAS'`.

- Si la diferencia es mayor a 30 dias: el estado del cobro se marca como `'M'` (mora). El contador de pasados a mora se incrementa en uno.
- Si la diferencia es de 30 dias o menos: el estado del cobro se marca como `'P'` (pendiente). El contador de pendientes se incrementa en uno. El cobro se reintentara en la siguiente ejecucion del programa, ya que el cursor selecciona tanto los registros `'X'` como los `'P'`.

### Regla de negocio RN-CHQ-31: reincidencia por cheques sin fondos

Esta regla se evalua unicamente cuando el indicador de cobro del registro es `'X'` (primera vez que se procesa) y el motivo de rechazo es `'01'` (sin fondos). Si cualquiera de esas dos condiciones no se cumple, la evaluacion se omite.

El programa ejecuta una consulta SQL sobre la tabla `CHQ_RECHAZO` contando cuantos registros existen para la misma cuenta con motivo `'01'` y con fecha de rechazo posterior a la fecha limite de la ventana de reincidencia calculada al inicio (es decir, en los ultimos 365 dias). El resultado se compara con la constante `CHQ-MAX-RECHAZOS-SF`, que vale 3.

Si el conteo es igual o mayor a 3 Y el estado actual de la cuenta es `'AC'` (activa):

1. Se llama a SDCMAEST con la funcion `'BL'` (bloqueo), indicando el nuevo estado `'BL'` (bloqueada) y el motivo de bloqueo `'CHQ3'`.
2. Si el bloqueo es exitoso, se ejecutan las siguientes actualizaciones en DB2:
   - En la tabla `CHQ_CHEQUE`: todos los cheques de esa cuenta cuyo estado sea `'DI'` (disponible) pasan a estado `'AN'` (anulado), registrando la fecha de proceso en el campo `FEC_ESTADO`.
   - En la tabla `CHQ_CHEQUERA`: todas las chequeras de esa cuenta cuyo estado sea `'EM'` (emitida) o `'EN'` (entregada) pasan a estado `'BL'` (bloqueada).
3. Se encola una notificacion por correo electronico al titular mediante NTFENCOL, usando la plantilla `'CHQ003'`, canal `'EM'`, prioridad 1 (urgente), con el texto `'CUENTA BLOQUEADA POR 3 CHEQUES SIN FONDOS'` como parametro.
4. El contador de cuentas bloqueadas se incrementa en uno.

Si el bloqueo falla en SDCMAEST, se registra el error en la bitacora pero el procesamiento del rechazo continua.

### Actualizacion del registro de rechazo en CHQ_RECHAZO

Despues de ejecutar la logica de reincidencia (o de omitirla), y siempre que no haya habido un error grave en el registro, el programa actualiza la fila correspondiente en `CHQ_RECHAZO` usando el campo `NUM_RECHAZO` como clave. Se escriben los campos `MON_MULTA`, `MON_COMISION` y `MON_IGV` con los importes calculados (o cero si no hubo calculo).

- Si el nuevo estado del cobro es `'C'`: se actualiza ademas el campo `IND_COBRO` a `'C'` y se escribe la fecha de proceso en el campo `FEC_COBRO`.
- En cualquier otro caso (pendiente `'P'`, mora `'M'`, sin cargo): se actualiza solo el campo `IND_COBRO` con el nuevo estado, sin tocar `FEC_COBRO`.

### Notificacion al girador por SMS

La notificacion por SMS se envia unicamente cuando el indicador de cobro original del registro era `'X'` (primera vez que se procesa) y cuando la lectura de los datos del girador en SDCMAEST fue exitosa. Se llama a NTFENCOL con:

- Canal: `'SM'` (SMS).
- Plantilla: `'CHQ002'`.
- Codigo unico del titular: tomado de los datos del maestro de cuenta.
- Parametros: numero de cheque separado por `'|'` del codigo de motivo de rechazo, para que la plantilla pueda sustituir las variables `{1}` y `{2}`.
- Prioridad: 3.

NTFENCOL valida la plantilla, arma el texto sustituyendo las variables y encola el mensaje en el archivo VSAM NTFCOLA. El envio real al proveedor de SMS lo realiza un proceso batch separado (NTFENVIO).

### Cierre y codigos de retorno del trabajo

Al finalizar el procesamiento de todos los registros, el programa cierra el cursor DB2, muestra por la salida estandar el resumen de la ejecucion con todos los contadores y totales acumulados, y ejecuta un COMMIT para confirmar todas las actualizaciones de la sesion.

Los codigos de retorno que el programa puede devolver al JCL son:

- 0: proceso completado sin errores y sin cobros pendientes.
- 4: proceso completado pero quedan registros en estado pendiente `'P'`.
- 12: error irrecuperable al leer el cursor (FETCH fallido).
- 16: error irrecuperable al abrir el cursor.

### Codigo inactivo: condonacion de multa

El programa contiene un bloque de codigo comentado (nunca activado en produccion) que correspondia a una funcion de condonacion de multa por autorizacion gerencial. Ese bloque simplemente llevaria la multa a cero y recalcularia el total del cargo como la suma de comision mas IGV. No tiene efecto alguno en el comportamiento actual del programa.

### Subrutinas externas invocadas

| Subrutina | Proposito dentro de CHQRECHA |
|---|---|
| SDCMAEST | Leer datos de la cuenta giradora; bloquear la cuenta en caso de reincidencia |
| SDMPOSTA | Debitar el total de cargos (multa + comision + IGV) de la cuenta giradora |
| TESTCAMB | Obtener el tipo de cambio compra/venta para cheques en moneda extranjera |
| SDUFECHA | Calcular la fecha limite de la ventana de reincidencia; calcular dias entre fechas para determinar mora |
| NTFENCOL | Encolar notificacion SMS al girador y notificacion por correo en caso de bloqueo |
| SDULOGER | Registrar errores y eventos en la bitacora centralizada del sistema |

<!-- general-rule-end -->

## Dependencies

El programa CHQRECHA concentra un numero elevado de dependencias externas: subrutinas del nucleo del sistema, copybooks de definicion de datos y de interfaz, tablas DB2 propias del dominio de cheques y tablas de otros dominios, un archivo de parametros secuencial y un archivo VSAM de log. Todas las dependencias son internas al sistema SIDEP (Sistema Integrado de Depositos) del Banco Andes del Peru. No se utiliza ninguna API externa ni paquete de terceros.

Los puntos mas relevantes para la modernizacion son los siguientes:

- Cuatro subrutinas del nucleo (SDMPOSTA, SDCMAEST, SDUFECHA, SDULOGER) concentran toda la logica de posteo contable, mantenimiento del maestro de cuentas, aritmetica de fechas y registro de bitacora. Cualquier reemplazo de CHQRECHA debe reproducir o invocar esas mismas capacidades.
- El cobro de cargos se realiza exclusivamente a traves de SDMPOSTA. Esta subrutina valida saldo, calcula ITF, inserta el movimiento en DB2 y actualiza el saldo del maestro. CHQRECHA no toca la tabla de movimientos ni el maestro directamente para el posteo.
- SDCMAEST es el unico punto de acceso a la tabla CUENTA_MAESTRO. CHQRECHA lo invoca en dos modos: lectura ('LE') para obtener el estado y los datos del girador, y bloqueo ('BL') para cambiar el estado de la cuenta a bloqueada por reincidencia. El copybook SDCMAEW define el area de comunicacion; sin embargo, la advertencia documentada en ese copybook senala que dos programas del core (CTSCERTI y SDMPOSTA) replicaron el area a mano antes de que el copybook existiera, por lo que un cambio de estructura en SDCMAEW no seria detectado en compilacion para esos programas.
- SDUFECHA se invoca tres veces con funciones distintas: 'SUMADIAS' para calcular la fecha de inicio de la ventana de reincidencia (365 dias atras), 'DIFDIAS' para calcular los dias transcurridos desde el rechazo y determinar si un pendiente supera los 30 dias, y 'SUMADIAS' nuevamente en el modulo SDMPOSTA cuando este necesita resolver la fecha de proceso. La tabla de feriados precargada en SDUFECHA cubre solamente hasta 2019; para anios posteriores el calculo de dias habiles depende unicamente de los feriados nacionales fijos hardcodeados en esa subrutina, lo que representa un riesgo operativo.
- TESTCAMB se invoca solo para cheques en moneda extranjera, para obtener el tipo de cambio compra y venta del dia con spread por segmento masivo ('MA'). Si TESTCAMB no devuelve cotizacion, el registro queda en error y no se cobra; no existe tipo de cambio de contingencia en este flujo (esa opcion fue rechazada por Tesoreria y permanece comentada en TESTCAMB).
- NTFENCOL se invoca hasta dos veces por rechazo: una para enviar un SMS al girador (plantilla CHQ002, canal 'SM', prioridad 3) y otra para encolar una notificacion por correo al girador en caso de bloqueo de cuenta por reincidencia (plantilla CHQ003, canal 'EM', prioridad 1). NTFENCOL no envia el mensaje en linea; lo escribe en el VSAM NTFCOLA y el envio real lo realiza el proceso NTFENVIO en una corrida posterior.
- SDULOGER se invoca cada vez que se detecta un error o se necesita dejar auditoria. Escribe en el VSAM LOGSIDEP. Si ese archivo no esta disponible, SDULOGER degrada silenciosamente a DISPLAY y devuelve codigo de retorno '00' al llamador, por lo que CHQRECHA no detecta la falla del log.
- Existe un bloque de codigo comentado denominado '9500-CONDONA-MULTA' que habria llamado a una subrutina 'SDGCONDO' para condonar la multa por autorizacion gerencial. Ese bloque nunca se activo en produccion, no esta compilado y no tiene efecto alguno. No debe considerarse como comportamiento del programa.

| Dependencia | Descripcion | Tipo | Referencia | Relevancia para Modernizacion |
|---|---|---|---|---|
| SDMPOSTA | Motor de posteo de movimientos. Valida saldo disponible, calcula ITF, inserta en SIDEP.MOVIMIENTO, actualiza CUENTA_MAESTRO y genera asiento contable. CHQRECHA lo invoca para cobrar la multa, la comision y el IGV como un unico cargo debito. | Subrutina del nucleo (CALL) | SDMPOSTA.cbl | Unica puerta autorizada para afectar saldos. Debe reemplazarse o envolverse en el sistema moderno. Tiene dependencias propias de SDCMAEST, SDMVALSA, SDXITFCA, SDGASIEN y SDULOGER. |
| SDCMAEST | Hub de acceso a la tabla CUENTA_MAESTRO. CHQRECHA lo invoca con funcion 'LE' para leer estado y datos del girador, y con funcion 'BL' para bloquear la cuenta por reincidencia. | Subrutina del nucleo (CALL) | SDCMAEST.cbl | Unico acceso a CUENTA_MAESTRO. La advertencia de desalineacion con CTSCERTI y SDMPOSTA debe resolverse antes de cualquier cambio de estructura. |
| SDUFECHA | Aritmetica de fechas: suma de dias calendario ('SUMADIAS') y diferencia de dias ('DIFDIAS'). CHQRECHA la usa para calcular la fecha limite de la ventana de reincidencia y para determinar si un cobro pendiente supera los 30 dias. | Subrutina del nucleo (CALL) | SDUFECHA.cbl | La tabla de feriados precargada llega solo hasta 2019. Para modernizar se debe sustituir por un servicio de calendario actualizable. |
| TESTCAMB | Tipo de cambio al cliente con spread por segmento. Solo se invoca para cheques en moneda extranjera (distinta de soles). Devuelve TC compra y TC venta para el segmento masivo ('MA'). Si no hay cotizacion devuelve error y el registro queda sin cobrar. | Subrutina del dominio TES (CALL) | TESTCAMB.cbl | Lee las tablas DB2 TES_COTIZACION y TES_SPREAD. No existe TC de contingencia en este flujo. El sistema moderno debe decidir como manejar la ausencia de cotizacion. |
| NTFENCOL | Cola de notificaciones. CHQRECHA lo invoca para encolar un SMS al girador (plantilla CHQ002) y, en caso de bloqueo por reincidencia, un correo electronico (plantilla CHQ003). El envio real lo realiza NTFENVIO en un proceso separado. | Subrutina del dominio NTF (CALL) | NTFENCOL.cbl | Lee la tabla DB2 NTF_PLANTILLA y escribe en el VSAM NTFCOLA. En la modernizacion debe evaluarse si el envio sigue siendo asincrono o pasa a ser en linea. |
| SDULOGER | Registro centralizado de errores y auditoria. CHQRECHA lo invoca directamente en 9900-REGISTRA-ERROR y de forma indirecta a traves de SDMPOSTA, SDCMAEST, TESTCAMB y NTFENCOL. | Subrutina del nucleo (CALL) | SDULOGER.cbl | Escribe en el VSAM LOGSIDEP. Si el archivo no abre, degrada a DISPLAY sin avisar al llamador. El sistema moderno debe garantizar la disponibilidad del log o detectar su falla. |
| CHQ_RECHAZO | Tabla DB2 principal del proceso. CHQRECHA la lee mediante el cursor CUR_RECH (filas con IND_COBRO = 'X' o 'P', ordenadas por NUM_RECHAZO) y la actualiza al final de cada registro para reflejar el resultado del cobro (IND_COBRO = 'C', 'P', 'M'), los importes de multa, comision e IGV y la fecha de cobro. | Tabla DB2 (lectura y escritura) | Base de datos SIDEP, dominio CHQ | Tabla central del proceso. Debe migrarse con todos sus estados e indicadores. |
| CHQ_CHEQUE | Tabla DB2 de hojas de cheque individuales. CHQRECHA la actualiza en caso de bloqueo por reincidencia: cambia el estado de las hojas disponibles ('DI') a anuladas ('AN') y registra la fecha de estado. | Tabla DB2 (escritura) | Base de datos SIDEP, dominio CHQ | Solo se escribe en el flujo de reincidencia. La actualizacion es directa via SQL UPDATE, sin subrutina intermediaria. |
| CHQ_CHEQUERA | Tabla DB2 de chequeras. CHQRECHA la actualiza en caso de bloqueo por reincidencia: cambia el estado de las chequeras emitidas ('EM') o entregadas ('EN') a bloqueadas ('BL'). | Tabla DB2 (escritura) | Base de datos SIDEP, dominio CHQ | Solo se escribe en el flujo de reincidencia. La actualizacion es directa via SQL UPDATE. |
| CUENTA_MAESTRO | Tabla DB2 del maestro de cuentas. CHQRECHA no la accede directamente; lo hace a traves de SDCMAEST. | Tabla DB2 (acceso indirecto via SDCMAEST) | Base de datos SIDEP, tabla CUENTA_MAESTRO | Ver restricciones de acceso en SDCMAEST. |
| NTF_PLANTILLA | Tabla DB2 de plantillas de notificacion. La lee NTFENCOL para obtener el texto de las plantillas CHQ002 y CHQ003. CHQRECHA no la accede directamente. | Tabla DB2 (acceso indirecto via NTFENCOL) | Base de datos SIDEP, dominio NTF | Las plantillas CHQ002 (SMS rechazo) y CHQ003 (correo bloqueo) deben existir y estar activas para que las notificaciones funcionen. |
| TES_COTIZACION | Tabla DB2 con cotizaciones de mesa diarias por moneda. La lee TESTCAMB. CHQRECHA no la accede directamente. | Tabla DB2 (acceso indirecto via TESTCAMB) | Base de datos SIDEP, dominio TES | Debe tener cotizacion vigente para el dia de proceso cuando existan cheques en moneda extranjera. |
| TES_SPREAD | Tabla DB2 con spreads por segmento de cliente. La lee TESTCAMB para calcular el TC al cliente. CHQRECHA no la accede directamente. | Tabla DB2 (acceso indirecto via TESTCAMB) | Base de datos SIDEP, dominio TES | Debe tener spread definido para el segmento 'MA' (masivo). |
| SIDEP.MOVIMIENTO | Tabla DB2 de movimientos de cuenta. La escribe SDMPOSTA al registrar el cargo de multa, comision e IGV. CHQRECHA no la accede directamente. | Tabla DB2 (acceso indirecto via SDMPOSTA) | Base de datos SIDEP, tabla MOVIMIENTO | Destino final del posteo contable. |
| ARCH-PARM (PARMCHQ) | Archivo secuencial de parametros de ejecucion. Contiene hasta tres registros con las claves 'COM-RECHAZO-PEN' (comision en soles, defecto 25.00), 'COM-RECHAZO-USD' (comision en dolares, defecto 8.00) y 'MULTA-PCT' (porcentaje de multa, defecto 5.00). Si el archivo no abre, el programa continua con los valores por defecto sin emitir error. | Archivo secuencial QSAM (lectura) | DD PARMCHQ, miembro PARM/CHQPARM | Los valores por defecto estan hardcodeados en el programa. Si el archivo no existe o no abre, el proceso continua silenciosamente con esos valores. El sistema moderno debe externalizar estos parametros en una tabla o servicio de configuracion. |
| LOGSIDEP | Archivo VSAM indexado de bitacora del sistema. Lo escribe SDULOGER. CHQRECHA no lo accede directamente. | VSAM KSDS (escritura indirecta via SDULOGER) | DD LOGSIDEP | Si no esta disponible, SDULOGER degrada a DISPLAY sin notificar al llamador. |
| NTFCOLA | Archivo VSAM indexado de cola de notificaciones pendientes. Lo escribe NTFENCOL. CHQRECHA no lo accede directamente. | VSAM KSDS (escritura indirecta via NTFENCOL) | DD NTFCOLA | Si no esta disponible, NTFENCOL devuelve error pero CHQRECHA no interrumpe el proceso por ello. |
| FERIADOS | Archivo VSAM indexado de feriados del calendario bancario. Lo lee SDUFECHA para enriquecer su tabla interna. CHQRECHA no lo accede directamente. | VSAM KSDS (lectura indirecta via SDUFECHA) | DD FERIADOS | Si no abre, SDUFECHA continua con la tabla fija precargada (solo hasta 2019). El sistema moderno debe garantizar un calendario actualizado. |
| JCL CHQJD010, paso CHQRECHA | Trabajo batch que ejecuta el programa. Define el DD PARMCHQ con el archivo de parametros y suministra la tarjeta de control (SYSIN) con la fecha de proceso en los primeros 8 bytes. Si la fecha viene en blanco, el programa toma la fecha del sistema operativo. | JCL batch | CHQJD010, paso CHQRECHA | El identificador 'CHQJD010' se graba en cada movimiento posteado (campo POS-BATCH-ID). Debe preservarse o mapearse en el sistema moderno para trazabilidad. |
| SDBPARMW | Copybook que define el area de parametros de ejecucion batch (SDB-PARM-TARJETA, 80 bytes). CHQRECHA lo usa para leer la fecha de proceso desde SYSIN. | Copybook de datos (COPY) | SDBPARMW.cpy | Define la estructura de la tarjeta de control. Cualquier cambio en el formato de entrada del JCL debe reflejarse aqui. |
| SDULOGW | Copybook que define el area de comunicacion con SDULOGER (SDU-AREA-LOG). Lo incluyen CHQRECHA y todas las subrutinas que llama. | Copybook de datos (COPY) | SDULOGW.cpy | Interfaz del log. Si cambia, afecta a practicamente todo el core. |
| SDUCONST | Copybook de constantes institucionales: codigos de moneda (SDU-MON-SOLES = '604', SDU-MON-DOLARES = '840'), estados de cuenta (SDU-EST-ACTIVA = 'AC', SDU-EST-CERRADA = 'CE', SDU-EST-BLOQUEADA = 'BL'), codigos de retorno estandar, UIT vigente (SDU-UIT-VIGENTE = 4300.00) y canal batch (SDU-CAN-BATCH = 'BA'). | Copybook de datos (COPY) | SDUCONST.cpy | La UIT vigente (4300.00) esta hardcodeada aqui. Si cambia por decreto supremo, debe actualizarse en este copybook y recompilarse todo el core. |
| SDUFECHW | Copybook que define el area de comunicacion con SDUFECHA (SDU-AREA-FECHA). | Copybook de datos (COPY) | SDUFECHW.cpy | Interfaz de la rutina de fechas. |
| SDCMAEW | Copybook que define el area de comunicacion con SDCMAEST (SDC-AREA-MAESTRO). Incluye campos de cuenta, titular, saldos, fechas, auditoria e indicadores de bloqueo. | Copybook de datos (COPY) | SDCMAEW.cpy | Ver advertencia de desalineacion con CTSCERTI y SDMPOSTA documentada en el propio copybook. |
| SDMPOSTW | Copybook que define el area de comunicacion con SDMPOSTA (AREA-POSTEO). Incluye los campos de entrada del cargo, los saldos devueltos y los codigos de retorno (POS-SALDO-INSUF = 0040, POS-CTA-BLOQUEADA = 0020). | Copybook de datos (COPY) | SDMPOSTW.cpy | Interfaz del motor de posteo. Cualquier cambio obliga a recompilar todo el sistema. |
| CHQCONW | Copybook de constantes del dominio de cheques: motivos de rechazo (01 sin fondos, 02 firma, 08 defecto formal, etc.), CHQ-MAX-RECHAZOS-SF = 3, CHQ-DIAS-VENTANA-RECH = 365, CHQ-PCT-IGV = 0.18. Estos valores estan hardcodeados y no se leen del archivo de parametros. | Copybook de datos (COPY) | CHQCONW.cpy | Los umbrales de reincidencia y la tasa de IGV estan fijos en codigo. El comentario del propio copybook senala que su parametrizacion esta pendiente (ticket SD-2019-441). |
| TESIFCW | Copybook que define el area de comunicacion con TESTCAMB (TES-AREA-TC). | Copybook de datos (COPY) | TESIFCW.cpy | Interfaz del servicio de tipo de cambio. |
| NTFIFCW | Copybook que define el area de comunicacion con NTFENCOL (NTF-AREA-ENCOLA). Incluye canal, codigo de plantilla, codigo unico del cliente, parametros y prioridad. | Copybook de datos (COPY) | NTFIFCW.cpy | Interfaz del servicio de notificaciones. |

## Data Structure

A continuacion se presenta la estructura de datos del programa CHQRECHA y de los modulos y copybooks de referencia.

---

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| **ARCH-PARM - Archivo secuencial de parametros (DD PARMCHQ)** | | | | | | | | | |
| REG-PARM.PRM-CLAVE | PRM-CLAVE | Alfanumerico | 18 | Nombre del parametro de configuracion (p.ej. 'COM-RECHAZO-PEN', 'COM-RECHAZO-USD', 'MULTA-PCT') | Si | N/A | Clave de busqueda en el bucle de lectura del archivo de parametros | Si | Configuracion |
| REG-PARM.PRM-VALOR | PRM-VALOR | Alfanumerico | 12 | Valor del parametro en formato texto; los primeros 9 caracteres son la parte entera, el caracter 10 es el separador decimal y los ultimos 2 son la parte decimal | Si | N/A | Se convierte a numerico mediante la formula: parte-entera + (parte-decimal / 100) | Si | Configuracion |
| REG-PARM.FILLER | FILLER | Alfanumerico | 50 | Relleno no utilizado del registro de parametros | No | N/A | N/A | No | N/A |
| **WORKING-STORAGE - Identificacion del programa** | | | | | | | | | |
| WS-IDENTIFICACION.WS-NOM-PROGRAMA | WS-NOM-PROGRAMA | Alfanumerico | 8 | Nombre del programa en ejecucion; valor fijo 'CHQRECHA' | Si | 'CHQRECHA' | Se usa como identificador en las llamadas al logger SDULOGER y en la glosa de posteo | No | Control |
| WS-IDENTIFICACION.WS-PARRAFO-ACT | WS-PARRAFO-ACT | Alfanumerico | 20 | Nombre del parrafo activo al momento de producirse un error; se actualiza al inicio de cada seccion logica | No | Espacios | Facilita la localizacion del error en el log | Si | Control |
| WS-IDENTIFICACION.WS-COD-ERROR | WS-COD-ERROR | Alfanumerico | 6 | Codigo de error interno del programa (p.ej. 'E0001' a 'E0006') | No | Espacios | Se escribe en el log junto con WS-GLOSA-ERROR | Si | Control |
| WS-IDENTIFICACION.WS-GLOSA-ERROR | WS-GLOSA-ERROR | Alfanumerico | 120 | Descripcion textual del error ocurrido | No | Espacios | N/A | Si | Control |
| **WORKING-STORAGE - Indicadores (switches)** | | | | | | | | | |
| WS-SWITCHES.WS-FS-PARM | WS-FS-PARM | Alfanumerico | 2 | Codigo de estado del archivo de parametros ARCH-PARM; '00' indica apertura correcta | No | Espacios | Si el valor es distinto de '00' el archivo se ignora y se usan los valores por defecto | Si | Control |
| WS-SWITCHES.SW-FIN-CURSOR | SW-FIN-CURSOR | Alfanumerico | 1 | Indicador de fin del cursor CUR_RECH; 'S' = se agotaron los registros o se produjo un error fatal | No | 'N' | El valor 'S' activa la condicion FIN-CURSOR que detiene el bucle principal | Si | Control |
| WS-SWITCHES.SW-FIN-PARM | SW-FIN-PARM | Alfanumerico | 1 | Indicador de fin del archivo de parametros; 'S' = se leyo el ultimo registro | No | 'N' | Controla el bucle de lectura de ARCH-PARM | No | Control |
| WS-SWITCHES.SW-HAY-MULTA | SW-HAY-MULTA | Alfanumerico | 1 | Indica si al rechazo en curso le corresponde multa; 'S' = si | No | 'N' | Se activa unicamente para motivo de rechazo '01' (sin fondos) | Si | Regla de negocio |
| WS-SWITCHES.SW-HAY-COMISION | SW-HAY-COMISION | Alfanumerico | 1 | Indica si al rechazo en curso le corresponde comision de rechazo; 'S' = si | No | 'N' | Se activa para motivos '01', '02' y '08' | Si | Regla de negocio |
| WS-SWITCHES.SW-ES-DOLARES | SW-ES-DOLARES | Alfanumerico | 1 | Indica si la cuenta del girador esta en dolares (USD); 'S' = si | No | 'N' | Determina la ruta de calculo de la multa y la comision en moneda extranjera | Si | Regla de negocio |
| WS-SWITCHES.SW-ERROR-REG | SW-ERROR-REG | Alfanumerico | 1 | Indicador de error en el procesamiento del registro actual; 'S' = hay error (condicion HAY-ERROR-REG) | No | 'N' | Cuando se activa se omiten los pasos de reincidencia, actualizacion y notificacion para ese registro | Si | Control |
| **WORKING-STORAGE - Contadores y acumuladores** | | | | | | | | | |
| WS-CONTADORES.WS-CNT-LEIDOS | WS-CNT-LEIDOS | Numerico con signo, decimal empaquetado | 9 enteros | Total de registros de rechazo leidos del cursor CUR_RECH | No | 0 | Se incrementa en 1 por cada FETCH exitoso procesado | Si | Operacional |
| WS-CONTADORES.WS-CNT-COBRADOS | WS-CNT-COBRADOS | Numerico con signo, decimal empaquetado | 9 enteros | Total de rechazos cuyo cargo fue cobrado exitosamente en la cuenta | No | 0 | Se incrementa cuando SDMPOSTA devuelve codigo de retorno 0000 | Si | Operacional |
| WS-CONTADORES.WS-CNT-PENDIENTES | WS-CNT-PENDIENTES | Numerico con signo, decimal empaquetado | 9 enteros | Total de rechazos que quedaron en estado pendiente ('P') por saldo insuficiente o cuenta bloqueada, dentro de los 30 dias | No | 0 | Si es mayor que cero al cierre, el programa devuelve codigo de retorno 4 al JCL | Si | Operacional |
| WS-CONTADORES.WS-CNT-SIN-CARGO | WS-CNT-SIN-CARGO | Numerico con signo, decimal empaquetado | 9 enteros | Total de rechazos sin cargo aplicable (motivos no imputables al girador o cuenta cerrada/inexistente) | No | 0 | N/A | Si | Operacional |
| WS-CONTADORES.WS-CNT-A-MORA | WS-CNT-A-MORA | Numerico con signo, decimal empaquetado | 9 enteros | Total de rechazos pendientes con mas de 30 dias que pasan a estado mora ('M') | No | 0 | N/A | Si | Operacional |
| WS-CONTADORES.WS-CNT-BLOQUEOS | WS-CNT-BLOQUEOS | Numerico con signo, decimal empaquetado | 9 enteros | Total de cuentas bloqueadas por reincidencia (3 rechazos sin fondos en 365 dias) | No | 0 | N/A | Si | Operacional |
| WS-CONTADORES.WS-TOT-MULTAS | WS-TOT-MULTAS | Numerico con signo, decimal empaquetado | 13 enteros, 2 decimales | Suma acumulada de todas las multas cobradas en la corrida | No | 0 | Se imprime en el resumen de cierre | Si | Financiero |
| WS-CONTADORES.WS-TOT-COMISIONES | WS-TOT-COMISIONES | Numerico con signo, decimal empaquetado | 13 enteros, 2 decimales | Suma acumulada de todas las comisiones cobradas en la corrida | No | 0 | Se imprime en el resumen de cierre | Si | Financiero |
| WS-CONTADORES.WS-TOT-IGV | WS-TOT-IGV | Numerico con signo, decimal empaquetado | 13 enteros, 2 decimales | Suma acumulada del IGV cobrado sobre comisiones en la corrida | No | 0 | Se imprime en el resumen de cierre | Si | Financiero |
| **WORKING-STORAGE - Parametros operativos** | | | | | | | | | |
| WS-PARAMETROS.WS-COM-RECH-PEN | WS-COM-RECH-PEN | Numerico con signo, decimal empaquetado | 9 enteros, 2 decimales | Comision fija de rechazo para cuentas en soles (PEN) | Si | 25.00 | Se sobreescribe con el valor del archivo ARCH-PARM si la clave es 'COM-RECHAZO-PEN' | Si | Financiero |
| WS-PARAMETROS.WS-COM-RECH-USD | WS-COM-RECH-USD | Numerico con signo, decimal empaquetado | 9 enteros, 2 decimales | Comision fija de rechazo para cuentas en dolares (USD) | Si | 8.00 | Se sobreescribe con el valor del archivo ARCH-PARM si la clave es 'COM-RECHAZO-USD' | Si | Financiero |
| WS-PARAMETROS.WS-MULTA-PCT | WS-MULTA-PCT | Numerico con signo, decimal empaquetado | 3 enteros, 2 decimales | Porcentaje de multa aplicado al importe del cheque sin fondos | Si | 5.00 | Se sobreescribe con el valor del archivo ARCH-PARM si la clave es 'MULTA-PCT'; se usa en la formula: multa-PEN = importe-PEN * WS-MULTA-PCT / 100 | Si | Financiero |
| WS-VALOR-PARM.WS-PV-TEXTO | WS-PV-TEXTO | Alfanumerico | 12 | Buffer de texto para leer el valor del parametro del archivo antes de convertirlo a numerico | No | N/A | Se redefine en WS-PV-PARTES para extraer parte entera (9 digitos), separador (1 caracter) y parte decimal (2 digitos) | Si | Configuracion |
| WS-VALOR-PARM.WS-PV-PARTES.WS-PV-ENT | WS-PV-ENT | Numerico | 9 | Parte entera del valor del parametro leido del archivo | No | N/A | REDEFINES sobre WS-PV-TEXTO, posiciones 1-9 | Si | Configuracion |
| WS-VALOR-PARM.WS-PV-PARTES.WS-PV-PUNTO | WS-PV-PUNTO | Alfanumerico | 1 | Caracter separador decimal del valor del parametro (se espera '.') | No | N/A | REDEFINES sobre WS-PV-TEXTO, posicion 10 | No | Configuracion |
| WS-VALOR-PARM.WS-PV-PARTES.WS-PV-DEC | WS-PV-DEC | Numerico | 2 | Parte decimal del valor del parametro leido del archivo | No | N/A | REDEFINES sobre WS-PV-TEXTO, posiciones 11-12 | Si | Configuracion |
| WS-VALOR-PARM.WS-PV-NUMERO | WS-PV-NUMERO | Numerico con signo, decimal empaquetado | 9 enteros, 2 decimales | Valor numerico del parametro ya convertido; resultado de: WS-PV-ENT + (WS-PV-DEC / 100) | No | N/A | Se copia al campo de parametro correspondiente segun la clave | Si | Configuracion |
| **WORKING-STORAGE - Fechas** | | | | | | | | | |
| WS-FECHAS.WS-FEC-PROCESO | WS-FEC-PROCESO | Alfanumerico | 8 | Fecha de proceso en formato AAAAMMDD; se toma del parametro del JCL o del sistema | Si | Fecha del sistema | Fecha base para todos los calculos de diferencia de dias y para el posteo en SDMPOSTA | Si | Operacional |
| WS-FECHAS.WS-FECHA-TRAB | WS-FECHA-TRAB | Alfanumerico | 8 | Fecha de trabajo auxiliar usada en llamadas a SDUFECHA; se redefine en WS-FECHA-TRAB-N | No | N/A | Actua como entrada y salida temporal en operaciones de aritmetica de fechas | No | Operacional |
| WS-FECHAS.WS-FECHA-TRAB-N.WS-FT-ANIO | WS-FT-ANIO | Alfanumerico | 4 | Componente anio de WS-FECHA-TRAB (REDEFINES) | No | N/A | Se usa para construir WS-FECHA-ISO | No | Operacional |
| WS-FECHAS.WS-FECHA-TRAB-N.WS-FT-MES | WS-FT-MES | Alfanumerico | 2 | Componente mes de WS-FECHA-TRAB (REDEFINES) | No | N/A | Se usa para construir WS-FECHA-ISO | No | Operacional |
| WS-FECHAS.WS-FECHA-TRAB-N.WS-FT-DIA | WS-FT-DIA | Alfanumerico | 2 | Componente dia de WS-FECHA-TRAB (REDEFINES) | No | N/A | Se usa para construir WS-FECHA-ISO | No | Operacional |
| WS-FECHA-ISO.WS-FI-ANIO | WS-FI-ANIO | Alfanumerico | 4 | Componente anio de la fecha en formato ISO (AAAA-MM-DD) | No | N/A | Parte del area WS-FECHA-ISO que incluye literales '-' fijos | No | Operacional |
| WS-FECHA-ISO.WS-FI-MES | WS-FI-MES | Alfanumerico | 2 | Componente mes de la fecha en formato ISO | No | N/A | N/A | No | Operacional |
| WS-FECHA-ISO.WS-FI-DIA | WS-FI-DIA | Alfanumerico | 2 | Componente dia de la fecha en formato ISO | No | N/A | N/A | No | Operacional |
| **WORKING-STORAGE - Area de calculo** | | | | | | | | | |
| WS-CALCULO.WS-IMPORTE-PEN | WS-IMPORTE-PEN | Numerico con signo, decimal empaquetado | 13 enteros, 2 decimales | Importe del cheque expresado en soles; si la cuenta es en USD se obtiene multiplicando HV-MON-CHEQUE por WS-TC-COMPRA | No | N/A | Base de calculo para la multa en soles | Si | Financiero |
| WS-CALCULO.WS-MULTA-PEN | WS-MULTA-PEN | Numerico con signo, decimal empaquetado | 13 enteros, 2 decimales | Multa calculada en soles antes de aplicar piso y techo; resultado de: WS-IMPORTE-PEN * WS-MULTA-PCT / 100 | No | N/A | Puede ser ajustada al piso (1% de la UIT) o al techo (5 UIT) | Si | Financiero |
| WS-CALCULO.WS-MULTA-MIN | WS-MULTA-MIN | Numerico con signo, decimal empaquetado | 9 enteros, 2 decimales | Importe minimo de multa en soles; resultado de: SDU-UIT-VIGENTE * 0.01 | No | N/A | UIT vigente = 4300.00; piso = 43.00 soles | Si | Financiero |
| WS-CALCULO.WS-MULTA-MAX | WS-MULTA-MAX | Numerico con signo, decimal empaquetado | 9 enteros, 2 decimales | Importe maximo de multa en soles; resultado de: SDU-UIT-VIGENTE * 5 | No | N/A | UIT vigente = 4300.00; techo = 21500.00 soles | Si | Financiero |
| WS-CALCULO.WS-MULTA | WS-MULTA | Numerico con signo, decimal empaquetado | 11 enteros, 2 decimales | Multa definitiva en la moneda de la cuenta; si es USD = WS-MULTA-PEN / WS-TC-VENTA; si es PEN = WS-MULTA-PEN | No | 0 | Se copia a HV-MON-MULTA para actualizar CHQ_RECHAZO | Si | Financiero |
| WS-CALCULO.WS-COMISION | WS-COMISION | Numerico con signo, decimal empaquetado | 9 enteros, 2 decimales | Comision de rechazo en la moneda de la cuenta; 25.00 PEN o 8.00 USD segun parametro | No | 0 | Base para el calculo del IGV | Si | Financiero |
| WS-CALCULO.WS-IGV | WS-IGV | Numerico con signo, decimal empaquetado | 9 enteros, 2 decimales | IGV calculado sobre la comision; resultado de: WS-COMISION * CHQ-PCT-IGV (0.18) con redondeo half-up | No | 0 | La multa no lleva IGV segun criterio tributario (Ticket SD-2005-8) | Si | Financiero |
| WS-CALCULO.WS-TOTAL-CARGO | WS-TOTAL-CARGO | Numerico con signo, decimal empaquetado | 13 enteros, 2 decimales | Importe total a debitar de la cuenta; resultado de: WS-MULTA + WS-COMISION + WS-IGV | No | N/A | Es el importe que se envia a SDMPOSTA en POS-IMPORTE | Si | Financiero |
| WS-CALCULO.WS-TC-COMPRA | WS-TC-COMPRA | Numerico con signo, decimal empaquetado | 5 enteros, 4 decimales | Tipo de cambio de compra del banco (soles por unidad de moneda extranjera) devuelto por TESTCAMB | No | N/A | Se usa para convertir el importe del cheque en USD a soles | Si | Financiero |
| WS-CALCULO.WS-TC-VENTA | WS-TC-VENTA | Numerico con signo, decimal empaquetado | 5 enteros, 4 decimales | Tipo de cambio de venta del banco (soles por unidad de moneda extranjera) devuelto por TESTCAMB | No | N/A | Se usa para convertir la multa en soles a dolares | Si | Financiero |
| WS-CALCULO.WS-DIAS-PENDIENTE | WS-DIAS-PENDIENTE | Numerico con signo, decimal empaquetado | 7 enteros | Diferencia en dias calendario entre la fecha de rechazo y la fecha de proceso; calculada por SDUFECHA funcion 'DIFDIAS' | No | N/A | Si es mayor que 30 el rechazo pasa a mora 'M'; si es 30 o menos queda pendiente 'P' | Si | Regla de negocio |
| WS-CALCULO.WS-CANT-SF | WS-CANT-SF | Numerico con signo, decimal empaquetado | 5 enteros | Cantidad de rechazos por sin fondos (motivo '01') que tiene la cuenta en los ultimos 365 dias | No | N/A | Si es mayor o igual a CHQ-MAX-RECHAZOS-SF (3) se bloquea la cuenta | Si | Regla de negocio |
| WS-NUM-CHEQUE-DISP | WS-NUM-CHEQUE-DISP | Numerico | 8 | Numero del cheque en formato de visualizacion; copia de HV-NUM-CHEQUE | No | 0 | Se usa en la glosa y en los campos de referencia y documento del posteo | Si | Operacional |
| WS-IND-COBRO-NUEVO | WS-IND-COBRO-NUEVO | Alfanumerico | 1 | Nuevo estado de cobro que se grabara en CHQ_RECHAZO; 'C'=cobrado, 'P'=pendiente, 'M'=mora, 'N'=sin cargo | No | 'N' | Determina cual de los dos UPDATE se ejecuta en el parrafo 6000-ACTUALIZA-RECHAZO | Si | Regla de negocio |
| **WORKING-STORAGE - Variables host para DB2 (cursor CUR_RECH y sentencias SQL)** | | | | | | | | | |
| WS-HOST-VARIABLES.HV-NUM-RECHAZO | HV-NUM-RECHAZO | Numerico con signo, decimal empaquetado | 9 enteros | Identificador unico del registro de rechazo en CHQ_RECHAZO | Si | N/A | Clave WHERE en los UPDATE de CHQ_RECHAZO | Si | Identificador |
| WS-HOST-VARIABLES.HV-NUM-LOTE | HV-NUM-LOTE | Numerico con signo, decimal empaquetado | 6 enteros | Numero de lote de compensacion al que pertenece el cheque rechazado | Si | N/A | Se lee del cursor; no se modifica en este programa | No | Operacional |
| WS-HOST-VARIABLES.HV-NUM-SECUENCIA | HV-NUM-SECUENCIA | Numerico con signo, decimal empaquetado | 7 enteros | Numero de secuencia del cheque dentro del lote | Si | N/A | Se lee del cursor; no se modifica en este programa | No | Operacional |
| WS-HOST-VARIABLES.HV-CUENTA | HV-CUENTA | Alfanumerico | 14 | Numero de cuenta giradora del cheque rechazado | Si | N/A | Se pasa a SDCMAEST, SDMPOSTA y SDUFECHA; es la cuenta que recibe el cargo | Si | Identificador |
| WS-HOST-VARIABLES.HV-NUM-CHEQUE | HV-NUM-CHEQUE | Numerico con signo, decimal empaquetado | 8 enteros | Numero del cheque rechazado | Si | N/A | Se copia a WS-NUM-CHEQUE-DISP para uso en glosas | Si | Identificador |
| WS-HOST-VARIABLES.HV-COD-MOTIVO | HV-COD-MOTIVO | Alfanumerico | 2 | Codigo del motivo de rechazo segun tabla de la Camara de Compensacion; valores posibles: '01' a '10' | Si | N/A | Determina si se aplica multa y/o comision; '01'=sin fondos activa ambas; '02' y '08' solo comision; resto sin cargo | Si | Regla de negocio |
| WS-HOST-VARIABLES.HV-MON-CHEQUE | HV-MON-CHEQUE | Numerico con signo, decimal empaquetado | 13 enteros, 2 decimales | Importe del cheque en la moneda de la cuenta | Si | N/A | Base para el calculo de la multa | Si | Financiero |
| WS-HOST-VARIABLES.HV-COD-MONEDA | HV-COD-MONEDA | Alfanumerico | 3 | Codigo ISO de moneda de la cuenta giradora; '604'=soles, '840'=dolares | Si | N/A | Determina si se requiere conversion de tipo de cambio | Si | Financiero |
| WS-HOST-VARIABLES.HV-FEC-RECHAZO | HV-FEC-RECHAZO | Alfanumerico | 8 | Fecha en que se proceso el rechazo del cheque, en formato AAAAMMDD | Si | N/A | Se usa como fecha inicial en el calculo de diferencia de dias para determinar mora | Si | Operacional |
| WS-HOST-VARIABLES.HV-IND-COBRO | HV-IND-COBRO | Alfanumerico | 1 | Estado actual de cobro del rechazo en CHQ_RECHAZO; 'X'=pendiente primera vez, 'P'=pendiente reintento | Si | N/A | 'X' indica que es la primera vez que se procesa el rechazo; activa la evaluacion de reincidencia y el envio de SMS | Si | Regla de negocio |
| WS-HOST-VARIABLES.HV-FEC-PROCESO | HV-FEC-PROCESO | Alfanumerico | 10 | Fecha de proceso en formato ISO (AAAA-MM-DD) para uso en sentencias SQL | Si | N/A | Se usa en el UPDATE de CHQ_RECHAZO en el campo FEC_COBRO | Si | Operacional |
| WS-HOST-VARIABLES.HV-FEC-VENTANA | HV-FEC-VENTANA | Alfanumerico | 10 | Fecha limite de la ventana de reincidencia en formato ISO; resultado de restar 365 dias a la fecha de proceso | Si | N/A | Se usa en el WHERE del COUNT de CHQ_RECHAZO para la regla de reincidencia | Si | Regla de negocio |
| WS-HOST-VARIABLES.HV-MON-MULTA | HV-MON-MULTA | Numerico con signo, decimal empaquetado | 11 enteros, 2 decimales | Importe de la multa calculada en la moneda de la cuenta; copia de WS-MULTA | No | N/A | Se graba en CHQ_RECHAZO.MON_MULTA | Si | Financiero |
| WS-HOST-VARIABLES.HV-MON-COMISION | HV-MON-COMISION | Numerico con signo, decimal empaquetado | 7 enteros, 2 decimales | Importe de la comision de rechazo en la moneda de la cuenta; copia de WS-COMISION | No | N/A | Se graba en CHQ_RECHAZO.MON_COMISION | Si | Financiero |
| WS-HOST-VARIABLES.HV-MON-IGV | HV-MON-IGV | Numerico con signo, decimal empaquetado | 7 enteros, 2 decimales | Importe del IGV sobre la comision en la moneda de la cuenta; copia de WS-IGV | No | N/A | Se graba en CHQ_RECHAZO.MON_IGV | Si | Financiero |
| WS-HOST-VARIABLES.HV-IND-NUEVO | HV-IND-NUEVO | Alfanumerico | 1 | Nuevo valor del indicador de cobro que se grabara en CHQ_RECHAZO; copia de WS-IND-COBRO-NUEVO | No | N/A | N/A | Si | Control |
| WS-HOST-VARIABLES.HV-CONTEO | HV-CONTEO | Numerico con signo, binario | 9 enteros | Resultado del COUNT de rechazos por sin fondos en los ultimos 365 dias para la cuenta en evaluacion | No | N/A | Se copia a WS-CANT-SF para comparar contra CHQ-MAX-RECHAZOS-SF | Si | Regla de negocio |
| **TABLA DB2: CHQ_RECHAZO (leida y actualizada por CUR_RECH y UPDATE)** | | | | | | | | | |
| CHQ_RECHAZO.NUM_RECHAZO | NUM_RECHAZO | Numerico | 9 | Identificador unico del registro de rechazo | Si | N/A | Clave primaria implicita; clave del cursor y del UPDATE | Si | Identificador |
| CHQ_RECHAZO.NUM_LOTE | NUM_LOTE | Numerico | 6 | Numero de lote de compensacion | Si | N/A | Solo lectura en este programa | No | Operacional |
| CHQ_RECHAZO.NUM_SECUENCIA | NUM_SECUENCIA | Numerico | 7 | Numero de secuencia dentro del lote | Si | N/A | Solo lectura en este programa | No | Operacional |
| CHQ_RECHAZO.CTA_NUMERO | CTA_NUMERO | Alfanumerico | 14 | Numero de cuenta giradora | Si | N/A | Solo lectura en este programa | Si | Identificador |
| CHQ_RECHAZO.NUM_CHEQUE | NUM_CHEQUE | Numerico | 8 | Numero del cheque rechazado | Si | N/A | Solo lectura en este programa | Si | Identificador |
| CHQ_RECHAZO.COD_MOTIVO | COD_MOTIVO | Alfanumerico | 2 | Codigo de motivo de rechazo segun Camara de Compensacion | Si | N/A | Solo lectura en este programa | Si | Regla de negocio |
| CHQ_RECHAZO.MON_CHEQUE | MON_CHEQUE | Numerico decimal | 13 enteros, 2 decimales | Importe del cheque en la moneda de la cuenta | Si | N/A | Solo lectura en este programa | Si | Financiero |
| CHQ_RECHAZO.COD_MONEDA | COD_MONEDA | Alfanumerico | 3 | Codigo ISO de moneda del cheque | Si | N/A | Solo lectura en este programa | Si | Financiero |
| CHQ_RECHAZO.FEC_RECHAZO | FEC_RECHAZO | Alfanumerico | 8 | Fecha del rechazo en formato AAAAMMDD (se lee con conversion de guiones eliminados via REPLACE/CHAR ISO) | Si | N/A | Solo lectura en este programa | Si | Operacional |
| CHQ_RECHAZO.IND_COBRO | IND_COBRO | Alfanumerico | 1 | Estado del cobro del rechazo; 'X'=pendiente primera vez, 'P'=pendiente reintento, 'C'=cobrado, 'M'=mora | Si | N/A | El cursor filtra solo 'X' y 'P'; se actualiza al final de cada registro | Si | Regla de negocio |
| CHQ_RECHAZO.MON_MULTA | MON_MULTA | Numerico decimal | 11 enteros, 2 decimales | Importe de la multa calculada; se graba en el UPDATE | No | N/A | Actualizado por este programa | Si | Financiero |
| CHQ_RECHAZO.MON_COMISION | MON_COMISION | Numerico decimal | 7 enteros, 2 decimales | Importe de la comision de rechazo calculada; se graba en el UPDATE | No | N/A | Actualizado por este programa | Si | Financiero |
| CHQ_RECHAZO.MON_IGV | MON_IGV | Numerico decimal | 7 enteros, 2 decimales | Importe del IGV sobre la comision; se graba en el UPDATE | No | N/A | Actualizado por este programa | Si | Financiero |
| CHQ_RECHAZO.FEC_COBRO | FEC_COBRO | Alfanumerico | 10 | Fecha en que se efectuo el cobro en formato ISO; se graba solo cuando IND_COBRO pasa a 'C' | No | N/A | Actualizado por este programa unicamente cuando el cobro es exitoso | Si | Operacional |
| **TABLA DB2: CHQ_CHEQUE (actualizada en 5100-BLOQUEA-CHEQUERAS)** | | | | | | | | | |
| CHQ_CHEQUE.EST_CHEQUE | EST_CHEQUE | Alfanumerico | 2 | Estado del cheque individual; valores posibles: 'DI'=disponible, 'PR'=presentado, 'PA'=pagado, 'RE'=rechazado, 'NP'=no pago, 'AN'=anulado | Si | N/A | Este programa actualiza de 'DI' a 'AN' los cheques disponibles de cuentas bloqueadas por reincidencia | Si | Regla de negocio |
| CHQ_CHEQUE.FEC_ESTADO | FEC_ESTADO | Alfanumerico | 10 | Fecha en que se produjo el ultimo cambio de estado del cheque en formato ISO | No | N/A | Se actualiza a HV-FEC-PROCESO cuando se anula el cheque | Si | Operacional |
| CHQ_CHEQUE.CTA_NUMERO | CTA_NUMERO | Alfanumerico | 14 | Numero de cuenta a la que pertenece el cheque; clave del UPDATE | Si | N/A | Clave del WHERE en el UPDATE de anulacion | Si | Identificador |
| **TABLA DB2: CHQ_CHEQUERA (actualizada en 5100-BLOQUEA-CHEQUERAS)** | | | | | | | | | |
| CHQ_CHEQUERA.EST_CHEQUERA | EST_CHEQUERA | Alfanumerico | 2 | Estado de la chequera; valores posibles: 'SO'=solicitada, 'EM'=emitida, 'EN'=entregada, 'AG'=agotada, 'AN'=anulada, 'BL'=bloqueada | Si | N/A | Este programa actualiza de 'EM' o 'EN' a 'BL' las chequeras vigentes de cuentas bloqueadas por reincidencia | Si | Regla de negocio |
| CHQ_CHEQUERA.CTA_NUMERO | CTA_NUMERO | Alfanumerico | 14 | Numero de cuenta a la que pertenece la chequera; clave del UPDATE | Si | N/A | Clave del WHERE en el UPDATE de bloqueo | Si | Identificador |
| **TABLA DB2: CUENTA_MAESTRO (leida y actualizada via SDCMAEST)** | | | | | | | | | |
| CUENTA_MAESTRO.NUM_CUENTA | NUM_CUENTA | Alfanumerico | 14 | Numero de cuenta; clave primaria | Si | N/A | N/A | Si | Identificador |
| CUENTA_MAESTRO.COD_PRODUCTO | COD_PRODUCTO | Alfanumerico | 2 | Codigo de producto de deposito; '01'=ahorro, '02'=ahorro gana, '03'=CTS, '04'=sueldo, '05'=plazo, '06'=corriente, '07'=digital | Si | N/A | Se devuelve en SDC-MAE-CTA-PRODUCTO | Si | Clasificacion |
| CUENTA_MAESTRO.COD_MONEDA | COD_MONEDA | Alfanumerico | 3 | Codigo ISO de moneda de la cuenta; '604'=soles, '840'=dolares, '978'=euros | Si | N/A | Se devuelve en SDC-MAE-CTA-MONEDA | Si | Financiero |
| CUENTA_MAESTRO.ESTADO | ESTADO | Alfanumerico | 2 | Estado de la cuenta; 'AC'=activa, 'IN'=inactiva, 'BL'=bloqueada, 'BJ'=bloqueo judicial, 'CE'=cerrada, 'CA'=castigada, 'AP'=en apertura | Si | N/A | Se devuelve en SDC-MAE-CTA-ESTADO; si es 'CE' no se aplican cargos | Si | Regla de negocio |
| CUENTA_MAESTRO.SUB_ESTADO | SUB_ESTADO | Alfanumerico | 2 | Sub-estado de la cuenta; uso especifico por producto | No | N/A | Se devuelve en SDC-MAE-CTA-SUB-ESTADO | No | Clasificacion |
| CUENTA_MAESTRO.COD_UNICO_TIT | COD_UNICO_TIT | Alfanumerico | 10 | Codigo unico del titular de la cuenta | No | N/A | Se devuelve en SDC-MAE-TIT-CODIGO-UNICO; se usa como NTF-COD-UNICO en las notificaciones | Si | Identificador |
| CUENTA_MAESTRO.TIPO_DOI | TIPO_DOI | Alfanumerico | 1 | Tipo de documento de identidad del titular; '1'=DNI, '4'=carnet extranjeria, '6'=RUC, '7'=pasaporte, '9'=partida nacimiento | No | N/A | Se devuelve en SDC-MAE-TIT-TIPO-DOI | No | Identificador |
| CUENTA_MAESTRO.NUM_DOI | NUM_DOI | Alfanumerico | 12 | Numero de documento de identidad del titular | No | N/A | Se devuelve en SDC-MAE-TIT-NUM-DOI | No | Identificador |
| CUENTA_MAESTRO.NOMBRE | NOMBRE | Alfanumerico | 60 | Nombre del titular de la cuenta | No | N/A | Se devuelve en SDC-MAE-TIT-NOMBRE | No | Identificador |
| CUENTA_MAESTRO.APE_PATERNO | APE_PATERNO | Alfanumerico | 30 | Apellido paterno del titular | No | N/A | Se devuelve en SDC-MAE-TIT-APE-PATERNO | No | Identificador |
| CUENTA_MAESTRO.APE_MATERNO | APE_MATERNO | Alfanumerico | 30 | Apellido materno del titular | No | N/A | Se devuelve en SDC-MAE-TIT-APE-MATERNO | No | Identificador |
| CUENTA_MAESTRO.SALDO_CONTABLE | SALDO_CONTABLE | Numerico decimal | 13 enteros, 2 decimales | Saldo contable de la cuenta | No | N/A | Se devuelve en SDC-MAE-SAL-CONTABLE | Si | Financiero |
| CUENTA_MAESTRO.SALDO_DISPONIBLE | SALDO_DISPONIBLE | Numerico decimal | 13 enteros, 2 decimales | Saldo disponible de la cuenta; lo valida SDMPOSTA para autorizar el cargo | No | N/A | Se devuelve en SDC-MAE-SAL-DISPONIBLE | Si | Financiero |
| CUENTA_MAESTRO.SALDO_INTANGIBLE | SALDO_INTANGIBLE | Numerico decimal | 13 enteros, 2 decimales | Saldo intangible (inembargable) de la cuenta | No | N/A | Se devuelve en SDC-MAE-SAL-INTANGIBLE | No | Financiero |
| CUENTA_MAESTRO.FEC_APERTURA | FEC_APERTURA | Alfanumerico | 8 | Fecha de apertura de la cuenta en formato AAAAMMDD | No | N/A | Se devuelve en SDC-MAE-FEC-APERTURA | No | Operacional |
| CUENTA_MAESTRO.FEC_ULT_MOVIM | FEC_ULT_MOVIM | Alfanumerico | 8 | Fecha del ultimo movimiento de la cuenta en formato AAAAMMDD | No | N/A | Se devuelve en SDC-MAE-FEC-ULT-MOVIM | No | Operacional |
| CUENTA_MAESTRO.FEC_ULT_BLOQUEO | FEC_ULT_BLOQUEO | Alfanumerico | 8 | Fecha del ultimo bloqueo de la cuenta en formato AAAAMMDD | No | N/A | La actualiza SDCMAEST funcion 'BL' | No | Operacional |
| CUENTA_MAESTRO.RUC_EMPLEADOR | RUC_EMPLEADOR | Alfanumerico | 11 | RUC del empleador para cuentas CTS o sueldo | No | N/A | Se devuelve en SDC-MAE-CTS-RUC-EMPLEADOR | No | Identificador |
| CUENTA_MAESTRO.SUELDO_BRUTO | SUELDO_BRUTO | Numerico decimal | 9 enteros, 2 decimales | Sueldo bruto del titular para cuentas CTS o sueldo | No | N/A | Se devuelve en SDC-MAE-CTS-SUELDO-BRUTO | No | Financiero |
| **AREA DE COMUNICACION SDC-AREA-MAESTRO (copybook SDCMAEW) - campos de control adicionales** | | | | | | | | | |
| SDC-AREA-MAESTRO.SDC-MAE-FUNCION | SDC-MAE-FUNCION | Alfanumerico | 2 | Funcion a ejecutar en SDCMAEST; 'LE'=leer, 'AC'=actualizar saldos, 'BL'=bloquear, 'CR'=crear | Si | N/A | Este programa usa 'LE' para leer datos del girador y 'BL' para bloquear por reincidencia | Si | Control |
| SDC-AREA-MAESTRO.SDC-MAE-COD-RETORNO | SDC-MAE-COD-RETORNO | Alfanumerico | 2 | Codigo de retorno de SDCMAEST; '00'=OK, '08'=no encontrado, '12'=dato invalido, '90'=error DB2 | No | N/A | Si es distinto de SDU-RC-OK ('00') no se aplican cargos | Si | Control |
| SDC-AREA-MAESTRO.SDC-MAE-NUEVO-ESTADO | SDC-MAE-NUEVO-ESTADO | Alfanumerico | 2 | Nuevo estado a asignar a la cuenta en la funcion 'BL'; se envia 'BL' (bloqueada) | No | N/A | Solo se usa en la llamada de bloqueo por reincidencia | Si | Regla de negocio |
| SDC-AREA-MAESTRO.SDC-MAE-MOTIVO-BLOQUEO | SDC-MAE-MOTIVO-BLOQUEO | Alfanumerico | 4 | Motivo del bloqueo de la cuenta; se envia 'CHQ3' para indicar tercer rechazo por sin fondos | No | N/A | Solo se usa en la llamada de bloqueo por reincidencia | Si | Regla de negocio |
| **AREA DE COMUNICACION AREA-POSTEO (copybook SDMPOSTW)** | | | | | | | | | |
| AREA-POSTEO.POS-EMPRESA | POS-EMPRESA | Numerico | 3 | Codigo de empresa; se envia el valor 1 | Si | N/A | N/A | Si | Identificador |
| AREA-POSTEO.POS-CUENTA | POS-CUENTA | Alfanumerico | 20 | Numero de cuenta a debitar; se envia HV-CUENTA | Si | N/A | N/A | Si | Identificador |
| AREA-POSTEO.POS-PRODUCTO | POS-PRODUCTO | Alfanumerico | 2 | Codigo de producto de la cuenta; se toma de SDC-MAE-CTA-PRODUCTO | Si | N/A | N/A | Si | Clasificacion |
| AREA-POSTEO.POS-MONEDA | POS-MONEDA | Numerico | 3 | Codigo ISO numerico de moneda; se toma de SDC-MAE-CTA-MONEDA | Si | N/A | N/A | Si | Financiero |
| AREA-POSTEO.POS-TIPO-OPERACION | POS-TIPO-OPERACION | Alfanumerico | 4 | Tipo de operacion contable; se envia SDU-OP-COBRO-COMISION ('060') | Si | N/A | N/A | Si | Clasificacion |
| AREA-POSTEO.POS-SIGNO | POS-SIGNO | Alfanumerico | 1 | Signo de la operacion; 'D'=debito (cargo), 'H'=credito (abono) | Si | N/A | Se envia 'D' para debitar la cuenta del girador | Si | Financiero |
| AREA-POSTEO.POS-IMPORTE | POS-IMPORTE | Numerico con signo, decimal empaquetado | 13 enteros, 2 decimales | Importe total del cargo; se envia WS-TOTAL-CARGO | Si | N/A | N/A | Si | Financiero |
| AREA-POSTEO.POS-GLOSA | POS-GLOSA | Alfanumerico | 40 | Descripcion de la operacion; se envia 'MULTA/COM RECHAZO CHQ ' mas el numero de cheque en posiciones 23-30 | No | N/A | N/A | Si | Operacional |
| AREA-POSTEO.POS-REFERENCIA | POS-REFERENCIA | Alfanumerico | 20 | Referencia de la operacion; se envia el numero de cheque | No | N/A | N/A | Si | Operacional |
| AREA-POSTEO.POS-DOC-TIPO | POS-DOC-TIPO | Alfanumerico | 2 | Tipo de documento de respaldo; se envia 'CH' (cheque) | No | N/A | N/A | Si | Operacional |
| AREA-POSTEO.POS-DOC-NUMERO | POS-DOC-NUMERO | Alfanumerico | 15 | Numero de documento de respaldo; se envia el numero de cheque | No | N/A | N/A | Si | Operacional |
| AREA-POSTEO.POS-BATCH-ID | POS-BATCH-ID | Alfanumerico | 8 | Identificador del proceso batch; se envia 'CHQJD010' | No | N/A | N/A | No | Control |
| AREA-POSTEO.POS-IND-FORZAR | POS-IND-FORZAR | Alfanumerico | 1 | Indicador de forzar posteo sin validar saldo; se envia 'N' | No | N/A | N/A | Si | Control |
| AREA-POSTEO.POS-IND-EXONERA-ITF | POS-IND-EXONERA-ITF | Alfanumerico | 1 | Indicador de exoneracion del ITF; se envia 'N' | No | N/A | N/A | Si | Financiero |
| AREA-POSTEO.POS-IND-SOLO-VALIDA | POS-IND-SOLO-VALIDA | Alfanumerico | 1 | Indicador de solo validar sin postear; se envia 'N' | No | N/A | N/A | Si | Control |
| AREA-POSTEO.POS-COD-RETORNO | POS-COD-RETORNO | Numerico | 4 | Codigo de retorno de SDMPOSTA; 0000=OK, 0020=cuenta bloqueada, 0040=saldo insuficiente | No | N/A | Los valores 0020 y 0040 activan la logica de pendiente; cualquier otro valor distinto de 0000 es error | Si | Control |
| AREA-POSTEO.POS-SALDO-INSUF | POS-SALDO-INSUF | Condicion sobre POS-COD-RETORNO | N/A | Condicion verdadera cuando POS-COD-RETORNO = 0040 (saldo disponible insuficiente) | No | N/A | N/A | Si | Regla de negocio |
| AREA-POSTEO.POS-CTA-BLOQUEADA | POS-CTA-BLOQUEADA | Condicion sobre POS-COD-RETORNO | N/A | Condicion verdadera cuando POS-COD-RETORNO = 0020 (cuenta bloqueada para cargos) | No | N/A | N/A | Si | Regla de negocio |
| AREA-POSTEO.POS-MENSAJE | POS-MENSAJE | Alfanumerico | 70 | Mensaje descriptivo del resultado del posteo; se copia a WS-GLOSA-ERROR en caso de error no esperado | No | N/A | N/A | Si | Control |
| **AREA DE COMUNICACION SDU-AREA-FECHA (copybook SDUFECHW)** | | | | | | | | | |
| SDU-AREA-FECHA.SDU-FE-FUNCION | SDU-FE-FUNCION | Alfanumerico | 10 | Funcion a ejecutar en SDUFECHA; 'SUMADIAS  '=sumar dias calendario, 'DIFDIAS   '=diferencia en dias | Si | N/A | Debe tener exactamente 10 caracteres incluyendo espacios de relleno | Si | Control |
| SDU-AREA-FECHA.SDU-FE-FECHA-ENT | SDU-FE-FECHA-ENT | Alfanumerico | 8 | Fecha de entrada para la operacion de fecha en formato AAAAMMDD | Si | N/A | N/A | Si | Operacional |
| SDU-AREA-FECHA.SDU-FE-FECHA-ENT-2 | SDU-FE-FECHA-ENT-2 | Alfanumerico | 8 | Segunda fecha de entrada para la funcion 'DIFDIAS'; es la fecha mas reciente | No | N/A | Solo se usa con la funcion 'DIFDIAS' | Si | Operacional |
| SDU-AREA-FECHA.SDU-FE-DIAS | SDU-FE-DIAS | Numerico con signo, decimal empaquetado | 5 enteros | Numero de dias a sumar (positivo) o restar (negativo) en la funcion 'SUMADIAS' | No | N/A | Para calcular la ventana de reincidencia se envia CHQ-DIAS-VENTANA-RECH * -1 = -365 | Si | Operacional |
| SDU-AREA-FECHA.SDU-FE-FECHA-SAL | SDU-FE-FECHA-SAL | Alfanumerico | 8 | Fecha resultante de la operacion en formato AAAAMMDD | No | N/A | N/A | Si | Operacional |
| SDU-AREA-FECHA.SDU-FE-DIAS-RESULT | SDU-FE-DIAS-RESULT | Numerico con signo, decimal empaquetado | 7 enteros | Diferencia en dias devuelta por la funcion 'DIFDIAS'; se copia a WS-DIAS-PENDIENTE | No | N/A | N/A | Si | Operacional |
| SDU-AREA-FECHA.SDU-FE-COD-RETORNO | SDU-FE-COD-RETORNO | Alfanumerico | 2 | Codigo de retorno de SDUFECHA; '00'=OK | No | N/A | N/A | Si | Control |
| **AREA DE COMUNICACION TES-AREA-TC (copybook TESIFCW)** | | | | | | | | | |
| TES-AREA-TC.TES-FUNCION | TES-FUNCION | Alfanumerico | 2 | Funcion a ejecutar en TESTCAMB; se envia 'TC' | Si | N/A | N/A | No | Control |
| TES-AREA-TC.TES-FECHA | TES-FECHA | Numerico | 8 | Fecha para la que se solicita el tipo de cambio en formato AAAAMMDD; se envia WS-FEC-PROCESO | Si | N/A | N/A | Si | Operacional |
| TES-AREA-TC.TES-MONEDA-ORIGEN | TES-MONEDA-ORIGEN | Alfanumerico | 3 | Codigo ISO de la moneda origen; se envia HV-COD-MONEDA (p.ej. '840' para USD) | Si | N/A | N/A | Si | Financiero |
| TES-AREA-TC.TES-MONEDA-DESTINO | TES-MONEDA-DESTINO | Alfanumerico | 3 | Codigo ISO de la moneda destino; se envia SDU-MON-SOLES ('604') | Si | N/A | N/A | Si | Financiero |
| TES-AREA-TC.TES-SEGMENTO | TES-SEGMENTO | Alfanumerico | 2 | Segmento de cliente para aplicar el spread; se envia 'MA' (masivo) | No | N/A | N/A | Si | Financiero |
| TES-AREA-TC.TES-TC-COMPRA | TES-TC-COMPRA | Numerico con signo, decimal empaquetado | 5 enteros, 4 decimales | Tipo de cambio de compra al cliente (soles por unidad de ME); se copia a WS-TC-COMPRA | No | N/A | Se usa para convertir el importe del cheque de USD a PEN | Si | Financiero |
| TES-AREA-TC.TES-TC-VENTA | TES-TC-VENTA | Numerico con signo, decimal empaquetado | 5 enteros, 4 decimales | Tipo de cambio de venta al cliente (soles por unidad de ME); se copia a WS-TC-VENTA | No | N/A | Se usa para convertir la multa de PEN a USD | Si | Financiero |
| TES-AREA-TC.TES-COD-RETORNO | TES-COD-RETORNO | Numerico | 4 | Codigo de retorno de TESTCAMB; 0000=OK, 0008=sin cotizacion, 0012=dato invalido, 0090=error DB2 | No | N/A | Si es distinto de 0000 se registra error E0003 y se omite el registro | Si | Control |
| **AREA DE COMUNICACION NTF-AREA-ENCOLA (copybook NTFIFCW)** | | | | | | | | | |
| NTF-AREA-ENCOLA.NTF-FUNCION | NTF-FUNCION | Alfanumerico | 2 | Funcion a ejecutar en NTFENCOL; se envia 'EN' (encolar) | Si | N/A | N/A | No | Control |
| NTF-AREA-ENCOLA.NTF-CANAL | NTF-CANAL | Alfanumerico | 2 | Canal de notificacion; 'SM'=SMS para aviso al girador (parrafo 7000), 'EM'=correo para aviso de bloqueo (parrafo 5100) | Si | N/A | N/A | Si | Operacional |
| NTF-AREA-ENCOLA.NTF-COD-PLANTILLA | NTF-COD-PLANTILLA | Alfanumerico | 6 | Codigo de la plantilla de mensaje; 'CHQ002' para SMS al girador, 'CHQ003' para correo de bloqueo | Si | N/A | N/A | Si | Operacional |
| NTF-AREA-ENCOLA.NTF-COD-UNICO | NTF-COD-UNICO | Alfanumerico | 10 | Codigo unico del destinatario de la notificacion; se envia SDC-MAE-TIT-CODIGO-UNICO | Si | N/A | N/A | Si | Identificador |
| NTF-AREA-ENCOLA.NTF-PARAMETROS | NTF-PARAMETROS | Alfanumerico | 100 | Valores de sustitucion de variables en la plantilla, separados por '|'; para CHQ002: numero de cheque '|' motivo de rechazo; para CHQ003: texto fijo de bloqueo | No | Espacios | El separador '|' divide los parametros que NTFENCOL asigna a {1}, {2}, etc. en la plantilla | Si | Operacional |
| NTF-AREA-ENCOLA.NTF-PRIORIDAD | NTF-PRIORIDAD | Numerico | 1 | Prioridad de la notificacion; 1=urgente, 5=baja; 0=usar la de la plantilla; se envia 3 para SMS y 1 para correo de bloqueo | No | N/A | Rango valido: 0 a 5 | Si | Operacional |
| NTF-AREA-ENCOLA.NTF-COD-RETORNO | NTF-COD-RETORNO | Numerico | 4 | Codigo de retorno de NTFENCOL; 0000=OK, 0004=advertencia, 0008=plantilla inexistente, 0012=dato invalido, 0016=inactiva, 0032=duplicado, 0090=error DB2, 0092=error VSAM | No | N/A | El programa CHQRECHA no evalua este codigo de retorno | Si | Control |
| NTF-AREA-ENCOLA.NTF-MENSAJE | NTF-MENSAJE | Alfanumerico | 60 | Mensaje descriptivo del resultado de la operacion de encolado | No | N/A | N/A | No | Control |
| **AREA DE COMUNICACION SDU-AREA-LOG (copybook SDULOGW)** | | | | | | | | | |
| SDU-AREA-LOG.SDU-LG-NIVEL | SDU-LG-NIVEL | Alfanumerico | 1 | Nivel de severidad del mensaje de log; 'I'=informativo, 'A'=advertencia, 'E'=error, 'F'=fatal, 'D'=debug | Si | N/A | CHQRECHA siempre envia 'E' | No | Control |
| SDU-AREA-LOG.SDU-LG-PROGRAMA | SDU-LG-PROGRAMA | Alfanumerico | 8 | Nombre del programa que genera el log; se envia WS-NOM-PROGRAMA ('CHQRECHA') | Si | N/A | N/A | No | Control |
| SDU-AREA-LOG.SDU-LG-PARRAFO | SDU-LG-PARRAFO | Alfanumerico | 20 | Nombre del parrafo donde se origino el evento; se envia WS-PARRAFO-ACT | No | N/A | N/A | No | Control |
| SDU-AREA-LOG.SDU-LG-COD-ERROR | SDU-LG-COD-ERROR | Alfanumerico | 6 | Codigo de error; se envia WS-COD-ERROR | No | N/A | N/A | No | Control |
| SDU-AREA-LOG.SDU-LG-GLOSA | SDU-LG-GLOSA | Alfanumerico | 120 | Descripcion del evento; se envia WS-GLOSA-ERROR | No | N/A | N/A | No | Control |
| SDU-AREA-LOG.SDU-LG-CUENTA | SDU-LG-CUENTA | Alfanumerico | 14 | Numero de cuenta relacionada con el evento; se envia HV-CUENTA | No | N/A | N/A | No | Control |
| SDU-AREA-LOG.SDU-LG-IMPORTE | SDU-LG-IMPORTE | Numerico con signo, decimal empaquetado | 13 enteros, 2 decimales | Importe relacionado con el evento; se envia HV-MON-CHEQUE | No | N/A | N/A | No | Control |
| SDU-AREA-LOG.SDU-LG-SQLCODE | SDU-LG-SQLCODE | Numerico con signo, binario | 9 enteros | Codigo SQL del error de base de datos; se envia SQLCODE | No | N/A | N/A | No | Control |
| **REGISTRO FISICO DEL LOG (SDU-REG-LOGSIDEP - copybook SDULOGW)** | | | | | | | | | |
| SDU-REG-LOGSIDEP.SDU-RL-CLAVE.SDU-RL-FECHA | SDU-RL-FECHA | Alfanumerico | 8 | Componente fecha de la clave del registro VSAM LOGSIDEP en formato AAAAMMDD | Si | N/A | Parte de la clave primaria del VSAM | No | Control |
| SDU-REG-LOGSIDEP.SDU-RL-CLAVE.SDU-RL-HORA | SDU-RL-HORA | Alfanumerico | 6 | Componente hora de la clave en formato HHMMSS | Si | N/A | Parte de la clave primaria del VSAM | No | Control |
| SDU-REG-LOGSIDEP.SDU-RL-CLAVE.SDU-RL-PROGRAMA | SDU-RL-PROGRAMA | Alfanumerico | 8 | Componente programa de la clave | Si | N/A | Parte de la clave primaria del VSAM | No | Control |
| SDU-REG-LOGSIDEP.SDU-RL-CLAVE.SDU-RL-CONTADOR | SDU-RL-CONTADOR | Numerico | 6 | Contador secuencial para evitar claves duplicadas dentro del mismo programa en el mismo segundo | Si | N/A | Parte de la clave primaria del VSAM; cicla de 1 a 999999 | No | Control |
| SDU-REG-LOGSIDEP.SDU-RL-GLOSA | SDU-RL-GLOSA | Alfanumerico | 120 | Descripcion del evento registrada en el VSAM | No | N/A | N/A | No | Control |
| SDU-REG-LOGSIDEP.SDU-RL-DOI | SDU-RL-DOI | Alfanumerico | 12 | Numero de documento de identidad; los primeros 4 caracteres se enmascaran con '****' | No | N/A | Enmascarado parcial; no usar para identificacion exacta en sistemas modernos | Si | Identificador |
| SDU-REG-LOGSIDEP.SDU-RL-IMPORTE | SDU-RL-IMPORTE | Alfanumerico | 16 | Importe formateado como texto con signo y dos decimales para almacenamiento en el VSAM | No | N/A | N/A | No | Financiero |
| **PARAMETROS DE TARJETA DE CONTROL BATCH (copybook SDBPARMW)** | | | | | | | | | |
| SDB-PARM-AREA.SDB-PARM-TARJETA | SDB-PARM-TARJETA | Alfanumerico | 80 | Tarjeta completa de parametros del JCL tal como llega del DD SYSIN | Si | N/A | Debe medir exactamente 80 bytes | Si | Configuracion |
| SDB-PARM-CAMPOS.SDB-PRM-FECHA-PROCESO | SDB-PRM-FECHA-PROCESO | Alfanumerico | 8 | Fecha de proceso en formato AAAAMMDD leida del JCL; si viene en blanco se usa la fecha del sistema | No | Espacios | REDEFINES sobre SDB-PARM-TARJETA, posiciones 1-8 | Si | Configuracion |
| SDB-PARM-CAMPOS.SDB-PRM-MODO | SDB-PRM-MODO | Alfanumerico | 1 | Modo de ejecucion; 'P'=produccion, 'S'=simulacion, 'R'=reproceso | No | N/A | REDEFINES sobre SDB-PARM-TARJETA, posicion 9; CHQRECHA no evalua este campo | Si | Configuracion |
| **CONSTANTES DEL DOMINIO CHQ (copybook CHQCONW)** | | | | | | | | | |
| CHQ-CONSTANTES.CHQ-DIAS-PLAZO-LOCAL | CHQ-DIAS-PLAZO-LOCAL | Numerico | 3 | Plazo de presentacion del cheque en dias para la misma plaza; valor fijo 30 | Si | 30 | No se usa directamente en CHQRECHA pero forma parte del contexto del dominio | No | Regla de negocio |
| CHQ-CONSTANTES.CHQ-DIAS-PLAZO-PLAZA | CHQ-DIAS-PLAZO-PLAZA | Numerico | 3 | Plazo de presentacion del cheque en dias para otra plaza del pais; valor fijo 60 | Si | 60 | No se usa directamente en CHQRECHA | No | Regla de negocio |
| CHQ-CONSTANTES.CHQ-DIAS-CADUCIDAD | CHQ-DIAS-CADUCIDAD | Numerico | 3 | Dias de caducidad del cheque; valor fijo 180 | Si | 180 | No se usa directamente en CHQRECHA | No | Regla de negocio |
| CHQ-CONSTANTES.CHQ-MAX-RECHAZOS-SF | CHQ-MAX-RECHAZOS-SF | Numerico | 2 | Numero maximo de rechazos por sin fondos en la ventana de 365 dias antes de bloquear la cuenta; valor fijo 3 | Si | 3 | Se compara contra WS-CANT-SF en la regla de reincidencia RN-CHQ-31; no esta en el archivo de parametros | Si | Regla de negocio |
| CHQ-CONSTANTES.CHQ-DIAS-VENTANA-RECH | CHQ-DIAS-VENTANA-RECH | Numerico | 3 | Numero de dias que define la ventana de reincidencia; valor fijo 365 | Si | 365 | Se multiplica por -1 y se envia a SDUFECHA para calcular HV-FEC-VENTANA; no esta en el archivo de parametros | Si | Regla de negocio |
| CHQ-CONSTANTES.CHQ-PCT-IGV | CHQ-PCT-IGV | Numerico | 1 entero, 2 decimales | Tasa de IGV aplicada sobre la comision de rechazo; valor fijo 0.18 (18%) | Si | 0.18 | La multa no lleva IGV; solo la comision | Si | Financiero |
| CHQ-CONSTANTES.CHQ-HOJAS-CHEQUERA | CHQ-HOJAS-CHEQUERA | Numerico | 3 | Numero de hojas por chequera; valor fijo 25 | No | 25 | No se usa directamente en CHQRECHA | No | Operacional |
| **CONSTANTES GENERALES DEL SISTEMA (copybook SDUCONST) - campos relevantes para CHQRECHA** | | | | | | | | | |
| SDU-MONEDAS.SDU-MON-SOLES | SDU-MON-SOLES | Alfanumerico | 3 | Codigo ISO de soles peruanos; valor fijo '604' | Si | '604' | Se usa para comparar HV-COD-MONEDA y como destino en la llamada a TESTCAMB | Si | Financiero |
| SDU-MONEDAS.SDU-MON-DOLARES | SDU-MON-DOLARES | Alfanumerico | 3 | Codigo ISO de dolares estadounidenses; valor fijo '840' | Si | '840' | Se usa como validacion en TESTCAMB | No | Financiero |
| SDU-ESTADOS.SDU-EST-ACTIVA | SDU-EST-ACTIVA | Alfanumerico | 2 | Estado activo de cuenta; valor fijo 'AC' | Si | 'AC' | Se compara contra SDC-MAE-CTA-ESTADO antes de ejecutar el bloqueo por reincidencia | Si | Regla de negocio |
| SDU-ESTADOS.SDU-EST-CERRADA | SDU-EST-CERRADA | Alfanumerico | 2 | Estado cerrada de cuenta; valor fijo 'CE' | Si | 'CE' | Si la cuenta esta cerrada no se aplican cargos | Si | Regla de negocio |
| SDU-ESTADOS.SDU-EST-BLOQUEADA | SDU-EST-BLOQUEADA | Alfanumerico | 2 | Estado bloqueada de cuenta; valor fijo 'BL' | Si | 'BL' | Se envia como SDC-MAE-NUEVO-ESTADO en el bloqueo por reincidencia | Si | Regla de negocio |
| SDU-PARAM-TRIBUTARIO.SDU-UIT-VIGENTE | SDU-UIT-VIGENTE | Numerico con signo | 5 enteros, 2 decimales | Valor de la Unidad Impositiva Tributaria vigente; valor fijo 4300.00 | Si | 4300.00 | Se usa para calcular el piso (1% = 43.00) y el techo (5 UIT = 21500.00) de la multa; actualizable solo por cambio en el copybook | Si | Financiero |
| SDU-CODIGOS-RETORNO.SDU-RC-OK | SDU-RC-OK | Alfanumerico | 2 | Codigo de retorno satisfactorio del sistema; valor fijo '00' | Si | '00' | Se compara contra SDC-MAE-COD-RETORNO para validar la lectura del maestro | Si | Control |
| SDU-CANALES.SDU-CAN-BATCH | SDU-CAN-BATCH | Alfanumerico | 2 | Codigo de canal batch; valor fijo 'BA' | Si | 'BA' | Se envia en POS-CANAL y en SDU-LG-CANAL | No | Control |
| SDU-OPERACIONES.SDU-OP-COBRO-COMISION | SDU-OP-COBRO-COMISION | Alfanumerico | 3 | Codigo de tipo de operacion de cobro de comision; valor fijo '060' | Si | '060' | Se envia en POS-TIPO-OPERACION a SDMPOSTA | Si | Clasificacion |

## Detailed Rules

<!-- rule-start -->
### 1. Regla / Operacion - 0000-PRINCIPAL (Flujo de control principal)
<!-- reviewed -->

_Reviewed_

El programa comienza aquí. Ejecuta tres pasos en secuencia y luego termina:

1. Llama a la operación de inicio (1000-INICIO) para leer parámetros, calcular fechas y abrir el cursor de rechazos.
2. Repite la operación de procesamiento de un rechazo (2000-PROCESA-RECHAZO) de forma continua hasta que la bandera de fin de cursor quede marcada como 'S'. Cada iteración consume un registro del cursor y avanza al siguiente al final.
3. Llama a la operación de cierre (8000-CIERRE) para cerrar el cursor, mostrar totales y confirmar la transacción en la base de datos.

**Estado de la regla:** Relevante para Modernización

**Algoritmo**

1. Invocar 1000-INICIO. Durante esta fase se realizan las siguientes acciones en orden:
   - Leer la tarjeta de parámetros de ejecución del flujo de entrada estándar (SYSIN) hacia el área SDB-PARM-TARJETA.
   - Determinar la fecha de proceso: si el campo SDB-PRM-FECHA-PROCESO viene en blanco, se obtiene la fecha del sistema en formato AAAAMMDD; en caso contrario se usa el valor recibido en dicho campo. El resultado se almacena en WS-FEC-PROCESO.
   - Calcular la fecha límite de la ventana de reincidencia invocando a SDUFECHA con la función 'SUMADIAS', pasando WS-FEC-PROCESO como fecha de entrada y el valor negativo de la constante CHQ-DIAS-VENTANA-RECH (365 días) como desplazamiento. La fecha resultante, convertida al formato ISO (AAAA-MM-DD), se almacena en HV-FEC-VENTANA y se utiliza posteriormente como límite inferior en la consulta de conteo de rechazos por reincidencia.
   - Leer los parámetros operativos del archivo secuencial PARMCHQ (1100-LEER-PARM). Si el archivo no puede abrirse, se continúa con los valores por defecto. Los parámetros reconocidos son exactamente los siguientes tres, identificados por su clave en el campo PRM-CLAVE:
     - **'COM-RECHAZO-PEN'**: comisión de rechazo en soles (valor por defecto: 25.00).
     - **'COM-RECHAZO-USD'**: comisión de rechazo en dólares (valor por defecto: 8.00).
     - **'MULTA-PCT'**: porcentaje de multa por cheque sin fondos (valor por defecto: 5.00 %).
     - Cualquier otra clave que aparezca en el archivo se ignora sin error.
     - El valor numérico de cada parámetro se construye sumando la parte entera (posiciones 1–9 del campo PRM-VALOR) más la parte decimal dividida entre 100 (posiciones 11–12 del campo PRM-VALOR, separadas por un punto en la posición 10).
   - Abrir el cursor CUR_RECH sobre la tabla CHQ_RECHAZO. Dicho cursor selecciona los campos NUM_RECHAZO, NUM_LOTE, NUM_SECUENCIA, CTA_NUMERO, NUM_CHEQUE, COD_MOTIVO, MON_CHEQUE, COD_MONEDA, FEC_RECHAZO (convertida a formato AAAAMMDD eliminando los guiones) e IND_COBRO, filtrando únicamente los registros cuyo IND_COBRO sea 'X' (nuevo rechazo, primera vez que se procesa) o 'P' (pendiente de cobro de una corrida anterior), ordenados por NUM_RECHAZO de forma ascendente.
   - Si la apertura del cursor falla (SQLCODE distinto de 0), registrar el error con código 'E0001', marcar la bandera SW-FIN-CURSOR como 'S' y establecer RETURN-CODE en 16, lo que impide que se procese ningún registro.
   - Si la apertura es exitosa, ejecutar un primer FETCH (2100-FETCH-RECHAZO) para posicionar el cursor en el primer registro disponible antes de entrar al ciclo principal.

2. Mientras la bandera SW-FIN-CURSOR sea distinta de 'S', invocar 2000-PROCESA-RECHAZO. La condición de fin se activa cuando el FETCH devuelve SQLCODE +100 (no hay más filas) o cuando ocurre un error de FETCH (SQLCODE distinto de 0 y distinto de +100), en cuyo caso adicionalmente se establece RETURN-CODE en 12.

3. Invocar 8000-CIERRE. Durante esta fase se realizan las siguientes acciones en orden:
   - Cerrar el cursor CUR_RECH.
   - Mostrar por salida estándar un resumen con la fecha de proceso y los siguientes contadores acumulados durante la ejecución: rechazos leídos (WS-CNT-LEIDOS), cobrados exitosamente (WS-CNT-COBRADOS), pendientes de cobro (WS-CNT-PENDIENTES), pasados a mora (WS-CNT-A-MORA), sin cargo aplicable (WS-CNT-SIN-CARGO), cuentas bloqueadas por reincidencia (WS-CNT-BLOQUEOS), total de multas cobradas (WS-TOT-MULTAS), total de comisiones cobradas (WS-TOT-COMISIONES) y total de IGV cobrado (WS-TOT-IGV).
   - Si el contador de pendientes de cobro (WS-CNT-PENDIENTES) es mayor que cero y el RETURN-CODE actual es 0, establecer RETURN-CODE en 4 para advertir al JCL que existen cobros pendientes para la siguiente corrida.
   - Emitir un COMMIT de la unidad de trabajo en la base de datos DB2.

4. Terminar el programa (GOBACK).
<!-- rule-end -->

<!-- rule-start -->
### 2. Regla / Operacion - 1000-INICIO (Inicializacion del proceso)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para Modernizacion

**Algoritmo**

1. Leer 80 bytes desde SYSIN en SDB-PARM-TARJETA.
2. Si los primeros 8 bytes (SDB-PRM-FECHA-PROCESO) son espacios, obtener la fecha actual del sistema en formato AAAAMMDD y guardarla en WS-FEC-PROCESO. En caso contrario, copiar SDB-PRM-FECHA-PROCESO a WS-FEC-PROCESO.
3. Copiar WS-FEC-PROCESO a WS-FECHA-TRAB y ejecutar 8100-FECHA-A-ISO para obtener WS-FECHA-ISO en formato AAAA-MM-DD (el procedimiento descompone WS-FECHA-TRAB en sus partes año, mes y día mediante la redefinición WS-FECHA-TRAB-N y las ensambla en WS-FECHA-ISO con separadores '-' literales). Copiar WS-FECHA-ISO a HV-FEC-PROCESO.
4. Llamar a SDUFECHA con funcion 'SUMADIAS', fecha de entrada (SDU-FE-FECHA-ENT) = WS-FEC-PROCESO, dias (SDU-FE-DIAS) = -(CHQ-DIAS-VENTANA-RECH), es decir -365 (el valor negativo se obtiene con la instruccion `COMPUTE SDU-FE-DIAS = CHQ-DIAS-VENTANA-RECH * -1`). La fecha resultante devuelta en SDU-FE-FECHA-SAL se copia a WS-FECHA-TRAB. A continuacion se ejecuta nuevamente 8100-FECHA-A-ISO y el resultado WS-FECHA-ISO se copia a HV-FEC-VENTANA. Esta variable se usara como filtro en la consulta de reincidencia para delimitar la ventana de 365 dias calendario hacia atras desde la fecha de proceso.
5. Invocar 1100-LEER-PARM para leer los parametros de comision y multa desde el archivo secuencial ARCH-PARM (DD PARMCHQ). El procedimiento abre el archivo; si el archivo no puede abrirse (estado de archivo WS-FS-PARM distinto de '00') se abandona la lectura inmediatamente sin error fatal y los parametros conservan sus valores por defecto. Si el archivo abre correctamente, se lee registro a registro hasta fin de archivo. Por cada registro se interpreta PRM-VALOR como un numero decimal: la parte entera son los primeros 9 caracteres (WS-PV-ENT) y los dos decimales son los caracteres 11 y 12 (WS-PV-DEC), calculándose el valor numérico como `WS-PV-NUMERO = WS-PV-ENT + (WS-PV-DEC / 100)`. Según el valor de PRM-CLAVE se actualiza el parámetro correspondiente:
   - `'COM-RECHAZO-PEN'` → WS-COM-RECH-PEN (valor por defecto: 25.00)
   - `'COM-RECHAZO-USD'` → WS-COM-RECH-USD (valor por defecto: 8.00)
   - `'MULTA-PCT'` → WS-MULTA-PCT (valor por defecto: 5.00)
   - Cualquier otra clave se ignora (CONTINUE).
   Al finalizar la lectura se cierra el archivo.
6. Ejecutar SQL OPEN CUR_RECH. El cursor selecciona de la tabla CHQ_RECHAZO los campos NUM_RECHAZO, NUM_LOTE, NUM_SECUENCIA, CTA_NUMERO, NUM_CHEQUE, COD_MOTIVO, MON_CHEQUE, COD_MONEDA, FEC_RECHAZO (convertida a formato AAAAMMDD eliminando los guiones de la representacion ISO de DB2) e IND_COBRO, filtrando únicamente los registros cuyo IND_COBRO sea 'X' (rechazo nuevo, primera vez que se procesa) o 'P' (cobro pendiente de un ciclo anterior), ordenados por NUM_RECHAZO de forma ascendente. Si SQLCODE es distinto de 0: registrar el error con codigo 'E0001' y glosa 'ERROR ABRIENDO CUR_RECH' mediante el procedimiento 9900-REGISTRA-ERROR, poner 'S' en SW-FIN-CURSOR para evitar el ciclo de procesamiento y establecer RETURN-CODE en 16. Si SQLCODE es 0 (cursor abierto correctamente): invocar 2100-FETCH-RECHAZO para posicionar el cursor en el primer registro.
<!-- rule-end -->

<!-- rule-start -->
### 3. Regla / Operacion - 1100-LEER-PARM (Lectura de parametros de configuracion)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para Modernizacion

Lee el archivo secuencial ARCH-PARM (asignado al DD PARMCHQ en el JCL) para obtener los valores configurables de comision y porcentaje de multa. Cada registro del archivo tiene una clave de 18 caracteres (PRM-CLAVE), un valor de 12 caracteres (PRM-VALOR) y 50 caracteres de relleno (FILLER), para un total de 80 caracteres por registro en modo fijo (RECORDING MODE F).

El valor de 12 caracteres se interpreta como un numero decimal: los primeros 9 caracteres son la parte entera (WS-PV-ENT), el caracter 10 es un separador de punto (WS-PV-PUNTO) que no interviene en el calculo, y los ultimos 2 caracteres son la parte decimal (WS-PV-DEC). El numero resultante se calcula como: WS-PV-NUMERO = WS-PV-ENT + (WS-PV-DEC / 100). El resultado se almacena en WS-PV-NUMERO, que es un campo numerico comprimido con signo de 9 enteros y 2 decimales.

Se reconocen exactamente tres claves. Cualquier otra clave es ignorada sin error ni interrupcion del proceso:

- **'COM-RECHAZO-PEN'**: comision de rechazo en soles peruanos (moneda 604). Se almacena en WS-COM-RECH-PEN. Valor por defecto si no se lee del archivo: 25.00.
- **'COM-RECHAZO-USD'**: comision de rechazo en dolares (moneda 840). Se almacena en WS-COM-RECH-USD. Valor por defecto si no se lee del archivo: 8.00.
- **'MULTA-PCT'**: porcentaje de multa a aplicar sobre el importe del cheque. Se almacena en WS-MULTA-PCT. Valor por defecto si no se lee del archivo: 5.00 (es decir, 5%).

Si el archivo no puede abrirse (el file status WS-FS-PARM es distinto de '00' tras el OPEN), la logica salta directamente al parrafo de salida 1100-EXIT sin leer ningun registro y sin modificar los valores por defecto. Esta condicion no genera error ni registro en bitacora; el proceso principal continua normalmente con los valores preestablecidos.

**Algoritmo**

1. Abrir ARCH-PARM en modo lectura (OPEN INPUT).
2. Si WS-FS-PARM es distinto de '00' tras la apertura, saltar a 1100-EXIT (los valores por defecto permanecen intactos; no se registra error).
3. Repetir el siguiente ciclo hasta que SW-FIN-PARM sea igual a 'S' (condicion de nivel 88: FIN-PARM):
   - a. Leer el siguiente registro de ARCH-PARM.
   - b. Si se detecta fin de archivo (AT END): mover 'S' a SW-FIN-PARM, lo que activa la condicion FIN-PARM y termina el ciclo.
   - c. Si no es fin de archivo (NOT AT END):
     - Copiar PRM-VALOR (12 caracteres) a WS-PV-TEXTO.
     - Interpretar WS-PV-TEXTO mediante la redefinicion WS-PV-PARTES: WS-PV-ENT ocupa los 9 primeros caracteres (parte entera numerica), WS-PV-PUNTO ocupa el caracter 10 (separador, no utilizado en el calculo) y WS-PV-DEC ocupa los 2 ultimos caracteres (parte decimal numerica).
     - Calcular: WS-PV-NUMERO = WS-PV-ENT + (WS-PV-DEC / 100).
     - Evaluar PRM-CLAVE con EVALUATE:
       - Si es **'COM-RECHAZO-PEN'**: mover WS-PV-NUMERO a WS-COM-RECH-PEN.
       - Si es **'COM-RECHAZO-USD'**: mover WS-PV-NUMERO a WS-COM-RECH-USD.
       - Si es **'MULTA-PCT'**: mover WS-PV-NUMERO a WS-MULTA-PCT.
       - Cualquier otro valor (WHEN OTHER): ejecutar CONTINUE, es decir, ignorar el registro sin error.
4. Cerrar ARCH-PARM (CLOSE).
5. Continuar en 1100-EXIT.
<!-- rule-end -->

<!-- rule-start -->
### 4. Regla / Operacion - 2000-PROCESA-RECHAZO (Procesamiento de un registro de rechazo)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para Modernizacion

**Algoritmo**

1. Incrementar el contador WS-CNT-LEIDOS en 1.
2. Inicializar SW-ERROR-REG = 'N'.
3. Guardar el valor actual de HV-IND-COBRO en HV-IND-NUEVO (se usara para rastrear si el indicador cambia durante el procesamiento).
4. Inicializar WS-MULTA, WS-COMISION y WS-IGV en cero.
5. Copiar HV-NUM-CHEQUE (numero del cheque, 8 digitos) a WS-NUM-CHEQUE-DISP para uso en glosas y referencias.
6. Invocar 2500-LEER-GIRADOR para obtener los datos de la cuenta giradora desde el maestro de cuentas (llamada a SDCMAEST con funcion 'LE', pasando HV-CUENTA como numero de cuenta).
7. Invocar 3000-DETERMINA-CARGOS para decidir si corresponde multa, comision, ambas o ninguna, segun el motivo de rechazo y el estado de la cuenta. La logica exacta es la siguiente:
   - Inicializar SW-HAY-MULTA = 'N' y SW-HAY-COMISION = 'N'.
   - Si la llamada a SDCMAEST no devolvio codigo de retorno satisfactorio (SDU-RC-OK), o si el estado de la cuenta es igual a SDU-EST-CERRADA, no se asigna ningun cargo y se sale del paso sin modificar las banderas (ambas quedan en 'N').
   - En caso contrario, evaluar HV-COD-MOTIVO:
     - Motivo '01' (sin fondos): activar SW-HAY-MULTA = 'S' y SW-HAY-COMISION = 'S'.
     - Motivo '02' (firma) o motivo '08' (defecto formal): activar unicamente SW-HAY-COMISION = 'S'.
     - Cualquier otro motivo (incluidos '03', '04', '05', '06', '07', '09' y '10'): no se asigna ningun cargo; ambas banderas permanecen en 'N'.
8. Evaluar las banderas SW-HAY-MULTA y SW-HAY-COMISION:
   - Si alguna de las dos es 'S':
     a. Invocar 3100-CALCULA-IMPORTES para calcular los montos de multa, comision e IGV. La logica detallada de este calculo se describe en la regla correspondiente a ese paso.
     b. Solo si SW-ERROR-REG no fue marcado como 'S' durante el calculo anterior, invocar 4000-COBRAR-CARGOS para intentar el debito en la cuenta.
   - Si ambas son 'N': asignar 'N' a WS-IND-COBRO-NUEVO e incrementar WS-CNT-SIN-CARGO en 1.
9. Solo si SW-ERROR-REG no esta marcado como 'S' al concluir el paso 8:
   a. Invocar 5000-REINCIDENCIA para evaluar si la cuenta debe bloquearse por acumulacion de rechazos sin fondos. Esta suboperacion se ejecuta unicamente cuando el indicador original HV-IND-COBRO vale 'X' y el motivo HV-COD-MOTIVO vale '01'; en cualquier otro caso la suboperacion no realiza ninguna accion (sale inmediatamente).
   b. Invocar 6000-ACTUALIZA-RECHAZO para persistir el resultado del procesamiento en la tabla CHQ_RECHAZO.
   c. Si el valor original de HV-IND-COBRO al inicio de este ciclo es exactamente 'X', invocar 7000-NOTIFICAR-GIRADOR para enviar la notificacion al titular. Esta notificacion se omite si la llamada previa a SDCMAEST no devolvio codigo de retorno satisfactorio (SDU-RC-OK).
10. Invocar 2100-FETCH-RECHAZO para leer el siguiente registro del cursor CUR_RECH y preparar la proxima iteracion. Este paso se ejecuta siempre, independientemente de si hubo error o no durante el procesamiento del registro actual.
<!-- rule-end -->

<!-- rule-start -->
### 5. Regla / Operacion - 2100-FETCH-RECHAZO (Lectura del siguiente registro del cursor)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para Modernizacion

**Algoritmo**

El cursor CUR_RECH se declara sobre la tabla CHQ_RECHAZO con la cláusula WITH HOLD (mantiene el cursor abierto a través de puntos de commit). Selecciona todos los registros cuyo campo IND_COBRO tenga el valor 'X' (rechazo nuevo, primera vez que se procesa) o 'P' (cobro pendiente de un ciclo anterior), ordenados de forma ascendente por NUM_RECHAZO. Las columnas recuperadas son: NUM_RECHAZO, NUM_LOTE, NUM_SECUENCIA, CTA_NUMERO (número de cuenta giradora), NUM_CHEQUE, COD_MOTIVO, MON_CHEQUE, COD_MONEDA, FEC_RECHAZO (la fecha se extrae aplicando la función REPLACE de DB2 sobre la representación ISO con guiones —producida por CHAR(FEC_RECHAZO, ISO)— para eliminar los guiones y obtener el formato AAAAMMDD sin separadores), e IND_COBRO.

1. Ejecutar FETCH sobre CUR_RECH cargando los valores recuperados en las siguientes variables de trabajo, en este orden: HV-NUM-RECHAZO, HV-NUM-LOTE, HV-NUM-SECUENCIA, HV-CUENTA, HV-NUM-CHEQUE, HV-COD-MOTIVO, HV-MON-CHEQUE, HV-COD-MONEDA, HV-FEC-RECHAZO, HV-IND-COBRO.
2. Evaluar el SQLCODE resultante:
   - Si SQLCODE es igual a +100 (no hay más filas disponibles en el cursor): asignar el valor 'S' a SW-FIN-CURSOR, lo que detendrá el ciclo principal de procesamiento. No se realiza ninguna otra acción.
   - Si SQLCODE es distinto de cero y distinto de +100 (error en la lectura): registrar el error invocando el párrafo 9900-REGISTRA-ERROR con el código de error 'E0002' y el texto descriptivo 'ERROR FETCH CUR_RECH'; a continuación asignar el valor 'S' a SW-FIN-CURSOR para detener el ciclo principal, y establecer RETURN-CODE en 12 para señalar la condición de error al JCL.
   - Si SQLCODE es igual a cero (lectura exitosa): no se realiza ninguna acción adicional en este párrafo; el registro queda disponible en las variables de trabajo para ser procesado por el ciclo principal.
<!-- rule-end -->

<!-- rule-start -->
### 6. Regla / Operacion - 2500-LEER-GIRADOR (Lectura del maestro de la cuenta giradora)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para Modernizacion

**Algoritmo**

1. Poner 'LE' en SDC-MAE-FUNCION.
2. Copiar HV-CUENTA a SDC-MAE-CTA-NUMERO.
3. Limpiar SDC-MAE-COD-RETORNO (poner espacios).
4. Llamar a SDCMAEST pasando SDC-AREA-MAESTRO.
5. El resultado queda disponible en SDC-AREA-MAESTRO para uso de las operaciones siguientes. Los campos relevantes para el procesamiento posterior son:
   - **SDC-MAE-COD-RETORNO**: indica si la lectura fue exitosa. El valor de exito es SDU-RC-OK ('00'). Cualquier valor distinto (por ejemplo, cuenta inexistente o error de base de datos) es interpretado por la operacion 3000-DETERMINA-CARGOS para omitir el cobro.
   - **SDC-MAE-CTA-ESTADO**: estado actual de la cuenta. Los valores posibles definidos en SDUCONST son: 'AC' (activa), 'IN' (inactiva), 'BL' (bloqueada), 'BJ' (bloqueada judicialmente), 'CE' (cerrada), 'CA' (castigada) y 'AP' (en apertura). La operacion 3000-DETERMINA-CARGOS utiliza este campo para verificar si la cuenta esta cerrada (SDU-EST-CERRADA = 'CE'), en cuyo caso no se generan cargos. Adicionalmente, la operacion 5000-REINCIDENCIA comprueba si el estado es activo (SDU-EST-ACTIVA = 'AC') antes de ejecutar un bloqueo.
   - **SDC-MAE-CTA-PRODUCTO**: codigo de producto de la cuenta giradora, utilizado por SDMPOSTA al momento del cobro.
   - **SDC-MAE-CTA-MONEDA**: moneda de la cuenta giradora, utilizada por SDMPOSTA al momento del cobro.
   - **SDC-MAE-TIT-CODIGO-UNICO**: identificador unico del titular, utilizado como NTF-COD-UNICO al encolar notificaciones via NTFENCOL (tanto el aviso por SMS al girador en 7000-NOTIFICAR-GIRADOR como la notificacion de bloqueo por correo electronico en 5100-BLOQUEA-CHEQUERAS).

Esta operacion no maneja errores directamente: si la cuenta no existe o hay un error de base de datos, SDC-MAE-COD-RETORNO tendra un valor distinto de SDU-RC-OK, y la logica de 3000-DETERMINA-CARGOS interpretara ese resultado saltando al final del parrafo sin establecer ningun cargo (ni multa ni comision).
<!-- rule-end -->

<!-- rule-start -->
### 7. Regla / Operacion - 3000-DETERMINA-CARGOS (Reglas de negocio RN-CHQ-30 y RN-CHQ-32: determinacion de cargos por motivo)
<!-- reviewed -->

_Reviewed_

Determina si al rechazo le corresponde multa, comisión, ambas o ninguna, basándose en dos condiciones: el estado de la cuenta giradora y el motivo del rechazo.

**Condición previa obligatoria:** Si la llamada a SDCMAEST devolvió un código de retorno distinto de SDU-RC-OK (la cuenta no existe o hubo error), **o** si el estado de la cuenta (SDC-MAE-CTA-ESTADO) es igual a SDU-EST-CERRADA (valor `'CE'`), no se aplica ningún cargo. Ambas banderas quedan en `'N'` y la operación termina sin evaluar el motivo.

**Lógica por motivo de rechazo (campo HV-COD-MOTIVO):**

- Código `'01'` (Sin fondos): se aplican tanto multa como comisión. SW-HAY-MULTA = `'S'`, SW-HAY-COMISION = `'S'`.
- Código `'02'` (Firma irregular): se aplica solo comisión. SW-HAY-COMISION = `'S'`. SW-HAY-MULTA permanece en `'N'`.
- Código `'08'` (Defecto formal): se aplica solo comisión. SW-HAY-COMISION = `'S'`. SW-HAY-MULTA permanece en `'N'`. Los códigos `'02'` y `'08'` son evaluados como condiciones separadas pero producen el mismo resultado.
- Cualquier otro código — `'03'` (cuenta cerrada), `'04'` (cuenta bloqueada), `'05'` (orden de no pago), `'06'` (vencido), `'07'` (no emitido), `'09'` (ya pagado), `'10'` (cuenta inexistente) — no se aplica ningún cargo. Ambas banderas permanecen en `'N'`. Estos motivos corresponden a rechazos no imputables al girador o a situaciones en que la cuenta no es operable, por lo que no procede cargo alguno.

**Nota sobre la condición de cuenta cerrada:** La verificación del estado `SDU-EST-CERRADA` en la condición previa es independiente del motivo `'03'` (cuenta cerrada). Una cuenta puede estar cerrada en el maestro independientemente del motivo de rechazo informado por la cámara; en ese caso, la condición previa bloquea el cargo antes de evaluar el motivo.

**Rule Status:** Relevante para Modernización

**Algoritmo**

1. Poner `'N'` en SW-HAY-MULTA y `'N'` en SW-HAY-COMISION.
2. Verificar condición de exclusión: si SDC-MAE-COD-RETORNO es distinto de SDU-RC-OK (`'00'`), **o** si SDC-MAE-CTA-ESTADO es igual a SDU-EST-CERRADA (`'CE'`), terminar esta operación inmediatamente; ambas banderas quedan en `'N'` y no se evalúa el motivo.
3. Evaluar HV-COD-MOTIVO mediante las siguientes condiciones excluyentes:
   - Si el valor es `'01'`: poner `'S'` en SW-HAY-MULTA y `'S'` en SW-HAY-COMISION.
   - Si el valor es `'02'`: poner `'S'` en SW-HAY-COMISION (SW-HAY-MULTA permanece en `'N'`).
   - Si el valor es `'08'`: poner `'S'` en SW-HAY-COMISION (SW-HAY-MULTA permanece en `'N'`).
   - Para cualquier otro valor (`'03'`, `'04'`, `'05'`, `'06'`, `'07'`, `'09'`, `'10'`): no realizar ninguna acción; ambas banderas permanecen en `'N'`.
<!-- rule-end -->

<!-- rule-start -->
### 8. Regla / Operacion - 3100-CALCULA-IMPORTES (Calculo de multa, comision e IGV)
<!-- reviewed -->

_Reviewed_

Los importes de multa, comision e IGV que se cobraran al girador se calculan siempre en soles para la multa, con conversion posterior si la cuenta es en dolares. El calculo se inicia unicamente cuando al menos uno de los indicadores SW-HAY-MULTA o SW-HAY-COMISION es igual a 'S', y puede ser abandonado anticipadamente si ocurre un error al obtener el tipo de cambio.

**Paso 1 - Determinar el importe del cheque en soles (WS-IMPORTE-PEN):**

- Si HV-COD-MONEDA es igual a SDU-MON-SOLES ('604'): se marca SW-ES-DOLARES = 'N' y se copia directamente HV-MON-CHEQUE a WS-IMPORTE-PEN.
- Si HV-COD-MONEDA es distinto de '604': se marca SW-ES-DOLARES = 'S'. Se llama a la rutina TESTCAMB con los siguientes parametros:
  - TES-FUNCION = 'TC'
  - TES-FECHA = WS-FEC-PROCESO
  - TES-MONEDA-ORIGEN = HV-COD-MONEDA (la moneda del cheque)
  - TES-MONEDA-DESTINO = SDU-MON-SOLES ('604')
  - TES-SEGMENTO = 'MA' (segmento masivo)
  - Si TESTCAMB devuelve un codigo de retorno distinto de 0000: se marca SW-ERROR-REG = 'S', se registra el error con codigo E0003 y glosa 'TESTCAMB NO DEVOLVIO TIPO DE CAMBIO', y se abandona el calculo saltando directamente a 3100-EXIT sin ejecutar ningun paso posterior.
  - Si TESTCAMB responde correctamente: se guarda TES-TC-COMPRA en WS-TC-COMPRA y TES-TC-VENTA en WS-TC-VENTA. Luego se calcula: **WS-IMPORTE-PEN = HV-MON-CHEQUE * WS-TC-COMPRA** (con redondeo half-up a 2 decimales, aplicado por la clausula ROUNDED del compilador).

**Paso 2 - Calcular la multa (solo si SW-HAY-MULTA = 'S'):**

La multa se calcula en soles y luego se convierte si la cuenta es en dolares. Este bloque completo se ejecuta unicamente si SW-HAY-MULTA = 'S'; de lo contrario WS-MULTA permanece en cero (valor inicializado al comienzo de 2000-PROCESA-RECHAZO).

a. Calcular la multa base en soles: **WS-MULTA-PEN = WS-IMPORTE-PEN * WS-MULTA-PCT / 100** (con redondeo half-up aplicado por ROUNDED). WS-MULTA-PCT vale por defecto 5.00 y puede ser sobreescrito desde el archivo de parametros PARMCHQ mediante la clave 'MULTA-PCT', por lo que la multa base es el porcentaje parametrizado del importe del cheque expresado en soles.

b. Calcular el piso de la multa: **WS-MULTA-MIN = SDU-UIT-VIGENTE * 0.01** (con redondeo half-up aplicado por ROUNDED). SDU-UIT-VIGENTE vale 4300.00 segun el copybook SDUCONST, por lo que el piso es 43.00 soles.

c. Calcular el techo de la multa: **WS-MULTA-MAX = SDU-UIT-VIGENTE * 5** (con redondeo half-up aplicado por ROUNDED). Con la UIT vigente de 4300.00, el techo es 21500.00 soles.

d. Aplicar el piso: si WS-MULTA-PEN es menor que WS-MULTA-MIN, reemplazar WS-MULTA-PEN con WS-MULTA-MIN.

e. Aplicar el techo: si WS-MULTA-PEN es mayor que WS-MULTA-MAX, reemplazar WS-MULTA-PEN con WS-MULTA-MAX.

f. Convertir la multa a la moneda de la cuenta:
   - Si SW-ES-DOLARES = 'S': **WS-MULTA = WS-MULTA-PEN / WS-TC-VENTA** (con redondeo half-up aplicado por ROUNDED). Se divide por el tipo de cambio de venta porque el banco convierte soles a dolares al precio al que el cliente compra dolares.
   - Si SW-ES-DOLARES = 'N': copiar WS-MULTA-PEN a WS-MULTA directamente (sin operacion aritmetica).

**La multa no lleva IGV.**

**Paso 3 - Calcular la comision (solo si SW-HAY-COMISION = 'S'):**

Este bloque se ejecuta unicamente si SW-HAY-COMISION = 'S'; de lo contrario WS-COMISION y WS-IGV permanecen en cero. Puede ejecutarse de forma independiente al paso 2 (por ejemplo, para el motivo '02' o '08' donde SW-HAY-MULTA = 'N' y SW-HAY-COMISION = 'S').

a. Determinar el importe fijo de la comision segun la moneda de la cuenta:
   - Si SW-ES-DOLARES = 'S': copiar WS-COM-RECH-USD a WS-COMISION. WS-COM-RECH-USD vale por defecto 8.00 USD y puede ser sobreescrito desde el archivo de parametros PARMCHQ mediante la clave 'COM-RECHAZO-USD'.
   - Si SW-ES-DOLARES = 'N': copiar WS-COM-RECH-PEN a WS-COMISION. WS-COM-RECH-PEN vale por defecto 25.00 soles y puede ser sobreescrito desde el archivo de parametros PARMCHQ mediante la clave 'COM-RECHAZO-PEN'.

b. Calcular el IGV sobre la comision: **WS-IGV = WS-COMISION * CHQ-PCT-IGV** (con redondeo half-up aplicado por ROUNDED). CHQ-PCT-IGV vale 0.18 segun el copybook CHQCONW, por lo que el IGV es el 18% de la comision. La multa no forma parte de la base de calculo del IGV.

**Paso 4 - Calcular el total a cobrar:**

**WS-TOTAL-CARGO = WS-MULTA + WS-COMISION + WS-IGV**

Esta suma se ejecuta siempre al final del parrafo, independientemente de que SW-HAY-MULTA o SW-HAY-COMISION sean 'S' o 'N', dado que los valores no calculados permanecen en cero. El resultado WS-TOTAL-CARGO es el importe que se enviara a SDMPOSTA para el cobro a la cuenta giradora.

**Rule Status:** Relevante para Modernizacion

**Algoritmo**

1. Si HV-COD-MONEDA = '604': SW-ES-DOLARES = 'N'; WS-IMPORTE-PEN = HV-MON-CHEQUE.
2. Si HV-COD-MONEDA != '604': SW-ES-DOLARES = 'S'; llamar a TESTCAMB (funcion 'TC', fecha = WS-FEC-PROCESO, moneda origen = HV-COD-MONEDA, moneda destino = '604', segmento = 'MA'). Si TES-COD-RETORNO != 0000: SW-ERROR-REG = 'S', registrar error E0003 con glosa 'TESTCAMB NO DEVOLVIO TIPO DE CAMBIO', saltar a 3100-EXIT sin continuar. Si TES-COD-RETORNO = 0000: WS-TC-COMPRA = TES-TC-COMPRA; WS-TC-VENTA = TES-TC-VENTA; WS-IMPORTE-PEN = HV-MON-CHEQUE * WS-TC-COMPRA (redondeo half-up por ROUNDED).
3. Si SW-HAY-MULTA = 'S':
   - a. WS-MULTA-PEN = WS-IMPORTE-PEN * WS-MULTA-PCT / 100 (redondeo half-up por ROUNDED). WS-MULTA-PCT por defecto = 5.00; parametrizable con clave 'MULTA-PCT' en PARMCHQ.
   - b. WS-MULTA-MIN = SDU-UIT-VIGENTE (4300.00) * 0.01 (redondeo half-up por ROUNDED) = 43.00 soles.
   - c. WS-MULTA-MAX = SDU-UIT-VIGENTE (4300.00) * 5 (redondeo half-up por ROUNDED) = 21500.00 soles.
   - d. Si WS-MULTA-PEN < WS-MULTA-MIN: WS-MULTA-PEN = WS-MULTA-MIN.
   - e. Si WS-MULTA-PEN > WS-MULTA-MAX: WS-MULTA-PEN = WS-MULTA-MAX.
   - f. Si SW-ES-DOLARES = 'S': WS-MULTA = WS-MULTA-PEN / WS-TC-VENTA (redondeo half-up por ROUNDED). Si SW-ES-DOLARES = 'N': WS-MULTA = WS-MULTA-PEN (copia directa, sin redondeo).
4. Si SW-HAY-COMISION = 'S':
   - a. Si SW-ES-DOLARES = 'S': WS-COMISION = WS-COM-RECH-USD (por defecto 8.00 USD; parametrizable con clave 'COM-RECHAZO-USD' en PARMCHQ). Si SW-ES-DOLARES = 'N': WS-COMISION = WS-COM-RECH-PEN (por defecto 25.00 soles; parametrizable con clave 'COM-RECHAZO-PEN' en PARMCHQ).
   - b. WS-IGV = WS-COMISION * CHQ-PCT-IGV (0.18) (redondeo half-up por ROUNDED). La multa no integra la base del IGV.
5. WS-TOTAL-CARGO = WS-MULTA + WS-COMISION + WS-IGV.
<!-- rule-end -->

<!-- rule-start -->
### 9. Regla / Operacion - 4000-COBRAR-CARGOS (Cobro del cargo total via SDMPOSTA)
<!-- reviewed -->

_Reviewed_

**Rule Status:** Relevante para Modernizacion

Intenta debitar el importe total calculado (WS-TOTAL-CARGO) de la cuenta giradora llamando al motor de posteo SDMPOSTA. Arma el area de comunicacion AREA-POSTEO con los siguientes valores fijos y variables:

- POS-EMPRESA = 1
- POS-CUENTA = HV-CUENTA (numero de cuenta del girador)
- POS-PRODUCTO = SDC-MAE-CTA-PRODUCTO (producto leido del maestro)
- POS-MONEDA = SDC-MAE-CTA-MONEDA (moneda leida del maestro)
- POS-TIPO-OPERACION = SDU-OP-COBRO-COMISION (codigo de operacion para cobro de comision; segun SDUCONST su valor literal es '060', aunque en el codigo se referencia por nombre de constante)
- POS-SIGNO = 'D' (debito, es decir cargo a la cuenta)
- POS-IMPORTE = WS-TOTAL-CARGO
- POS-FECHA-PROCESO = WS-FEC-PROCESO
- POS-FECHA-VALOR = WS-FEC-PROCESO
- POS-CANAL = SDU-CAN-BATCH (canal batch; segun SDUCONST su valor literal es 'BA')
- POS-SUCURSAL = 0
- POS-TERMINAL = WS-NOM-PROGRAMA (contiene el literal 'CHQRECHA')
- POS-USUARIO = 'BATCH'
- POS-SUPERVISOR = espacios
- POS-GLOSA: se inicializa con el texto fijo 'MULTA/COM RECHAZO CHQ ' (22 caracteres) y a continuacion, en las posiciones 23 a 30 (8 caracteres), se escribe WS-NUM-CHEQUE-DISP (numero de cheque en formato de 8 digitos). El resultado es una glosa de 40 caracteres con la forma `MULTA/COM RECHAZO CHQ NNNNNNNN`.
- POS-REFERENCIA = WS-NUM-CHEQUE-DISP (numero de cheque como referencia, en campo de 20 caracteres)
- POS-DOC-TIPO = 'CH'
- POS-DOC-NUMERO = WS-NUM-CHEQUE-DISP
- POS-LOTE = 0
- POS-BATCH-ID = 'CHQJD010'
- POS-IND-FORZAR = 'N' (no forzar: se valida saldo disponible)
- POS-IND-EXONERA-ITF = 'N' (la operacion paga ITF normalmente)
- POS-IND-SOLO-VALIDA = 'N' (se ejecuta el posteo, no solo se valida)

**Interpretacion del resultado de SDMPOSTA:**

- Si POS-COD-RETORNO = 0000 (exito): se marca WS-IND-COBRO-NUEVO = 'C', se incrementa WS-CNT-COBRADOS en 1, y se acumulan WS-MULTA en WS-TOT-MULTAS, WS-COMISION en WS-TOT-COMISIONES y WS-IGV en WS-TOT-IGV.
- Si se cumple la condicion POS-SALDO-INSUF (POS-COD-RETORNO = 0040, saldo disponible insuficiente) **o** la condicion POS-CTA-BLOQUEADA (POS-COD-RETORNO = 0020, cuenta bloqueada para cargos): se invoca la suboperacion 4100-MARCA-PENDIENTE para determinar si el cobro pasa a estado pendiente ('P') o a mora ('M'). En ninguno de estos dos casos se activa SW-ERROR-REG.
- Cualquier otro codigo de retorno distinto de 0000, 0040 y 0020: se marca SW-ERROR-REG = 'S', se asigna el codigo interno 'E0004' a WS-COD-ERROR, se copia POS-MENSAJE a WS-GLOSA-ERROR y se invoca 9900-REGISTRA-ERROR.

**Algoritmo**

1. Llenar AREA-POSTEO con los valores descritos arriba. Destacar que WS-NUM-CHEQUE-DISP se escribe en tres campos distintos: dentro de POS-GLOSA en las posiciones 23 a 30, en POS-REFERENCIA y en POS-DOC-NUMERO.
2. Llamar a SDMPOSTA pasando AREA-POSTEO.
3. Evaluar POS-COD-RETORNO en el siguiente orden de prioridad:
   - Si POS-COD-RETORNO = 0000 (condicion POS-OK): asignar 'C' a WS-IND-COBRO-NUEVO; incrementar WS-CNT-COBRADOS en 1; sumar WS-MULTA a WS-TOT-MULTAS; sumar WS-COMISION a WS-TOT-COMISIONES; sumar WS-IGV a WS-TOT-IGV.
   - Si se activa la condicion POS-SALDO-INSUF (0040) o la condicion POS-CTA-BLOQUEADA (0020): invocar 4100-MARCA-PENDIENTE. No se actualiza WS-IND-COBRO-NUEVO en este parrafo; el valor lo establece 4100-MARCA-PENDIENTE ('P' o 'M').
   - Cualquier otro codigo de retorno: asignar 'S' a SW-ERROR-REG; asignar 'E0004' a WS-COD-ERROR; copiar POS-MENSAJE a WS-GLOSA-ERROR; invocar 9900-REGISTRA-ERROR.
<!-- rule-end -->

<!-- rule-start -->
### 10. Regla / Operacion - 4100-MARCA-PENDIENTE (Regla RN-CHQ-33: clasificacion de cobros fallidos)
<!-- reviewed -->

_Reviewed_

Cuando SDMPOSTA no puede cobrar por saldo insuficiente (`POS-SALDO-INSUF`, código de retorno 0040) o cuenta bloqueada (`POS-CTA-BLOQUEADA`, código de retorno 0020), esta operación determina si el cobro pasa a estado 'P' (pendiente, se reintentará en la próxima corrida) o a estado 'M' (mora, ya no se reintentará de forma ordinaria).

La regla es: si el rechazo lleva más de 30 días sin poder cobrarse, pasa a mora. El conteo de días se calcula como la diferencia en días calendario entre la fecha del rechazo (`HV-FEC-RECHAZO`) y la fecha de proceso actual (`WS-FEC-PROCESO`), usando la rutina SDUFECHA con la función `'DIFDIAS   '` (diez caracteres, completada con espacios a la derecha). La función calcula la diferencia como la fecha de entrada 2 menos la fecha de entrada 1, es decir: días transcurridos = `WS-FEC-PROCESO` − `HV-FEC-RECHAZO`.

- Si `WS-DIAS-PENDIENTE` > 30: `WS-IND-COBRO-NUEVO` = `'M'`; incrementar `WS-CNT-A-MORA` en 1.
- Si `WS-DIAS-PENDIENTE` <= 30: `WS-IND-COBRO-NUEVO` = `'P'`; incrementar `WS-CNT-PENDIENTES` en 1.

En ambos casos, el valor resultante de `WS-IND-COBRO-NUEVO` será posteriormente grabado en el campo `IND_COBRO` de la tabla `CHQ_RECHAZO` por el párrafo `6000-ACTUALIZA-RECHAZO`.

**Estado de la regla:** Relevante para Modernización

**Algoritmo**

1. Preparar la llamada a SDUFECHA:
   - Cargar la función `'DIFDIAS   '` (diez caracteres) en `SDU-FE-FUNCION`.
   - Cargar `HV-FEC-RECHAZO` en `SDU-FE-FECHA-ENT` (fecha de inicio, la más antigua).
   - Cargar `WS-FEC-PROCESO` en `SDU-FE-FECHA-ENT-2` (fecha de fin, la más reciente).
2. Llamar a `SDUFECHA` pasando `SDU-AREA-FECHA`.
3. Copiar el resultado `SDU-FE-DIAS-RESULT` a `WS-DIAS-PENDIENTE`. Este valor representa los días calendario transcurridos desde la fecha del rechazo hasta la fecha de proceso actual.
4. Si `WS-DIAS-PENDIENTE` > 30:
   - Asignar `'M'` a `WS-IND-COBRO-NUEVO`.
   - Incrementar `WS-CNT-A-MORA` en 1.
5. Si `WS-DIAS-PENDIENTE` <= 30:
   - Asignar `'P'` a `WS-IND-COBRO-NUEVO`.
   - Incrementar `WS-CNT-PENDIENTES` en 1.
<!-- rule-end -->

<!-- rule-start -->
### 11. Regla / Operacion - 5000-REINCIDENCIA (Regla RN-CHQ-31: bloqueo por reincidencia en cheques sin fondos)
<!-- reviewed -->

_Reviewed_

Implementa la regla de reincidencia: si una cuenta acumula 3 o más rechazos por motivo '01' (sin fondos) en los últimos 365 días, la cuenta se bloquea y sus chequeras vigentes quedan bloqueadas, con las hojas disponibles anuladas, y se encola una notificación al titular.

**Condición de aplicación:** Esta regla solo se evalúa si el rechazo se está procesando por primera vez, es decir, si el indicador de cobro original del registro (HV-IND-COBRO, tal como fue leído del cursor antes de cualquier modificación) es 'X' (nuevo). Si es 'P' (reintento de cobro pendiente), se omite completamente. Además, solo aplica para rechazos con motivo '01' (sin fondos). Si cualquiera de estas dos condiciones no se cumple, la operación termina sin hacer nada.

**Conteo de rechazos:** Se ejecuta una consulta SQL sobre la tabla CHQ_RECHAZO contando todos los registros donde CTA_NUMERO sea igual a HV-CUENTA, COD_MOTIVO sea '01', y FEC_RECHAZO sea mayor que HV-FEC-VENTANA (la fecha calculada en el inicio como 365 días antes de la fecha de proceso, en formato ISO con guiones, por ejemplo 'AAAA-MM-DD'). El resultado se almacena en HV-CONTEO y luego se copia a WS-CANT-SF.

**Acción si se alcanza el umbral:** Si WS-CANT-SF es mayor o igual a CHQ-MAX-RECHAZOS-SF (constante con valor 3, definida en CHQCONW) Y el estado actual de la cuenta (SDC-MAE-CTA-ESTADO) es SDU-EST-ACTIVA (valor 'AC'):

1. Se llama a SDCMAEST con función 'BL' (bloquear), informando el número de cuenta en SDC-MAE-CTA-NUMERO, el nuevo estado SDU-EST-BLOQUEADA (valor 'BL') en SDC-MAE-NUEVO-ESTADO, y el motivo de bloqueo 'CHQ3' en SDC-MAE-MOTIVO-BLOQUEO.
2. Si SDCMAEST responde con código SDU-RC-OK (valor '00'): se invoca el proceso 5100-BLOQUEA-CHEQUERAS (detallado más abajo) y se incrementa el contador WS-CNT-BLOQUEOS en 1.
3. Si SDCMAEST responde con error (código distinto de '00'): se asigna 'E0005' a WS-COD-ERROR, se mueve el texto 'NO SE PUDO BLOQUEAR CUENTA POR REINCIDENCIA' a WS-GLOSA-ERROR y se registra el error mediante 9900-REGISTRA-ERROR.

Si la condición de umbral no se cumple (WS-CANT-SF menor que 3, o la cuenta no está en estado activo), no se realiza ninguna acción.

Si el SQL de conteo falla (SQLCODE distinto de 0), la operación termina sin bloquear ni registrar error.

**Detalle de 5100-BLOQUEA-CHEQUERAS:** Este proceso realiza tres acciones en secuencia:

- Actualiza en CHQ_CHEQUE todos los registros de la cuenta (CTA_NUMERO = HV-CUENTA) cuyo estado sea 'DI' (disponible), cambiando EST_CHEQUE a 'AN' (anulado) y FEC_ESTADO a la fecha de proceso en formato ISO con guiones (HV-FEC-PROCESO).
- Actualiza en CHQ_CHEQUERA todos los registros de la cuenta (CTA_NUMERO = HV-CUENTA) cuyo estado sea 'EM' (emitida) o 'EN' (entregada), cambiando EST_CHEQUERA a 'BL' (bloqueada).
- Encola una notificación al titular mediante NTFENCOL con los siguientes parámetros: función 'EN', canal 'EM' (correo electrónico), plantilla 'CHQ003', código único del titular tomado de SDC-MAE-TIT-CODIGO-UNICO, el texto 'CUENTA BLOQUEADA POR 3 CHEQUES SIN FONDOS' como parámetro de la plantilla, y prioridad 1 (urgente).

**Estado de la regla:** Relevante para Modernización

**Algoritmo**

1. Si HV-IND-COBRO es distinto de 'X' o HV-COD-MOTIVO es distinto de '01': terminar sin hacer nada.
2. Ejecutar: SELECT COUNT(\*) INTO HV-CONTEO FROM CHQ_RECHAZO WHERE CTA_NUMERO = HV-CUENTA AND COD_MOTIVO = '01' AND FEC_RECHAZO > HV-FEC-VENTANA.
3. Si SQLCODE es distinto de 0: terminar sin hacer nada.
4. Copiar HV-CONTEO a WS-CANT-SF.
5. Si WS-CANT-SF >= 3 y SDC-MAE-CTA-ESTADO = 'AC':
   - a. Preparar llamada a SDCMAEST: SDC-MAE-FUNCION = 'BL'; SDC-MAE-CTA-NUMERO = HV-CUENTA; SDC-MAE-NUEVO-ESTADO = 'BL' (SDU-EST-BLOQUEADA); SDC-MAE-MOTIVO-BLOQUEO = 'CHQ3'. Llamar a SDCMAEST.
   - b. Si SDC-MAE-COD-RETORNO = '00' (SDU-RC-OK):
     - b.1. Actualizar CHQ_CHEQUE: SET EST_CHEQUE = 'AN', FEC_ESTADO = HV-FEC-PROCESO (fecha ISO) WHERE CTA_NUMERO = HV-CUENTA AND EST_CHEQUE = 'DI'.
     - b.2. Actualizar CHQ_CHEQUERA: SET EST_CHEQUERA = 'BL' WHERE CTA_NUMERO = HV-CUENTA AND EST_CHEQUERA IN ('EM', 'EN').
     - b.3. Encolar notificación vía NTFENCOL: función 'EN', canal 'EM', plantilla 'CHQ003', código único = SDC-MAE-TIT-CODIGO-UNICO, parámetros = 'CUENTA BLOQUEADA POR 3 CHEQUES SIN FONDOS', prioridad = 1.
     - b.4. Incrementar WS-CNT-BLOQUEOS en 1.
   - c. Si SDC-MAE-COD-RETORNO es distinto de '00': WS-COD-ERROR = 'E0005'; WS-GLOSA-ERROR = 'NO SE PUDO BLOQUEAR CUENTA POR REINCIDENCIA'; invocar 9900-REGISTRA-ERROR.
6. Si WS-CANT-SF < 3 o SDC-MAE-CTA-ESTADO es distinto de 'AC': no realizar ninguna acción.
<!-- rule-end -->

<!-- rule-start -->
### 12. Regla / Operacion - 5100-BLOQUEA-CHEQUERAS (Bloqueo de hojas y chequeras vigentes)
<!-- reviewed -->

_Reviewed_

Se invoca únicamente cuando una cuenta es bloqueada por reincidencia (tres o más rechazos por sin fondos —motivo `01`— en los últimos 365 días, detectados en el párrafo `5000-REINCIDENCIA`). Realiza tres acciones sobre la base de datos y luego encola una notificación al titular.

**Acción 1 - Anular hojas disponibles:** Actualiza en la tabla `CHQ_CHEQUE` todos los registros donde `CTA_NUMERO` sea igual a `HV-CUENTA` y `EST_CHEQUE` sea `'DI'` (disponible), cambiando `EST_CHEQUE` a `'AN'` (anulado) y `FEC_ESTADO` a `HV-FEC-PROCESO`. El valor de `HV-FEC-PROCESO` contiene la fecha de proceso en formato ISO `AAAA-MM-DD` (diez caracteres con guiones), tal como fue cargado en el párrafo `1000-INICIO` mediante la conversión de la fecha de proceso a formato ISO. Esto invalida todas las hojas de cheque que el cliente aún no ha utilizado.

**Acción 2 - Bloquear chequeras vigentes:** Actualiza en la tabla `CHQ_CHEQUERA` todos los registros donde `CTA_NUMERO` sea igual a `HV-CUENTA` y `EST_CHEQUERA` esté en `'EM'` (emitida) o `'EN'` (entregada), cambiando `EST_CHEQUERA` a `'BL'` (bloqueada). No se actualiza ningún campo de fecha en esta sentencia.

**Acción 3 - Notificar al titular:** Llama a `NTFENCOL` para encolar una notificación por correo electrónico al titular de la cuenta. Antes de la llamada, el campo `NTF-PARAMETROS` se inicializa a espacios y luego se le mueve el texto fijo. Los parámetros de la llamada son:

- `NTF-FUNCION` = `'EN'` (encolar)
- `NTF-CANAL` = `'EM'` (correo electrónico)
- `NTF-COD-PLANTILLA` = `'CHQ003'`
- `NTF-COD-UNICO` = `SDC-MAE-TIT-CODIGO-UNICO` (identificador único del titular obtenido del maestro de cuentas mediante la llamada previa a `SDCMAEST` con función `'LE'`)
- `NTF-PARAMETROS` = `'CUENTA BLOQUEADA POR 3 CHEQUES SIN FONDOS'` (texto fijo asignado directamente; no se usa el separador `'|'` porque solo hay un parámetro)
- `NTF-PRIORIDAD` = `1` (urgente)

No se verifica el código de retorno de `NTFENCOL`; si la notificación falla, el bloqueo ya fue realizado y no se deshace. De igual modo, no se verifica el código de retorno de las sentencias `UPDATE` de la base de datos dentro de este párrafo; cualquier error en ellas pasa desapercibido para el flujo de control.

**Rule Status:** Relevante para Modernización

**Algoritmo**

1. Ejecutar: `UPDATE CHQ_CHEQUE SET EST_CHEQUE = 'AN', FEC_ESTADO = :HV-FEC-PROCESO WHERE CTA_NUMERO = :HV-CUENTA AND EST_CHEQUE = 'DI'`. El valor de `HV-FEC-PROCESO` es la fecha de proceso en formato ISO `AAAA-MM-DD` (diez caracteres con guiones).
2. Ejecutar: `UPDATE CHQ_CHEQUERA SET EST_CHEQUERA = 'BL' WHERE CTA_NUMERO = :HV-CUENTA AND EST_CHEQUERA IN ('EM', 'EN')`. No se actualiza ningún campo de fecha.
3. Inicializar `NTF-PARAMETROS` a espacios.
4. Mover el texto fijo `'CUENTA BLOQUEADA POR 3 CHEQUES SIN FONDOS'` a `NTF-PARAMETROS`.
5. Llamar a `NTFENCOL` con: `NTF-FUNCION = 'EN'`, `NTF-CANAL = 'EM'`, `NTF-COD-PLANTILLA = 'CHQ003'`, `NTF-COD-UNICO = SDC-MAE-TIT-CODIGO-UNICO`, `NTF-PARAMETROS = 'CUENTA BLOQUEADA POR 3 CHEQUES SIN FONDOS'`, `NTF-PRIORIDAD = 1`.
6. No se evalúa el código de retorno de `NTFENCOL` ni el de los `UPDATE` anteriores; el control retorna al párrafo invocador (`5000-REINCIDENCIA`) en cualquier caso.
<!-- rule-end -->

<!-- rule-start -->
### 13. Regla / Operacion - 6000-ACTUALIZA-RECHAZO (Persistencia del resultado del rechazo en CHQ_RECHAZO)
<!-- reviewed -->

_Reviewed_

Actualiza el registro de la tabla `CHQ_RECHAZO` con los importes calculados y el nuevo estado del cobro. El campo clave del `WHERE` es `NUM_RECHAZO = HV-NUM-RECHAZO`.

Primero copia los importes calculados a las variables host: `WS-MULTA` a `HV-MON-MULTA`, `WS-COMISION` a `HV-MON-COMISION`, `WS-IGV` a `HV-MON-IGV`, y `WS-IND-COBRO-NUEVO` a `HV-IND-NUEVO`.

Luego ejecuta uno de dos `UPDATE` según el valor de `WS-IND-COBRO-NUEVO`:

**Si `WS-IND-COBRO-NUEVO = 'C'` (cobrado exitosamente):** Actualiza `MON_MULTA`, `MON_COMISION`, `MON_IGV`, `IND_COBRO = 'C'` y `FEC_COBRO = HV-FEC-PROCESO` (fecha de proceso en formato ISO `YYYY-MM-DD`, tal como fue almacenada en `HV-FEC-PROCESO` durante la inicialización).

**En cualquier otro caso (`'P'` pendiente, `'M'` mora, o `'N'` sin cargo):** Actualiza `MON_MULTA`, `MON_COMISION`, `MON_IGV` e `IND_COBRO = HV-IND-NUEVO`, tomando el valor que tenga `HV-IND-NUEVO` en ese momento. No se actualiza `FEC_COBRO` en este caso.

Si cualquiera de los dos `UPDATE` falla con `SQLCODE` distinto de cero, se asigna el código `'E0006'` a `WS-COD-ERROR`, se asigna el texto `'ERROR ACTUALIZANDO CHQ_RECHAZO'` a `WS-GLOSA-ERROR` y se invoca el párrafo `9900-REGISTRA-ERROR`, que escribe el evento en el log `LOGSIDEP` mediante `SDULOGER` con nivel `'E'`, incluyendo el `SQLCODE` en el registro.

Este párrafo es invocado únicamente cuando no existe un error previo en el registro (`SW-ERROR-REG` no está activo), es decir, se ejecuta dentro del bloque `IF NOT HAY-ERROR-REG` del párrafo `2000-PROCESA-RECHAZO`.

**Estado de la regla:** Relevante para Modernizacion

**Algoritmo**

1. Asignar: `HV-MON-MULTA` ← `WS-MULTA`; `HV-MON-COMISION` ← `WS-COMISION`; `HV-MON-IGV` ← `WS-IGV`; `HV-IND-NUEVO` ← `WS-IND-COBRO-NUEVO`.
2. Si `WS-IND-COBRO-NUEVO = 'C'`: ejecutar `UPDATE CHQ_RECHAZO SET MON_MULTA = HV-MON-MULTA, MON_COMISION = HV-MON-COMISION, MON_IGV = HV-MON-IGV, IND_COBRO = 'C', FEC_COBRO = HV-FEC-PROCESO WHERE NUM_RECHAZO = HV-NUM-RECHAZO`.
3. En cualquier otro caso (valores posibles de `HV-IND-NUEVO`: `'P'` pendiente, `'M'` mora, `'N'` sin cargo): ejecutar `UPDATE CHQ_RECHAZO SET MON_MULTA = HV-MON-MULTA, MON_COMISION = HV-MON-COMISION, MON_IGV = HV-MON-IGV, IND_COBRO = HV-IND-NUEVO WHERE NUM_RECHAZO = HV-NUM-RECHAZO`. No se actualiza `FEC_COBRO`.
4. Si `SQLCODE != 0`: asignar `WS-COD-ERROR = 'E0006'` y `WS-GLOSA-ERROR = 'ERROR ACTUALIZANDO CHQ_RECHAZO'`; invocar `9900-REGISTRA-ERROR`.
<!-- rule-end -->

<!-- rule-start -->
### 14. Regla / Operacion - 7000-NOTIFICAR-GIRADOR (Notificacion SMS al girador del rechazo)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para Modernizacion

Encola una notificación por SMS al titular de la cuenta giradora informando el rechazo de su cheque. Esta operación solo se ejecuta la primera vez que se procesa el rechazo, es decir, únicamente cuando el indicador de cobro original del registro (HV-IND-COBRO, leído del cursor antes de cualquier modificación) era igual a 'X' al inicio del ciclo de procesamiento. Los rechazos que ya estaban en estado pendiente ('P') no generan notificación.

**Condición previa:** Si la lectura del maestro de cuentas falló (SDC-MAE-COD-RETORNO distinto de SDU-RC-OK), no se envía notificación y la operación termina sin hacer nada.

Los parámetros de la llamada a NTFENCOL son:
- NTF-FUNCION = 'EN' (encolar)
- NTF-CANAL = 'SM' (SMS)
- NTF-COD-PLANTILLA = 'CHQ002'
- NTF-COD-UNICO = SDC-MAE-TIT-CODIGO-UNICO (identificador único del titular, obtenido de la lectura previa del maestro de cuentas mediante SDCMAEST función 'LE')
- NTF-PARAMETROS: antes de construir el valor se limpia el campo asignándole espacios; a continuación se concatenan, delimitados por tamaño (DELIMITED BY SIZE), los valores WS-NUM-CHEQUE-DISP (número del cheque en formato de 8 dígitos) + el carácter separador '|' + HV-COD-MOTIVO (código de motivo de rechazo de 2 caracteres). Esto proporciona los valores para los marcadores {1} (número de cheque) y {2} (motivo de rechazo) de la plantilla SMS.
- NTF-PRIORIDAD = 3

No se verifica el código de retorno de NTFENCOL tras la llamada.

**Algoritmo**

1. Si SDC-MAE-COD-RETORNO es distinto de SDU-RC-OK (valor '00'): terminar sin hacer nada (saltar al punto de salida del párrafo).
2. Asignar NTF-FUNCION = 'EN'.
3. Asignar NTF-CANAL = 'SM'.
4. Asignar NTF-COD-PLANTILLA = 'CHQ002'.
5. Asignar NTF-COD-UNICO = SDC-MAE-TIT-CODIGO-UNICO (campo devuelto por la lectura del maestro de cuentas).
6. Limpiar NTF-PARAMETROS asignándole espacios.
7. Construir NTF-PARAMETROS mediante concatenación delimitada por tamaño (STRING ... DELIMITED BY SIZE INTO NTF-PARAMETROS): WS-NUM-CHEQUE-DISP + '|' + HV-COD-MOTIVO. El resultado queda como cadena de la forma `NNNNNNNNN|MM`, donde NNNNNNNNN es el número del cheque (8 dígitos) y MM es el código de motivo (2 caracteres); estos valores corresponden a los parámetros {1} y {2} de la plantilla.
8. Asignar NTF-PRIORIDAD = 3.
9. Llamar a NTFENCOL pasando NTF-AREA-ENCOLA como único parámetro.
10. El código de retorno de NTFENCOL no se evalúa; la ejecución continúa independientemente del resultado de la llamada.
<!-- rule-end -->

<!-- rule-start -->
### 15. Regla / Operacion - 8000-CIERRE (Cierre del proceso y reporte de totales)
<!-- reviewed -->

_Reviewed_

El resumen del proceso que se muestra en el paso 2 omite una línea de encabezado en blanco (`DISPLAY ' '`) que el código emite antes del título. Además, la condición del paso 3 está descrita incorrectamente: el código verifica que `RETURN-CODE = 0`, pero el `EVALUATE` del código fuente usa `RETURN-CODE = 0` como condición implícita del `IF`; sin embargo, revisando el código con precisión, la condición real es `WS-CNT-PENDIENTES > ZEROS AND RETURN-CODE = 0`, lo cual coincide con la descripción, pero el valor literal usado en la comparación es `ZEROS` (no el literal numérico `0`), detalle sin impacto funcional. Lo que sí está ausente en la regla es la descripción precisa del texto del encabezado tal como aparece en el código (`'CHQRECHA - LIQUIDACION DE RECHAZOS  FECHA '` seguido del valor de `WS-FEC-PROCESO`). Todo lo demás es correcto.

---

Realiza el cierre ordenado del proceso. Las acciones son:

1. Cierra el cursor `CUR_RECH` en la base de datos mediante `SQL CLOSE CUR_RECH`.
2. Muestra por la salida estándar un resumen del proceso. Primero se emite una línea en blanco, luego el encabezado con el texto fijo `CHQRECHA - LIQUIDACION DE RECHAZOS  FECHA` concatenado con el valor de la fecha de proceso (`WS-FEC-PROCESO`), y a continuación cada uno de los siguientes contadores y totales, uno por línea con la etiqueta indicada:
   - `RECHAZOS LEIDOS......:` — `WS-CNT-LEIDOS` (total de registros leídos del cursor)
   - `COBRADOS.............:` — `WS-CNT-COBRADOS` (cobros exitosos realizados mediante SDMPOSTA)
   - `PENDIENTES DE COBRO..:` — `WS-CNT-PENDIENTES` (cobros fallidos por saldo insuficiente o cuenta bloqueada con 30 días o menos desde la fecha de rechazo, reintentables en la próxima corrida)
   - `PASADOS A MORA.......:` — `WS-CNT-A-MORA` (cobros fallidos por saldo insuficiente o cuenta bloqueada con más de 30 días desde la fecha de rechazo, marcados con indicador `'M'`)
   - `SIN CARGO............:` — `WS-CNT-SIN-CARGO` (rechazos para los que no corresponde ningún cargo, ya sea porque el motivo no genera multa ni comisión —motivos distintos de `'01'`, `'02'` y `'08'`— o porque la cuenta no existe o está cerrada)
   - `CUENTAS BLOQUEADAS...:` — `WS-CNT-BLOQUEOS` (cuentas bloqueadas exitosamente por reincidencia —tres o más rechazos por sin fondos en los últimos 365 días—)
   - `TOTAL MULTAS.........:` — `WS-TOT-MULTAS` (suma acumulada de multas efectivamente cobradas)
   - `TOTAL COMISIONES.....:` — `WS-TOT-COMISIONES` (suma acumulada de comisiones efectivamente cobradas)
   - `TOTAL IGV............:` — `WS-TOT-IGV` (suma acumulada de IGV efectivamente cobrado)
3. Si `WS-CNT-PENDIENTES` es mayor que cero **y** el `RETURN-CODE` actual es igual a `0`, establece `RETURN-CODE = 4`. Esto señala al JCL que el proceso terminó correctamente pero existen cobros pendientes que deben reintentarse en la próxima corrida. Si el `RETURN-CODE` ya tiene un valor distinto de `0` (por ejemplo, `12` o `16` asignados ante errores previos de cursor), no se sobreescribe.
4. Ejecuta `SQL COMMIT WORK` para confirmar en la base de datos todos los cambios realizados durante el proceso.

**Estado de la regla:** Relevante para Modernización

**Algoritmo**

1. Ejecutar `SQL CLOSE CUR_RECH`.
2. Emitir una línea en blanco por la salida estándar.
3. Mostrar el encabezado: texto fijo `CHQRECHA - LIQUIDACION DE RECHAZOS  FECHA` seguido del valor de `WS-FEC-PROCESO`.
4. Mostrar, en el orden indicado, cada uno de los nueve contadores y totales con sus etiquetas exactas:
   - `RECHAZOS LEIDOS......:` `WS-CNT-LEIDOS`
   - `COBRADOS.............:` `WS-CNT-COBRADOS`
   - `PENDIENTES DE COBRO..:` `WS-CNT-PENDIENTES`
   - `PASADOS A MORA.......:` `WS-CNT-A-MORA`
   - `SIN CARGO............:` `WS-CNT-SIN-CARGO`
   - `CUENTAS BLOQUEADAS...:` `WS-CNT-BLOQUEOS`
   - `TOTAL MULTAS.........:` `WS-TOT-MULTAS`
   - `TOTAL COMISIONES.....:` `WS-TOT-COMISIONES`
   - `TOTAL IGV............:` `WS-TOT-IGV`
5. Evaluar la condición de advertencia: si `WS-CNT-PENDIENTES > ZEROS` **y** `RETURN-CODE = 0`, asignar `RETURN-CODE = 4`. Si `RETURN-CODE` ya es distinto de `0`, no modificarlo.
6. Ejecutar `SQL COMMIT WORK`.
<!-- rule-end -->

<!-- rule-start -->
### 16. Regla / Operacion - 8100-FECHA-A-ISO (Conversion de fecha de formato compacto a formato ISO con guiones)
<!-- reviewed -->

_Reviewed_

Convierte una fecha almacenada en WS-FECHA-TRAB (formato AAAAMMDD, 8 caracteres sin separadores) al formato ISO con guiones (AAAA-MM-DD, 10 caracteres) en WS-FECHA-ISO.

La estructura WS-FECHA-TRAB-N descompone WS-FECHA-TRAB en tres subcampos: WS-FT-ANIO (4 caracteres), WS-FT-MES (2 caracteres) y WS-FT-DIA (2 caracteres). La estructura WS-FECHA-ISO tiene literales fijos '-' en las posiciones 5 y 8, por lo que solo se necesita copiar los tres componentes a sus posiciones correspondientes.

Esta operación se invoca desde dos puntos distintos dentro del proceso de inicialización (párrafo 1000-INICIO): primero, justo después de mover WS-FEC-PROCESO a WS-FECHA-TRAB, para construir HV-FEC-PROCESO (fecha de proceso en formato ISO usada en predicados SQL); y segundo, después de calcular la fecha límite de la ventana de reincidencia mediante la llamada a SDUFECHA con función 'SUMADIAS' restando el valor de CHQ-DIAS-VENTANA-RECH (365 días) a la fecha de proceso, para construir HV-FEC-VENTANA (fecha de inicio de la ventana de reincidencia, también en formato ISO para predicados SQL). En ambos casos el resultado de WS-FECHA-ISO se mueve inmediatamente a la variable de host correspondiente (HV-FEC-PROCESO o HV-FEC-VENTANA) tras retornar del párrafo.

**Estado de la regla:** Relevante para Modernizacion

**Algoritmo**

1. Copiar WS-FT-ANIO (posiciones 1-4 de WS-FECHA-TRAB, redefinición de WS-FECHA-TRAB a través de WS-FECHA-TRAB-N) a WS-FI-ANIO.
2. Copiar WS-FT-MES (posiciones 5-6 de WS-FECHA-TRAB) a WS-FI-MES.
3. Copiar WS-FT-DIA (posiciones 7-8 de WS-FECHA-TRAB) a WS-FI-DIA.
4. WS-FECHA-ISO queda formado como: WS-FI-ANIO + '-' + WS-FI-MES + '-' + WS-FI-DIA, donde los caracteres '-' en las posiciones 5 y 8 son literales fijos declarados en la propia estructura de WS-FECHA-ISO y no se asignan en tiempo de ejecución.
<!-- rule-end -->

<!-- rule-start -->
### 17. Regla / Operacion - 9900-REGISTRA-ERROR (Registro centralizado de errores en el log del sistema)
<!-- reviewed -->

_Reviewed_

Registra un evento de error en el log centralizado del sistema SIDEP llamando a la rutina SDULOGER. Se invoca desde múltiples puntos del programa cuando ocurre una condición de error.

Los campos que se pasan a SDULOGER son:
- Nivel: 'E' (error)
- Programa: WS-NOM-PROGRAMA ('CHQRECHA')
- Párrafo: WS-PARRAFO-ACT (nombre de la operación activa en el momento del error)
- Código de error: WS-COD-ERROR (uno de los códigos E0001 a E0006 asignados en el punto de detección)
- Glosa: WS-GLOSA-ERROR (descripción del error)
- Cuenta: HV-CUENTA (número de cuenta del rechazo en proceso)
- DOI: espacios (no se informa el documento de identidad)
- Importe: HV-MON-CHEQUE (importe del cheque en proceso)
- Usuario: 'BATCH'
- Terminal: WS-NOM-PROGRAMA ('CHQRECHA')
- Canal: SDU-CAN-BATCH (constante con valor 'BA', definida en SDUCONST)
- Fecha: WS-FEC-PROCESO
- SQLCODE: el valor actual de SQLCODE en el momento de la llamada

El registro físico queda en el VSAM LOGSIDEP. SDULOGER mantiene el archivo abierto entre llamadas durante toda la unidad de ejecución; si no puede abrir el VSAM, degrada silenciosamente a DISPLAY sin interrumpir el proceso ni informar al llamador del fallo. La clave del registro en el VSAM se compone de fecha del sistema, hora, nombre de programa y un contador secuencial interno de SDULOGER.

**Estado de la regla:** Relevante para Modernización

**Algoritmo**

1. Asignar al campo de nivel del área de log el valor 'E' (error).
2. Asignar al campo de programa del área de log el valor de WS-NOM-PROGRAMA, cuyo contenido es la literal 'CHQRECHA'.
3. Asignar al campo de párrafo del área de log el valor de WS-PARRAFO-ACT, que contiene el nombre del párrafo activo en el momento en que se detectó el error.
4. Asignar al campo de código de error del área de log el valor de WS-COD-ERROR. Los códigos posibles asignados en los distintos puntos de detección son: 'E0001' (error al abrir el cursor CUR_RECH), 'E0002' (error en FETCH de CUR_RECH), 'E0003' (TESTCAMB no devolvió tipo de cambio), 'E0004' (error devuelto por SDMPOSTA distinto de saldo insuficiente o cuenta bloqueada), 'E0005' (no se pudo bloquear la cuenta por reincidencia mediante SDCMAEST), 'E0006' (error al actualizar CHQ_RECHAZO).
5. Asignar al campo de glosa del área de log el valor de WS-GLOSA-ERROR, que contiene la descripción textual del error establecida en el punto de detección.
6. Asignar al campo de cuenta del área de log el valor de HV-CUENTA, que es el número de cuenta del rechazo en proceso.
7. Asignar al campo de DOI del área de log el valor de espacios, ya que el documento de identidad no se informa en este contexto.
8. Asignar al campo de importe del área de log el valor de HV-MON-CHEQUE, que es el importe del cheque en proceso.
9. Asignar al campo de usuario del área de log la literal 'BATCH'.
10. Asignar al campo de terminal del área de log el valor de WS-NOM-PROGRAMA, cuyo contenido es la literal 'CHQRECHA'.
11. Asignar al campo de canal del área de log el valor de SDU-CAN-BATCH, constante definida en SDUCONST con valor 'BA'.
12. Asignar al campo de fecha del área de log el valor de WS-FEC-PROCESO, que contiene la fecha de proceso del lote en formato AAAAMMDD.
13. Asignar al campo de SQLCODE del área de log el valor actual de SQLCODE en el momento de la llamada.
14. Llamar a la rutina SDULOGER pasando el área SDU-AREA-LOG como único parámetro.
<!-- rule-end -->

<!-- rule-start -->
### 18. Regla / Operacion - Codigo comentado: 9500-CONDONA-MULTA (Condonacion de multa por autorizacion gerencial)
<!-- reviewed -->

_Reviewed_

Existe en el fuente un bloque de código completamente comentado (inactivo) identificado como `9500-CONDONA-MULTA`. Este bloque nunca fue compilado ni puesto en producción, según el propio comentario del código fuente, que lo describe explícitamente como: *"CODIGO MUERTO: CONDONACION DE MULTA POR AUTORIZACION DE GERENCIA (SDGCONDO). NUNCA SE ACTIVO EN PRODUCCION."*

Su lógica habría consistido en dos pasos secuenciales: primero, mover el valor cero a la variable `WS-MULTA`, anulando así el importe de la multa calculada; segundo, recalcular `WS-TOTAL-CARGO` como la suma de `WS-COMISION` más `WS-IGV`, es decir, excluyendo completamente la multa del total a cobrar a la cuenta giradora. Habría requerido la llamada a una rutina denominada `SDGCONDO`, que no forma parte de los archivos fuente suministrados y cuya interfaz se desconoce.

Dado que este código está comentado, no es compilado ni ejecutado por el programa y no tiene efecto alguno en el comportamiento actual. Ningún párrafo activo lo invoca ni lo referencia. El programa no dispone de ningún mecanismo de condonación de multas en producción.

**Estado de la regla:** Irrelevante para Modernización

**Algoritmo**

Este bloque no tiene algoritmo activo. El código comentado habría ejecutado, en ese orden:

1. Asignar cero al importe de multa (`WS-MULTA = 0`).
2. Recalcular el total a cobrar como: `WS-TOTAL-CARGO = WS-COMISION + WS-IGV` (sin incluir multa).

El comportamiento actual del programa es no condonar multas bajo ninguna circunstancia. Si en la modernización se requiere implementar condonación de multas, deberá diseñarse desde cero con los controles de autorización gerencial correspondientes, dado que la rutina `SDGCONDO` referenciada en el código muerto no existe en la base de código disponible y nunca fue integrada al flujo productivo.
<!-- rule-end -->

---

## Extraction metadata

- **Main file:** cobol/CHQRECHA.cbl
- **Created:** 2026-11-08 15:59:28 UTC
- **Started:** 2026-11-08 16:28:54 UTC
- **Duration:** 01:05:47
- **LLM:** us.anthropic.claude-sonnet-4-6 (us.anthropic.claude-sonnet-4-6)
- **Context window:** 200000 tokens · **Max output:** 64000 tokens
- **Extraction prompt:** business_rules_extraction_cobol · **Reviewer prompt:** business_rules_reviewer_cobol
- **Token usage:** 1679204 total (1614080 input, 65124 output)

### Reference files (15)
Intended for the extraction; any excluded below were not submitted:
- cobol/NTFENCOL.cbl
- cobol/SDCMAEST.cbl
- cobol/SDMPOSTA.cbl
- cobol/SDUFECHA.cbl
- cobol/SDULOGER.cbl
- cobol/TESTCAMB.cbl
- copybook/CHQCONW.cpy
- copybook/NTFIFCW.cpy
- copybook/SDBPARMW.cpy
- copybook/SDCMAEW.cpy
- copybook/SDMPOSTW.cpy
- copybook/SDUCONST.cpy
- copybook/SDUFECHW.cpy
- copybook/SDULOGW.cpy
- copybook/TESIFCW.cpy
