# CHQVALCH.cbl: Validacion de Cheques Pagaderos - Subrutina CHQVALCH

## Overview

CHQVALCH es una subrutina del sistema SIDEP (Sistema Integrado de Depositos) del Banco Andes del Peru, perteneciente al modulo de Cheques y Compensacion (CHQ). Su unico proposito es determinar si un cheque presentado al cobro es pagadero o debe ser rechazado, y en caso de rechazo, identificar el motivo exacto segun la tabla de codigos de la Camara de Compensacion.

El programa no mueve dinero ni actualiza ningun saldo. Su resultado es exclusivamente una decision de aceptacion o rechazo, acompanada de un codigo de motivo estandarizado, el saldo disponible informativo y un mensaje descriptivo.

La subrutina es invocada por dos tipos de llamadores: el programa de compensacion por lotes CHQCAMAR (procesamiento nocturno de la camara) y, opcionalmente, el canal en linea para pre-validar pagos antes de que el operador los confirme. Al ser una subrutina, no se ejecuta de forma autonoma ni tiene JCL propio; siempre es llamada por otro programa que le pasa el area de comunicacion definida en el copybook CHQVALCW.

Las validaciones se aplican en un orden fijo e inamovible establecido por la Camara de Compensacion. Ante el primer motivo de rechazo encontrado, el programa devuelve ese motivo y termina sin continuar con las validaciones siguientes. Si ninguna validacion falla, el cheque se declara pagadero.

## Process Flow

```mermaid
flowchart TD
    A("Inicio: llamada con datos del cheque")
    B["Inicializar: limpiar resultados y copiar datos de entrada"]
    C{"Funcion = 'VP'?"}
    D["Retornar error: funcion no soportada"]
    E{{"Validar cuenta (SDCMAEST)"}}
    F{"Cuenta inexistente,<br/>cerrada o bloqueada?"}
    G{{"Validar estado del cheque (CHQ_CHEQUE)"}}
    H{"Cheque anulado, con<br/>orden de no pago<br/>o ya pagado?"}
    I{{"Validar plazo de presentacion (SDUFECHA)"}}
    J{"Fuera de plazo<br/>o caducado?"}
    K{{"Validar defectos formales"}}
    L{"Importe cero, moneda<br/>incorrecta o enmendadura?"}
    M{{"Validar firma"}}
    N{"Firma disconforme?"}
    O{{"Validar fondos disponibles (SDMVALSA)"}}
    P{"Saldo disponible cubre<br/>importe + ITF estimado?"}
    Q["Marcar rechazo con motivo<br/>y codigo 0100"]
    R["Resultado: CHEQUE PAGADERO<br/>codigo 0000"]
    S("Fin: devolver resultado al llamador")

    A --> B
    B --> C
    C -->|"No"| D
    D --> S
    C -->|"Si"| E
    E --> F
    F -->|"Si - motivo 10, 03 o 04"| Q
    F -->|"No"| G
    G --> H
    H -->|"Si - motivo 07, 05 o 09"| Q
    H -->|"No"| I
    I --> J
    J -->|"Si - motivo 06 u 08"| Q
    J -->|"No"| K
    K --> L
    L -->|"Si - motivo 08"| Q
    L -->|"No"| M
    M --> N
    N -->|"Si - motivo 02"| Q
    N -->|"No"| O
    O --> P
    P -->|"No - motivo 01"| Q
    P -->|"Si"| R
    Q --> S
    R --> S
```

<!-- general-rule-start -->

## General Business Rules:

### Tipo de programa y forma de invocacion

CHQVALCH es una subrutina batch. No se ejecuta de forma directa ni tiene entrada de datos propia. Es invocada mediante una llamada de programa (CALL) desde CHQCAMAR (proceso de compensacion por lotes) o desde un programa del canal en linea que desee pre-validar un pago. El llamador debe pasar como unico parametro el area de comunicacion CHQ-AREA-VALIDA, cuya estructura esta definida en el copybook CHQVALCW.

### Datos de entrada

El llamador debe proporcionar los siguientes campos en el area de comunicacion antes de invocar a CHQVALCH:

- **CHQV-FUNCION**: codigo de funcion; el unico valor valido es `VP` (Validar Pago). Cualquier otro valor provoca el rechazo inmediato con codigo de retorno 0200 (dato invalido).
- **CHQV-CUENTA**: numero de cuenta corriente del girador, 14 caracteres.
- **CHQV-NUM-CHEQUE**: numero del cheque, 8 digitos.
- **CHQV-IMPORTE**: importe del cheque en la moneda de la cuenta, con dos decimales.
- **CHQV-MONEDA**: codigo de moneda del cheque (por ejemplo, `604` para soles, `840` para dolares).
- **CHQV-FEC-GIRO**: fecha de emision del cheque en formato AAAAMMDD.
- **CHQV-FEC-PRESENT**: fecha de presentacion al cobro en formato AAAAMMDD.
- **CHQV-PLAZA**: indicador de plaza; `P` si el cheque se presenta en una plaza distinta a la de emision, cualquier otro valor se trata como misma plaza.
- **CHQV-IND-FIRMA**: indicador de conformidad de firma; `S` si la firma fue verificada como conforme por imagen, `N` si es disconforme.
- **CHQV-IND-DEFECTO**: indicador de defecto formal; `S` si el cheque presenta enmendaduras u otro defecto formal visible.

### Datos de salida

Al retornar, el area de comunicacion contiene:

- **CHQV-COD-RETORNO**: resultado global. `0000` significa cheque pagadero; `0100` significa rechazable (ver motivo); `0900` indica error de sistema (fallo de base de datos u otro error tecnico).
- **CHQV-COD-MOTIVO**: codigo de motivo de rechazo de dos digitos segun la tabla de la Camara de Compensacion (vacio si el cheque es pagadero).
- **CHQV-SALDO-DISP**: saldo disponible de la cuenta al momento de la validacion, expresado con dos decimales. Se informa solo si la validacion llega hasta la etapa de fondos; en caso de rechazo previo o error, puede quedar en cero.
- **CHQV-COD-UNICO**: codigo unico del titular de la cuenta, obtenido del maestro de cuentas.
- **CHQV-MENSAJE**: descripcion textual del resultado o del motivo de rechazo.

### Inicializacion

Antes de iniciar cualquier validacion, el programa limpia todos los campos de salida: pone el indicador interno de rechazo en `N` (sin rechazo), establece el codigo de retorno en `0000` (OK), borra el codigo de motivo, el mensaje, el saldo disponible y el codigo unico del titular. Tambien copia el numero de cuenta y el numero de cheque a las variables internas que se usaran en las consultas a la base de datos.

### Validacion 1 - Existencia y estado de la cuenta (Regla RN-CHQ-11)

El programa llama a la subrutina SDCMAEST con funcion `LE` (leer) para consultar la tabla CUENTA_MAESTRO usando el numero de cuenta recibido. Se producen los siguientes resultados posibles:

- Si la cuenta no existe en la base de datos (SDCMAEST devuelve codigo `08` - no encontrado): se asigna **motivo 10** ("Cuenta inexistente") y se rechaza.
- Si SDCMAEST devuelve cualquier otro codigo de error distinto de OK: se asigna codigo de retorno `0900` (error de sistema) y se termina sin motivo de rechazo de camara.
- Si la cuenta existe, se examina su estado (campo ESTADO de CUENTA_MAESTRO):
  - Estado `CE` (Cerrada): **motivo 03** ("Cuenta cerrada").
  - Estados `BL` (Bloqueada), `BJ` (Bloqueada judicial), `IN` (Inactiva), `CA` (Castigada) o `AP` (En apertura): **motivo 04** ("Cuenta bloqueada o no operativa").
  - Cualquier otro estado (incluido `AC` - Activa): la cuenta es valida y se continua con la siguiente validacion.

Cuando la cuenta existe y es valida, se guarda el codigo unico del titular (campo COD_UNICO_TIT de CUENTA_MAESTRO) en CHQV-COD-UNICO para devolverlo al llamador. Tambien quedan disponibles internamente el producto, la moneda y el estado de la cuenta para su uso en validaciones posteriores.

### Validacion 2 - Estado del cheque en la chequera (Reglas RN-CHQ-10 y RN-CHQ-12)

El programa consulta directamente la tabla DB2 CHQ_CHEQUE buscando la fila donde el numero de cuenta (CTA_NUMERO) coincida con la cuenta recibida y el numero de cheque (NUM_CHEQUE) coincida con el cheque recibido. Se lee el campo EST_CHEQUE (estado del cheque).

- Si no se encuentra ninguna fila (SQLCODE +100): el cheque no fue emitido por el banco. **Motivo 07** ("Cheque no fue emitido por el banco").
- Si ocurre cualquier otro error de base de datos: se registra el error en el log del sistema (llamando a SDULOGER) y se asigna codigo de retorno `0900`.
- Si se encuentra la fila, se evalua el estado:
  - `AN` (Anulado): **motivo 07** ("Cheque anulado").
  - `NP` (Orden de no pago): **motivo 05** ("Orden de no pago vigente").
  - `PA` (Pagado): **motivo 09** ("Cheque ya fue pagado").
  - `DI` (Disponible), `PR` (Presentado) o `RE` (Rechazado): el cheque puede ser pagado; se continua con la siguiente validacion.

### Validacion 3 - Plazo de presentacion (Regla RN-CHQ-06)

El programa llama a la subrutina SDUFECHA con funcion `DIFDIAS` para calcular la diferencia en dias calendario entre la fecha de giro (CHQV-FEC-GIRO) y la fecha de presentacion (CHQV-FEC-PRESENT). El resultado es el numero de dias transcurridos desde la emision.

- Si SDUFECHA devuelve error (fechas invalidas): se asigna **motivo 08** ("Fecha de giro o presentacion invalida") y se rechaza.
- Si la diferencia es negativa (el cheque se presenta antes de su fecha de giro), se trata como cero dias. Esto responde al principio legal de que el cheque es pagadero a la vista desde su fecha de emision.
- Se determina el plazo aplicable segun la plaza:
  - Si CHQV-PLAZA = `P` (otra plaza): el plazo es de **60 dias calendario** (CHQ-DIAS-PLAZO-PLAZA).
  - En cualquier otro caso (misma plaza): el plazo es de **30 dias calendario** (CHQ-DIAS-PLAZO-LOCAL).
- El cheque se rechaza con **motivo 06** ("Cheque presentado fuera de plazo") si se cumple cualquiera de estas condiciones:
  - Los dias transcurridos superan el plazo aplicable (30 o 60 dias segun la plaza), O
  - Los dias transcurridos superan los **180 dias** de caducidad absoluta (CHQ-DIAS-CADUCIDAD), independientemente de la plaza.

### Validacion 4 - Defectos formales (Regla RN-CHQ-13)

Se verifican tres condiciones formales del cheque. Ante la primera que falle se asigna **motivo 08** y se termina esta etapa:

1. **Importe invalido**: si CHQV-IMPORTE es cero o negativo, el cheque se rechaza con motivo 08 ("Importe del cheque invalido").
2. **Moneda incorrecta**: si la moneda indicada en el cheque (CHQV-MONEDA) es distinta a la moneda de la cuenta obtenida del maestro (SDC-MAE-CTA-MONEDA), se rechaza con motivo 08 ("Moneda del cheque distinta a la cuenta"). No se realiza ninguna conversion de moneda.
3. **Enmendadura o defecto formal**: si el indicador CHQV-IND-DEFECTO tiene el valor `S`, se rechaza con motivo 08 ("Cheque con defecto formal").

### Validacion 5 - Firma (Regla RN-CHQ-14)

Si el indicador de firma (CHQV-IND-FIRMA) tiene el valor `N`, significa que la firma del cheque fue verificada por imagen y se determino que es disconforme con el registro del banco. En ese caso se asigna **motivo 02** ("Firma disconforme con registro") y se rechaza. Si el indicador es `S` (firma conforme), se continua con la siguiente validacion.

### Validacion 6 - Fondos disponibles (Regla RN-CHQ-15)

Esta es la ultima validacion y la mas compleja. El programa llama a la subrutina SDMVALSA para obtener el saldo realmente disponible de la cuenta. SDMVALSA calcula ese saldo como: saldo contable menos retenciones judiciales, alimenticias o coactivas vigentes, menos el monto intangible (aplicable a cuentas CTS por mandato legal). El resultado ya neto de todas esas deducciones se recibe en el campo POS-SALDO-DISPONIBLE.

La llamada a SDMVALSA se realiza configurando los siguientes parametros en el area AREA-POSTEO:
- Empresa: 1 (valor fijo).
- Cuenta: CHQV-CUENTA.
- Producto y moneda: los obtenidos del maestro de cuentas en la validacion 1.
- Signo de operacion: `D` (debito/cargo).
- Importe: CHQV-IMPORTE.
- Fecha de proceso y fecha valor: ambas igual a CHQV-FEC-PRESENT.
- Canal: `BA` (batch).

Si SDMVALSA devuelve codigo de saldo insuficiente (POS-SALDO-INSUF, codigo 0040): se pone CHQV-SALDO-DISP en cero, se asigna **motivo 01** ("Sin fondos suficientes") y se rechaza.

Si SDMVALSA devuelve cualquier otro error distinto de OK: se asigna codigo de retorno `0900` con el mensaje de error de SDMVALSA, sin asignar motivo de camara.

Si SDMVALSA responde correctamente, el saldo disponible obtenido (POS-SALDO-DISPONIBLE) se guarda en CHQV-SALDO-DISP. A continuacion se calcula el monto total requerido para pagar el cheque, que incluye el importe del cheque mas el ITF estimado:

1. **ITF estimado** = CHQV-IMPORTE multiplicado por la tasa ITF vigente (SDU-TASA-ITF = 0.000050, es decir el 0.005%). El resultado se redondea al centavo mas cercano (redondeo half-up, segun la clausula ROUNDED del calculo).
2. **Monto requerido** = CHQV-IMPORTE + ITF estimado.

Si el saldo disponible (CHQV-SALDO-DISP) es menor que el monto requerido, se asigna **motivo 01** ("Sin fondos suficientes") y se rechaza.

Si el saldo disponible cubre el monto requerido, el cheque es declarado pagadero y se establece el mensaje "CHEQUE PAGADERO" con codigo de retorno `0000`.

### Mecanismo de rechazo

Cuando cualquier validacion detecta un motivo de rechazo, el programa ejecuta el procedimiento interno de marca de rechazo, que realiza dos acciones: pone el indicador interno SW-RECHAZO en `S` y establece el codigo de retorno CHQV-COD-RETORNO en `0100` (rechazable). El flujo principal verifica este indicador despues de cada validacion y, si esta activo, salta directamente al final del programa sin ejecutar las validaciones restantes.

### Registro de errores tecnicos

Cuando ocurre un error de base de datos en la consulta a CHQ_CHEQUE, el programa invoca a la subrutina SDULOGER para dejar constancia en el archivo de log del sistema (VSAM LOGSIDEP). El registro incluye: nivel de severidad `E` (error), nombre del programa (`CHQVALCH`), nombre del paso en ejecucion, codigo de error `E0100`, el mensaje descriptivo, el numero de cuenta, el importe, el canal (`BA` - batch), la fecha de presentacion y el SQLCODE de la base de datos. Los errores de las demas subrutinas (SDCMAEST, SDMVALSA) son registrados por esas propias subrutinas.

### Tabla de codigos de motivo de rechazo

Los codigos de motivo que puede devolver este programa son los siguientes, en el orden en que se evaluan:

| Motivo | Descripcion | Validacion que lo genera |
|--------|-------------|--------------------------|
| 10 | Cuenta inexistente | Existencia de la cuenta |
| 03 | Cuenta cerrada | Estado de la cuenta |
| 04 | Cuenta bloqueada o no operativa | Estado de la cuenta |
| 07 | Cheque no emitido o anulado | Estado del cheque |
| 05 | Orden de no pago vigente | Estado del cheque |
| 09 | Cheque ya fue pagado | Estado del cheque |
| 06 | Cheque fuera de plazo o caducado | Plazo de presentacion |
| 08 | Fecha invalida, importe invalido, moneda incorrecta o defecto formal | Formales y fechas |
| 02 | Firma disconforme | Verificacion de firma |
| 01 | Sin fondos suficientes | Disponibilidad de fondos |

### Codigo inactivo

Existe en el fuente un bloque de codigo comentado correspondiente a la validacion de cheques certificados. Este producto fue retirado en 2009, pero la Camara de Compensacion continua enviando el indicador correspondiente. El bloque fue desactivado y no tiene efecto alguno en el procesamiento actual.

<!-- general-rule-end -->

## Dependencies

El programa CHQVALCH depende de seis modulos externos invocados en tiempo de ejecucion, siete copybooks incorporados en compilacion, una tabla DB2 consultada directamente mediante SQL embebido, y un archivo VSAM al que accede de forma indirecta a traves de uno de los modulos externos. A continuacion se describe cada dependencia y su relevancia para la modernizacion.

**Modulos externos invocados en tiempo de ejecucion**

CHQVALCH no gestiona ninguna conexion a base de datos ni ningun archivo por si mismo, salvo la consulta SQL directa a CHQ_CHEQUE. Toda la logica de acceso a datos de cuenta, calculo de saldo, aritmetica de fechas y registro de errores se delega en subrutinas especializadas del nucleo SIDEP. Cada llamada se realiza pasando un unico bloque de datos definido por el copybook correspondiente.

**Copybooks incorporados en compilacion**

Los copybooks se incluyen mediante sentencias COPY y se expanden en el codigo en tiempo de compilacion. Definen las estructuras de datos que el programa comparte con los modulos externos y con su propio llamador.

**Tabla DB2 accedida directamente**

El programa ejecuta una sentencia SELECT directa sobre la tabla CHQ_CHEQUE para obtener el estado del cheque. Es el unico acceso SQL propio del programa; todos los demas accesos a datos de cuenta se realizan a traves de SDCMAEST.

**Archivo VSAM accedido de forma indirecta**

El programa no abre ningun archivo VSAM directamente. Sin embargo, SDUFECHA accede al archivo VSAM FERIADOS para construir su tabla de dias festivos, y SDULOGER escribe en el archivo VSAM LOGSIDEP. Ambos archivos son dependencias transitivas de CHQVALCH.

**Nota sobre codigo inactivo**

Existe un bloque de codigo comentado que correspondia a la validacion de cheques certificados (parrafo 8000-VALIDAR-CERTIFICADO). Ese bloque no se compila ni se ejecuta. El programa no realiza ninguna accion relacionada con cheques certificados.

---

| Dependencia | Descripcion | Tipo | Referencia | Relevancia para Modernizacion |
|---|---|---|---|---|
| SDCMAEST | Subrutina hub de acceso al maestro de cuentas. CHQVALCH la invoca con funcion 'LE' (lectura) para obtener el estado, moneda, producto y codigo unico del titular de la cuenta presentada. Devuelve codigo SDU-RC-NO-ENCONTRADO si la cuenta no existe, o SDU-RC-OK con los datos si la encuentra. | Subrutina COBOL invocada por CALL | SDCMAEST.cbl | Punto unico de acceso a CUENTA_MAESTRO. La modernizacion debe reemplazarlo por un servicio o repositorio de cuentas equivalente. Advertencia documentada en el fuente: los programas CTSCERTI y SDMPOSTA replican el layout del area de comunicacion a mano sin usar el copybook SDCMAEW; si la firma de este modulo cambia, esos programas quedan desalineados sin que el compilador lo detecte. |
| SDUFECHA | Subrutina de aritmetica de fechas. CHQVALCH la invoca con funcion 'DIFDIAS' para calcular la diferencia en dias calendario entre la fecha de giro y la fecha de presentacion del cheque. El resultado se almacena en SDU-FE-DIAS-RESULT y se usa para determinar si el cheque esta dentro del plazo de presentacion. Si la llamada devuelve un codigo distinto a SDU-RC-OK, el cheque se rechaza con motivo 08 (defecto formal). | Subrutina COBOL invocada por CALL | SDUFECHA.cbl | Contiene logica de calendario con feriados hardcodeados hasta 2019 y un archivo VSAM de feriados (FERIADOS) que debe estar actualizado. La modernizacion debe reemplazar esta rutina por una libreria de fechas estandar y externalizar el catalogo de feriados a un medio mantenible. |
| SDMVALSA | Subrutina de calculo y validacion de saldo disponible. CHQVALCH la invoca para verificar si la cuenta tiene fondos suficientes para cubrir el importe del cheque. El programa le pasa la cuenta, producto, moneda, importe, fecha de proceso y fecha valor, con signo 'D' (debito). Si POS-COD-RETORNO es distinto de cero y POS-SALDO-INSUF esta activo (codigo 0040), se rechaza el cheque con motivo 01. Si el retorno es distinto de cero por otro motivo, se registra error de sistema. Si el retorno es cero, CHQVALCH toma el saldo devuelto en POS-SALDO-DISPONIBLE y realiza su propia verificacion adicional sumando el ITF estimado. | Subrutina COBOL invocada por CALL | SDMVALSA.cbl | Calcula el saldo neto de retenciones e intangible llamando internamente a SDCMAEST, SDRAPLIC, SDTDISPO y SDDLIMIT. La modernizacion debe entender que CHQVALCH realiza dos comprobaciones de fondos: una delegada en SDMVALSA y otra propia sobre el resultado devuelto. Ambas deben reproducirse. SDMVALSA reutiliza el area SDMPOSTW completa aunque solo necesita parte de ella. |
| SDULOGER | Subrutina centralizada de registro de errores y auditoria. CHQVALCH la invoca unicamente desde el parrafo 9900-REGISTRA-ERROR, que se activa solo cuando se produce un error de base de datos al leer CHQ_CHEQUE (SQLCODE distinto de 0 y distinto de +100). Escribe un registro de nivel 'E' en el archivo VSAM LOGSIDEP con datos del programa, parrafo, cuenta, importe, fecha y SQLCODE. Para los rechazos de negocio normales (motivos 01 a 10) no se llama a SDULOGER; solo se registra el motivo en el area de retorno al llamador. | Subrutina COBOL invocada por CALL | SDULOGER.cbl | Si el archivo VSAM LOGSIDEP no esta disponible, SDULOGER degrada silenciosamente a DISPLAY sin notificar al llamador; CHQVALCH nunca sabe si el error quedo registrado. La modernizacion debe reemplazarlo por un mecanismo de logging que garantice la entrega y notifique fallos. |
| CHQ_CHEQUE | Tabla DB2 del dominio de cheques. CHQVALCH ejecuta un SELECT directo para obtener la columna EST_CHEQUE (estado del cheque) usando como clave la combinacion de CTA_NUMERO (numero de cuenta, 14 caracteres) y NUM_CHEQUE (numero de cheque, 8 digitos). Si SQLCODE es +100 (no encontrado) el cheque se rechaza con motivo 07. Si SQLCODE es cualquier otro valor negativo, se registra error de sistema. | Tabla DB2 accedida por SQL embebido | CHQ_CHEQUE (base de datos DB2) | Unico acceso SQL directo del programa. Los estados validos leidos de esta tabla estan definidos en CHQCONW: DI=disponible, PR=presentado, PA=pagado, RE=rechazado, NP=no pago, AN=anulado. La modernizacion debe mapear esta tabla y sus estados al modelo de datos destino. |
| FERIADOS (VSAM) | Archivo VSAM indexado de feriados del calendario bancario. CHQVALCH no lo accede directamente; lo accede SDUFECHA en su primera llamada para cargar la tabla de dias festivos en memoria. Los registros contienen fecha (8 caracteres YYYYMMDD), tipo de feriado y descripcion. Si el archivo no puede abrirse, SDUFECHA continua con una tabla fija de feriados hardcodeados valida solo hasta 2019. | Archivo VSAM indexado (acceso indirecto via SDUFECHA) | DD name: FERIADOS (nombre logico en JCL) | La tabla hardcodeada esta desactualizada a partir de 2020. La modernizacion debe asegurar que el catalogo de feriados se mantiene actualizado y es accesible en el entorno destino. |
| LOGSIDEP (VSAM) | Archivo VSAM indexado de bitacora del sistema SIDEP. CHQVALCH no lo accede directamente; lo escribe SDULOGER cuando se le invoca desde 9900-REGISTRA-ERROR. La clave del registro es la combinacion de fecha, hora, nombre de programa y un contador secuencial interno de SDULOGER. | Archivo VSAM indexado (acceso indirecto via SDULOGER) | DD name: LOGSIDEP (nombre logico en JCL) | Si este archivo no esta disponible, los errores de base de datos ocurridos durante la validacion del cheque se pierden silenciosamente. La modernizacion debe garantizar la trazabilidad de errores con un mecanismo alternativo. |
| CHQVALCW | Copybook que define el area de comunicacion CHQ-AREA-VALIDA, unico parametro que recibe CHQVALCH. Contiene los campos de entrada (funcion, cuenta, numero de cheque, importe, moneda, fechas de giro y presentacion, plaza, indicador de firma, indicador de defecto formal) y los campos de salida (codigo de motivo de rechazo, saldo disponible, codigo unico del titular, codigo de retorno y mensaje). | Copybook COBOL (COPY en LINKAGE SECTION) | CHQVALCW.cpy | Define el contrato de interfaz del programa. Cualquier llamador (CHQCAMAR o canal en linea) debe construir esta estructura exactamente. La modernizacion debe traducirla al modelo de parametros del lenguaje destino. |
| CHQCONW | Copybook de constantes, estados y motivos de rechazo del dominio de cheques. Define los plazos de presentacion (30 dias misma plaza, 60 dias otra plaza), el plazo de caducidad (180 dias), los codigos de estado del cheque (DI, PR, PA, RE, NP, AN), los diez motivos de rechazo de la camara de compensacion (01 a 10) y los codigos de retorno propios del dominio. Estos valores estan hardcodeados en el copybook y no se leen de ningun parametro externo. | Copybook COBOL (COPY en WORKING-STORAGE) | CHQCONW.cpy | Los plazos y el tope de rechazos por fondos estan cableados aqui. El ticket SD-2019-441 los marca como pendientes de parametrizar. La modernizacion debe decidir si estos valores pasan a configuracion externalizada. |
| SDCMAEW | Copybook que define el area de comunicacion SDC-AREA-MAESTRO usada en la llamada a SDCMAEST. Contiene todos los campos de identificacion de cuenta, datos del titular, saldos, fechas de control, auditoria e indicadores. CHQVALCH usa los campos SDC-MAE-CTA-ESTADO, SDC-MAE-CTA-MONEDA, SDC-MAE-CTA-PRODUCTO y SDC-MAE-TIT-CODIGO-UNICO de la respuesta. | Copybook COBOL (COPY en WORKING-STORAGE) | SDCMAEW.cpy | Advertencia critica documentada en el fuente: CTSCERTI y SDMPOSTA no usan este copybook y replican el layout a mano. Si el orden de campos cambia, esos programas quedan desalineados sin error de compilacion. La modernizacion debe auditar todos los llamadores de SDCMAEST. |
| SDMPOSTW | Copybook que define el area de comunicacion AREA-POSTEO usada en la llamada a SDMVALSA. CHQVALCH llena los campos de entrada (empresa, cuenta, producto, moneda, signo, importe, fechas y canal) y lee los campos de salida (POS-COD-RETORNO, POS-SALDO-INSUF, POS-SALDO-DISPONIBLE y POS-MENSAJE). | Copybook COBOL (COPY en WORKING-STORAGE) | SDMPOSTW.cpy | SDMVALSA reutiliza este copybook completo aunque solo necesita parte de el, por compatibilidad con SDMPOSTA. La modernizacion debe mapear solo los campos efectivamente usados por CHQVALCH. |
| SDUFECHW | Copybook que define el area de comunicacion SDU-AREA-FECHA usada en la llamada a SDUFECHA. CHQVALCH llena SDU-FE-FUNCION con 'DIFDIAS', SDU-FE-FECHA-ENT con la fecha de giro y SDU-FE-FECHA-ENT-2 con la fecha de presentacion, y lee SDU-FE-DIAS-RESULT y SDU-FE-COD-RETORNO. | Copybook COBOL (COPY en WORKING-STORAGE) | SDUFECHW.cpy | Define el contrato de la rutina de fechas. La modernizacion debe asegurarse de que el calculo de diferencia de dias en el entorno destino produce resultados identicos (dias calendario, no habiles). |
| SDULOGW | Copybook que define el area de comunicacion SDU-AREA-LOG usada en la llamada a SDULOGER. CHQVALCH llena los campos de nivel, programa, parrafo, codigo de error, glosa, cuenta, importe, usuario, terminal, canal, fecha y SQLCODE antes de invocar a SDULOGER. | Copybook COBOL (COPY en WORKING-STORAGE) | SDULOGW.cpy | Define el contrato del logger centralizado. La modernizacion debe mapear estos campos al sistema de logging del entorno destino. |
| SDUCONST | Copybook de constantes institucionales del sistema SIDEP. CHQVALCH usa SDU-CAN-BATCH (canal de proceso por lotes, valor 'BA') al preparar la llamada a SDMVALSA, y SDU-TASA-ITF (tasa del Impuesto a las Transacciones Financieras, valor 0.000050, es decir 0.005%) para calcular el ITF estimado sobre el importe del cheque. | Copybook COBOL (COPY en WORKING-STORAGE) | SDUCONST.cpy | La tasa ITF esta hardcodeada en este copybook y no se lee de ningun parametro externo ni de base de datos. Si la tasa cambia por norma legal, requiere recompilacion. La modernizacion debe externalizar este valor a configuracion. |

## Data Structure

The application uses three categories of data structures: the communication area passed by the caller (defined in the LINKAGE SECTION via copybook CHQVALCW), internal working variables declared in WORKING-STORAGE, and the shared structures imported through copybooks. The DB2 table CHQ_CHEQUE is accessed directly. All field names below follow the copybook and source definitions.

---

### Communication Area: CHQ-AREA-VALIDA (Copybook CHQVALCW)

This is the single parameter block passed to CHQVALCH by its caller. It carries both the inputs describing the cheque to be validated and the outputs that report the result.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| CHQV-FUNCION | Function Code | Alphanumeric | 2 characters | Operation selector. Only value accepted is 'VP' (Validar Pago). Any other value causes immediate rejection with return code 0200. | Yes | N/A | Entry field. Must equal 'VP' or the program exits without performing any validation. | Yes | Control |
| CHQV-CUENTA | Account Number | Alphanumeric | 14 characters | Checking account number to be validated. Passed to SDCMAEST and SDMVALSA. | Yes | N/A | Entry field. Copied internally to HV-CUENTA for DB2 use. | Yes | Identifier |
| CHQV-NUM-CHEQUE | Cheque Number | Unsigned numeric | 8 digits (packed decimal) | Cheque number within the account's chequebook. Used to query CHQ_CHEQUE. | Yes | N/A | Entry field. Copied internally to HV-NUM-CHEQUE. | Yes | Identifier |
| CHQV-IMPORTE | Amount | Signed numeric, 2 decimal places | 15 digits total (packed decimal) | Face value of the cheque. Must be greater than zero. Used in the funds check and ITF calculation. | Yes | N/A | Entry field. | Yes | Monetary |
| CHQV-MONEDA | Currency | Alphanumeric | 3 characters | Currency code of the cheque (e.g., '604' for Soles, '840' for Dollars). Must match the account's currency; no conversion is performed. | Yes | N/A | Entry field. Compared against SDC-MAE-CTA-MONEDA returned by SDCMAEST. | Yes | Reference |
| CHQV-FEC-GIRO | Issue Date | Alphanumeric (date YYYYMMDD) | 8 characters | Date the cheque was drawn. Used to calculate elapsed days for the presentment deadline check. | Yes | N/A | Entry field. Passed to SDUFECHA as SDU-FE-FECHA-ENT. | Yes | Date |
| CHQV-FEC-PRESENT | Presentment Date | Alphanumeric (date YYYYMMDD) | 8 characters | Date the cheque is being presented for payment. Used in the deadline calculation and as the processing date for SDMVALSA. | Yes | N/A | Entry field. Passed to SDUFECHA as SDU-FE-FECHA-ENT-2 and to SDMVALSA as POS-FECHA-PROCESO and POS-FECHA-VALOR. | Yes | Date |
| CHQV-PLAZA | Clearing Zone | Alphanumeric | 1 character | Indicates whether the cheque was drawn in the same clearing zone ('L' = local) or a different one ('P' = otra plaza). Determines the applicable presentment deadline (30 or 60 days). | Yes | N/A | Entry field. Any value other than 'P' is treated as local (30-day limit). | Yes | Reference |
| CHQV-IND-FIRMA | Signature Indicator | Alphanumeric | 1 character | Result of the image-based signature verification performed before calling CHQVALCH. 'S' = signature matches; 'N' = signature does not match. | Yes | N/A | Entry field. Set by the calling process (CHQCAMAR or online channel) before the call. | Yes | Indicator |
| CHQV-IND-DEFECTO | Formal Defect Indicator | Alphanumeric | 1 character | Indicates whether a formal defect (alteration, erasure) was detected on the cheque. 'S' = defect present. | Yes | N/A | Entry field. Added in 2008. The value 'C' (certified cheque) is referenced in commented-out dead code from a product discontinued in 2009. | Yes | Indicator |
| CHQV-COD-MOTIVO | Rejection Reason Code | Alphanumeric | 2 characters | Output: the clearing house reason code for the first rejection found. Values are defined in CHQCONW: '01'=Insufficient funds, '02'=Signature mismatch, '03'=Account closed, '04'=Account blocked/inactive, '05'=Stop payment order, '06'=Presented out of deadline or expired, '07'=Cheque not issued or voided, '08'=Formal defect, '09'=Cheque already paid, '10'=Account does not exist. | No | Spaces (set in 1000-INICIALIZAR) | Output field. Populated only when a rejection is found. The order of assignment is fixed by the clearing house and must not be changed. | Yes | Code |
| CHQV-SALDO-DISP | Available Balance | Signed numeric, 2 decimal places | 15 digits total (packed decimal) | Output: the net available balance returned by SDMVALSA after deducting retentions and intangible amounts. Set to zero if funds are insufficient. | No | 0 (set in 1000-INICIALIZAR) | Output field. | Yes | Monetary |
| CHQV-COD-UNICO | Holder Unique Code | Alphanumeric | 10 characters | Output: the account holder's unique identification code (COD_UNICO_TIT from CUENTA_MAESTRO), returned after a successful account read. | No | Spaces (set in 1000-INICIALIZAR) | Output field. Populated from SDC-MAE-TIT-CODIGO-UNICO. | Yes | Identifier |
| CHQV-COD-RETORNO | Return Code | Unsigned numeric | 4 digits | Output: overall result of the validation. 0000 = cheque is payable; 0100 = cheque is rejectable (see CHQV-COD-MOTIVO); 0200 = invalid input data; 0900 = DB2 system error. | No | 0000 (set in 1000-INICIALIZAR via CHQ-RC-OK) | Output field. Codes are defined in CHQCONW. | Yes | Control |
| CHQV-MENSAJE | Message | Alphanumeric | 60 characters | Output: descriptive text explaining the result or the error. | No | Spaces (set in 1000-INICIALIZAR) | Output field. | No | Descriptive |

---

### Internal Working Storage: CHQVALCH

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| WS-NOM-PROGRAMA | Program Name | Alphanumeric | 8 characters | Literal identifier of this program ('CHQVALCH'). Used when writing error log entries. | N/A | 'CHQVALCH' | Constant. | No | Control |
| WS-VERSION | Version | Alphanumeric | 5 characters | Version string ('V3.1 '). Used for identification only. | N/A | 'V3.1 ' | Constant. | No | Control |
| WS-PARRAFO-ACT | Current Paragraph | Alphanumeric | 20 characters | Name of the validation step currently executing. Written to the error log to indicate where a failure occurred. | N/A | Spaces | Updated at the start of each major validation step. | No | Diagnostic |
| SW-RECHAZO | Rejection Switch | Alphanumeric | 1 character | Internal flag: 'N' = no rejection found so far; 'S' = a rejection has been recorded (condition name HAY-RECHAZO). Controls whether subsequent validation steps are skipped. | N/A | 'N' | Set to 'S' by 9000-MARCA-RECHAZO. Reset to 'N' by 1000-INICIALIZAR at the start of each call. | Yes | Control |
| WS-DIAS-TRANSCURR | Elapsed Days | Signed numeric (packed decimal) | 7 digits | Number of calendar days between the issue date and the presentment date, calculated by SDUFECHA. If negative (cheque presented before its issue date), it is forced to zero. | N/A | 0 | Used in the deadline validation (step 4000). | Yes | Calculation |
| WS-PLAZO-APLICABLE | Applicable Deadline | Signed numeric (packed decimal) | 3 digits | The deadline in days that applies to this cheque: 30 days for local plaza, 60 days for another plaza. Loaded from CHQ-DIAS-PLAZO-LOCAL or CHQ-DIAS-PLAZO-PLAZA (defined in CHQCONW). | N/A | 0 | Used in the deadline validation (step 4000). | Yes | Calculation |
| WS-ITF-ESTIMADO | Estimated ITF | Signed numeric, 2 decimal places (packed decimal) | 11 digits total | Estimated Financial Transactions Tax (ITF) on the cheque amount. Calculated as CHQV-IMPORTE multiplied by SDU-TASA-ITF, rounded using half-up rounding. | N/A | 0 | Used in the funds validation (step 7000). SDU-TASA-ITF = 0.000050 (0.005%). | Yes | Calculation |
| WS-REQUERIDO | Required Amount | Signed numeric, 2 decimal places (packed decimal) | 15 digits total | Total amount the available balance must cover: CHQV-IMPORTE plus WS-ITF-ESTIMADO. | N/A | 0 | Used in the funds validation (step 7000). | Yes | Calculation |
| HV-CUENTA | Host Variable: Account | Alphanumeric | 14 characters | DB2 host variable holding the account number for the SQL query on CHQ_CHEQUE. | N/A | N/A | Loaded from CHQV-CUENTA in 1000-INICIALIZAR. | Yes | Identifier |
| HV-NUM-CHEQUE | Host Variable: Cheque Number | Signed numeric (packed decimal) | 8 digits | DB2 host variable holding the cheque number for the SQL query on CHQ_CHEQUE. | N/A | N/A | Loaded from CHQV-NUM-CHEQUE in 1000-INICIALIZAR. | Yes | Identifier |
| HV-EST-CHEQUE | Host Variable: Cheque Status | Alphanumeric | 2 characters | DB2 host variable that receives the value of EST_CHEQUE from CHQ_CHEQUE after the SELECT in step 3000. | N/A | N/A | Copied to CHQ-EST-CHE (defined in CHQCONW) for evaluation. | Yes | Status |

---

### DB2 Table: CHQ_CHEQUE

Only one column is read from this table by CHQVALCH. The full table structure is not declared in the source, but the accessed column is:

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| EST_CHEQUE | Cheque Status | Alphanumeric | 2 characters | Current lifecycle status of the cheque. Valid values (from CHQCONW): 'DI'=Available, 'PR'=Presented, 'PA'=Paid, 'RE'=Rejected, 'NP'=Stop Payment Order, 'AN'=Voided. | Yes | N/A | The table is queried by CTA_NUMERO (account number) and NUM_CHEQUE (cheque number). SQLCODE +100 means the cheque was never issued. Statuses 'DI', 'PR', and 'RE' do not trigger rejection; the cheque proceeds to further validations. | Yes | Status |

---

### Shared Structures from Copybooks

#### CHQCONW - Cheque Domain Constants

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| CHQ-DIAS-PLAZO-LOCAL | Local Deadline (days) | Unsigned numeric | 3 digits | Maximum calendar days for presentment when the cheque is drawn in the same clearing zone. | N/A | 30 | Hard-coded; not read from a parameter file. Pending parameterization (ticket SD-2019-441). | Yes | Parameter |
| CHQ-DIAS-PLAZO-PLAZA | Inter-Zone Deadline (days) | Unsigned numeric | 3 digits | Maximum calendar days for presentment when the cheque is drawn in a different clearing zone. | N/A | 60 | Hard-coded; not read from a parameter file. | Yes | Parameter |
| CHQ-DIAS-CADUCIDAD | Expiry Limit (days) | Unsigned numeric | 3 digits | Absolute maximum age of a cheque in calendar days. A cheque older than this is always rejected regardless of plaza. | N/A | 180 | Hard-coded. | Yes | Parameter |
| CHQ-MAX-RECHAZOS-SF | Max NSF Rejections | Unsigned numeric | 2 digits | Maximum number of insufficient-funds rejections within the rolling window before the account is blocked. Not used by CHQVALCH itself; used by CHQCAMAR. | N/A | 3 | Hard-coded. | Yes | Parameter |
| CHQ-DIAS-VENTANA-RECH | Rejection Window (days) | Unsigned numeric | 3 digits | Rolling window in days for counting NSF rejections. Not used by CHQVALCH. | N/A | 365 | Hard-coded. | No | Parameter |
| CHQ-RC-OK | Return Code: OK | Unsigned numeric | 4 digits | Return code indicating the cheque is payable. | N/A | 0000 | Used to initialise CHQV-COD-RETORNO. | Yes | Code |
| CHQ-RC-RECHAZABLE | Return Code: Rejectable | Unsigned numeric | 4 digits | Return code set when a rejection reason is found. | N/A | 0100 | Set by 9000-MARCA-RECHAZO. | Yes | Code |
| CHQ-RC-DATO-INVALIDO | Return Code: Invalid Data | Unsigned numeric | 4 digits | Return code set when the function code is not 'VP'. | N/A | 0200 | | Yes | Code |
| CHQ-RC-ERROR-DB2 | Return Code: DB2 Error | Unsigned numeric | 4 digits | Return code set when an unexpected DB2 error occurs. | N/A | 0900 | | Yes | Code |
| CHQ-EST-CHE | Cheque Status Work Field | Alphanumeric | 2 characters | Working field used to evaluate the cheque status retrieved from DB2. Condition names: CHQ-CHE-DISPONIBLE='DI', CHQ-CHE-PRESENTADO='PR', CHQ-CHE-PAGADO='PA', CHQ-CHE-RECHAZADO='RE', CHQ-CHE-NO-PAGO='NP', CHQ-CHE-ANULADO='AN'. | N/A | N/A | Receives the value of HV-EST-CHEQUE before the EVALUATE in step 3000. | Yes | Status |

#### SDCMAEW - Account Master Communication Area (Copybook SDCMAEW)

The fields listed below are those actually read or written by CHQVALCH when calling SDCMAEST. The full copybook contains additional fields used by other callers.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| SDC-MAE-FUNCION | Function Code | Alphanumeric | 2 characters | Instruction to SDCMAEST. CHQVALCH always sets this to 'LE' (read without lock). | Yes | N/A | Input to SDCMAEST. | Yes | Control |
| SDC-MAE-CTA-NUMERO | Account Number | Alphanumeric | 14 characters | Account number to be read from CUENTA_MAESTRO. | Yes | N/A | Input to SDCMAEST. Set from CHQV-CUENTA. | Yes | Identifier |
| SDC-MAE-COD-RETORNO | Return Code | Alphanumeric | 2 characters | Result of the SDCMAEST call. '00'=OK, '08'=Not found. Compared against SDU-RC-OK and SDU-RC-NO-ENCONTRADO. | N/A | N/A | Output from SDCMAEST. | Yes | Control |
| SDC-MAE-MENSAJE | Message | Alphanumeric | 60 characters | Descriptive text from SDCMAEST on error. | N/A | N/A | Output from SDCMAEST. | No | Descriptive |
| SDC-MAE-CTA-ESTADO | Account Status | Alphanumeric | 2 characters | Current status of the account. Values used in CHQVALCH: 'CE'=Closed (motivo 03), 'BL'=Blocked, 'BJ'=Judicial block, 'IN'=Inactive, 'CA'=Written-off, 'AP'=Opening in progress (all produce motivo 04). Any other value is treated as active. | N/A | N/A | Output from SDCMAEST. | Yes | Status |
| SDC-MAE-CTA-MONEDA | Account Currency | Alphanumeric | 3 characters | Currency of the account. Compared against CHQV-MONEDA in the formal defects check. | N/A | N/A | Output from SDCMAEST. Passed to SDMVALSA as POS-MONEDA. | Yes | Reference |
| SDC-MAE-CTA-PRODUCTO | Product Code | Alphanumeric | 2 characters | Product code of the account (e.g., '06' for current account). Passed to SDMVALSA as POS-PRODUCTO. | N/A | N/A | Output from SDCMAEST. | Yes | Reference |
| SDC-MAE-TIT-CODIGO-UNICO | Holder Unique Code | Alphanumeric | 10 characters | Unique identifier of the account holder (COD_UNICO_TIT from CUENTA_MAESTRO). Copied to CHQV-COD-UNICO in the output. | N/A | N/A | Output from SDCMAEST. | Yes | Identifier |

#### SDMPOSTW - Posting Engine Communication Area (Copybook SDMPOSTW)

The fields listed below are those set or read by CHQVALCH when calling SDMVALSA. The copybook is also used by the full posting engine SDMPOSTA; only the fields relevant to CHQVALCH are shown.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| POS-EMPRESA | Company Code | Unsigned numeric | 3 digits | Company identifier. CHQVALCH hard-codes this to 1. | Yes | N/A | Input to SDMVALSA. | Yes | Identifier |
| POS-CUENTA | Account Number | Alphanumeric | 20 characters | Account number passed to SDMVALSA. Set from CHQV-CUENTA. | Yes | N/A | Input to SDMVALSA. Note: this field is 20 characters while CHQV-CUENTA is 14; the remaining 6 characters are left as whatever was in memory. | Yes | Identifier |
| POS-PRODUCTO | Product Code | Alphanumeric | 2 characters | Product code, set from SDC-MAE-CTA-PRODUCTO. | Yes | N/A | Input to SDMVALSA. | Yes | Reference |
| POS-MONEDA | Currency | Unsigned numeric | 3 digits | Currency code, set from SDC-MAE-CTA-MONEDA. | Yes | N/A | Input to SDMVALSA. | Yes | Reference |
| POS-SIGNO | Debit/Credit Sign | Alphanumeric | 1 character | Direction of the operation. CHQVALCH always sets this to 'D' (debit/cargo). Condition name POS-CARGO. | Yes | N/A | Input to SDMVALSA. | Yes | Control |
| POS-IMPORTE | Amount | Signed numeric, 2 decimal places (packed decimal) | 15 digits total | Amount of the cheque. Set from CHQV-IMPORTE. | Yes | N/A | Input to SDMVALSA. | Yes | Monetary |
| POS-FECHA-PROCESO | Processing Date | Unsigned numeric (date YYYYMMDD) | 8 digits | Date used as the processing date for the balance check. Set from CHQV-FEC-PRESENT. | Yes | N/A | Input to SDMVALSA. | Yes | Date |
| POS-FECHA-VALOR | Value Date | Unsigned numeric (date YYYYMMDD) | 8 digits | Value date for the operation. Set from CHQV-FEC-PRESENT (same as processing date). | Yes | N/A | Input to SDMVALSA. | Yes | Date |
| POS-CANAL | Channel | Alphanumeric | 3 characters | Channel identifier. CHQVALCH sets this to SDU-CAN-BATCH ('BA'), meaning the call is treated as a batch operation regardless of whether it originates from the online channel. | Yes | N/A | Input to SDMVALSA. | Yes | Reference |
| POS-COD-RETORNO | Return Code | Unsigned numeric | 4 digits | Result of the SDMVALSA call. 0000=OK; 0040=Insufficient balance (condition POS-SALDO-INSUF); other values indicate errors. | N/A | N/A | Output from SDMVALSA. | Yes | Control |
| POS-SALDO-DISPONIBLE | Available Balance | Signed numeric, 2 decimal places (packed decimal) | 15 digits total | Net available balance calculated by SDMVALSA (accounting balance minus retentions minus intangible). Copied to CHQV-SALDO-DISP when the balance check passes. | N/A | N/A | Output from SDMVALSA. | Yes | Monetary |
| POS-MENSAJE | Message | Alphanumeric | 70 characters | Descriptive message from SDMVALSA on error. Copied to CHQV-MENSAJE when SDMVALSA returns an unexpected error. | N/A | N/A | Output from SDMVALSA. | No | Descriptive |

#### SDUFECHW - Date Utility Communication Area (Copybook SDUFECHW)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| SDU-FE-FUNCION | Function Code | Alphanumeric | 10 characters | Instruction to SDUFECHA. CHQVALCH sets this to 'DIFDIAS   ' (difference in days). | Yes | N/A | Input to SDUFECHA. Must be exactly 10 characters including trailing spaces. | Yes | Control |
| SDU-FE-FECHA-ENT | Input Date 1 | Alphanumeric (date YYYYMMDD) | 8 characters | First date for the difference calculation. Set from CHQV-FEC-GIRO (issue date). | Yes | N/A | Input to SDUFECHA. | Yes | Date |
| SDU-FE-FECHA-ENT-2 | Input Date 2 | Alphanumeric (date YYYYMMDD) | 8 characters | Second date for the difference calculation. Set from CHQV-FEC-PRESENT (presentment date). | Yes | N/A | Input to SDUFECHA. | Yes | Date |
| SDU-FE-DIAS-RESULT | Result in Days | Signed numeric (packed decimal) | 7 digits | Number of calendar days between the two input dates (Date 2 minus Date 1). A negative result means the cheque was presented before its issue date. | N/A | 0 | Output from SDUFECHA. Copied to WS-DIAS-TRANSCURR. | Yes | Calculation |
| SDU-FE-COD-RETORNO | Return Code | Alphanumeric | 2 characters | Result of the SDUFECHA call. '00'=OK; any other value means one or both dates are invalid. | N/A | N/A | Output from SDUFECHA. | Yes | Control |

#### SDULOGW - Logger Communication Area (Copybook SDULOGW)

These fields are populated by CHQVALCH only in the error-logging routine (9900-REGISTRA-ERROR), which is called exclusively when a DB2 error occurs reading CHQ_CHEQUE.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| SDU-LG-NIVEL | Log Level | Alphanumeric | 1 character | Severity of the log entry. CHQVALCH always writes 'E' (Error). | Yes | N/A | Input to SDULOGER. | No | Control |
| SDU-LG-PROGRAMA | Program Name | Alphanumeric | 8 characters | Name of the program writing the log entry. Set from WS-NOM-PROGRAMA ('CHQVALCH'). | Yes | N/A | Input to SDULOGER. | No | Identifier |
| SDU-LG-PARRAFO | Paragraph Name | Alphanumeric | 20 characters | Name of the step where the error occurred. Set from WS-PARRAFO-ACT. | Yes | N/A | Input to SDULOGER. | No | Diagnostic |
| SDU-LG-COD-ERROR | Error Code | Alphanumeric | 6 characters | Application error code. CHQVALCH always writes 'E0100'. | Yes | N/A | Input to SDULOGER. | No | Code |
| SDU-LG-GLOSA | Description | Alphanumeric | 120 characters | Narrative description of the error. Set from CHQV-MENSAJE. | Yes | N/A | Input to SDULOGER. | No | Descriptive |
| SDU-LG-CUENTA | Account Number | Alphanumeric | 14 characters | Account number associated with the error. Set from CHQV-CUENTA. | Yes | N/A | Input to SDULOGER. | No | Identifier |
| SDU-LG-DOI | Document of Identity | Alphanumeric | 12 characters | Holder identity document. CHQVALCH always sets this to spaces (not available at error time). | No | Spaces | Input to SDULOGER. The first 4 characters are masked with '****' by SDULOGER. | No | Identifier |
| SDU-LG-IMPORTE | Amount | Signed numeric, 2 decimal places (packed decimal) | 15 digits total | Amount associated with the log entry. Set from CHQV-IMPORTE. | No | N/A | Input to SDULOGER. | No | Monetary |
| SDU-LG-USUARIO | User | Alphanumeric | 8 characters | User identifier. CHQVALCH hard-codes this to 'BATCH'. | Yes | N/A | Input to SDULOGER. | No | Identifier |
| SDU-LG-TERMINAL | Terminal | Alphanumeric | 8 characters | Terminal identifier. CHQVALCH sets this to WS-NOM-PROGRAMA ('CHQVALCH'). | Yes | N/A | Input to SDULOGER. | No | Identifier |
| SDU-LG-CANAL | Channel | Alphanumeric | 2 characters | Channel code. Set from SDU-CAN-BATCH ('BA'). | Yes | N/A | Input to SDULOGER. | No | Reference |
| SDU-LG-FECHA | Date | Alphanumeric (date YYYYMMDD) | 8 characters | Date of the log entry. Set from CHQV-FEC-PRESENT. | Yes | N/A | Input to SDULOGER. | No | Date |
| SDU-LG-SQLCODE | SQL Code | Signed numeric (binary) | 9 digits | DB2 SQLCODE value at the time of the error. | No | N/A | Input to SDULOGER. | No | Diagnostic |

#### SDUCONST - System Constants (Copybook SDUCONST)

Only the constants used by CHQVALCH are listed.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| SDU-TASA-ITF | ITF Tax Rate | Signed numeric, 6 decimal places | 7 digits total (packed decimal) | Financial Transactions Tax rate applied to the cheque amount to estimate the ITF. | N/A | +0.000050 | Equals 0.005% per operation. Used in step 7000. Hard-coded constant; requires a parameter table change if the rate changes. | Yes | Parameter |
| SDU-RC-OK | Standard Return Code: OK | Alphanumeric | 2 characters | Standard system return code for success ('00'). Used to compare the result of SDCMAEST and SDUFECHA calls. | N/A | '00' | | Yes | Code |
| SDU-RC-NO-ENCONTRADO | Standard Return Code: Not Found | Alphanumeric | 2 characters | Standard system return code when a record is not found ('08'). Used to detect a non-existent account in the SDCMAEST response. | N/A | '08' | | Yes | Code |
| SDU-CAN-BATCH | Batch Channel Code | Alphanumeric | 2 characters | Channel identifier for batch processing ('BA'). Used when populating POS-CANAL and SDU-LG-CANAL. | N/A | 'BA' | | Yes | Reference |

## Detailed Rules

<!-- rule-start -->
### 1. Regla / Operacion - 0000-PRINCIPAL (Control de flujo principal)
<!-- reviewed -->

_Reviewed_

El programa CHQVALCH es una subrutina que recibe una solicitud de validacion de pago de cheque y ejecuta una cadena de verificaciones en orden fijo. El flujo es secuencial y se detiene en cuanto encuentra el primer motivo de rechazo o un error de sistema. No realiza ningun movimiento de dinero.

El programa comienza ejecutando la inicializacion (parrafo 1000-INICIALIZAR). A continuacion verifica que el campo de funcion recibido sea exactamente igual al valor `'VP'` (validar pago). Si el valor es cualquier otro, coloca el codigo de retorno `CHQ-RC-DATO-INVALIDO` (valor `0200`) en el campo de salida `CHQV-COD-RETORNO`, escribe el mensaje `'FUNCION NO SOPORTADA POR CHQVALCH'` en `CHQV-MENSAJE` y termina de inmediato sin ejecutar ninguna validacion.

Si la funcion es `'VP'`, ejecuta los siguientes pasos en orden. La condicion de corte que se evalua despues de cada paso depende del paso en cuestion: para los pasos 1 y 2 se evalua si existe un rechazo activo (indicador `SW-RECHAZO` igual a `'S'`) **o** si el codigo de retorno es `CHQ-RC-ERROR-DB2` (valor `0900`); para los pasos 3 a 6 se evalua unicamente si existe un rechazo activo (`SW-RECHAZO` igual a `'S'`). En cualquiera de esos casos el programa abandona la cadena y devuelve el control al llamador mediante `GOBACK`. Si ninguna condicion de corte se cumple, pasa al siguiente paso. El paso 6 (validacion de fondos) es el ultimo y no tiene condicion de corte posterior; el programa termina normalmente con `GOBACK` tras su ejecucion.

1. Ejecuta **2000-VALIDAR-CUENTA**: verifica que la cuenta exista y este en estado operable.
2. Ejecuta **3000-VALIDAR-ESTADO-CHEQUE**: verifica el estado del cheque en la base de datos.
3. Ejecuta **4000-VALIDAR-PLAZO**: verifica que el cheque se presente dentro del plazo legal.
4. Ejecuta **5000-VALIDAR-FORMALES**: verifica el importe, la moneda y la ausencia de defectos formales.
5. Ejecuta **6000-VALIDAR-FIRMA**: verifica la conformidad de la firma.
6. Ejecuta **7000-VALIDAR-FONDOS**: verifica que la cuenta tenga saldo suficiente para cubrir el importe mas el ITF estimado.

**Estado de la regla:** Relevante para la Modernizacion

**Algoritmo**

1. Ejecutar la inicializacion (ver regla 1000-INICIALIZAR).
2. Comparar `CHQV-FUNCION` con el literal `'VP'`.
   - Si no es igual: asignar `0200` a `CHQV-COD-RETORNO`, asignar `'FUNCION NO SOPORTADA POR CHQVALCH'` a `CHQV-MENSAJE` y terminar con `GOBACK`.
3. Ejecutar **2000-VALIDAR-CUENTA**. Si `SW-RECHAZO = 'S'` **o** `CHQV-COD-RETORNO = 0900`, terminar con `GOBACK`.
4. Ejecutar **3000-VALIDAR-ESTADO-CHEQUE**. Si `SW-RECHAZO = 'S'` **o** `CHQV-COD-RETORNO = 0900`, terminar con `GOBACK`.
5. Ejecutar **4000-VALIDAR-PLAZO**. Si `SW-RECHAZO = 'S'`, terminar con `GOBACK`. *(La condicion de error de base de datos no se evalua en este paso.)*
6. Ejecutar **5000-VALIDAR-FORMALES**. Si `SW-RECHAZO = 'S'`, terminar con `GOBACK`. *(La condicion de error de base de datos no se evalua en este paso.)*
7. Ejecutar **6000-VALIDAR-FIRMA**. Si `SW-RECHAZO = 'S'`, terminar con `GOBACK`. *(La condicion de error de base de datos no se evalua en este paso.)*
8. Ejecutar **7000-VALIDAR-FONDOS**. Este es el ultimo paso de la cadena; no existe condicion de corte posterior.
9. Devolver el control al llamador mediante `GOBACK`.
<!-- rule-end -->

<!-- rule-start -->
### 2. Regla / Operacion - 1000-INICIALIZAR (Inicializacion de variables de trabajo)
<!-- reviewed -->

_Reviewed_

Este parrafo prepara el area de comunicacion y las variables internas antes de comenzar cualquier validacion. Garantiza que no queden valores residuales de ejecuciones anteriores.

**Estado de la regla:** Relevante para la Modernizacion

**Algoritmo**

1. Asignar el valor 'N' al indicador interno SW-RECHAZO. El valor 'N' significa que no hay rechazo activo; el valor 'S' activaria la condicion HAY-RECHAZO, que es evaluada por el programa principal para decidir si se interrumpe el flujo de validaciones.
2. Asignar el valor 0000 (constante CHQ-RC-OK) al campo de salida CHQV-COD-RETORNO.
3. Limpiar el campo de salida CHQV-COD-MOTIVO asignandole espacios en blanco.
4. Limpiar el campo de salida CHQV-MENSAJE asignandole espacios en blanco.
5. Asignar ceros al campo de salida CHQV-SALDO-DISP.
6. Limpiar el campo de salida CHQV-COD-UNICO asignandole espacios en blanco.
7. Copiar el valor del campo de entrada CHQV-CUENTA (numero de cuenta de 14 caracteres recibido del llamador) a la variable interna HV-CUENTA. Esta variable se utilizara como parametro de busqueda en las consultas posteriores a la base de datos DB2, concretamente en la lectura de la tabla CHQ_CHEQUE del paso de validacion del estado del cheque.
8. Copiar el valor del campo de entrada CHQV-NUM-CHEQUE (numero de cheque de 8 digitos recibido del llamador) a la variable interna HV-NUM-CHEQUE. Esta variable se utilizara igualmente como parametro de busqueda en las consultas a la tabla CHQ_CHEQUE.
<!-- rule-end -->

<!-- rule-start -->
### 3. Regla / Operacion - 2000-VALIDAR-CUENTA (RN-CHQ-11: Validacion de existencia y estado de la cuenta)
<!-- reviewed -->

_Reviewed_

**Rule Status:** Relevante para la Modernizacion

Esta regla verifica que la cuenta sobre la que se presenta el cheque exista en el sistema y se encuentre en un estado que permita operaciones. Implementa la regla de negocio identificada como RN-CHQ-11.

La validacion se realiza llamando al programa SDCMAEST con la funcion 'LE' (lectura), pasando el numero de cuenta recibido. SDCMAEST consulta la tabla CUENTA_MAESTRO de DB2 y devuelve los datos de la cuenta o un codigo de error.

Los posibles resultados y sus consecuencias son:

- Si SDCMAEST devuelve el codigo SDU-RC-NO-ENCONTRADO (valor '08'): la cuenta no existe. Se asigna el motivo de rechazo '10' (cuenta inexistente), se escribe el mensaje 'CUENTA INEXISTENTE', se activa el rechazo mediante 9000-MARCA-RECHAZO y se sale del parrafo. El parrafo 9000-MARCA-RECHAZO establece 'S' en el indicador SW-RECHAZO y asigna CHQ-RC-RECHAZABLE (valor 0100) a CHQV-COD-RETORNO.
- Si SDCMAEST devuelve cualquier otro codigo distinto de SDU-RC-OK (valor '00'): se trata como error de sistema. Se asigna CHQ-RC-ERROR-DB2 (valor 0900) directamente a CHQV-COD-RETORNO y el mensaje 'ERROR AL LEER MAESTRO DE CUENTAS' a CHQV-MENSAJE. No se invoca 9000-MARCA-RECHAZO ni se activa el indicador SW-RECHAZO, pero el flujo principal detectara el codigo 0900 y detendra la cadena de validaciones.
- Si la lectura es exitosa (codigo '00'): se copia el campo SDC-MAE-TIT-CODIGO-UNICO (codigo unico del titular) al campo de salida CHQV-COD-UNICO. Luego se evalua el estado de la cuenta (campo SDC-MAE-CTA-ESTADO) segun las siguientes reglas:
  - Estado 'CE' (cerrada): motivo de rechazo '03', mensaje 'CUENTA CERRADA', se invoca 9000-MARCA-RECHAZO.
  - Estados 'BL', 'BJ', 'IN', 'CA' o 'AP': motivo de rechazo '04', mensaje 'CUENTA BLOQUEADA O NO OPERATIVA', se invoca 9000-MARCA-RECHAZO. Estos cinco estados se evaluan como condiciones separadas pero todas conducen al mismo motivo y mensaje; no existe un agrupamiento implicito entre ellos.
  - Cualquier otro estado (incluido 'AC', cuenta activa): no se realiza ninguna accion; la cuenta se considera operable y la validacion continua.

**Algoritmo**

1. Registrar el nombre del parrafo activo ('2000-VALIDAR-CUENTA') en WS-PARRAFO-ACT.
2. Preparar la llamada a SDCMAEST:
   - Asignar 'LE' a SDC-MAE-FUNCION.
   - Copiar CHQV-CUENTA a SDC-MAE-CTA-NUMERO.
   - Limpiar SDC-MAE-COD-RETORNO con espacios.
3. Llamar al programa SDCMAEST pasando el area SDC-AREA-MAESTRO.
4. Evaluar SDC-MAE-COD-RETORNO:
   - Si es igual a '08' (SDU-RC-NO-ENCONTRADO): asignar '10' a CHQV-COD-MOTIVO, asignar 'CUENTA INEXISTENTE' a CHQV-MENSAJE, ejecutar 9000-MARCA-RECHAZO (que fija SW-RECHAZO en 'S' y CHQV-COD-RETORNO en 0100) y salir del parrafo.
   - Si es distinto de '00' (SDU-RC-OK) y distinto de '08': asignar CHQ-RC-ERROR-DB2 (0900) directamente a CHQV-COD-RETORNO, asignar 'ERROR AL LEER MAESTRO DE CUENTAS' a CHQV-MENSAJE y salir del parrafo sin invocar 9000-MARCA-RECHAZO.
5. Si el retorno fue '00': copiar SDC-MAE-TIT-CODIGO-UNICO a CHQV-COD-UNICO.
6. Evaluar SDC-MAE-CTA-ESTADO mediante condiciones excluyentes en el siguiente orden:
   - Igual a 'CE': asignar '03' a CHQV-COD-MOTIVO, 'CUENTA CERRADA' a CHQV-MENSAJE, ejecutar 9000-MARCA-RECHAZO.
   - Igual a 'BL': asignar '04' a CHQV-COD-MOTIVO, 'CUENTA BLOQUEADA O NO OPERATIVA' a CHQV-MENSAJE, ejecutar 9000-MARCA-RECHAZO.
   - Igual a 'BJ': misma accion que 'BL'.
   - Igual a 'IN': misma accion que 'BL'.
   - Igual a 'CA': misma accion que 'BL'.
   - Igual a 'AP': misma accion que 'BL'.
   - Cualquier otro valor: no realizar ninguna accion; la cuenta se considera operable.
<!-- rule-end -->

<!-- rule-start -->
### 4. Regla / Operacion - 3000-VALIDAR-ESTADO-CHEQUE (RN-CHQ-10 / RN-CHQ-12: Validacion del estado del cheque en la chequera)
<!-- reviewed -->

_Reviewed_

Esta regla consulta directamente la tabla DB2 `CHQ_CHEQUE` para obtener el estado actual del cheque identificado por el número de cuenta y el número de cheque. Implementa las reglas RN-CHQ-10 y RN-CHQ-12.

La consulta busca el campo `EST_CHEQUE` en `CHQ_CHEQUE` filtrando por `CTA_NUMERO` igual a `HV-CUENTA` y `NUM_CHEQUE` igual a `HV-NUM-CHEQUE`. Los valores de `HV-CUENTA` y `HV-NUM-CHEQUE` fueron cargados durante la inicialización (párrafo `1000-INICIALIZAR`) copiando respectivamente `CHQV-CUENTA` y `CHQV-NUM-CHEQUE` desde el área de comunicación.

Los posibles resultados de la consulta SQL son:

- **SQLCODE = 0** (fila encontrada): continúa a la evaluación del estado.
- **SQLCODE = +100** (no existe fila): el cheque no fue emitido por el banco. Se asigna el motivo `'07'`, el mensaje `'CHEQUE NO FUE EMITIDO POR EL BANCO'`, se ejecuta el procedimiento `9000-MARCA-RECHAZO` (que activa el indicador de rechazo `SW-RECHAZO = 'S'` y establece `CHQV-COD-RETORNO = CHQ-RC-RECHAZABLE`, es decir, `0100`) y se sale del párrafo sin evaluar el estado.
- **Cualquier otro SQLCODE** (error de base de datos): se asigna `CHQ-RC-ERROR-DB2` (`0900`) a `CHQV-COD-RETORNO`, el mensaje `'ERROR DB2 LEYENDO CHQ_CHEQUE'` a `CHQV-MENSAJE`, se ejecuta el procedimiento `9900-REGISTRA-ERROR` (que escribe un registro de nivel `'E'` con código `'E0100'` en el log centralizado `SDULOGER`) y se sale del párrafo. Nótese que en este caso de error técnico **no** se llama a `9000-MARCA-RECHAZO`: el indicador `SW-RECHAZO` no se activa, pero `CHQV-COD-RETORNO` queda en `0900`, lo que es suficiente para que el párrafo principal (`0000-PRINCIPAL`) interrumpa el procesamiento al detectar `CHQV-COD-RETORNO = CHQ-RC-ERROR-DB2`.

Si la fila fue encontrada, el valor recuperado en `HV-EST-CHEQUE` se copia al campo `CHQ-EST-CHE`, que es el campo de evaluación de los estados definidos en el copybook `CHQCONW`. Los estados posibles y sus consecuencias son:

- **`'AN'`** (anulado, condición `CHQ-CHE-ANULADO`): se asigna motivo `'07'`, mensaje `'CHEQUE ANULADO'`, se ejecuta `9000-MARCA-RECHAZO`.
- **`'NP'`** (orden de no pago, condición `CHQ-CHE-NO-PAGO`): se asigna motivo `'05'`, mensaje `'ORDEN DE NO PAGO VIGENTE'`, se ejecuta `9000-MARCA-RECHAZO`.
- **`'PA'`** (pagado, condición `CHQ-CHE-PAGADO`): se asigna motivo `'09'`, mensaje `'CHEQUE YA FUE PAGADO'`, se ejecuta `9000-MARCA-RECHAZO`.
- **Cualquier otro valor** (`'DI'` disponible, `'PR'` presentado o `'RE'` rechazado): no se realiza ninguna acción; el cheque puede continuar siendo validado en los pasos siguientes.

El procedimiento `9000-MARCA-RECHAZO`, invocado en los casos de rechazo, establece `SW-RECHAZO = 'S'` y `CHQV-COD-RETORNO = CHQ-RC-RECHAZABLE` (`0100`). Tras la ejecución de este párrafo, el párrafo principal evalúa si `HAY-RECHAZO` o si `CHQV-COD-RETORNO = CHQ-RC-ERROR-DB2` (`0900`) y, en cualquiera de los dos casos, interrumpe el flujo de validación y retorna al llamador sin ejecutar las validaciones siguientes.

**Estado de la regla:** Relevante para la Modernización

**Algoritmo**

1. Registrar `'3000-VALIDAR-ESTADO'` en `WS-PARRAFO-ACT`.
2. Ejecutar la consulta SQL: `SELECT EST_CHEQUE INTO :HV-EST-CHEQUE FROM CHQ_CHEQUE WHERE CTA_NUMERO = :HV-CUENTA AND NUM_CHEQUE = :HV-NUM-CHEQUE`.
3. Evaluar `SQLCODE`:
   - Igual a `0`: continuar al paso 4.
   - Igual a `+100`: asignar `'07'` a `CHQV-COD-MOTIVO`, `'CHEQUE NO FUE EMITIDO POR EL BANCO'` a `CHQV-MENSAJE`, ejecutar `9000-MARCA-RECHAZO` (`SW-RECHAZO = 'S'`, `CHQV-COD-RETORNO = 0100`) y salir del párrafo.
   - Cualquier otro valor: asignar `CHQ-RC-ERROR-DB2` (`0900`) a `CHQV-COD-RETORNO`, asignar `'ERROR DB2 LEYENDO CHQ_CHEQUE'` a `CHQV-MENSAJE`, ejecutar `9900-REGISTRA-ERROR` (log de error nivel `'E'`, código `'E0100'`, en `SDULOGER`) y salir del párrafo. En este caso **no** se activa el indicador `SW-RECHAZO`.
4. Copiar `HV-EST-CHEQUE` a `CHQ-EST-CHE`.
5. Evaluar `CHQ-EST-CHE`:
   - Igual a `'AN'`: asignar `'07'` a `CHQV-COD-MOTIVO`, `'CHEQUE ANULADO'` a `CHQV-MENSAJE`, ejecutar `9000-MARCA-RECHAZO`.
   - Igual a `'NP'`: asignar `'05'` a `CHQV-COD-MOTIVO`, `'ORDEN DE NO PAGO VIGENTE'` a `CHQV-MENSAJE`, ejecutar `9000-MARCA-RECHAZO`.
   - Igual a `'PA'`: asignar `'09'` a `CHQV-COD-MOTIVO`, `'CHEQUE YA FUE PAGADO'` a `CHQV-MENSAJE`, ejecutar `9000-MARCA-RECHAZO`.
   - Cualquier otro valor (`'DI'`, `'PR'` o `'RE'`): no realizar ninguna acción; el procesamiento continúa con las validaciones posteriores.
<!-- rule-end -->

<!-- rule-start -->
### 5. Regla / Operacion - 4000-VALIDAR-PLAZO (RN-CHQ-06: Validacion del plazo de presentacion y caducidad)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para la Modernizacion

**Algoritmo**

Esta regla verifica que el cheque se haya presentado dentro del plazo legal permitido desde su fecha de giro, y que no haya superado el plazo de caducidad absoluta. Implementa la regla RN-CHQ-06.

El calculo de la diferencia de dias se delega al programa SDUFECHA con la funcion 'DIFDIAS'. Se le pasa la fecha de giro (CHQV-FEC-GIRO) como primera fecha (campo SDU-FE-FECHA-ENT) y la fecha de presentacion (CHQV-FEC-PRESENT) como segunda fecha (campo SDU-FE-FECHA-ENT-2). SDUFECHA calcula la diferencia en dias calendario entre ambas fechas y la devuelve en el campo SDU-FE-DIAS-RESULT. La formula interna de SDUFECHA es: dias transcurridos = dias absolutos de la fecha de presentacion (segunda fecha) menos dias absolutos de la fecha de giro (primera fecha). Un resultado positivo indica que el cheque se presenta despues de su fecha de giro; un resultado negativo indica que se presenta antes.

Si SDUFECHA devuelve un codigo de retorno en SDU-FE-COD-RETORNO distinto de SDU-RC-OK (valor '00'), significa que alguna de las dos fechas es invalida. En ese caso se asigna el motivo **'08'** a CHQV-COD-MOTIVO, el mensaje 'FECHA DE GIRO O PRESENTACION INVALIDA' a CHQV-MENSAJE, se invoca el procedimiento 9000-MARCA-RECHAZO (que activa el indicador de rechazo SW-RECHAZO en 'S' y asigna CHQ-RC-RECHAZABLE, valor 0100, a CHQV-COD-RETORNO) y se termina el parrafo sin continuar con las validaciones de plazo.

Si SDUFECHA tiene exito, se aplica la siguiente logica:

1. Se copia SDU-FE-DIAS-RESULT a WS-DIAS-TRANSCURR. Si el valor resultante es negativo (es decir, estrictamente menor que cero, lo que indica que el cheque se presenta antes de su fecha de giro), se fuerza a cero. Esto implementa la regla legal de que un cheque es pagadero a la vista: si se presenta antes de la fecha escrita, se trata como si se presentara exactamente en esa fecha y por tanto los dias transcurridos se consideran cero.

2. Se determina el plazo aplicable segun el campo CHQV-PLAZA:
   - Si CHQV-PLAZA es igual a **'P'** (otra plaza del pais): el plazo es CHQ-DIAS-PLAZO-PLAZA, cuyo valor fijo es **60 dias**, y se copia a WS-PLAZO-APLICABLE.
   - En cualquier otro caso (es decir, si CHQV-PLAZA es cualquier valor distinto de 'P', incluyendo el valor 'L' de misma plaza): el plazo es CHQ-DIAS-PLAZO-LOCAL, cuyo valor fijo es **30 dias**, y se copia a WS-PLAZO-APLICABLE.

3. Se evalua si WS-DIAS-TRANSCURR es mayor que WS-PLAZO-APLICABLE **o** si WS-DIAS-TRANSCURR es mayor que CHQ-DIAS-CADUCIDAD (valor fijo de **180 dias**). Ambas condiciones se evaluan en una sola instruccion condicional con el operador OR; si cualquiera de las dos es verdadera, se asigna el motivo **'06'** a CHQV-COD-MOTIVO, el mensaje 'CHEQUE PRESENTADO FUERA DE PLAZO' a CHQV-MENSAJE y se invoca 9000-MARCA-RECHAZO. Si ninguna condicion es verdadera, no se genera rechazo y el parrafo termina normalmente.

Los valores 30, 60 y 180 dias estan definidos como constantes fijas en el copybook CHQCONW (campos CHQ-DIAS-PLAZO-LOCAL, CHQ-DIAS-PLAZO-PLAZA y CHQ-DIAS-CADUCIDAD respectivamente) y no se leen de ningun parametro externo. El propio comentario del copybook advierte que esta es una deuda tecnica pendiente de parametrizar (referencia SD-2019-441).

**Pasos detallados del algoritmo**

1. Registrar '4000-VALIDAR-PLAZO' en WS-PARRAFO-ACT.
2. Preparar la llamada a SDUFECHA:
   - Asignar 'DIFDIAS   ' (10 caracteres, completado con espacios a la derecha) a SDU-FE-FUNCION.
   - Copiar CHQV-FEC-GIRO a SDU-FE-FECHA-ENT (primera fecha: fecha de giro).
   - Copiar CHQV-FEC-PRESENT a SDU-FE-FECHA-ENT-2 (segunda fecha: fecha de presentacion).
3. Llamar a SDUFECHA pasando SDU-AREA-FECHA.
4. Evaluar SDU-FE-COD-RETORNO:
   - Si es distinto de '00' (SDU-RC-OK):
     - Asignar '08' a CHQV-COD-MOTIVO.
     - Asignar 'FECHA DE GIRO O PRESENTACION INVALIDA' a CHQV-MENSAJE.
     - Ejecutar 9000-MARCA-RECHAZO (activa SW-RECHAZO='S' y pone 0100 en CHQV-COD-RETORNO).
     - Terminar el parrafo (la rama ELSE no se ejecuta).
   - Si es igual a '00':
     - a. Copiar SDU-FE-DIAS-RESULT a WS-DIAS-TRANSCURR.
     - b. Si WS-DIAS-TRANSCURR es estrictamente menor que cero, asignar cero a WS-DIAS-TRANSCURR.
     - c. Determinar el plazo segun la plaza:
       - Si CHQV-PLAZA es igual a 'P': copiar CHQ-DIAS-PLAZO-PLAZA (60) a WS-PLAZO-APLICABLE.
       - En cualquier otro caso: copiar CHQ-DIAS-PLAZO-LOCAL (30) a WS-PLAZO-APLICABLE.
     - d. Si WS-DIAS-TRANSCURR es mayor que WS-PLAZO-APLICABLE, **O** si WS-DIAS-TRANSCURR es mayor que CHQ-DIAS-CADUCIDAD (180):
       - Asignar '06' a CHQV-COD-MOTIVO.
       - Asignar 'CHEQUE PRESENTADO FUERA DE PLAZO' a CHQV-MENSAJE.
       - Ejecutar 9000-MARCA-RECHAZO (activa SW-RECHAZO='S' y pone 0100 en CHQV-COD-RETORNO).
     - e. Si ninguna de las condiciones del paso d es verdadera, no se genera rechazo y el parrafo termina normalmente sin modificar CHQV-COD-MOTIVO ni CHQV-COD-RETORNO.
<!-- rule-end -->

<!-- rule-start -->
### 6. Regla / Operacion - 5000-VALIDAR-FORMALES (RN-CHQ-13: Validacion de defectos formales del cheque)
<!-- reviewed -->

_Reviewed_

Esta regla verifica tres condiciones formales del cheque en secuencia. Ante el primer defecto encontrado en las dos primeras condiciones, activa el rechazo y sale sin verificar las siguientes. La tercera condición, si se alcanza, activa el rechazo y el parrafo termina en su punto final sin salida anticipada. Implementa la regla RN-CHQ-13. Los tres defectos se reportan todos con el mismo motivo de rechazo: '08'.

Las tres condiciones son:

1. **Importe invalido:** si CHQV-IMPORTE no es mayor que cero (es decir, es cero o negativo), el cheque tiene importe invalido. Se asigna motivo '08', mensaje 'IMPORTE DEL CHEQUE INVALIDO', se ejecuta 9000-MARCA-RECHAZO y se transfiere el control a 5000-FIN, terminando el parrafo sin evaluar las condiciones siguientes.

2. **Moneda distinta:** si CHQV-MONEDA (moneda indicada en el cheque) es diferente al valor de SDC-MAE-CTA-MONEDA (moneda de la cuenta, obtenida en la llamada previa a SDCMAEST con funcion 'LE'), el cheque tiene una moneda incompatible. El programa no realiza ninguna conversion de moneda; simplemente rechaza. Se asigna motivo '08', mensaje 'MONEDA DEL CHEQUE DISTINTA A LA CUENTA', se ejecuta 9000-MARCA-RECHAZO y se transfiere el control a 5000-FIN, terminando el parrafo sin evaluar la condicion siguiente.

3. **Defecto formal por enmendadura:** si CHQV-IND-DEFECTO es igual a 'S', el cheque tiene un defecto formal (por ejemplo, enmendaduras detectadas por el operador o por imagen). Se asigna motivo '08', mensaje 'CHEQUE CON DEFECTO FORMAL' y se ejecuta 9000-MARCA-RECHAZO. En este caso no hay salida anticipada; el parrafo termina en su punto final (5000-FIN).

El subproceso 9000-MARCA-RECHAZO, invocado en los tres casos, establece el indicador de rechazo SW-RECHAZO en 'S' y asigna el codigo de retorno CHQ-RC-RECHAZABLE (valor 0100) a CHQV-COD-RETORNO.

**Estado de la regla:** Relevante para la Modernizacion

**Algoritmo**

1. Registrar '5000-VALIDAR-FORMAL' en WS-PARRAFO-ACT.
2. Si CHQV-IMPORTE no es mayor que cero:
   - Asignar '08' a CHQV-COD-MOTIVO.
   - Asignar 'IMPORTE DEL CHEQUE INVALIDO' a CHQV-MENSAJE.
   - Ejecutar 9000-MARCA-RECHAZO (establece SW-RECHAZO = 'S' y CHQV-COD-RETORNO = 0100).
   - Transferir el control a 5000-FIN (no continuar con las siguientes validaciones).
3. Si CHQV-MONEDA es diferente de SDC-MAE-CTA-MONEDA:
   - Asignar '08' a CHQV-COD-MOTIVO.
   - Asignar 'MONEDA DEL CHEQUE DISTINTA A LA CUENTA' a CHQV-MENSAJE.
   - Ejecutar 9000-MARCA-RECHAZO (establece SW-RECHAZO = 'S' y CHQV-COD-RETORNO = 0100).
   - Transferir el control a 5000-FIN (no continuar con la siguiente validacion).
4. Si CHQV-IND-DEFECTO es igual a 'S':
   - Asignar '08' a CHQV-COD-MOTIVO.
   - Asignar 'CHEQUE CON DEFECTO FORMAL' a CHQV-MENSAJE.
   - Ejecutar 9000-MARCA-RECHAZO (establece SW-RECHAZO = 'S' y CHQV-COD-RETORNO = 0100).
5. El parrafo finaliza en el punto 5000-FIN, al que tambien llegan las salidas anticipadas de los pasos 2 y 3.
<!-- rule-end -->

<!-- rule-start -->
### 7. Regla / Operacion - 6000-VALIDAR-FIRMA (RN-CHQ-14: Validacion de conformidad de firma)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para la Modernizacion

**Algoritmo**

Esta regla verifica si la firma del cheque fue validada correctamente por el proceso de verificacion por imagen. Implementa la regla RN-CHQ-14.

El indicador `CHQV-IND-FIRMA` es enviado por el llamador (CHQCAMAR u otro proceso) y refleja el resultado de la comparacion de la firma del cheque contra el registro de firmas del titular. El programa CHQVALCH no realiza la comparacion por si mismo; solo consume el resultado.

Si `CHQV-IND-FIRMA` es igual a `'N'` (firma disconforme), se activa el rechazo. Cualquier otro valor del indicador (en particular `'S'`, firma conforme) no genera rechazo.

La rutina de marcado de rechazo (`9000-MARCA-RECHAZO`) realiza dos acciones de forma conjunta: establece el indicador interno de rechazo `SW-RECHAZO` en `'S'` y asigna el codigo de retorno de salida `CHQV-COD-RETORNO` al valor `CHQ-RC-RECHAZABLE` (valor numerico `0100`). Este codigo de retorno `0100` es distinto del codigo de exito (`CHQ-RC-OK` = `0000`) y del codigo de error de sistema (`CHQ-RC-ERROR-DB2` = `0900`), e indica al llamador que el cheque es rechazable por un motivo de camara.

1. Evaluar `CHQV-IND-FIRMA`:
   - Si es igual a `'N'`:
     - Asignar `'02'` a `CHQV-COD-MOTIVO`.
     - Asignar `'FIRMA DISCONFORME CON REGISTRO'` a `CHQV-MENSAJE`.
     - Ejecutar la rutina de marcado de rechazo, la cual:
       - Establece el indicador interno `SW-RECHAZO` en `'S'` (condicion `HAY-RECHAZO`).
       - Asigna el valor `0100` (`CHQ-RC-RECHAZABLE`) a `CHQV-COD-RETORNO`.
   - En cualquier otro caso: no realizar ninguna accion.

2. El control retorna al flujo principal (`0000-PRINCIPAL`), que evalua si `HAY-RECHAZO` esta activo. Si lo esta, el programa finaliza de inmediato sin ejecutar la validacion de fondos (`7000-VALIDAR-FONDOS`), que es la unica etapa posterior en la secuencia fija de validaciones. Si la firma es conforme, el flujo continua hacia la validacion de fondos.
<!-- rule-end -->

<!-- rule-start -->
### 8. Regla / Operacion - 7000-VALIDAR-FONDOS (RN-CHQ-15: Validacion de saldo disponible suficiente)
<!-- reviewed -->

_Reviewed_

Esta regla verifica que la cuenta tenga saldo disponible suficiente para cubrir el importe del cheque más el Impuesto a las Transacciones Financieras (ITF) estimado. Implementa la regla RN-CHQ-15.

La validación de saldo se delega al programa SDMVALSA, que calcula el saldo realmente disponible de la cuenta descontando retenciones vigentes y el monto intangible (en caso de cuentas CTS). SDMVALSA recibe el área de comunicación AREA-POSTEO (definida en el copybook SDMPOSTW).

Antes de llamar a SDMVALSA, el programa prepara los campos de entrada del área AREA-POSTEO de la siguiente manera:

- **POS-EMPRESA:** valor literal 1 (empresa por defecto).
- **POS-CUENTA:** valor de CHQV-CUENTA.
- **POS-PRODUCTO:** valor de SDC-MAE-CTA-PRODUCTO (producto de la cuenta, obtenido previamente de SDCMAEST en la validación de cuenta).
- **POS-MONEDA:** valor de SDC-MAE-CTA-MONEDA (moneda de la cuenta, obtenida previamente de SDCMAEST).
- **POS-SIGNO:** valor literal 'D' (cargo, es decir, débito a la cuenta). La condición de nivel 88 POS-CARGO queda activa con este valor.
- **POS-IMPORTE:** valor de CHQV-IMPORTE.
- **POS-FECHA-PROCESO:** valor de CHQV-FEC-PRESENT (fecha de presentación del cheque).
- **POS-FECHA-VALOR:** valor de CHQV-FEC-PRESENT (misma fecha de presentación).
- **POS-CANAL:** valor de SDU-CAN-BATCH (canal de proceso por lotes, valor literal 'BA').

Nótese que los campos POS-TIPO-OPERACION, POS-SUCURSAL, POS-TERMINAL, POS-USUARIO, POS-SUPERVISOR, POS-GLOSA, POS-REFERENCIA, POS-DOC-TIPO, POS-DOC-NUMERO, POS-LOTE, POS-BATCH-ID, POS-IND-FORZAR, POS-IND-EXONERA-ITF y POS-IND-SOLO-VALIDA del área AREA-POSTEO no son inicializados explícitamente por CHQVALCH antes de la llamada; quedan con los valores que tuvieran en memoria.

Tras llamar a SDMVALSA, se evalúa POS-COD-RETORNO:

- **Si POS-COD-RETORNO es distinto de 0000** (hay algún error o condición especial):
  - Si la condición POS-SALDO-INSUF es verdadera (POS-COD-RETORNO igual a 0040): SDMVALSA ya determinó que el saldo es insuficiente. Se asigna cero a CHQV-SALDO-DISP, se asigna '01' a CHQV-COD-MOTIVO, se asigna el mensaje 'SIN FONDOS SUFICIENTES' a CHQV-MENSAJE y se ejecuta 9000-MARCA-RECHAZO, que establece SW-RECHAZO en 'S' y CHQV-COD-RETORNO en CHQ-RC-RECHAZABLE (0100).
  - En cualquier otro caso (error de sistema u otra condición no esperada): se asigna CHQ-RC-ERROR-DB2 (0900) a CHQV-COD-RETORNO y se copia POS-MENSAJE a CHQV-MENSAJE. No se ejecuta 9000-MARCA-RECHAZO ni se activa SW-RECHAZO, pero el código 0900 en CHQV-COD-RETORNO será detectado por el llamador.
  - En ambos subcasos se sale del párrafo sin continuar con los cálculos siguientes (salto a 7000-EXIT).

- **Si POS-COD-RETORNO es 0000** (SDMVALSA ejecutó correctamente):
  1. Se copia POS-SALDO-DISPONIBLE a CHQV-SALDO-DISP. Este saldo ya viene neto de retenciones e intangible, calculado internamente por SDMVALSA.
  2. Se calcula el ITF estimado aplicando la tasa SDU-TASA-ITF (valor fijo +0.000050, es decir 0.005‰ del importe) sobre el importe del cheque, con redondeo al centavo más cercano (cláusula ROUNDED, equivalente a redondeo half-up): **WS-ITF-ESTIMADO = CHQV-IMPORTE × SDU-TASA-ITF**.
  3. Se calcula el monto total requerido sin redondeo: **WS-REQUERIDO = CHQV-IMPORTE + WS-ITF-ESTIMADO**.
  4. Se compara CHQV-SALDO-DISP con WS-REQUERIDO:
     - Si CHQV-SALDO-DISP es **menor** que WS-REQUERIDO: saldo insuficiente. Se asigna '01' a CHQV-COD-MOTIVO, se asigna 'SIN FONDOS SUFICIENTES' a CHQV-MENSAJE y se ejecuta 9000-MARCA-RECHAZO (SW-RECHAZO queda en 'S' y CHQV-COD-RETORNO en 0100).
     - Si CHQV-SALDO-DISP es **mayor o igual** a WS-REQUERIDO: el cheque es pagadero. Se asigna el mensaje 'CHEQUE PAGADERO' a CHQV-MENSAJE. No se asigna ningún motivo de rechazo y el indicador SW-RECHAZO permanece en 'N'. CHQV-COD-RETORNO mantiene el valor CHQ-RC-OK (0000) establecido en la inicialización.

El comentario del propio código advierte que SDMVALSA no es la autoridad final en el posteo real: si el proceso posterior de posteo (SDMPOSTA, llamado por CHQCAMAR) detecta saldo insuficiente al momento de debitar, también se rechazará con motivo '01'. La validación de fondos en CHQVALCH es preliminar.

**Estado de la regla:** Relevante para la Modernización

**Algoritmo**

1. Registrar '7000-VALIDAR-FONDOS' en WS-PARRAFO-ACT.
2. Preparar el área AREA-POSTEO para llamar a SDMVALSA:
   - Asignar 1 a POS-EMPRESA.
   - Copiar CHQV-CUENTA a POS-CUENTA.
   - Copiar SDC-MAE-CTA-PRODUCTO a POS-PRODUCTO (valor obtenido de SDCMAEST en el paso 2000-VALIDAR-CUENTA).
   - Copiar SDC-MAE-CTA-MONEDA a POS-MONEDA (valor obtenido de SDCMAEST en el paso 2000-VALIDAR-CUENTA).
   - Asignar 'D' a POS-SIGNO (cargo/débito).
   - Copiar CHQV-IMPORTE a POS-IMPORTE.
   - Copiar CHQV-FEC-PRESENT a POS-FECHA-PROCESO.
   - Copiar CHQV-FEC-PRESENT a POS-FECHA-VALOR.
   - Copiar SDU-CAN-BATCH (valor 'BA') a POS-CANAL.
3. Llamar a SDMVALSA pasando AREA-POSTEO.
4. Evaluar POS-COD-RETORNO:
   - Si es **distinto de 0000**:
     - Si POS-SALDO-INSUF es verdadero (POS-COD-RETORNO igual a 0040):
       - Asignar cero a CHQV-SALDO-DISP.
       - Asignar '01' a CHQV-COD-MOTIVO.
       - Asignar 'SIN FONDOS SUFICIENTES' a CHQV-MENSAJE.
       - Ejecutar 9000-MARCA-RECHAZO (establece SW-RECHAZO en 'S' y CHQV-COD-RETORNO en CHQ-RC-RECHAZABLE 0100).
     - En cualquier otro caso (error u otra condición):
       - Asignar CHQ-RC-ERROR-DB2 (0900) a CHQV-COD-RETORNO.
       - Copiar POS-MENSAJE a CHQV-MENSAJE.
       - No se ejecuta 9000-MARCA-RECHAZO ni se modifica SW-RECHAZO.
     - En ambos subcasos, salir del párrafo (salto a 7000-EXIT) sin ejecutar los pasos siguientes.
   - Si es **igual a 0000**:
     - a. Copiar POS-SALDO-DISPONIBLE a CHQV-SALDO-DISP.
     - b. Calcular WS-ITF-ESTIMADO = CHQV-IMPORTE × SDU-TASA-ITF (+0.000050), con redondeo half-up al centavo (cláusula ROUNDED).
     - c. Calcular WS-REQUERIDO = CHQV-IMPORTE + WS-ITF-ESTIMADO (sin redondeo adicional).
     - d. Si CHQV-SALDO-DISP es **menor** que WS-REQUERIDO:
       - Asignar '01' a CHQV-COD-MOTIVO.
       - Asignar 'SIN FONDOS SUFICIENTES' a CHQV-MENSAJE.
       - Ejecutar 9000-MARCA-RECHAZO (establece SW-RECHAZO en 'S' y CHQV-COD-RETORNO en CHQ-RC-RECHAZABLE 0100).
     - e. Si CHQV-SALDO-DISP es **mayor o igual** a WS-REQUERIDO:
       - Asignar 'CHEQUE PAGADERO' a CHQV-MENSAJE.
       - No se asigna motivo de rechazo; SW-RECHAZO permanece en 'N' y CHQV-COD-RETORNO permanece en CHQ-RC-OK (0000).
<!-- rule-end -->

<!-- rule-start -->
### 9. Regla / Operacion - 9000-MARCA-RECHAZO (Activacion del indicador de rechazo)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para la Modernizacion

**Algoritmo**

1. Asignar el valor 'S' al indicador interno SW-RECHAZO. Esto activa la condición HAY-RECHAZO, que el flujo principal evalúa después de cada validación para decidir si continúa o se detiene.
2. Asignar el código de retorno 0100 (CHQ-RC-RECHAZABLE) al campo de salida CHQV-COD-RETORNO. Este código indica al llamador que el cheque fue evaluado correctamente pero debe ser rechazado por el motivo indicado en CHQV-COD-MOTIVO.

**Contexto de uso**

Este párrafo es invocado exclusivamente cuando una validación individual detecta un motivo de rechazo concreto. En ese momento, el párrafo que detectó el rechazo ya habrá colocado previamente en CHQV-COD-MOTIVO el código de motivo correspondiente (según la tabla de la Cámara de Compensación) y en CHQV-MENSAJE el texto descriptivo. Los valores de motivo posibles que pueden preceder a esta activación son los siguientes, en el orden en que las validaciones los pueden generar:

- **'10'** – Cuenta inexistente (la cuenta no fue encontrada en el maestro).
- **'03'** – Cuenta cerrada (estado 'CE' en el maestro).
- **'04'** – Cuenta bloqueada o no operativa (estados 'BL', 'BJ', 'IN', 'CA' o 'AP' en el maestro).
- **'07'** – Cheque no emitido por el banco (no existe registro en la tabla CHQ_CHEQUE) o cheque anulado (estado 'AN' en CHQ_CHEQUE).
- **'05'** – Orden de no pago vigente (estado 'NP' en CHQ_CHEQUE).
- **'09'** – Cheque ya pagado (estado 'PA' en CHQ_CHEQUE).
- **'06'** – Cheque presentado fuera de plazo (días transcurridos desde la fecha de giro superan el plazo aplicable de 30 días para misma plaza o 60 días para otra plaza, o superan los 180 días de caducidad) o fecha de giro o de presentación inválida.
- **'08'** – Defecto formal: importe igual a cero, moneda del cheque distinta a la moneda de la cuenta, o indicador de enmendadura activo ('S' en CHQV-IND-DEFECTO).
- **'02'** – Firma disconforme (indicador CHQV-IND-FIRMA con valor 'N').
- **'01'** – Sin fondos suficientes (el saldo disponible devuelto por SDMVALSA es insuficiente, o el saldo disponible neto es menor que el importe del cheque más el ITF estimado calculado como CHQV-IMPORTE multiplicado por SDU-TASA-ITF con redondeo).

Este párrafo no establece ni modifica CHQV-COD-MOTIVO ni CHQV-MENSAJE; esos campos son responsabilidad exclusiva del párrafo de validación que realiza la llamada. Tampoco interrumpe el flujo por sí mismo: es el párrafo principal (0000-PRINCIPAL) quien, tras cada validación, evalúa la condición HAY-RECHAZO y decide si transfiere el control a 0000-SALIR o continúa con la siguiente validación.
<!-- rule-end -->

<!-- rule-start -->
### 10. Regla / Operacion - 9900-REGISTRA-ERROR (Registro de errores de sistema en la bitacora)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Relevante para la Modernizacion

**Algoritmo**

1. Asignar el nivel 'E' (error) al campo SDU-LG-NIVEL del area de log.
2. Copiar WS-NOM-PROGRAMA (valor fijo 'CHQVALCH') a SDU-LG-PROGRAMA.
3. Copiar WS-PARRAFO-ACT (nombre del parrafo activo en el momento del error, de hasta 20 caracteres) a SDU-LG-PARRAFO.
4. Asignar el codigo de error fijo 'E0100' a SDU-LG-COD-ERROR.
5. Copiar CHQV-MENSAJE (el mensaje de error ya preparado por el parrafo que invoco a este) a SDU-LG-GLOSA.
6. Copiar CHQV-CUENTA al campo SDU-LG-CUENTA.
7. Asignar espacios a SDU-LG-DOI (no aplica en este contexto).
8. Copiar CHQV-IMPORTE a SDU-LG-IMPORTE.
9. Asignar el literal fijo 'BATCH' a SDU-LG-USUARIO.
10. Copiar WS-NOM-PROGRAMA (valor fijo 'CHQVALCH') a SDU-LG-TERMINAL. El programa se identifica a si mismo como terminal, dado que la ejecucion es en modo batch.
11. Copiar el valor de la constante SDU-CAN-BATCH (valor fijo 'BA') a SDU-LG-CANAL.
12. Copiar CHQV-FEC-PRESENT (fecha de presentacion del cheque) a SDU-LG-FECHA.
13. Copiar el valor actual de SQLCODE a SDU-LG-SQLCODE.
14. Llamar al programa SDULOGER pasando SDU-AREA-LOG como unico parametro. SDULOGER escribe el registro en el archivo VSAM LOGSIDEP. Si el VSAM no esta disponible, SDULOGER se degrada silenciosamente a escritura por DISPLAY sin notificar al llamador, por lo que CHQVALCH no recibe ninguna indicacion de que el registro de error no pudo grabarse fisicamente.

> **Nota de alcance:** Este parrafo unicamente es invocado desde el parrafo 3000-VALIDAR-ESTADO-CHEQUE, especificamente ante un error de base de datos DB2 distinto de SQLCODE 0 y SQLCODE +100 al leer la tabla CHQ_CHEQUE. Los rechazos de negocio normales (motivos 01 al 10) no invocan este parrafo; utilizan en su lugar el parrafo 9000-MARCA-RECHAZO, que no genera entrada en la bitacora.
<!-- rule-end -->

<!-- rule-start -->
### 11. Regla / Operacion - Codigo comentado: 8000-VALIDAR-CERTIFICADO (Validacion de cheques certificados - inactiva)
<!-- reviewed -->

_Reviewed_

**Estado de la regla:** Irrelevante para la Modernización (código inactivo; se documenta únicamente para dejar constancia de su existencia y de que el producto asociado fue discontinuado)

El código fuente contiene un bloque completamente comentado que corresponde a la validación de cheques certificados. El bloque lleva el nombre `8000-VALIDAR-CERTIFICADO`. Al estar comentado mediante asteriscos en la columna 7 de cada línea, este bloque no es compilado ni ejecutado bajo ninguna circunstancia; no forma parte del comportamiento actual del programa.

El comentario estructurado que precede al bloque indica explícitamente que el producto de cheque certificado fue retirado del catálogo en el año 2009, pero que la Cámara de Compensación todavía puede enviar el indicador correspondiente en el campo `CHQV-IND-DEFECTO` con el valor `'C'`. El código comentado, de haberse ejecutado, habría asignado el valor cero al campo de salida `CHQV-SALDO-DISP` cuando ese indicador era igual a `'C'`, sin generar ningún rechazo, sin asignar código de motivo y sin emitir mensaje alguno.

Adicionalmente, el bloque comentado nunca fue conectado al flujo principal del programa: en el párrafo `0000-PRINCIPAL` no existe ningún `PERFORM` que invoque a `8000-VALIDAR-CERTIFICADO`, por lo que, incluso si el código fuera descomentado tal cual, no sería alcanzable desde la cadena de ejecución.

El programa actual no tiene ninguna lógica alternativa para el valor `'C'` del indicador `CHQV-IND-DEFECTO`. El párrafo `5000-VALIDAR-FORMALES` únicamente reacciona ante el valor `'S'` de ese campo (indicador de enmendadura o defecto formal activo) asignando el motivo de rechazo `'08'`. Si `CHQV-IND-DEFECTO` llega con el valor `'C'`, la condición `IF CHQV-IND-DEFECTO = 'S'` no se cumple, el párrafo `5000-VALIDAR-FORMALES` no activa ningún rechazo por ese motivo, y el cheque continúa siendo evaluado con normalidad por el resto de la cadena de validaciones (firma y fondos).

**Algoritmo**

No aplica. El bloque no se ejecuta y tampoco está conectado al flujo principal. La modernización no debe reproducir esta lógica.
<!-- rule-end -->

---

## Extraction metadata

- **Main file:** cobol/CHQVALCH.cbl
- **Created:** 2026-11-08 15:59:28 UTC
- **Started:** 2026-11-08 16:00:37 UTC
- **Duration:** 00:28:16
- **LLM:** us.anthropic.claude-sonnet-4-6 (us.anthropic.claude-sonnet-4-6)
- **Context window:** 200000 tokens · **Max output:** 64000 tokens
- **Extraction prompt:** business_rules_extraction_cobol · **Reviewer prompt:** business_rules_reviewer_cobol
- **Token usage:** 723612 total (683506 input, 40106 output)

### Reference files (11)
Intended for the extraction; any excluded below were not submitted:
- cobol/SDCMAEST.cbl
- cobol/SDMVALSA.cbl
- cobol/SDUFECHA.cbl
- cobol/SDULOGER.cbl
- copybook/CHQCONW.cpy
- copybook/CHQVALCW.cpy
- copybook/SDCMAEW.cpy
- copybook/SDMPOSTW.cpy
- copybook/SDUCONST.cpy
- copybook/SDUFECHW.cpy
- copybook/SDULOGW.cpy
