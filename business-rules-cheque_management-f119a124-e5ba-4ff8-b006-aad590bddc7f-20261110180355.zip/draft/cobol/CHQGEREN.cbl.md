# CHQGEREN.cbl: Gestion de Cheques de Gerencia - Emision, Anulacion, Pago y Consulta

## Overview

CHQGEREN es una subrutina del sistema SIDEP (Sistema Integrado de Depositos) del Banco Andes del Peru, perteneciente al modulo de Cheques y Compensacion (CHQ). Es invocada directamente por las transacciones de ventanilla y por el canal web empresas; no se ejecuta de forma autonoma ni por procesos batch.

Su proposito central es gestionar el ciclo de vida completo de un cheque de gerencia: permite emitirlo con cargo a la cuenta del solicitante, anularlo con devolucion parcial o total de fondos, marcarlo como pagado cuando es presentado en camara o ventanilla, y consultar su estado actual. Toda la informacion de los cheques de gerencia se almacena y se consulta en la tabla DB2 CHQ_GERENCIA.

El programa aplica reglas de negocio propias del producto: calcula y cobra una comision mas el Impuesto General a las Ventas (IGV) sobre dicha comision al momento de la emision, controla topes maximos de importe por moneda como medida de prevencion de lavado de activos, y respeta el plazo de vigencia de 180 dias calendario. Para ejecutar los movimientos contables sobre la cuenta del cliente delega en el motor de posteo SDMPOSTA, y para validar la disponibilidad de saldo antes del cargo utiliza SDMVALSA. La lectura y validacion de la cuenta maestra se realiza a traves de SDCMAEST. El calculo de fechas (en particular la fecha de vencimiento del cheque) se delega en SDUFECHA. Al completar una emision exitosa, encola una notificacion al cliente mediante NTFENCOL. Los errores graves se registran en la bitacora centralizada SDULOGER.

## Process Flow

```mermaid
flowchart TD
    A("Inicio: llamada externa<br/>(ventanilla o web empresas)")
    B[/"Recibir parametros:<br/>funcion, cuenta, importe,<br/>moneda, beneficiario, usuario"/]
    C["Inicializar: codigo retorno OK,<br/>copiar datos de entrada,<br/>convertir fecha a formato ISO"]
    D{"Funcion<br/>solicitada"}

    EM["EMISION (EM)"]
    EM1{"Importe > 0 y<br/>beneficiario informado?"}
    EM2{"Importe dentro<br/>del tope por moneda?"}
    EM3{"Moneda es<br/>Soles o Dolares?"}
    EM4["Leer y validar cuenta<br/>(SDCMAEST):<br/>existe, activa, misma moneda"]
    EM5["Calcular comision e IGV<br/>(RN-CHQ-40)"]
    EM6["Verificar saldo disponible<br/>(SDMVALSA + ITF estimado)"]
    EM7["Obtener numero de cheque<br/>(MAX en CHQ_GERENCIA + 1)"]
    EM8["Cargar cuenta:<br/>debito importe (op.020)<br/>debito comision+IGV (op.060)"]
    EM8R["Reverso del importe<br/>si falla cargo comision"]
    EM9["Registrar cheque en DB2<br/>CHQ_GERENCIA estado='VI'<br/>vencimiento = hoy + 180 dias"]
    EM10["Encolar notificacion<br/>al cliente (NTFENCOL)"]

    AN["ANULACION (AN)"]
    AN1["Leer cheque de CHQ_GERENCIA"]
    AN2{"Estado = 'VI'<br/>(Vigente)?"}
    AN3{"Cuenta coincide<br/>con la del solicitante?"}
    AN4["Leer y validar cuenta<br/>de abono (SDCMAEST)"]
    AN5{"Fecha anulacion =<br/>fecha emision?"}
    AN6["Calcular importe a devolver:<br/>siempre el importe;<br/>+ comision + IGV si mismo dia"]
    AN7["Abonar importe a la cuenta<br/>(SDMPOSTA)"]
    AN8["Actualizar CHQ_GERENCIA<br/>estado='AN'"]

    PG["PAGO (PG)"]
    PG1["Leer cheque de CHQ_GERENCIA"]
    PG2{"Estado = 'VI'<br/>(Vigente)?"}
    PG3{"Fecha proceso<br/>dentro del vencimiento?"}
    PG4["Actualizar CHQ_GERENCIA<br/>estado='PA'"]

    CO["CONSULTA (CO)"]
    CO1["Leer cheque de CHQ_GERENCIA"]
    CO2["Devolver estado, importe,<br/>moneda, beneficiario,<br/>comision e IGV"]

    ERR["Retornar error:<br/>funcion no soportada"]
    Z("Fin: retornar resultado al llamador")

    A --> B --> C --> D

    D -->|"EM"| EM
    D -->|"AN"| AN
    D -->|"PG"| PG
    D -->|"CO"| CO
    D -->|"Otra"| ERR

    EM --> EM1
    EM1 -->|"No"| Z
    EM1 -->|"Si"| EM2
    EM2 -->|"No - excede tope"| Z
    EM2 -->|"Si"| EM3
    EM3 -->|"No"| Z
    EM3 -->|"Si"| EM4
    EM4 -->|"Error"| Z
    EM4 -->|"OK"| EM5
    EM5 --> EM6
    EM6 -->|"Saldo insuficiente"| Z
    EM6 -->|"OK"| EM7
    EM7 -->|"Error DB2"| Z
    EM7 -->|"OK"| EM8
    EM8 -->|"Falla cargo comision"| EM8R
    EM8R --> Z
    EM8 -->|"OK"| EM9
    EM9 -->|"OK"| EM10
    EM10 --> Z
    EM9 -->|"Error DB2"| Z

    AN --> AN1
    AN1 -->|"No encontrado o error"| Z
    AN1 -->|"OK"| AN2
    AN2 -->|"No"| Z
    AN2 -->|"Si"| AN3
    AN3 -->|"No"| Z
    AN3 -->|"Si"| AN4
    AN4 -->|"Error"| Z
    AN4 -->|"OK"| AN5
    AN5 -->|"Mismo dia"| AN6
    AN5 -->|"Distinto dia"| AN6
    AN6 --> AN7
    AN7 -->|"Error posteo"| Z
    AN7 -->|"OK"| AN8
    AN8 --> Z

    PG --> PG1
    PG1 -->|"No encontrado o error"| Z
    PG1 -->|"OK"| PG2
    PG2 -->|"No"| Z
    PG2 -->|"Si"| PG3
    PG3 -->|"Vencido"| Z
    PG3 -->|"Vigente"| PG4
    PG4 --> Z

    CO --> CO1
    CO1 --> CO2
    CO2 --> Z

    ERR --> Z
```

<!-- general-rule-start -->

## General Business Rules:

### Tipo de programa y forma de invocacion

CHQGEREN es una subrutina CICS (en linea), lo que significa que se ejecuta dentro de una transaccion interactiva iniciada por un cajero de ventanilla o por el canal web empresas. No tiene acceso a archivos de parametros (PARM/CHQPARM) porque ese mecanismo es exclusivo de los programas batch; por ello todas sus constantes operativas estan incorporadas directamente en el codigo. El llamador le pasa un unico bloque de datos definido en el copybook CHQGERCW, que contiene tanto los datos de entrada como los campos de salida donde el programa deposita sus resultados.

El campo de entrada CHQG-FUNCION determina cual de las cuatro operaciones se ejecuta:

- `EM`: Emision de un cheque de gerencia nuevo.
- `AN`: Anulacion de un cheque vigente.
- `PG`: Registro del pago de un cheque (lo marca como cobrado).
- `CO`: Consulta del estado y datos de un cheque existente.

Si se recibe cualquier otro valor en CHQG-FUNCION, el programa devuelve el codigo de error CHQ-RC-DATO-INVALIDO (0200) con el mensaje "FUNCION NO SOPORTADA POR CHQGEREN".

---

### Inicializacion comun a todas las operaciones

Antes de ejecutar cualquier funcion, el programa realiza los siguientes pasos:

1. Establece el codigo de retorno en CHQ-RC-OK (0000) y limpia el campo de mensaje.
2. Copia la cuenta del solicitante (CHQG-CUENTA) y el usuario (CHQG-USUARIO) a las variables internas de trabajo.
3. Toma la fecha de proceso recibida (CHQG-FEC-PROCESO, formato AAAAMMDD) y la convierte al formato ISO con separadores (AAAA-MM-DD) para usarla como fecha de emision al registrar o leer en la base de datos.

---

### Funcion EM: Emision de un cheque de gerencia

#### Validaciones previas

Se rechazan las solicitudes que no cumplan cualquiera de las siguientes condiciones:

- El importe (CHQG-IMPORTE) debe ser mayor que cero y el nombre del beneficiario (CHQG-BENEFICIARIO) no puede estar en blanco. Si alguna de estas condiciones falla, se devuelve CHQ-RC-DATO-INVALIDO con el mensaje "IMPORTE O BENEFICIARIO INVALIDO".
- El importe no puede superar los topes maximos por moneda definidos como regla de negocio RN-CHQ-41: 500,000.00 soles (PEN) o 150,000.00 dolares (USD). Si se supera, se devuelve CHQ-RC-DATO-INVALIDO con el mensaje "IMPORTE EXCEDE TOPE DE CHEQUE DE GERENCIA".
- La moneda (CHQG-MONEDA) debe ser exactamente '604' (soles) o '840' (dolares). Cualquier otra moneda genera CHQ-RC-DATO-INVALIDO con el mensaje "MONEDA NO PERMITIDA".

#### Lectura y validacion de la cuenta de cargo

Se llama a SDCMAEST con funcion 'LE' (leer) para obtener los datos de la cuenta indicada en CHQG-CUENTA. Se verifican tres condiciones en este orden:

1. La cuenta debe existir en la tabla CUENTA_MAESTRO. Si no existe, se devuelve CHQ-RC-NO-ENCONTRADO (0300) con el mensaje "CUENTA DE CARGO NO EXISTE".
2. El estado de la cuenta debe ser 'AC' (activa, valor SDU-EST-ACTIVA). Si no lo es, se devuelve CHQ-RC-ESTADO-INVALIDO (0400) con el mensaje "CUENTA DE CARGO NO ESTA ACTIVA".
3. La moneda de la cuenta debe coincidir con la moneda del cheque solicitado. Si difieren, se devuelve CHQ-RC-DATO-INVALIDO con el mensaje "MONEDA DEL CHEQUE DISTINTA A LA CUENTA".

#### Calculo de comision e IGV (RN-CHQ-40)

La comision se calcula como el 0.25% del importe del cheque (multiplicando el importe por 0.0025), con redondeo aritmetico convencional (half-up) a dos decimales. A continuacion se aplica un minimo segun la moneda:

- En soles: si la comision calculada es inferior a 15.00 PEN, se usa 15.00 PEN como comision.
- En dolares: si la comision calculada es inferior a 5.00 USD, se usa 5.00 USD como comision.

Sobre la comision resultante se calcula el IGV: se multiplica la comision por 0.18 (18%), con redondeo half-up a dos decimales.

El total a cargar a la cuenta es la suma del importe del cheque, la comision y el IGV. Los tres valores (comision, IGV y total) se devuelven al llamador en los campos de salida CHQG-COMISION, CHQG-IGV y CHQG-TOTAL-CARGO.

#### Verificacion de saldo disponible

Se llama a SDMVALSA para confirmar que la cuenta tiene fondos suficientes para cubrir el total (importe + comision + IGV). Si SDMVALSA devuelve codigo de saldo insuficiente (POS-SALDO-INSUF, codigo 0040), se devuelve CHQ-RC-SALDO-INSUF (0500) con el mensaje "SALDO DISPONIBLE INSUFICIENTE". Si devuelve cualquier otro error, se devuelve CHQ-RC-ERROR-POSTEO (0800) con el mensaje de SDMVALSA.

Adicionalmente, si SDMVALSA responde sin error, se estima el Impuesto a las Transacciones Financieras (ITF) que SDMPOSTA calculara internamente. El ITF estimado se obtiene multiplicando el importe del cheque (sin incluir la comision) por la tasa SDU-TASA-ITF (0.000050, es decir 0.005%). Se suma este ITF estimado al total ya calculado para obtener el monto requerido total. Si el saldo disponible devuelto por SDMVALSA es menor que este monto requerido, se devuelve igualmente CHQ-RC-SALDO-INSUF.

#### Obtencion del numero de cheque

Se consulta la tabla DB2 CHQ_GERENCIA para obtener el valor maximo actual del campo NUM_CHEQUE_GER. Si la tabla esta vacia, se usa como base el valor 1,000,000,000. El numero del nuevo cheque es el maximo encontrado mas uno. Este numero se devuelve al llamador en CHQG-NUM-CHEQUE-GER.

#### Cargo en la cuenta del solicitante

Se realizan dos movimientos de debito separados en la cuenta, llamando en cada caso al motor de posteo SDMPOSTA a traves del procedimiento interno 8200-LLAMA-POSTEO:

1. Primer movimiento: debito por el importe del cheque, con tipo de operacion SDU-OP-RETIRO (codigo '020') y glosa "CHEQUE GERENCIA NRO " seguida del numero del cheque. Este movimiento permite que contabilidad identifique el importe neto del cheque.
2. Segundo movimiento: debito por la suma de comision mas IGV, con tipo de operacion SDU-OP-COBRO-COMISION (codigo '060') y glosa "COMISION CHEQUE GERENCIA " seguida del numero del cheque. Este movimiento permite que contabilidad identifique por separado el cobro de comision.

Si el primer movimiento falla, se devuelve CHQ-RC-ERROR-POSTEO y se abandona la operacion. Si el segundo movimiento (comision) falla despues de que el primero ya se ejecuto exitosamente, se realiza automaticamente un reverso del primer cargo: se envia un abono forzado (indicador POS-IND-FORZAR = 'S') por el mismo importe del cheque, con tipo de operacion SDU-OP-REVERSO (codigo '099') y signo 'H' (haber), para compensar el cargo ya aplicado. En ambos casos de fallo se devuelve CHQ-RC-ERROR-POSTEO.

Todos los movimientos de posteo se configuran con los siguientes atributos comunes: empresa 1, canal SDU-CAN-VENTANILLA ('VE'), sin sucursal, nombre del programa como terminal, usuario del llamador, tipo de documento 'CG', numero de documento igual al numero del cheque, sin exoneracion de ITF, sin indicador de solo-validar.

#### Registro del cheque en la base de datos

Se calcula la fecha de vencimiento sumando 180 dias calendario (CHQ-DIAS-VIG-GERENCIA) a la fecha de proceso, utilizando la funcion 'SUMADIAS' de SDUFECHA. La fecha resultante se convierte al formato ISO (AAAA-MM-DD) para almacenarla en la base de datos.

Se inserta un registro en la tabla CHQ_GERENCIA con los siguientes valores:

| Campo | Valor |
|---|---|
| NUM_CHEQUE_GER | Numero obtenido en el paso anterior |
| CTA_CARGO | Numero de cuenta del solicitante |
| MON_IMPORTE | Importe del cheque |
| COD_MONEDA | Moneda ('604' o '840') |
| BENEFICIARIO | Nombre del beneficiario |
| MON_COMISION | Comision calculada |
| MON_IGV | IGV calculado |
| FEC_EMISION | Fecha de proceso en formato ISO |
| FEC_VENCIM | Fecha de proceso mas 180 dias en formato ISO |
| EST_GERENCIA | 'VI' (Vigente) |
| COD_USUARIO | Usuario del llamador |

Si la insercion falla, se devuelve CHQ-RC-ERROR-DB2 (0900) y se registra el error en SDULOGER. Si la insercion es exitosa, se devuelve el estado 'VI' en CHQG-ESTADO y el mensaje "CHEQUE DE GERENCIA EMITIDO".

#### Notificacion al cliente

Si el registro fue exitoso, se encola una notificacion al cliente llamando a NTFENCOL con los siguientes parametros: funcion 'EN' (encolar), canal 'EM' (correo electronico), plantilla 'CHQ004', codigo unico del titular de la cuenta (obtenido de SDCMAEST), y como parametros de la plantilla el numero del cheque y la moneda separados por el caracter '|'. La prioridad de la notificacion se establece en 4 (baja).

---

### Funcion AN: Anulacion de un cheque de gerencia

#### Lectura y validaciones del cheque

Se lee el registro de CHQ_GERENCIA por el numero de cheque informado en CHQG-NUM-CHEQUE-GER. Se verifican las siguientes condiciones:

- El cheque debe existir. Si no existe (SQLCODE +100), se devuelve CHQ-RC-NO-ENCONTRADO con el mensaje "CHEQUE DE GERENCIA NO EXISTE".
- El estado del cheque (EST_GERENCIA) debe ser 'VI' (Vigente). Si no lo es, se devuelve CHQ-RC-ESTADO-INVALIDO con el mensaje "CHEQUE DE GERENCIA NO ESTA VIGENTE".
- La cuenta de cargo almacenada en el cheque (CTA_CARGO) debe coincidir exactamente con la cuenta informada por el llamador (CHQG-CUENTA). Si no coinciden, se devuelve CHQ-RC-DATO-INVALIDO con el mensaje "CUENTA NO ES LA DEL SOLICITANTE".

#### Validacion de la cuenta de abono

Se llama a SDCMAEST con funcion 'LE' para verificar que la cuenta de destino del abono existe y no esta cerrada. Si SDCMAEST devuelve error o el estado es 'CE' (cerrada, valor SDU-EST-CERRADA), se devuelve CHQ-RC-ESTADO-INVALIDO con el mensaje "CUENTA DE ABONO NO OPERATIVA".

#### Calculo del importe a devolver (RN-CHQ-43)

El importe del cheque (MON_IMPORTE del registro leido) se devuelve siempre. La devolucion de la comision e IGV depende de si la anulacion ocurre el mismo dia de la emision:

- Si la fecha de proceso actual (en formato ISO, AAAA-MM-DD) es igual a la fecha de emision original almacenada en CHQ_GERENCIA (FEC_EMISION), el importe a abonar es: importe del cheque + comision original + IGV original.
- Si la fecha de proceso es distinta a la fecha de emision, el importe a abonar es unicamente el importe del cheque. La comision y el IGV no se devuelven.
- El ITF cobrado en la emision nunca se devuelve, por disposicion legal.

#### Abono a la cuenta y actualizacion del estado

Se llama a SDMPOSTA para abonar el importe calculado a la cuenta, con signo 'H' (haber), tipo de operacion SDU-OP-DEPOSITO (codigo '010'), y glosa "ANULA CHEQUE GERENCIA " seguida del numero del cheque. El indicador de forzar se establece en 'N' (no forzado).

Si el posteo falla, se devuelve CHQ-RC-ERROR-POSTEO con el mensaje de SDMPOSTA y no se actualiza la base de datos.

Si el posteo es exitoso, se actualiza el registro en CHQ_GERENCIA: se cambia EST_GERENCIA a 'AN' (Anulado) y se registra la fecha del estado (FEC_ESTADO) con la fecha de proceso actual en formato ISO. Si la actualizacion en DB2 falla, se devuelve CHQ-RC-ERROR-DB2 y se registra el error. Si es exitosa, se devuelve el estado 'AN' en CHQG-ESTADO, el importe total devuelto en CHQG-TOTAL-CARGO y el mensaje "CHEQUE DE GERENCIA ANULADO".

---

### Funcion PG: Pago del cheque (RN-CHQ-42)

Esta funcion es utilizada por la camara de compensacion o por ventanilla para registrar que un cheque de gerencia fue efectivamente cobrado por el beneficiario.

Se lee el registro de CHQ_GERENCIA por el numero de cheque. Se verifican dos condiciones:

- El estado debe ser 'VI' (Vigente). Si no lo es, se devuelve CHQ-RC-ESTADO-INVALIDO con el mensaje "CHEQUE DE GERENCIA NO ESTA VIGENTE".
- La fecha de vencimiento (FEC_VENCIM) no debe ser anterior a la fecha de emision almacenada en el registro (nota: el codigo compara FEC_EMISION contra FEC_VENCIM; si FEC_EMISION es mayor que FEC_VENCIM, el cheque se considera vencido). Si el cheque ha vencido, se devuelve CHQ-RC-ESTADO-INVALIDO con el mensaje "CHEQUE DE GERENCIA VENCIDO".

Si ambas validaciones son superadas, se actualiza CHQ_GERENCIA: EST_GERENCIA pasa a 'PA' (Pagado) y FEC_ESTADO se registra con la fecha de proceso en formato ISO. Si la actualizacion falla en DB2, se devuelve CHQ-RC-ERROR-DB2. Si es exitosa, se devuelve el estado 'PA' en CHQG-ESTADO y el mensaje "CHEQUE DE GERENCIA PAGADO". Esta funcion no genera ningun movimiento contable; unicamente actualiza el estado del cheque.

---

### Funcion CO: Consulta del estado de un cheque

Se lee el registro de CHQ_GERENCIA por el numero de cheque informado. Si la lectura es exitosa, se devuelven al llamador los siguientes campos: estado actual (CHQG-ESTADO), importe (CHQG-IMPORTE), moneda (CHQG-MONEDA), nombre del beneficiario (CHQG-BENEFICIARIO), comision cobrada (CHQG-COMISION) e IGV cobrado (CHQG-IGV). Si el cheque no existe, se devuelve CHQ-RC-NO-ENCONTRADO.

---

### Registro de errores

Cualquier error de base de datos DB2 (SQLCODE distinto de 0 o +100) es registrado en la bitacora centralizada SDULOGER mediante el procedimiento 9900-REGISTRA-ERROR. El registro incluye: nivel 'E' (error), nombre del programa 'CHQGEREN', nombre del procedimiento donde ocurrio el error, codigo de error 'E0300', el mensaje descriptivo, la cuenta del solicitante, el importe, el usuario, el canal (ventanilla) y el SQLCODE de DB2.

---

### Constantes de negocio incorporadas en el programa

Las siguientes constantes no se leen de parametros externos sino que estan fijas en el codigo fuente:

| Constante | Valor | Descripcion |
|---|---|---|
| Porcentaje de comision | 0.0025 (0.25%) | Se aplica sobre el importe del cheque |
| Minimo de comision en soles | 15.00 PEN | Si el 0.25% resulta menor, se usa este valor |
| Minimo de comision en dolares | 5.00 USD | Si el 0.25% resulta menor, se usa este valor |
| Tasa de IGV | 0.18 (18%) | Se aplica sobre la comision resultante |
| Tope maximo en soles | 500,000.00 PEN | Limite por cheque (prevencion lavado de activos) |
| Tope maximo en dolares | 150,000.00 USD | Limite por cheque (prevencion lavado de activos) |
| Dias de vigencia | 180 dias calendario | Plazo desde la emision hasta el vencimiento |
| Numero base para numeracion | 1,000,000,000 | Se usa como punto de partida si la tabla esta vacia |

<!-- general-rule-end -->

## Dependencies

El programa CHQGEREN no opera de forma autonoma: es una subrutina que delega todas las operaciones sobre cuentas, fechas, contabilidad y notificaciones en otros modulos del sistema SIDEP. A continuacion se describen todas sus dependencias.

La interfaz de entrada y salida del programa esta definida en un copybook externo. Las constantes del dominio de cheques provienen de otro copybook. El programa accede directamente a una tabla DB2 propia y llama a cinco subrutinas para leer cuentas, validar saldo, registrar movimientos, calcular fechas y encolar notificaciones. Los errores se registran a traves de un sexto programa de log. Todas las subrutinas se invocan mediante instruccion CALL por nombre, pasando un area de datos compartida cuya estructura esta definida en los copybooks correspondientes.

| Dependencia | Descripcion | Tipo | Referencia | Relevancia para la Modernizacion |
|---|---|---|---|---|
| CHQGERCW | Define el area de comunicacion unica que el llamador pasa a CHQGEREN: funcion, cuenta, importe, moneda, beneficiario, fecha de proceso, usuario, numero de cheque y todos los campos de salida (comision, IGV, total, vencimiento, estado, codigo de retorno y mensaje). Es la firma publica del programa. | Copybook (Linkage Section) | CHQGERCW.cpy | La modernizacion debe reproducir exactamente esta estructura como contrato de entrada/salida de la nueva subrutina o API equivalente. |
| CHQCONW | Proporciona las constantes del dominio de cheques que CHQGEREN usa en tiempo de ejecucion: la tasa de IGV (18 %), los dias de vigencia del cheque de gerencia (180), los codigos de retorno propios del dominio (CHQ-RC-OK, CHQ-RC-DATO-INVALIDO, CHQ-RC-NO-ENCONTRADO, CHQ-RC-ESTADO-INVALIDO, CHQ-RC-SALDO-INSUF, CHQ-RC-ERROR-POSTEO, CHQ-RC-ERROR-DB2) y los tipos de operacion contable (SDU-OP-RETIRO, SDU-OP-COBRO-COMISION, SDU-OP-DEPOSITO, SDU-OP-REVERSO). | Copybook (Working-Storage) | CHQCONW.cpy | Todos estos valores deben trasladarse a la capa de configuracion o catalogo del sistema moderno. Ninguno debe quedar como literal magico en el codigo. |
| SDUCONST | Proporciona las constantes institucionales generales que el programa usa: codigos de moneda (SDU-MON-SOLES = '604', SDU-MON-DOLARES = '840'), estados de cuenta (SDU-EST-ACTIVA, SDU-EST-CERRADA), codigo de canal de ventanilla (SDU-CAN-VENTANILLA = 'VE'), la tasa ITF (SDU-TASA-ITF = 0.000050) y el codigo de retorno estandar SDU-RC-OK. | Copybook (Working-Storage) | SDUCONST.cpy | Estos parametros regulatorios y operativos deben gestionarse en tablas de configuracion del sistema moderno, no como constantes de codigo. La tasa ITF en particular esta sujeta a cambio normativo. |
| SDCMAEW | Define el area de comunicacion del hub de maestro de cuentas SDCMAEST. CHQGEREN la usa para leer el producto, moneda, estado y codigo unico del titular de la cuenta de cargo, tanto en la emision como en la anulacion. | Copybook (Working-Storage) | SDCMAEW.cpy | La estructura de esta area es critica: segun la documentacion del propio sistema, dos programas (CTSCERTI y SDMPOSTA) replicaron el area a mano antes de que existiera el copybook y podrian quedar desalineados si cambia. El sistema moderno debe resolver esta ambiguedad con un contrato de interfaz unico y versionado. |
| SDMPOSTW | Define el area de comunicacion AREA-POSTEO, compartida entre el motor de posteo SDMPOSTA y el validador de saldo SDMVALSA. CHQGEREN la usa para todos sus movimientos contables: cargos de importe y comision en la emision, abono en la anulacion, y la validacion previa de fondos. | Copybook (Working-Storage) | SDMPOSTW.cpy | Este es el contrato mas critico del nucleo de depositos: lo usan mas de diez programas. Cualquier cambio de estructura obliga a recompilar todo el sistema. En la modernizacion debe convertirse en un contrato de servicio versionado con compatibilidad hacia atras. |
| SDUFECHW | Define el area de comunicacion SDU-AREA-FECHA de la rutina de aritmetica de fechas SDUFECHA. CHQGEREN la usa con la funcion 'SUMADIAS' para calcular la fecha de vencimiento del cheque sumando 180 dias calendario a la fecha de emision. | Copybook (Working-Storage) | SDUFECHW.cpy | La logica de suma de dias debe reimplementarse con las librerias de fecha del lenguaje destino. Se debe tener en cuenta que SDUFECHA mantiene una tabla de feriados en memoria cuya ultima actualizacion documentada es de 2019; esta dependencia desaparece si la funcion 'SUMADIAS' solo suma dias calendario, que es el unico uso de CHQGEREN. |
| SDULOGW | Define el area de comunicacion SDU-AREA-LOG del logger centralizado SDULOGER. CHQGEREN la usa para registrar errores DB2 mediante el parrafo 9900-REGISTRA-ERROR, con nivel 'E' y codigo de error 'E0300'. | Copybook (Working-Storage) | SDULOGW.cpy | El sistema moderno debe reemplazar SDULOGER por el mecanismo de logging corporativo correspondiente, manteniendo los mismos campos de contexto (programa, parrafo, cuenta, importe, usuario, canal, fecha, SQLCODE). |
| NTFIFCW | Define el area de comunicacion NTF-AREA-ENCOLA de la subrutina de notificaciones NTFENCOL. CHQGEREN la usa unicamente en la emision exitosa, llamando con funcion 'EN', canal 'EM' (correo), plantilla 'CHQ004', el codigo unico del titular y como parametros el numero del cheque y la moneda separados por '|', con prioridad 4. | Copybook (Linkage Section de NTFENCOL / Working-Storage de CHQGEREN) | NTFIFCW.cpy | La notificacion es asincrona: NTFENCOL solo encola el mensaje en el archivo VSAM NTFCOLA; el envio real lo realiza el proceso batch NTFENVIO. El sistema moderno debe reemplazar este mecanismo por el servicio de notificaciones corporativo, conservando la logica de que el fallo de la notificacion no revierte la emision del cheque (el retorno de NTFENCOL no se evalua). |
| SDCMAEST | Subrutina hub de acceso a la tabla DB2 CUENTA_MAESTRO. CHQGEREN la llama con funcion 'LE' (lectura) para obtener el producto, moneda y estado de la cuenta de cargo antes de emitir y antes de abonar en la anulacion. Nunca la llama con funciones de escritura. | Subrutina CALL | SDCMAEST.cbl | Es el unico punto de acceso autorizado a CUENTA_MAESTRO. En la modernizacion debe reemplazarse por el servicio o repositorio de cuentas equivalente. Advertencia documentada en el fuente: CTSCERTI y SDMPOSTA no usan el copybook SDCMAEW sino una replica manual del area; si la estructura cambia, esos programas quedan desalineados sin que el compilador lo detecte. |
| SDMVALSA | Subrutina de calculo del saldo disponible. CHQGEREN la llama durante la verificacion de fondos en la emision (parrafo 2300-VERIFICAR-FONDOS) para obtener el saldo disponible real de la cuenta, que incluye descuento de retenciones judiciales e intangible CTS. Si el retorno no es cero y el indicador POS-SALDO-INSUF esta activo, la emision se rechaza por saldo insuficiente. | Subrutina CALL | SDMVALSA.cbl | SDMVALSA reutiliza el area AREA-POSTEO completa aunque solo necesita parte de ella. Ademas realiza una segunda lectura de la cuenta a traves de SDCMAEST, lo que implica dos lecturas de CUENTA_MAESTRO por cada emision. En la modernizacion conviene consolidar estas lecturas. |
| SDMPOSTA | Motor de posteo de movimientos. CHQGEREN lo llama a traves del parrafo auxiliar 8200-LLAMA-POSTEO para registrar todos los movimientos contables: el cargo del importe del cheque (tipo de operacion SDU-OP-RETIRO, signo 'D'), el cargo de la comision mas IGV (tipo SDU-OP-COBRO-COMISION, signo 'D'), el abono de devolucion en la anulacion (tipo SDU-OP-DEPOSITO, signo 'H') y el reverso de compensacion en caso de fallo del cargo de comision (tipo SDU-OP-REVERSO, signo 'H', indicador forzado 'S'). SDMPOSTA inserta en la tabla SIDEP.MOVIMIENTO, actualiza CUENTA_MAESTRO y genera el asiento contable. | Subrutina CALL | SDMPOSTA.cbl | Es la unica puerta de entrada autorizada para afectar saldos. Tiene mas de diez llamadores en el core y tres canales externos; cualquier cambio en SDMPOSTW obliga a recompilar todo el sistema. En la modernizacion debe exponerse como un servicio transaccional con garantias ACID. Nota importante: el reverso de compensacion se ejecuta con indicador forzado ('S'), lo que significa que SDMPOSTA no valida saldo para ese movimiento; si el reverso tambien falla, el error se registra en log pero el codigo de retorno de la emision ya habia sido puesto en error de posteo, de modo que la cuenta podria quedar debitada sin cheque emitido. Este escenario debe tratarse explicitamente en la modernizacion. |
| SDUFECHA | Subrutina de aritmetica de fechas. CHQGEREN la llama una vez durante la emision (parrafo 2600-REGISTRAR-CHEQUE) con funcion 'SUMADIAS', fecha de proceso y 180 dias, para obtener la fecha de vencimiento del cheque. | Subrutina CALL | SDUFECHA.cbl | SDUFECHA mantiene una tabla de feriados en memoria cargada desde el archivo VSAM FERIADOS. La funcion 'SUMADIAS' suma dias calendario sin considerar feriados, por lo que la dependencia del VSAM no afecta a este uso concreto. Sin embargo, la tabla de feriados hardcodeada en el fuente solo llega hasta 2019, lo que es un riesgo si alguna funcion que si consulta feriados se invoca desde otro llamador en el mismo contexto de ejecucion CICS y la tabla VSAM no esta disponible. |
| NTFENCOL | Subrutina de encolado de notificaciones. CHQGEREN la llama al final de una emision exitosa para encolar una notificacion al titular con la plantilla 'CHQ004'. NTFENCOL valida la plantilla en la tabla DB2 NTF_PLANTILLA, construye el texto sustituyendo variables, y graba el registro en el archivo VSAM NTFCOLA con estado 'P' (pendiente). El envio real lo realiza el proceso batch NTFENVIO. El retorno de NTFENCOL no es evaluado por CHQGEREN; si falla, la emision ya fue completada y el error se pierde silenciosamente. | Subrutina CALL | NTFENCOL.cbl | El mecanismo de encolado en VSAM debe reemplazarse por el bus de mensajes o servicio de notificaciones del sistema moderno. El hecho de que CHQGEREN no evalua el retorno de NTFENCOL debe mantenerse como comportamiento intencional (la notificacion es best-effort), pero debe documentarse explicitamente en el nuevo diseno. Nota: existe en NTFENCOL un bloque de codigo comentado (9100-ENVIO-DIRECTO) que llamaba a NTFX25 para envio directo de SMS por enlace X.25; fue retirado en 2013 y no tiene efecto alguno en la ejecucion actual. |
| SDULOGER | Subrutina de registro centralizado de errores y auditoria. CHQGEREN la llama desde el parrafo 9900-REGISTRA-ERROR cada vez que se produce un error DB2 en las operaciones contra CHQ_GERENCIA. Escribe en el archivo VSAM LOGSIDEP con nivel 'E' y codigo 'E0300'. Si el VSAM no esta disponible, SDULOGER degrada silenciosamente a DISPLAY sin notificar al llamador; el codigo de retorno de SDULOGER siempre queda en '00'. | Subrutina CALL | SDULOGER.cbl | La degradacion silenciosa del log es un riesgo operativo: si LOGSIDEP no esta disponible, los errores DB2 de CHQGEREN no quedan registrados en ninguna bitacora persistente. El sistema moderno debe garantizar que el fallo del subsistema de log no sea transparente. |
| CHQ_GERENCIA | Tabla DB2 propia del programa. CHQGEREN la lee con SELECT por numero de cheque (parrafo 6000-LEER-GERENCIA), inserta un registro nuevo en la emision (parrafo 2600-REGISTRAR-CHEQUE) y actualiza el estado en la anulacion (a 'AN') y en el pago (a 'PA'). El numero de cheque se obtiene con SELECT MAX sobre esta misma tabla. Las columnas usadas son: NUM_CHEQUE_GER, CTA_CARGO, MON_IMPORTE, COD_MONEDA, BENEFICIARIO, MON_COMISION, MON_IGV, FEC_EMISION, FEC_VENCIM, EST_GERENCIA, FEC_ESTADO y COD_USUARIO. | Tabla DB2 | CHQ_GERENCIA (esquema SIDEP, base de datos DB2) | La estrategia de numeracion por MAX+1 sin secuencia DB2 ni bloqueo explicito es un riesgo de colision en entornos con alta concurrencia. En la modernizacion debe reemplazarse por una secuencia autogenerada (IDENTITY o equivalente). La columna FEC_ESTADO se actualiza en anulacion y pago usando HV-FEC-EMISION, que contiene la fecha de proceso de la llamada actual, no la fecha de emision original; esto es correcto pero el nombre de la variable puede inducir a confusion. |
| CUENTA_MAESTRO | Tabla DB2 accedida indirectamente a traves de SDCMAEST (funcion 'LE'). CHQGEREN nunca accede a esta tabla directamente. | Tabla DB2 (acceso indirecto) | CUENTA_MAESTRO (accedida via SDCMAEST) | Ver dependencia de SDCMAEST. |
| SIDEP.MOVIMIENTO | Tabla DB2 accedida indirectamente a traves de SDMPOSTA. CHQGEREN nunca accede a esta tabla directamente. | Tabla DB2 (acceso indirecto) | SIDEP.MOVIMIENTO (accedida via SDMPOSTA) | Ver dependencia de SDMPOSTA. |
| NTF_PLANTILLA | Tabla DB2 accedida indirectamente a traves de NTFENCOL para validar y leer la plantilla 'CHQ004'. CHQGEREN nunca accede a esta tabla directamente. | Tabla DB2 (acceso indirecto) | NTF_PLANTILLA (accedida via NTFENCOL) | La plantilla 'CHQ004' debe existir en esta tabla, estar activa y corresponder al canal 'EM' (correo). Si no existe o esta inactiva, NTFENCOL devuelve error, pero como CHQGEREN no evalua ese retorno, la emision se completa igualmente. |
| NTFCOLA | Archivo VSAM indexado donde NTFENCOL deposita las notificaciones pendientes de envio. CHQGEREN no accede a el directamente; lo hace NTFENCOL en nombre de CHQGEREN. | Archivo VSAM (acceso indirecto) | NTFCOLA (accedido via NTFENCOL) | En la modernizacion debe reemplazarse por una cola de mensajes persistente del middleware corporativo. |
| LOGSIDEP | Archivo VSAM indexado donde SDULOGER escribe los registros de error y auditoria. CHQGEREN no accede a el directamente. | Archivo VSAM (acceso indirecto) | LOGSIDEP (accedido via SDULOGER) | Ver dependencia de SDULOGER. |
| FERIADOS | Archivo VSAM indexado de feriados, accedido por SDUFECHA al inicializarse. CHQGEREN no accede a el directamente. | Archivo VSAM (acceso indirecto) | FERIADOS (accedido via SDUFECHA) | La tabla de feriados hardcodeada en SDUFECHA solo cubre hasta 2019. Si el VSAM FERIADOS no esta disponible, SDUFECHA continua con esa tabla fija sin avisar al llamador. Para la funcion 'SUMADIAS' (suma de dias calendario) esto no tiene impacto funcional, pero si lo tiene para otras funciones de SDUFECHA que consultan dias habiles. |

## Data Structure

La siguiente tabla recoge todos los campos que intervienen en CHQGEREN, organizados por su origen: el area de comunicacion propia del programa (copybook CHQGERCW), las constantes internas de calculo (WORKING-STORAGE), las variables host de DB2, los campos de los copybooks de interfaz con los modulos llamados (CHQCONW, SDCMAEW, SDMPOSTW, SDUFECHW, NTFIFCW, SDULOGW, SDUCONST) y el registro fisico de la tabla DB2 CHQ_GERENCIA. Los campos marcados como "Relevante para modernizacion: Si" son aquellos cuya logica, formato o valor hardcodeado representa una decision de negocio que debe trasladarse explicitamente al sistema nuevo.

---

### Area de comunicacion principal - CHQ-AREA-GERENCIA (copybook CHQGERCW)

Esta es la unica interfaz de entrada y salida del programa. El llamador la rellena antes de invocar a CHQGEREN y la lee despues para conocer el resultado.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| CHQG-FUNCION | Funcion solicitada | Alfanumerico | 2 caracteres | Codigo de la operacion a ejecutar. Valores validos: 'EM' (emision), 'AN' (anulacion), 'PG' (pago), 'CO' (consulta). Cualquier otro valor devuelve error. | Si | N/A | Actua como discriminador principal del flujo del programa. | Si | Control |
| CHQG-CUENTA | Numero de cuenta de cargo | Alfanumerico | 14 caracteres | Numero de cuenta del solicitante que financia el cheque de gerencia. Se usa como cuenta de cargo en emision y como cuenta de abono en anulacion. | Si | N/A | Debe existir en CUENTA_MAESTRO, estar activa y tener la misma moneda que el cheque. | Si | Identificador |
| CHQG-IMPORTE | Importe del cheque | Numerico decimal con signo (packed decimal) | 13 enteros + 2 decimales | Monto nominal del cheque de gerencia. Debe ser mayor que cero. Se usa como base para calcular la comision y para verificar el tope maximo por cheque. | Si (en 'EM') | N/A | En consulta ('CO') este campo se devuelve como salida con el valor almacenado en la base de datos. | Si | Monetario |
| CHQG-MONEDA | Codigo de moneda | Alfanumerico | 3 caracteres | Moneda del cheque. Valores permitidos: '604' (Soles peruanos) o '840' (Dolares estadounidenses). Cualquier otro valor es rechazado. | Si (en 'EM') | N/A | Debe coincidir con la moneda de la cuenta de cargo. Determina el minimo de comision y el tope maximo aplicable. | Si | Clasificacion |
| CHQG-BENEFICIARIO | Nombre del beneficiario | Alfanumerico | 40 caracteres | Nombre de la persona o empresa a cuyo favor se emite el cheque. No puede estar en blanco en la emision. | Si (en 'EM') | N/A | Se almacena tal cual en CHQ_GERENCIA.BENEFICIARIO. | No | Descriptivo |
| CHQG-FEC-PROCESO | Fecha de proceso | Alfanumerico | 8 caracteres | Fecha de la operacion en formato AAAAMMDD. Se usa como fecha de emision, fecha de proceso y fecha valor en los posteos. | Si | N/A | Se convierte a formato ISO (AAAA-MM-DD) para almacenarla en DB2. | Si | Fecha |
| CHQG-USUARIO | Codigo de usuario | Alfanumerico | 8 caracteres | Identificador del operador o sistema que realiza la operacion. Se propaga a todos los posteos y al registro en CHQ_GERENCIA. | Si | N/A | Se usa tambien en el log de errores. | No | Auditoria |
| CHQG-NUM-CHEQUE-GER | Numero del cheque de gerencia | Numerico sin signo | 10 digitos | Numero unico del cheque de gerencia. En emision lo genera el programa (MAX + 1 sobre CHQ_GERENCIA). En anulacion, pago y consulta lo suministra el llamador para identificar el cheque. | Si (en 'AN', 'PG', 'CO') | N/A | La numeracion parte de 1.000.000.000 (WS-NUM-BASE) si la tabla esta vacia. | Si | Identificador |
| CHQG-COMISION | Comision calculada | Numerico decimal con signo (packed decimal) | 7 enteros + 2 decimales | Importe de la comision por emision, calculada como 0,25% del importe con un minimo segun moneda. Se devuelve como salida en emision y consulta. | No (salida) | 0 | Veanse las reglas RN-CHQ-40 en la seccion de logica de negocio. | Si | Monetario |
| CHQG-IGV | IGV sobre la comision | Numerico decimal con signo (packed decimal) | 7 enteros + 2 decimales | Impuesto General a las Ventas calculado como 18% de la comision. Se devuelve como salida en emision y consulta. | No (salida) | 0 | El porcentaje de IGV (18%) esta definido en CHQ-PCT-IGV dentro de CHQCONW. | Si | Monetario |
| CHQG-TOTAL-CARGO | Total cargado a la cuenta | Numerico decimal con signo (packed decimal) | 13 enteros + 2 decimales | Suma de importe + comision + IGV que se debita de la cuenta del solicitante. En anulacion contiene el importe devuelto (con o sin comision segun la fecha). | No (salida) | 0 | Este campo resume el impacto total sobre la cuenta. | Si | Monetario |
| CHQG-FEC-VENCIM | Fecha de vencimiento del cheque | Alfanumerico | 8 caracteres | Fecha limite para el cobro del cheque, calculada sumando 180 dias calendario a la fecha de emision. Se devuelve como salida en emision. | No (salida) | Espacios | El plazo de 180 dias esta definido en CHQ-DIAS-VIG-GERENCIA dentro de CHQCONW. | Si | Fecha |
| CHQG-ESTADO | Estado del cheque | Alfanumerico | 2 caracteres | Estado resultante de la operacion. Valores posibles: 'VI' (vigente, tras emision), 'AN' (anulado), 'PA' (pagado). En consulta refleja el estado actual almacenado. | No (salida) | Espacios | Corresponde a EST_GERENCIA en la tabla CHQ_GERENCIA. | Si | Estado |
| CHQG-COD-RETORNO | Codigo de retorno | Numerico sin signo | 4 digitos | Resultado de la operacion. 0000 indica exito. Los valores de error estan definidos en CHQ-CODIGOS-RETORNO (CHQCONW). | No (salida) | 0000 | Veanse los codigos en la tabla de constantes CHQCONW mas adelante. | Si | Control |
| CHQG-MENSAJE | Mensaje descriptivo del resultado | Alfanumerico | 60 caracteres | Texto explicativo del resultado de la operacion, tanto en exito como en error. | No (salida) | Espacios | Destinado a presentacion en pantalla o log. | No | Descriptivo |

---

### Constantes internas de calculo - WS-CONSTANTES-GEREN

Estos valores estan fijos en el codigo fuente (hardcodeados). No se leen de ninguna tabla de parametros ni de archivos de configuracion. Cualquier cambio requiere recompilacion.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| WS-COM-PCT | Porcentaje de comision | Numerico decimal (packed decimal) | 1 entero + 4 decimales | Tasa de comision aplicada al importe del cheque: 0,0025 (equivalente a 0,25%). Regla RN-CHQ-40. | N/A | 0.0025 | Valor fijo. Debe convertirse en parametro configurable en el sistema nuevo. | Si | Parametro de negocio |
| WS-COM-MIN-PEN | Comision minima en Soles | Numerico decimal con signo (packed decimal) | 5 enteros + 2 decimales | Importe minimo de comision aplicable cuando la moneda es Soles (PEN): S/ 15,00. Regla RN-CHQ-40. | N/A | +15.00 | Valor fijo. Debe parametrizarse. | Si | Parametro de negocio |
| WS-COM-MIN-USD | Comision minima en Dolares | Numerico decimal con signo (packed decimal) | 5 enteros + 2 decimales | Importe minimo de comision aplicable cuando la moneda es Dolares (USD): $ 5,00. Regla RN-CHQ-40. | N/A | +5.00 | Valor fijo. Debe parametrizarse. | Si | Parametro de negocio |
| WS-TOPE-PEN | Tope maximo del cheque en Soles | Numerico decimal con signo (packed decimal) | 9 enteros + 2 decimales | Importe maximo permitido por cheque de gerencia en Soles: S/ 500.000,00. Regla RN-CHQ-41 (prevencion de lavado de activos). | N/A | +500000.00 | Valor fijo introducido en 2022. Debe parametrizarse. | Si | Parametro de negocio |
| WS-TOPE-USD | Tope maximo del cheque en Dolares | Numerico decimal con signo (packed decimal) | 9 enteros + 2 decimales | Importe maximo permitido por cheque de gerencia en Dolares: $ 150.000,00. Regla RN-CHQ-41. | N/A | +150000.00 | Valor fijo. Debe parametrizarse. | Si | Parametro de negocio |
| WS-NUM-BASE | Numero de inicio de la numeracion | Numerico sin signo | 10 digitos | Valor de arranque de la secuencia de numeracion de cheques cuando la tabla CHQ_GERENCIA esta vacia: 1.000.000.000. | N/A | 1000000000 | Si la tabla tiene registros, el numero siguiente se obtiene como MAX(NUM_CHEQUE_GER) + 1. | Si | Parametro tecnico |

---

### Variables de calculo intermedias - WS-CALCULOS

Campos de uso interno durante el procesamiento. No se exponen al llamador directamente, aunque varios de sus valores se copian a los campos de salida de CHQ-AREA-GERENCIA.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| WS-COMISION | Comision calculada (trabajo) | Numerico decimal con signo (packed decimal) | 7 enteros + 2 decimales | Resultado del calculo de comision antes de ser copiado a CHQG-COMISION y HV-COMISION. | N/A | N/A | Se inicializa en cada emision. | No | Calculo interno |
| WS-IGV | IGV calculado (trabajo) | Numerico decimal con signo (packed decimal) | 7 enteros + 2 decimales | Resultado del calculo del IGV antes de ser copiado a CHQG-IGV y HV-IGV. | N/A | N/A | Se inicializa en cada emision. | No | Calculo interno |
| WS-TOTAL | Total a cargar (trabajo) | Numerico decimal con signo (packed decimal) | 13 enteros + 2 decimales | Suma de importe + comision + IGV. Se usa para verificar fondos y para el posteo. | N/A | N/A | Se inicializa en cada emision. | No | Calculo interno |
| WS-ITF-ESTIMADO | ITF estimado (trabajo) | Numerico decimal con signo (packed decimal) | 9 enteros + 2 decimales | Estimacion del Impuesto a las Transacciones Financieras calculado como importe del cheque multiplicado por SDU-TASA-ITF (0,000050). Se suma al total para verificar si el saldo disponible es suficiente. | N/A | N/A | El ITF real lo calcula y cobra SDMPOSTA. Este campo es solo una estimacion previa para la verificacion de fondos. | Si | Calculo interno |
| WS-REQUERIDO | Fondos totales requeridos (trabajo) | Numerico decimal con signo (packed decimal) | 13 enteros + 2 decimales | Total a cargar mas el ITF estimado. Se compara contra el saldo disponible devuelto por SDMVALSA. | N/A | N/A | Si el saldo disponible es menor que este valor, la operacion se rechaza por saldo insuficiente. | Si | Calculo interno |
| WS-COM-ABONO | Importe a devolver en anulacion (trabajo) | Numerico decimal con signo (packed decimal) | 13 enteros + 2 decimales | Importe que se abona a la cuenta en una anulacion. Siempre incluye el importe del cheque; incluye tambien comision e IGV solo si la anulacion ocurre el mismo dia de la emision. | N/A | N/A | Regla RN-CHQ-43. | Si | Calculo interno |

---

### Variables de fecha - WS-FECHAS y WS-FECHA-ISO

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| WS-FECHA-TRAB | Fecha de trabajo (formato AAAAMMDD) | Alfanumerico | 8 caracteres | Almacena temporalmente una fecha en formato compacto AAAAMMDD para convertirla a formato ISO. | N/A | Espacios | Se reutiliza para la fecha de emision y para la fecha de vencimiento. | No | Fecha |
| WS-FT-ANIO | Anio de la fecha de trabajo | Alfanumerico | 4 caracteres | Parte del anio de WS-FECHA-TRAB, accedida mediante redefinicion. | N/A | N/A | Subgrupo de WS-FECHA-TRAB-N (REDEFINES). | No | Fecha |
| WS-FT-MES | Mes de la fecha de trabajo | Alfanumerico | 2 caracteres | Parte del mes de WS-FECHA-TRAB, accedida mediante redefinicion. | N/A | N/A | Subgrupo de WS-FECHA-TRAB-N (REDEFINES). | No | Fecha |
| WS-FT-DIA | Dia de la fecha de trabajo | Alfanumerico | 2 caracteres | Parte del dia de WS-FECHA-TRAB, accedida mediante redefinicion. | N/A | N/A | Subgrupo de WS-FECHA-TRAB-N (REDEFINES). | No | Fecha |
| WS-FECHA-ISO | Fecha en formato ISO (AAAA-MM-DD) | Alfanumerico | 10 caracteres | Fecha formateada con guiones para almacenamiento en columnas DATE de DB2. Se construye copiando los tres subgrupos de WS-FECHA-TRAB-N separados por literales '-'. | N/A | N/A | Contiene dos caracteres FILLER de valor '-' en posiciones 5 y 8. | Si | Fecha |
| WS-FI-ANIO | Anio del campo ISO | Alfanumerico | 4 caracteres | Subgrupo del anio dentro de WS-FECHA-ISO. | N/A | N/A | | No | Fecha |
| WS-FI-MES | Mes del campo ISO | Alfanumerico | 2 caracteres | Subgrupo del mes dentro de WS-FECHA-ISO. | N/A | N/A | | No | Fecha |
| WS-FI-DIA | Dia del campo ISO | Alfanumerico | 2 caracteres | Subgrupo del dia dentro de WS-FECHA-ISO. | N/A | N/A | | No | Fecha |

---

### Variables auxiliares de control interno

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| WS-NOM-PROGRAMA | Nombre del programa | Alfanumerico | 8 caracteres | Literal fijo 'CHQGEREN'. Se usa en los registros de log y como identificador del terminal en los posteos. | N/A | 'CHQGEREN' | | No | Auditoria |
| WS-PARRAFO-ACT | Parrafo en ejecucion | Alfanumerico | 20 caracteres | Nombre del bloque logico que se esta ejecutando en cada momento. Se actualiza al inicio de cada operacion principal y se incluye en los registros de error. | N/A | Espacios | Equivale a un indicador de contexto de ejecucion. | No | Auditoria |
| WS-NUM-GER-DISP | Numero de cheque (display) | Numerico sin signo | 10 digitos | Copia del numero de cheque generado o recibido, en formato numerico de visualizacion, para incluirlo en las glosas de los movimientos y en la referencia del posteo. | N/A | 0 | | No | Identificador |
| WS-FEC-EMISION-ORIG | Fecha de emision original del cheque | Alfanumerico | 10 caracteres | Fecha de emision leida desde CHQ_GERENCIA en formato ISO (AAAA-MM-DD). Se usa en la anulacion para comparar con la fecha de proceso actual y determinar si se devuelve la comision. | N/A | Espacios | Si WS-FEC-EMISION-ORIG es igual a HV-FEC-EMISION (fecha de proceso actual), se devuelven comision e IGV. | Si | Fecha |

---

### Variables host para DB2 - WS-HOST-VARIABLES

Estos campos actuan como puente entre la logica del programa y las columnas de la tabla CHQ_GERENCIA.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| HV-NUM-CHEQUE-GER | Numero del cheque (host) | Numerico decimal con signo (packed decimal) | 10 digitos | Variable host para la columna NUM_CHEQUE_GER. Se usa en SELECT, INSERT y UPDATE. | N/A | N/A | | No | Identificador |
| HV-CTA-CARGO | Cuenta de cargo (host) | Alfanumerico | 14 caracteres | Variable host para la columna CTA_CARGO. | N/A | N/A | | No | Identificador |
| HV-IMPORTE | Importe del cheque (host) | Numerico decimal con signo (packed decimal) | 13 enteros + 2 decimales | Variable host para la columna MON_IMPORTE. | N/A | N/A | | No | Monetario |
| HV-MONEDA | Moneda (host) | Alfanumerico | 3 caracteres | Variable host para la columna COD_MONEDA. | N/A | N/A | | No | Clasificacion |
| HV-BENEFICIARIO | Beneficiario (host) | Alfanumerico | 40 caracteres | Variable host para la columna BENEFICIARIO. | N/A | N/A | | No | Descriptivo |
| HV-COMISION | Comision (host) | Numerico decimal con signo (packed decimal) | 7 enteros + 2 decimales | Variable host para la columna MON_COMISION. | N/A | N/A | | No | Monetario |
| HV-IGV | IGV (host) | Numerico decimal con signo (packed decimal) | 7 enteros + 2 decimales | Variable host para la columna MON_IGV. | N/A | N/A | | No | Monetario |
| HV-FEC-EMISION | Fecha de emision / fecha de proceso actual (host) | Alfanumerico | 10 caracteres | Variable host para la columna FEC_EMISION en INSERT, y para la columna FEC_ESTADO en UPDATE. En el contexto de la llamada actual contiene la fecha de proceso en formato ISO. | N/A | N/A | Atencion: este campo tiene doble uso. En emision almacena la fecha de emision. En anulacion y pago se usa como fecha del cambio de estado. | Si | Fecha |
| HV-FEC-VENCIM | Fecha de vencimiento (host) | Alfanumerico | 10 caracteres | Variable host para la columna FEC_VENCIM. En lectura contiene el vencimiento almacenado; en insercion contiene el vencimiento calculado. | N/A | N/A | | No | Fecha |
| HV-EST-GERENCIA | Estado del cheque (host) | Alfanumerico | 2 caracteres | Variable host para la columna EST_GERENCIA. Valores: 'VI' (vigente), 'AN' (anulado), 'PA' (pagado). | N/A | N/A | | Si | Estado |
| HV-USUARIO | Usuario (host) | Alfanumerico | 8 caracteres | Variable host para la columna COD_USUARIO en el INSERT. | N/A | N/A | | No | Auditoria |
| HV-MAX-NUMERO | Maximo numero de cheque existente | Numerico decimal con signo (packed decimal) | 10 digitos | Resultado del MAX(NUM_CHEQUE_GER) consultado antes de asignar el numero siguiente. Si la tabla esta vacia, COALESCE devuelve WS-NUM-BASE (1.000.000.000). | N/A | N/A | | No | Control |

---

### Tabla DB2 CHQ_GERENCIA

Tabla principal que almacena el registro de cada cheque de gerencia emitido. El programa la lee, inserta y actualiza directamente mediante SQL embebido.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| NUM_CHEQUE_GER | Numero del cheque de gerencia | Numerico | 10 digitos | Clave primaria de la tabla. Numero unico secuencial asignado en la emision. | Si | N/A | Generado por el programa como MAX + 1. Parte de 1.000.000.000 si la tabla esta vacia. | Si | Identificador |
| CTA_CARGO | Cuenta de cargo | Caracter fijo | 14 caracteres | Numero de cuenta del solicitante que financio el cheque. | Si | N/A | | No | Identificador |
| MON_IMPORTE | Importe del cheque | Decimal | 13 enteros + 2 decimales | Monto nominal del cheque de gerencia. | Si | N/A | | No | Monetario |
| COD_MONEDA | Codigo de moneda | Caracter fijo | 3 caracteres | Moneda del cheque: '604' (Soles) o '840' (Dolares). | Si | N/A | | Si | Clasificacion |
| BENEFICIARIO | Nombre del beneficiario | Caracter fijo | 40 caracteres | Nombre a cuyo favor fue emitido el cheque. | Si | N/A | | No | Descriptivo |
| MON_COMISION | Comision cobrada | Decimal | 7 enteros + 2 decimales | Importe de la comision de emision, sin IGV. | Si | N/A | | Si | Monetario |
| MON_IGV | IGV sobre la comision | Decimal | 7 enteros + 2 decimales | Importe del IGV calculado sobre la comision. | Si | N/A | | Si | Monetario |
| FEC_EMISION | Fecha de emision | Fecha (DATE) | 10 caracteres en formato ISO | Fecha en que se emitio el cheque. Se almacena en formato AAAA-MM-DD. | Si | N/A | Se lee con la funcion CHAR(..., ISO) en las consultas. | Si | Fecha |
| FEC_VENCIM | Fecha de vencimiento | Fecha (DATE) | 10 caracteres en formato ISO | Fecha limite para el cobro del cheque (emision + 180 dias calendario). | Si | N/A | Se lee con la funcion CHAR(..., ISO) en las consultas. | Si | Fecha |
| EST_GERENCIA | Estado del cheque | Caracter fijo | 2 caracteres | Estado actual del cheque. Valores: 'VI' (vigente, recien emitido), 'AN' (anulado), 'PA' (pagado). | Si | 'VI' al insertar | Solo los cheques en estado 'VI' pueden anularse o pagarse. | Si | Estado |
| FEC_ESTADO | Fecha del ultimo cambio de estado | Fecha (DATE) | 10 caracteres en formato ISO | Fecha en que se produjo la anulacion o el pago. Solo se escribe en los UPDATE de anulacion y pago. | No | N/A | No se escribe en el INSERT inicial. | Si | Fecha |
| COD_USUARIO | Codigo del usuario que emitio el cheque | Caracter fijo | 8 caracteres | Operador o sistema que realizo la emision. | Si | N/A | | No | Auditoria |

---

### Area de comunicacion con SDCMAEST - SDC-AREA-MAESTRO (copybook SDCMAEW)

Campos utilizados por CHQGEREN al llamar a SDCMAEST para leer los datos de la cuenta de cargo.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| SDC-MAE-FUNCION | Funcion de SDCMAEST | Alfanumerico | 2 caracteres | Operacion solicitada al hub de maestro. CHQGEREN siempre usa 'LE' (lectura sin bloqueo). | Si | N/A | | No | Control |
| SDC-MAE-COD-RETORNO | Codigo de retorno de SDCMAEST | Alfanumerico | 2 caracteres | Resultado de la llamada. '00' indica exito (SDU-RC-OK). | No (salida) | N/A | | No | Control |
| SDC-MAE-MENSAJE | Mensaje de SDCMAEST | Alfanumerico | 60 caracteres | Descripcion del resultado devuelto por SDCMAEST. | No (salida) | N/A | | No | Descriptivo |
| SDC-MAE-CTA-NUMERO | Numero de cuenta consultada | Alfanumerico | 14 caracteres | Numero de cuenta que se pasa a SDCMAEST para la lectura. | Si | N/A | | No | Identificador |
| SDC-MAE-CTA-PRODUCTO | Codigo de producto de la cuenta | Alfanumerico | 2 caracteres | Producto bancario de la cuenta (p. ej. '01' ahorro, '06' corriente). Se usa para rellenar POS-PRODUCTO en los posteos. | No (salida) | N/A | | Si | Clasificacion |
| SDC-MAE-CTA-MONEDA | Moneda de la cuenta | Alfanumerico | 3 caracteres | Moneda registrada en el maestro. CHQGEREN verifica que coincida con CHQG-MONEDA. | No (salida) | N/A | | Si | Clasificacion |
| SDC-MAE-CTA-ESTADO | Estado de la cuenta | Alfanumerico | 2 caracteres | Estado actual de la cuenta segun CUENTA_MAESTRO. Debe ser 'AC' (SDU-EST-ACTIVA) para poder emitir. En anulacion no debe ser 'CE' (SDU-EST-CERRADA). | No (salida) | N/A | | Si | Estado |
| SDC-MAE-TIT-CODIGO-UNICO | Codigo unico del titular | Alfanumerico | 10 caracteres | Identificador unico del titular de la cuenta. Se pasa a NTFENCOL como NTF-COD-UNICO para la notificacion. | No (salida) | N/A | | Si | Identificador |

---

### Area de comunicacion con SDMPOSTA / SDMVALSA - AREA-POSTEO (copybook SDMPOSTW)

Campos relevantes que CHQGEREN rellena antes de llamar a SDMVALSA (verificacion de saldo) y a SDMPOSTA (posteo de movimientos).

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| POS-EMPRESA | Codigo de empresa | Numerico sin signo | 3 digitos | Identificador de la entidad bancaria. CHQGEREN siempre lo fija en 1. | Si | 1 | Valor hardcodeado. | Si | Identificador |
| POS-CUENTA | Numero de cuenta | Alfanumerico | 20 caracteres | Cuenta afectada por el posteo. | Si | N/A | | No | Identificador |
| POS-PRODUCTO | Codigo de producto | Alfanumerico | 2 caracteres | Producto de la cuenta, tomado de SDC-MAE-CTA-PRODUCTO. | Si | N/A | | No | Clasificacion |
| POS-MONEDA | Moneda de la operacion | Numerico sin signo | 3 digitos | Moneda en formato numerico ISO (604 o 840). | Si | N/A | | Si | Clasificacion |
| POS-TIPO-OPERACION | Tipo de operacion contable | Alfanumerico | 4 caracteres | Codigo de operacion. CHQGEREN usa SDU-OP-RETIRO ('020') para el cargo del importe, SDU-OP-COBRO-COMISION ('060') para el cargo de comision + IGV, SDU-OP-DEPOSITO ('010') para el abono en anulacion, y SDU-OP-REVERSO ('099') para el reverso de compensacion. | Si | N/A | | Si | Clasificacion |
| POS-SIGNO | Signo de la operacion | Alfanumerico | 1 caracter | 'D' para cargo (debito) y 'H' para abono (haber). | Si | N/A | | Si | Control |
| POS-IMPORTE | Importe de la operacion | Numerico decimal con signo (packed decimal) | 13 enteros + 2 decimales | Monto de la operacion a postear. Siempre positivo; el signo viaja en POS-SIGNO. | Si | N/A | | No | Monetario |
| POS-FECHA-PROCESO | Fecha de proceso del posteo | Numerico sin signo | 8 digitos | Fecha de la operacion en formato AAAAMMDD. | Si | N/A | | No | Fecha |
| POS-FECHA-VALOR | Fecha valor del posteo | Numerico sin signo | 8 digitos | Fecha valor. CHQGEREN la fija igual a la fecha de proceso. | Si | N/A | | No | Fecha |
| POS-CANAL | Canal de la operacion | Alfanumerico | 3 caracteres | Canal por el que se origina la operacion. CHQGEREN usa SDU-CAN-VENTANILLA ('VE'). | Si | 'VE' | Valor fijo tomado de SDUCONST. | Si | Clasificacion |
| POS-SUCURSAL | Sucursal | Numerico sin signo | 4 digitos | CHQGEREN lo fija siempre en 0. | Si | 0 | | No | Organizacion |
| POS-TERMINAL | Terminal | Alfanumerico | 8 caracteres | CHQGEREN coloca el nombre del programa ('CHQGEREN'). | Si | 'CHQGEREN' | | No | Auditoria |
| POS-USUARIO | Usuario del posteo | Alfanumerico | 8 caracteres | Operador que realiza la operacion, tomado de CHQG-USUARIO. | Si | N/A | | No | Auditoria |
| POS-SUPERVISOR | Supervisor | Alfanumerico | 8 caracteres | CHQGEREN lo deja en espacios. | No | Espacios | | No | Auditoria |
| POS-GLOSA | Glosa del movimiento | Alfanumerico | 40 caracteres | Descripcion del movimiento. Ejemplos: 'CHEQUE GERENCIA NRO 0000000001', 'COMISION CHEQUE GERENCIA 0000000001', 'ANULA CHEQUE GERENCIA 0000000001'. | Si | N/A | El numero del cheque ocupa 10 caracteres a partir de la posicion indicada en cada caso. | No | Descriptivo |
| POS-REFERENCIA | Referencia del movimiento | Alfanumerico | 20 caracteres | Numero del cheque de gerencia, usado como referencia del posteo. | Si | N/A | | No | Identificador |
| POS-DOC-TIPO | Tipo de documento | Alfanumerico | 2 caracteres | CHQGEREN lo fija en 'CG' (cheque de gerencia). | Si | 'CG' | | Si | Clasificacion |
| POS-DOC-NUMERO | Numero de documento | Alfanumerico | 15 caracteres | Numero del cheque de gerencia. | Si | N/A | | No | Identificador |
| POS-LOTE | Numero de lote | Numerico sin signo | 6 digitos | CHQGEREN lo fija en 0 (operacion en linea). | No | 0 | | No | Control |
| POS-BATCH-ID | Identificador de batch | Alfanumerico | 8 caracteres | CHQGEREN lo deja en espacios (no es proceso batch). | No | Espacios | | No | Control |
| POS-IND-FORZAR | Indicador de posteo forzado | Alfanumerico | 1 caracter | 'S' indica que no se valida saldo disponible. CHQGEREN lo usa en 'S' unicamente para el reverso de compensacion cuando falla el cargo de comision. En todos los demas posteos se fija en 'N'. | No | 'N' | Despues de cada llamada a SDMPOSTA se restablece a 'N'. | Si | Control |
| POS-IND-EXONERA-ITF | Indicador de exoneracion de ITF | Alfanumerico | 1 caracter | CHQGEREN lo fija siempre en 'N': el ITF se calcula y cobra en todos los posteos de cheques de gerencia. | Si | 'N' | | Si | Control |
| POS-IND-SOLO-VALIDA | Indicador de solo validacion | Alfanumerico | 1 caracter | CHQGEREN lo fija en 'N': todos los posteos son definitivos, no solo validaciones. | Si | 'N' | | No | Control |
| POS-COD-RETORNO | Codigo de retorno del posteo | Numerico sin signo | 4 digitos | Resultado devuelto por SDMPOSTA o SDMVALSA. 0000 indica exito. Valores de error definidos en SDMPOSTW (p. ej. 0040 = saldo insuficiente). | No (salida) | N/A | | Si | Control |
| POS-SALDO-DISPONIBLE | Saldo disponible devuelto | Numerico decimal con signo (packed decimal) | 13 enteros + 2 decimales | Saldo disponible de la cuenta calculado por SDMVALSA (contable menos retenciones menos intangible). Se compara con WS-REQUERIDO. | No (salida) | N/A | | Si | Monetario |
| POS-MENSAJE | Mensaje del posteo | Alfanumerico | 70 caracteres | Descripcion del resultado devuelto por SDMPOSTA o SDMVALSA. Se copia a CHQG-MENSAJE en caso de error. | No (salida) | N/A | | No | Descriptivo |
| POS-SALDO-INSUF | Indicador de saldo insuficiente | Condicion (88) | N/A | Condicion verdadera cuando POS-COD-RETORNO vale 0040. CHQGEREN la usa para distinguir entre saldo insuficiente y otros errores de posteo. | N/A | N/A | Condicion sobre POS-COD-RETORNO. | Si | Control |

---

### Area de comunicacion con SDUFECHA - SDU-AREA-FECHA (copybook SDUFECHW)

Campos relevantes utilizados por CHQGEREN al llamar a SDUFECHA con la funcion 'SUMADIAS  ' para calcular la fecha de vencimiento del cheque.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| SDU-FE-FUNCION | Funcion de SDUFECHA | Alfanumerico | 10 caracteres | Operacion solicitada. CHQGEREN usa 'SUMADIAS  ' (con espacios hasta completar 10). | Si | N/A | El campo tiene longitud fija de 10 caracteres; los valores cortos deben rellenarse con espacios. | Si | Control |
| SDU-FE-FECHA-ENT | Fecha de entrada | Alfanumerico | 8 caracteres | Fecha base en formato AAAAMMDD sobre la que se suma el numero de dias. CHQGEREN pasa CHQG-FEC-PROCESO. | Si | N/A | | No | Fecha |
| SDU-FE-DIAS | Numero de dias a sumar | Numerico decimal con signo (packed decimal) | 5 digitos con signo | Cantidad de dias calendario a agregar. CHQGEREN pasa CHQ-DIAS-VIG-GERENCIA (180). | Si | N/A | | Si | Parametro de negocio |
| SDU-FE-FECHA-SAL | Fecha resultante | Alfanumerico | 8 caracteres | Fecha calculada en formato AAAAMMDD. CHQGEREN la copia a CHQG-FEC-VENCIM y la convierte a ISO para HV-FEC-VENCIM. | No (salida) | N/A | | No | Fecha |
| SDU-FE-COD-RETORNO | Codigo de retorno de SDUFECHA | Alfanumerico | 2 caracteres | Resultado de la llamada. '00' indica exito. | No (salida) | N/A | CHQGEREN no verifica este codigo en la llamada de calculo de vencimiento; solo lo verifica en SDCMAEST. | Si | Control |

---

### Area de comunicacion con NTFENCOL - NTF-AREA-ENCOLA (copybook NTFIFCW)

Campos que CHQGEREN rellena al encolar la notificacion al cliente tras una emision exitosa.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| NTF-FUNCION | Funcion de NTFENCOL | Alfanumerico | 2 caracteres | Operacion solicitada. CHQGEREN siempre usa 'EN' (encolar). | Si | 'EN' | | No | Control |
| NTF-CANAL | Canal de la notificacion | Alfanumerico | 2 caracteres | Canal por el que se enviara el mensaje. CHQGEREN usa 'EM' (correo electronico). | Si | 'EM' | Valores posibles: 'SM' SMS, 'EM' correo, 'PU' push. | Si | Clasificacion |
| NTF-COD-PLANTILLA | Codigo de plantilla de mensaje | Alfanumerico | 6 caracteres | Identificador de la plantilla de texto a usar. CHQGEREN usa 'CHQ004'. | Si | 'CHQ004' | La plantilla debe existir en la tabla NTF_PLANTILLA, estar activa y corresponder al canal 'EM'. | Si | Clasificacion |
| NTF-COD-UNICO | Codigo unico del destinatario | Alfanumerico | 10 caracteres | Identificador del titular de la cuenta, tomado de SDC-MAE-TIT-CODIGO-UNICO. NTFENCOL lo usa para localizar el contacto del cliente. | Si | N/A | | Si | Identificador |
| NTF-PARAMETROS | Parametros para la plantilla | Alfanumerico | 100 caracteres | Valores separados por '|' para sustituir las variables {1}..{9} de la plantilla. CHQGEREN construye el valor concatenando el numero del cheque, '|', y el codigo de moneda. | No | Espacios | Ejemplo: '0000000001|604'. | Si | Descriptivo |
| NTF-PRIORIDAD | Prioridad de la notificacion | Numerico sin signo | 1 digito | Nivel de urgencia del mensaje. CHQGEREN lo fija en 4 (baja-media). Rango valido: 0 a 5. | Si | 4 | 0 significa usar la prioridad por defecto de la plantilla. | No | Control |
| NTF-COD-RETORNO | Codigo de retorno de NTFENCOL | Numerico sin signo | 4 digitos | Resultado de la llamada. CHQGEREN no lo verifica: la notificacion es un proceso de mejor esfuerzo que no afecta el resultado de la emision. | No (salida) | N/A | Esta es una deuda tecnica documentada implicitamente en el codigo. | Si | Control |

---

### Constantes del dominio CHQ (copybook CHQCONW)

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| CHQ-PCT-IGV | Porcentaje de IGV | Numerico decimal | 1 entero + 2 decimales | Tasa del Impuesto General a las Ventas aplicada sobre la comision: 0,18 (18%). | N/A | 0.18 | Valor fijo en el copybook. Debe parametrizarse en el sistema nuevo. | Si | Parametro de negocio |
| CHQ-DIAS-VIG-GERENCIA | Dias de vigencia del cheque de gerencia | Numerico sin signo | 3 digitos | Plazo en dias calendario desde la emision hasta el vencimiento del cheque: 180 dias. | N/A | 180 | Valor fijo en el copybook. Debe parametrizarse. | Si | Parametro de negocio |
| CHQ-RC-OK | Codigo de retorno: exito | Numerico sin signo | 4 digitos | Valor 0000. Indica operacion completada sin errores. | N/A | 0000 | | No | Control |
| CHQ-RC-DATO-INVALIDO | Codigo de retorno: dato invalido | Numerico sin signo | 4 digitos | Valor 0200. Se devuelve cuando algun dato de entrada no cumple las validaciones (importe cero, moneda no permitida, tope excedido, etc.). | N/A | 0200 | | Si | Control |
| CHQ-RC-NO-ENCONTRADO | Codigo de retorno: no encontrado | Numerico sin signo | 4 digitos | Valor 0300. Se devuelve cuando el cheque o la cuenta no existen en la base de datos. | N/A | 0300 | | Si | Control |
| CHQ-RC-ESTADO-INVALIDO | Codigo de retorno: estado invalido | Numerico sin signo | 4 digitos | Valor 0400. Se devuelve cuando el cheque no esta en el estado requerido para la operacion (p. ej. intentar anular un cheque ya pagado). | N/A | 0400 | | Si | Control |
| CHQ-RC-SALDO-INSUF | Codigo de retorno: saldo insuficiente | Numerico sin signo | 4 digitos | Valor 0500. Se devuelve cuando el saldo disponible de la cuenta no cubre el total requerido. | N/A | 0500 | | Si | Control |
| CHQ-RC-ERROR-POSTEO | Codigo de retorno: error de posteo | Numerico sin signo | 4 digitos | Valor 0800. Se devuelve cuando SDMPOSTA o SDMVALSA devuelven un error distinto de saldo insuficiente. | N/A | 0800 | | Si | Control |
| CHQ-RC-ERROR-DB2 | Codigo de retorno: error de base de datos | Numerico sin signo | 4 digitos | Valor 0900. Se devuelve cuando una sentencia SQL falla con un SQLCODE distinto de 0 y +100. | N/A | 0900 | | Si | Control |

---

### Constantes generales del sistema (copybook SDUCONST) - campos usados por CHQGEREN

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| SDU-MON-SOLES | Codigo de moneda Soles | Alfanumerico | 3 caracteres | Literal '604'. Se usa para comparar con CHQG-MONEDA y determinar el minimo de comision y el tope aplicable. | N/A | '604' | | Si | Clasificacion |
| SDU-MON-DOLARES | Codigo de moneda Dolares | Alfanumerico | 3 caracteres | Literal '840'. Igual uso que SDU-MON-SOLES. | N/A | '840' | | Si | Clasificacion |
| SDU-EST-ACTIVA | Estado de cuenta activa | Alfanumerico | 2 caracteres | Literal 'AC'. La cuenta de cargo debe tener este estado para poder emitir un cheque. | N/A | 'AC' | | Si | Estado |
| SDU-EST-CERRADA | Estado de cuenta cerrada | Alfanumerico | 2 caracteres | Literal 'CE'. En anulacion, la cuenta de abono no puede tener este estado. | N/A | 'CE' | | Si | Estado |
| SDU-RC-OK | Codigo de retorno OK (SDCMAEST) | Alfanumerico | 2 caracteres | Literal '00'. Se compara con SDC-MAE-COD-RETORNO para verificar que la lectura del maestro fue exitosa. | N/A | '00' | Diferente del CHQ-RC-OK (numerico 0000); este es alfanumerico de 2 caracteres. | Si | Control |
| SDU-TASA-ITF | Tasa del ITF | Numerico decimal con signo | 1 entero + 6 decimales | Tasa del Impuesto a las Transacciones Financieras: 0,000050 (equivalente a 0,005%). Se usa para estimar el ITF antes de llamar a SDMPOSTA. | N/A | +0.000050 | El ITF real lo calcula SDMPOSTA. | Si | Parametro de negocio |
| SDU-OP-RETIRO | Codigo de operacion retiro | Alfanumerico | 3 caracteres | Literal '020'. Se usa como tipo de operacion en el cargo del importe del cheque. | N/A | '020' | | Si | Clasificacion |
| SDU-OP-COBRO-COMISION | Codigo de operacion cobro de comision | Alfanumerico | 3 caracteres | Literal '060'. Se usa como tipo de operacion en el cargo de comision + IGV. | N/A | '060' | | Si | Clasificacion |
| SDU-OP-DEPOSITO | Codigo de operacion deposito | Alfanumerico | 3 caracteres | Literal '010'. Se usa como tipo de operacion en el abono de la anulacion. | N/A | '010' | | Si | Clasificacion |
| SDU-OP-REVERSO | Codigo de operacion reverso | Alfanumerico | 3 caracteres | Literal '099'. Se usa como tipo de operacion en el posteo de compensacion cuando falla el cargo de comision. | N/A | '099' | | Si | Clasificacion |
| SDU-CAN-VENTANILLA | Codigo de canal ventanilla | Alfanumerico | 2 caracteres | Literal 'VE'. Se usa en todos los posteos y en el log de errores. | N/A | 'VE' | Fijo en el codigo aunque el programa puede ser llamado desde el canal web empresas. | Si | Clasificacion |

---

### Area de log de errores - SDU-AREA-LOG (copybook SDULOGW)

Campos que CHQGEREN rellena al llamar a SDULOGER para registrar errores en el VSAM LOGSIDEP.

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|---|---|---|---|---|---|---|---|---|---|
| SDU-LG-NIVEL | Nivel del mensaje de log | Alfanumerico | 1 caracter | CHQGEREN siempre usa 'E' (error). | Si | 'E' | Valores posibles: 'I' informativo, 'A' advertencia, 'E' error, 'F' fatal, 'D' debug. | No | Auditoria |
| SDU-LG-PROGRAMA | Nombre del programa | Alfanumerico | 8 caracteres | Se fija con WS-NOM-PROGRAMA ('CHQGEREN'). | Si | 'CHQGEREN' | | No | Auditoria |
| SDU-LG-PARRAFO | Nombre del bloque en ejecucion | Alfanumerico | 20 caracteres | Se fija con WS-PARRAFO-ACT. | Si | N/A | | No | Auditoria |
| SDU-LG-COD-ERROR | Codigo de error | Alfanumerico | 6 caracteres | CHQGEREN siempre usa 'E0300'. | Si | 'E0300' | | No | Control |
| SDU-LG-GLOSA | Descripcion del error | Alfanumerico | 120 caracteres | Texto del mensaje de error, tomado de CHQG-MENSAJE. | Si | N/A | | No | Descriptivo |
| SDU-LG-CUENTA | Cuenta relacionada con el error | Alfanumerico | 14 caracteres | Numero de cuenta del solicitante, tomado de CHQG-CUENTA. | No | N/A | | No | Auditoria |
| SDU-LG-DOI | Documento de identidad | Alfanumerico | 12 caracteres | CHQGEREN lo deja en espacios. | No | Espacios | | No | Auditoria |
| SDU-LG-IMPORTE | Importe relacionado | Numerico decimal con signo (packed decimal) | 13 enteros + 2 decimales | Importe del cheque, tomado de CHQG-IMPORTE. | No | N/A | | No | Monetario |
| SDU-LG-USUARIO | Usuario | Alfanumerico | 8 caracteres | Operador, tomado de CHQG-USUARIO. | No | N/A | | No | Auditoria |
| SDU-LG-TERMINAL | Terminal | Alfanumerico | 8 caracteres | Nombre del programa ('CHQGEREN'). | No | N/A | | No | Auditoria |
| SDU-LG-CANAL | Canal | Alfanumerico | 2 caracteres | Canal de ventanilla ('VE'), tomado de SDU-CAN-VENTANILLA. | No | 'VE' | | No | Auditoria |
| SDU-LG-FECHA | Fecha del error | Alfanumerico | 8 caracteres | Fecha de proceso, tomada de CHQG-FEC-PROCESO. | No | N/A | | No | Fecha |
| SDU-LG-SQLCODE | Codigo SQL del error | Numerico con signo (binario) | 9 digitos | Valor del SQLCODE en el momento del error. | No | N/A | Solo es significativo cuando el error proviene de una sentencia SQL. | No | Control |

## Detailed Rules

<!-- rule-start -->
### 1. Regla / Operacion - 0000-PRINCIPAL (Punto de entrada y distribuidor de funciones)
<!-- reviewed -->

_Reviewed_

El programa recibe un único bloque de datos de entrada y salida llamado CHQ-AREA-GERENCIA. Al ser invocado, ejecuta primero la inicialización (1000-INICIALIZAR) y luego examina el campo CHQG-FUNCION para determinar qué operación debe realizar. Los valores reconocidos son exactamente cuatro:

- 'EM': ejecuta el proceso de emisión de cheque de gerencia.
- 'AN': ejecuta el proceso de anulación.
- 'PG': ejecuta el proceso de pago (marca el cheque como cobrado).
- 'CO': ejecuta la consulta de estado.

Si el campo CHQG-FUNCION contiene cualquier otro valor distinto a los cuatro anteriores, el programa coloca en CHQG-COD-RETORNO el código de error CHQ-RC-DATO-INVALIDO (valor numérico 0200) y en CHQG-MENSAJE el texto literal 'FUNCION NO SOPORTADA POR CHQGEREN'. No se ejecuta ninguna otra acción. Al terminar cualquiera de los caminos, el programa devuelve el control al llamador mediante GOBACK.

**Estado de la Regla:** Relevante para Modernización

**Algoritmo**

1. Ejecutar la inicialización general (ver regla 1000-INICIALIZAR).
2. Leer el campo CHQG-FUNCION del área de comunicación.
3. Si CHQG-FUNCION = 'EM', ejecutar el proceso de emisión completo (ver regla 2000-EMITIR).
4. Si CHQG-FUNCION = 'AN', ejecutar el proceso de anulación completo (ver regla 3000-ANULAR).
5. Si CHQG-FUNCION = 'PG', ejecutar el proceso de pago completo (ver regla 4000-PAGAR).
6. Si CHQG-FUNCION = 'CO', ejecutar el proceso de consulta completo (ver regla 5000-CONSULTAR).
7. Para cualquier otro valor: asignar el código CHQ-RC-DATO-INVALIDO (0200) a CHQG-COD-RETORNO y el texto literal 'FUNCION NO SOPORTADA POR CHQGEREN' a CHQG-MENSAJE.
8. Devolver el control al programa llamador mediante GOBACK, independientemente del camino ejecutado.
<!-- rule-end -->

<!-- rule-start -->
### 2. Regla / Operacion - 1000-INICIALIZAR (Inicializacion de la llamada)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

1. Asignar el valor CHQ-RC-OK (0000) al campo CHQG-COD-RETORNO.
2. Limpiar el campo CHQG-MENSAJE (dejarlo en espacios en blanco).
3. Copiar el contenido de CHQG-CUENTA al campo interno HV-CTA-CARGO.
4. Copiar el contenido de CHQG-USUARIO al campo interno HV-USUARIO.
5. Copiar el contenido de CHQG-FEC-PROCESO (fecha de proceso en formato AAAAMMDD) al campo de trabajo WS-FECHA-TRAB.
6. Ejecutar la conversión de fecha a formato ISO (ver regla 8100-FECHA-A-ISO), que transforma WS-FECHA-TRAB desglosando sus componentes año (posiciones 1-4), mes (posiciones 5-6) y día (posiciones 7-8) hacia los subcampos WS-FI-ANIO, WS-FI-MES y WS-FI-DIA respectivamente, produciendo en WS-FECHA-ISO una cadena con el formato AAAA-MM-DD (los separadores guión son literales fijos definidos en la estructura de WS-FECHA-ISO).
7. Copiar WS-FECHA-ISO al campo interno HV-FEC-EMISION. Este campo representa la fecha de proceso de la llamada actual en formato ISO y será utilizado como fecha de emisión en las operaciones de base de datos durante la función de emisión, y como fecha de estado en las operaciones de actualización de base de datos durante las funciones de anulación y pago.
<!-- rule-end -->

<!-- rule-start -->
### 3. Regla / Operacion - 2000-EMITIR (Proceso completo de emision de cheque de gerencia)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

1. Registrar el nombre del proceso activo ('2000-EMITIR') en la variable de trazabilidad de párrafo activo para que cualquier error posterior pueda identificar el origen.
2. Validar que el importe del cheque sea estrictamente mayor que cero y que el nombre del beneficiario no esté en blanco. Si alguna de las dos condiciones falla: asignar el código de retorno de dato inválido (0200) a la salida, el texto 'IMPORTE O BENEFICIARIO INVALIDO' al campo de mensaje, y terminar el proceso sin continuar con los pasos siguientes.
3. Validar el tope máximo por cheque según la moneda (regla de negocio RN-CHQ-41). Las dos condiciones se evalúan de forma independiente; basta con que una se cumpla para rechazar la operación:
   - Si la moneda es soles ('604') y el importe es estrictamente mayor que 500,000.00: asignar el código de retorno de dato inválido (0200), el texto 'IMPORTE EXCEDE TOPE DE CHEQUE DE GERENCIA' al mensaje, y terminar.
   - Si la moneda es dólares ('840') y el importe es estrictamente mayor que 150,000.00: misma acción anterior.
4. Validar que la moneda sea exactamente '604' (soles) o '840' (dólares). Si es cualquier otro valor: asignar el código de retorno de dato inválido (0200), el texto 'MONEDA NO PERMITIDA' al mensaje, y terminar. Esta validación se ejecuta únicamente si las validaciones de tope del paso anterior no terminaron el proceso; es decir, si la moneda ya superó el tope en el paso 3, este paso no se alcanza.
5. Ejecutar la lectura y validación de la cuenta de cargo (ver regla 2100-LEER-CUENTA). Si el código de retorno resultante no es el de operación correcta (0000), terminar el proceso sin continuar.
6. Ejecutar el cálculo de comisión e IGV (ver regla 2200-CALCULAR-COMISION). Este paso no produce un código de retorno que pueda interrumpir el flujo; siempre continúa al paso siguiente.
7. Ejecutar la verificación de fondos disponibles (ver regla 2300-VERIFICAR-FONDOS). Si el código de retorno resultante no es el de operación correcta (0000), terminar el proceso.
8. Ejecutar la obtención del número de cheque de gerencia (ver regla 2400-OBTENER-NUMERO). Si el código de retorno resultante no es el de operación correcta (0000), terminar el proceso.
9. Ejecutar el cargo en cuenta (ver regla 2500-CARGAR-CUENTA). Si el código de retorno resultante no es el de operación correcta (0000), terminar el proceso. Nótese que dentro de este paso, si el cargo de la comisión más el IGV falla habiendo ya aplicado el cargo del importe principal, se ejecuta automáticamente un posteo de reverso forzado del importe principal como compensación antes de retornar el error.
10. Ejecutar el registro del cheque en la base de datos (ver regla 2600-REGISTRAR-CHEQUE). Este paso no produce una verificación de retorno que interrumpa el flujo hacia el paso siguiente; el resultado se evalúa dentro del propio paso y se continúa al paso 11 independientemente del éxito o fracaso del registro.
11. Si y solo si el código de retorno tras el registro del cheque es el de operación correcta (0000), ejecutar el envío de notificación al cliente (ver regla 2700-NOTIFICAR). Si el registro falló, no se envía notificación.
<!-- rule-end -->

<!-- rule-start -->
### 4. Regla / Operacion - 2100-LEER-CUENTA (Lectura y validacion de la cuenta de cargo)
<!-- reviewed -->

_Reviewed_

Consulta los datos de la cuenta de cargo a través del módulo SDCMAEST usando la función 'LE' (lectura sin bloqueo). Verifica que la cuenta exista, esté activa y que su moneda coincida con la moneda del cheque solicitado.

**Estado de la Regla:** Relevante para Modernización

**Algoritmo**

1. Asignar el valor 'LE' al campo SDC-MAE-FUNCION del área de comunicación del maestro.
2. Copiar CHQG-CUENTA a SDC-MAE-CTA-NUMERO.
3. Limpiar SDC-MAE-COD-RETORNO asignándole espacios.
4. Invocar al módulo externo SDCMAEST pasando el área SDC-AREA-MAESTRO. Este módulo consulta la tabla CUENTA_MAESTRO en la base de datos DB2 y devuelve todos los datos de la cuenta (producto, moneda, estado, saldos, datos del titular, etc.) en los campos con prefijo SDC-MAE-.
5. Si SDC-MAE-COD-RETORNO es distinto de SDU-RC-OK ('00'): asignar CHQ-RC-NO-ENCONTRADO (0300) a CHQG-COD-RETORNO, el texto 'CUENTA DE CARGO NO EXISTE' a CHQG-MENSAJE, y terminar este proceso saltando al punto de salida del párrafo (2100-EXIT).
6. Si SDC-MAE-CTA-ESTADO es distinto de SDU-EST-ACTIVA ('AC'): asignar CHQ-RC-ESTADO-INVALIDO (0400) a CHQG-COD-RETORNO, el texto 'CUENTA DE CARGO NO ESTA ACTIVA' a CHQG-MENSAJE, y terminar saltando al punto de salida del párrafo (2100-EXIT).
7. Si SDC-MAE-CTA-MONEDA es distinto a CHQG-MONEDA: asignar CHQ-RC-DATO-INVALIDO (0200) a CHQG-COD-RETORNO y el texto 'MONEDA DEL CHEQUE DISTINTA A LA CUENTA' a CHQG-MENSAJE. En este caso no se ejecuta un salto explícito al punto de salida; el proceso llega al fin natural del párrafo con el error ya establecido en CHQG-COD-RETORNO y CHQG-MENSAJE, devolviendo el control al llamador con esos valores.
<!-- rule-end -->

<!-- rule-start -->
### 5. Regla / Operacion - 2200-CALCULAR-COMISION (Calculo de comision e IGV - Regla RN-CHQ-40)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

1. Calcular la comision base multiplicando el importe del cheque por la tasa de comision:
   - WS-COMISION = CHQG-IMPORTE × 0.0025, redondeado half-up a 2 decimales.
2. Aplicar el minimo segun la moneda:
   - Si CHQG-MONEDA = '604' (soles): si WS-COMISION es menor que 15.00, asignar 15.00 a WS-COMISION.
   - Si CHQG-MONEDA es cualquier valor distinto de '604' (es decir, dolares u otra moneda que haya superado las validaciones previas, en la practica '840'): si WS-COMISION es menor que 5.00, asignar 5.00 a WS-COMISION.
   - Nota: la estructura del codigo es `IF moneda = soles ... ELSE ...`, por lo que el minimo de 5.00 se aplica a cualquier moneda que no sea soles, no exclusivamente a dolares.
3. Calcular el IGV sobre la comision ya ajustada:
   - WS-IGV = WS-COMISION × CHQ-PCT-IGV (constante definida en CHQCONW con valor 0.18, es decir 18%), redondeado half-up a 2 decimales.
4. Calcular el total a cargar en la cuenta:
   - WS-TOTAL = CHQG-IMPORTE + WS-COMISION + WS-IGV.
   - Este calculo no aplica redondeo adicional (no lleva clausula ROUNDED).
5. Copiar WS-COMISION a CHQG-COMISION (campo de salida en CHQ-AREA-GERENCIA).
6. Copiar WS-IGV a CHQG-IGV (campo de salida en CHQ-AREA-GERENCIA).
7. Copiar WS-TOTAL a CHQG-TOTAL-CARGO (campo de salida en CHQ-AREA-GERENCIA).

**Notas adicionales sobre el alcance de este calculo:**
- WS-TOTAL queda tambien disponible internamente para ser usado en la verificacion de fondos (parrafo 2300-VERIFICAR-FONDOS), donde se comprueba que el saldo disponible cubra WS-TOTAL mas el ITF estimado sobre el importe del cheque.
- WS-COMISION y WS-IGV se usan posteriormente en el parrafo 2500-CARGAR-CUENTA para el segundo cargo a la cuenta (operacion tipo cobro de comision, codigo SDU-OP-COBRO-COMISION = '060'), y en el parrafo 2600-REGISTRAR-CHEQUE para persistirlos en la tabla CHQ_GERENCIA (columnas MON_COMISION y MON_IGV respectivamente).

**Ejemplo para un cheque de 10,000.00 soles:**
- Comision base: 10,000.00 × 0.0025 = 25.00 (supera el minimo de 15.00, se usa 25.00).
- IGV: 25.00 × 0.18 = 4.50.
- Total: 10,000.00 + 25.00 + 4.50 = 10,029.50.

**Ejemplo para un cheque de 100.00 soles:**
- Comision base: 100.00 × 0.0025 = 0.25 (menor que el minimo de 15.00, se aplica minimo 15.00).
- IGV: 15.00 × 0.18 = 2.70.
- Total: 100.00 + 15.00 + 2.70 = 117.70.
<!-- rule-end -->

<!-- rule-start -->
### 6. Regla / Operacion - 2300-VERIFICAR-FONDOS (Verificacion de saldo disponible antes de emitir)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

1. Preparar el area de posteo (AREA-POSTEO) con los siguientes valores para la llamada a SDMVALSA:
   - POS-EMPRESA = 1.
   - POS-CUENTA = CHQG-CUENTA.
   - POS-PRODUCTO = SDC-MAE-CTA-PRODUCTO (obtenido previamente de la lectura de cuenta en el paso 2100-LEER-CUENTA).
   - POS-MONEDA = SDC-MAE-CTA-MONEDA (obtenido previamente de la lectura de cuenta).
   - POS-SIGNO = 'D' (cargo/debito).
   - POS-IMPORTE = WS-TOTAL (importe del cheque + comision + IGV, calculado en 2200-CALCULAR-COMISION).
   - POS-FECHA-PROCESO = CHQG-FEC-PROCESO.
   - POS-FECHA-VALOR = CHQG-FEC-PROCESO.
   - POS-CANAL = SDU-CAN-VENTANILLA (valor 'VE').
2. Invocar al modulo externo SDMVALSA pasando AREA-POSTEO. Este modulo calcula el saldo disponible real de la cuenta (saldo contable menos retenciones vigentes menos monto intangible) y lo devuelve en POS-SALDO-DISPONIBLE. Tambien devuelve un codigo de retorno en POS-COD-RETORNO.
3. Si POS-COD-RETORNO es distinto de 0000:
   - Si la condicion POS-SALDO-INSUF es verdadera (POS-COD-RETORNO = 0040): asignar CHQ-RC-SALDO-INSUF (0500) a CHQG-COD-RETORNO y el texto 'SALDO DISPONIBLE INSUFICIENTE' a CHQG-MENSAJE. Saltar al final del parrafo (2300-EXIT), interrumpiendo el flujo de emision.
   - En cualquier otro caso de error (POS-COD-RETORNO distinto de 0000 y distinto de 0040): asignar CHQ-RC-ERROR-POSTEO (0800) a CHQG-COD-RETORNO y copiar el contenido de POS-MENSAJE a CHQG-MENSAJE. Saltar al final del parrafo (2300-EXIT), interrumpiendo el flujo de emision.
4. Calcular el ITF estimado sobre el importe bruto del cheque unicamente (no sobre la comision ni el IGV), con redondeo half-up a 2 decimales:
   - WS-ITF-ESTIMADO = CHQG-IMPORTE × SDU-TASA-ITF (constante 0.000050, equivalente al 0.005% del importe).
5. Calcular el monto total requerido sumando el ITF estimado al total ya calculado:
   - WS-REQUERIDO = WS-TOTAL + WS-ITF-ESTIMADO.
6. Si POS-SALDO-DISPONIBLE es menor que WS-REQUERIDO: asignar CHQ-RC-SALDO-INSUF (0500) a CHQG-COD-RETORNO y el texto 'SALDO DISPONIBLE INSUFICIENTE' a CHQG-MENSAJE. En este caso no se salta a 2300-EXIT mediante una instruccion explicita; la condicion simplemente establece el codigo de retorno y el control regresa al parrafo 2000-EMITIR, que detecta el error y abandona el flujo.

**Nota importante sobre el alcance del ITF estimado:** el ITF sobre la comision e IGV no se incluye deliberadamente en la estimacion. El comentario en el codigo fuente indica expresamente que esos importes son centimos y que el modulo SDMPOSTA es la autoridad final en el calculo del ITF real en el momento del posteo efectivo. Por ello, la segunda comparacion (paso 6) actua como una segunda barrera de seguridad sobre el saldo disponible ya validado por SDMVALSA, incorporando unicamente el impacto del ITF sobre el importe principal del cheque.
<!-- rule-end -->

<!-- rule-start -->
### 7. Regla / Operacion - 2400-OBTENER-NUMERO (Generacion del numero de cheque de gerencia)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

1. Ejecutar la siguiente consulta SQL sobre la tabla `CHQ_GERENCIA`:
   - Seleccionar el resultado de `COALESCE(MAX(NUM_CHEQUE_GER), :WS-NUM-BASE)` en la variable interna `HV-MAX-NUMERO`. La función `COALESCE` garantiza que, si `MAX` devuelve nulo (tabla vacía), se utilice directamente el valor de la variable de trabajo `WS-NUM-BASE`, que contiene el literal numérico **1,000,000,000** (mil millones). No se aplica ningún filtro `WHERE`; la consulta opera sobre la totalidad de las filas de la tabla.
2. El resultado de la consulta queda almacenado en `HV-MAX-NUMERO`.
3. Evaluar el código de retorno SQL (`SQLCODE`):
   - **Si `SQLCODE` es distinto de 0:** asignar el código `CHQ-RC-ERROR-DB2` (valor `0900`) al campo de salida `CHQG-COD-RETORNO`, copiar el texto literal `'ERROR OBTENIENDO NUMERO DE CHEQUE'` al campo de salida `CHQG-MENSAJE`, y ejecutar el registro del error en bitácora mediante la rutina `9900-REGISTRA-ERROR`. El procesamiento de la emisión se interrumpe en este punto (el párrafo `2000-EMITIR` evalúa el código de retorno tras el `PERFORM` y abandona hacia `2000-EXIT`).
   - **Si `SQLCODE` es igual a 0:** continuar con los pasos siguientes.
4. Calcular el nuevo número de cheque sumando 1 al máximo obtenido:
   - `HV-NUM-CHEQUE-GER = HV-MAX-NUMERO + 1`
5. Copiar `HV-NUM-CHEQUE-GER` al campo de salida `CHQG-NUM-CHEQUE-GER` (devuelto al llamador como número del cheque emitido).
6. Copiar `HV-NUM-CHEQUE-GER` a la variable de trabajo `WS-NUM-GER-DISP`, que es la que se utiliza posteriormente en las glosas de los movimientos de posteo (cargo del importe y cargo de comisión más IGV) y como parámetro en la notificación al cliente.

**Nota de riesgo:** este mecanismo de numeración basado en `MAX+1` sin bloqueo ni secuencia garantizada no es seguro en entornos con transacciones concurrentes. Si dos transacciones consultan el máximo simultáneamente pueden obtener el mismo número, y no existe ninguna lógica de reintento ni de bloqueo en DB2 para este escenario. Este punto debe ser atendido en la modernización, por ejemplo mediante el uso de una secuencia (`SEQUENCE`) de base de datos o un mecanismo de generación de identificadores atómico.
<!-- rule-end -->

<!-- rule-start -->
### 8. Regla / Operacion - 2500-CARGAR-CUENTA (Cargo en cuenta del importe y la comision)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

**Primer movimiento - Cargo del importe del cheque:**

1. Asignar 'D' (débito/cargo) a POS-SIGNO.
2. Asignar SDU-OP-RETIRO ('020') a POS-TIPO-OPERACION.
3. Asignar CHQG-IMPORTE a POS-IMPORTE.
4. Construir la glosa del movimiento: el texto fijo `'CHEQUE GERENCIA NRO '` (20 caracteres) seguido del número de cheque WS-NUM-GER-DISP en los 10 caracteres siguientes (posiciones 21 a 30 de POS-GLOSA).
5. Invocar al proceso 8200-LLAMA-POSTEO (ver regla correspondiente), que completa los campos comunes y llama al motor de posteo SDMPOSTA.
6. Si POS-COD-RETORNO es distinto de 0000: asignar CHQ-RC-ERROR-POSTEO (0800) a CHQG-COD-RETORNO, copiar POS-MENSAJE a CHQG-MENSAJE, y terminar sin ejecutar el segundo cargo.

**Segundo movimiento - Cargo de comisión más IGV:**

7. Calcular el importe del segundo cargo: POS-IMPORTE = WS-COMISION + WS-IGV.
8. Asignar SDU-OP-COBRO-COMISION ('060') a POS-TIPO-OPERACION.
9. Construir la glosa: el texto fijo `'COMISION CHEQUE GERENCIA '` (25 caracteres) seguido del número de cheque WS-NUM-GER-DISP en los 10 caracteres siguientes (posiciones 26 a 35 de POS-GLOSA).
10. Invocar al proceso 8200-LLAMA-POSTEO.
11. Si POS-COD-RETORNO es distinto de 0000:
    - Asignar CHQ-RC-ERROR-POSTEO (0800) a CHQG-COD-RETORNO y copiar POS-MENSAJE a CHQG-MENSAJE.
    - **Ejecutar el reverso del primer cargo (compensación):**
      - Asignar 'H' (abono/crédito) a POS-SIGNO.
      - Asignar SDU-OP-REVERSO ('099') a POS-TIPO-OPERACION.
      - Asignar CHQG-IMPORTE a POS-IMPORTE.
      - Construir la glosa: `'REVERSO CHEQUE GERENCIA '` (25 caracteres, sin número de cheque concatenado).
      - Asignar 'S' a POS-IND-FORZAR para que el posteo no valide saldo (el reverso debe ejecutarse incondicionalmente, sin importar el saldo disponible).
      - Invocar al proceso 8200-LLAMA-POSTEO. Nótese que el proceso 8200-LLAMA-POSTEO, al finalizar, restablece siempre POS-IND-FORZAR a 'N', por lo que el indicador de forzado solo aplica a esta llamada de reverso.
    - El resultado del reverso no se evalúa para modificar el código de retorno; el error del segundo cargo ya quedó registrado. El proceso termina con ese error.
<!-- rule-end -->

<!-- rule-start -->
### 9. Regla / Operacion - 2600-REGISTRAR-CHEQUE (Insercion del cheque en la base de datos)
<!-- reviewed -->

_Reviewed_

Calcula la fecha de vencimiento del cheque sumando 180 días calendario a la fecha de proceso, convierte esa fecha al formato ISO requerido por DB2, y luego inserta el registro del nuevo cheque en la tabla CHQ_GERENCIA con estado inicial 'VI' (vigente).

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

1. Calcular la fecha de vencimiento invocando al módulo SDUFECHA con la función 'SUMADIAS':
   - SDU-FE-FUNCION = 'SUMADIAS  ' (exactamente 10 caracteres, completado con espacios).
   - SDU-FE-FECHA-ENT = CHQG-FEC-PROCESO (fecha de proceso en formato AAAAMMDD).
   - SDU-FE-DIAS = CHQ-DIAS-VIG-GERENCIA (valor constante 180, definido en el copybook CHQCONW).
   - Invocar SDUFECHA. El resultado (fecha de vencimiento en formato AAAAMMDD) queda en SDU-FE-FECHA-SAL.
2. Copiar SDU-FE-FECHA-SAL a CHQG-FEC-VENCIM (campo de salida para el llamador).
3. Copiar SDU-FE-FECHA-SAL a WS-FECHA-TRAB y ejecutar la conversión a formato ISO (rutina interna 8100-FECHA-A-ISO). Esta rutina descompone WS-FECHA-TRAB en sus partes año (WS-FT-ANIO), mes (WS-FT-MES) y día (WS-FT-DIA), y las copia respectivamente a WS-FI-ANIO, WS-FI-MES y WS-FI-DIA dentro de la estructura WS-FECHA-ISO, que tiene los separadores '-' fijos entre cada parte. El resultado en formato AAAA-MM-DD queda en WS-FECHA-ISO.
4. Copiar WS-FECHA-ISO a HV-FEC-VENCIM (variable host para la inserción en DB2).
5. Preparar el resto de las variables host para la inserción:
   - HV-IMPORTE = CHQG-IMPORTE.
   - HV-MONEDA = CHQG-MONEDA.
   - HV-BENEFICIARIO = CHQG-BENEFICIARIO.
   - HV-COMISION = WS-COMISION (comisión calculada en el paso 2200-CALCULAR-COMISION).
   - HV-IGV = WS-IGV (IGV calculado en el paso 2200-CALCULAR-COMISION).
   - HV-FEC-EMISION ya contiene la fecha de proceso en formato ISO (fue asignada en 1000-INICIALIZAR convirtiendo CHQG-FEC-PROCESO mediante la misma rutina 8100-FECHA-A-ISO).
   - HV-NUM-CHEQUE-GER ya contiene el número de cheque asignado en 2400-OBTENER-NUMERO.
   - HV-CTA-CARGO ya contiene la cuenta de cargo (CHQG-CUENTA), asignada en 1000-INICIALIZAR.
   - HV-USUARIO ya contiene el usuario (CHQG-USUARIO), asignado en 1000-INICIALIZAR.
6. Ejecutar la inserción en la tabla CHQ_GERENCIA con los siguientes valores en las columnas, en el orden exacto en que aparecen en el INSERT:
   - NUM_CHEQUE_GER = HV-NUM-CHEQUE-GER.
   - CTA_CARGO = HV-CTA-CARGO.
   - MON_IMPORTE = HV-IMPORTE.
   - COD_MONEDA = HV-MONEDA.
   - BENEFICIARIO = HV-BENEFICIARIO.
   - MON_COMISION = HV-COMISION.
   - MON_IGV = HV-IGV.
   - FEC_EMISION = HV-FEC-EMISION.
   - FEC_VENCIM = HV-FEC-VENCIM.
   - EST_GERENCIA = 'VI' (valor literal fijo, no una variable; representa el estado "vigente").
   - COD_USUARIO = HV-USUARIO.
7. Si SQLCODE es distinto de 0: asignar CHQ-RC-ERROR-DB2 (valor 0900, definido en CHQCONW) a CHQG-COD-RETORNO, el texto literal 'ERROR REGISTRANDO CHEQUE DE GERENCIA' a CHQG-MENSAJE, y ejecutar la rutina interna 9900-REGISTRA-ERROR, que registra el error en el log centralizado SDULOGER con nivel 'E', código de error 'E0300', el SQLCODE del error de DB2, la cuenta (CHQG-CUENTA), el importe (CHQG-IMPORTE), el usuario (CHQG-USUARIO) y la fecha de proceso (CHQG-FEC-PROCESO).
8. Si SQLCODE = 0: asignar el valor literal 'VI' a CHQG-ESTADO (campo de salida hacia el llamador) y el texto literal 'CHEQUE DE GERENCIA EMITIDO' a CHQG-MENSAJE.
<!-- rule-end -->

<!-- rule-start -->
### 10. Regla / Operacion - 2700-NOTIFICAR (Envio de notificacion al cliente tras la emision)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

1. Asignar 'EN' a NTF-FUNCION (función de encolar notificación).
2. Asignar 'EM' a NTF-CANAL (canal correo electrónico).
3. Asignar 'CHQ004' a NTF-COD-PLANTILLA.
4. Copiar SDC-MAE-TIT-CODIGO-UNICO (código único del titular, obtenido de la lectura de cuenta en 2100-LEER-CUENTA) a NTF-COD-UNICO.
5. Limpiar NTF-PARAMETROS (mover espacios).
6. Construir el contenido de NTF-PARAMETROS concatenando, delimitado por tamaño (SIZE): el número de cheque (WS-NUM-GER-DISP, campo numérico de 10 dígitos), el carácter separador '|', y el código de moneda (CHQG-MONEDA, campo de 3 caracteres). El resultado es una cadena con el formato: NNNNNNNNNN|MMM. Este valor se almacena en NTF-PARAMETROS, que tiene capacidad para 100 caracteres y admite hasta 9 parámetros separados por '|'.
7. Asignar 4 a NTF-PRIORIDAD. Según la escala definida en NTFIFCW, los valores válidos van de 1 (urgente) a 5 (baja), siendo 0 un valor especial que indica que se debe usar la prioridad por defecto definida en la plantilla. El valor 4 corresponde a una prioridad baja pero no la más baja.
8. Invocar al módulo externo NTFENCOL pasando NTF-AREA-ENCOLA. Internamente, NTFENCOL: valida que el canal sea uno de los permitidos ('SM', 'EM' o 'PU'), que el código de plantilla y el código único no estén en blanco, y que la prioridad esté en el rango 0 a 5; consulta la plantilla 'CHQ004' en la tabla DB2 NTF_PLANTILLA verificando que exista, esté activa (estado 'A') y corresponda al canal 'EM'; separa los parámetros de NTF-PARAMETROS usando '|' como delimitador en hasta 9 valores de hasta 30 bytes cada uno; sustituye las variables {1}..{9} del texto de la plantilla con los valores separados; y finalmente graba el registro en el archivo VSAM NTFCOLA con estado 'P' (pendiente) para su envío posterior por el proceso batch NTFENVIO. Si la prioridad informada (4) es distinta de cero, se usa directamente como prioridad final en la clave del registro de cola.
9. El resultado de la llamada a NTFENCOL no es leído ni evaluado por CHQGEREN. Si la notificación falla por cualquier motivo (plantilla inexistente, error de VSAM, dato inválido, etc.), la emisión del cheque ya quedó registrada en la tabla CHQ_GERENCIA con estado 'VI' y los cargos contables ya se realizaron en la cuenta del solicitante; la falla de notificación no revierte ninguna operación.
<!-- rule-end -->

<!-- rule-start -->
### 11. Regla / Operacion - 3000-ANULAR (Proceso completo de anulacion de cheque de gerencia - Regla RN-CHQ-43)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

1. Registrar '3000-ANULAR' en WS-PARRAFO-ACT.
2. Leer el cheque de la base de datos (ver regla 6000-LEER-GERENCIA). Si el resultado no es CHQ-RC-OK (0000), terminar.
3. Verificar que HV-EST-GERENCIA sea igual a 'VI'. Si no lo es: asignar CHQ-RC-ESTADO-INVALIDO (0400) a CHQG-COD-RETORNO, el texto 'CHEQUE DE GERENCIA NO ESTA VIGENTE' a CHQG-MENSAJE, y terminar.
4. Verificar que HV-CTA-CARGO (cuenta original del cheque, leída de la base de datos) sea igual a CHQG-CUENTA (cuenta informada por el llamador). Si no coinciden: asignar CHQ-RC-DATO-INVALIDO (0200) a CHQG-COD-RETORNO, el texto 'CUENTA NO ES LA DEL SOLICITANTE' a CHQG-MENSAJE, y terminar.
5. Leer la cuenta de abono invocando a SDCMAEST con función 'LE' y número de cuenta CHQG-CUENTA:
   - Si SDC-MAE-COD-RETORNO es distinto de SDU-RC-OK ('00') **O** si SDC-MAE-CTA-ESTADO es igual a SDU-EST-CERRADA ('CE'): asignar CHQ-RC-ESTADO-INVALIDO (0400) a CHQG-COD-RETORNO, el texto 'CUENTA DE ABONO NO OPERATIVA' a CHQG-MENSAJE, y terminar.
   - Nota: a diferencia de la validación de la cuenta de cargo en la emisión, aquí **no** se rechaza la cuenta si está bloqueada, inactiva u otros estados distintos de cerrada; el único estado que impide el abono es SDU-EST-CERRADA ('CE').
6. Calcular el importe a abonar (WS-COM-ABONO):
   - Inicialmente WS-COM-ABONO = HV-IMPORTE (solo el importe del cheque).
   - Comparar WS-FEC-EMISION-ORIG (fecha de emisión original del cheque, leída de CHQ_GERENCIA en formato ISO AAAA-MM-DD por 6000-LEER-GERENCIA) con HV-FEC-EMISION (fecha de proceso de la llamada actual, convertida a formato ISO AAAA-MM-DD en 1000-INICIALIZAR y almacenada en HV-FEC-EMISION):
     - Si WS-FEC-EMISION-ORIG es **igual** a HV-FEC-EMISION (la anulación ocurre el mismo día de la emisión): WS-COM-ABONO = HV-IMPORTE + HV-COMISION + HV-IGV (se devuelven también la comisión e IGV).
     - Si son distintas: WS-COM-ABONO = HV-IMPORTE (solo se devuelve el importe; la comisión e IGV no se recuperan).
   - El ITF nunca se devuelve en ningún caso (es un impuesto de ley irrecuperable).
7. Preparar el posteo de abono con los siguientes campos:
   - POS-EMPRESA = 1.
   - POS-CUENTA = CHQG-CUENTA.
   - POS-PRODUCTO = SDC-MAE-CTA-PRODUCTO (producto leído de SDCMAEST en el paso 5).
   - POS-MONEDA = SDC-MAE-CTA-MONEDA (moneda leída de SDCMAEST en el paso 5).
   - POS-SIGNO = 'H' (abono/crédito).
   - POS-TIPO-OPERACION = SDU-OP-DEPOSITO ('010').
   - POS-IMPORTE = WS-COM-ABONO.
   - Construir la glosa: el texto literal 'ANULA CHEQUE GERENCIA ' (22 caracteres) en POS-GLOSA, seguido del número de cheque: CHQG-NUM-CHEQUE-GER se mueve primero a WS-NUM-GER-DISP (campo numérico de 10 dígitos) y luego WS-NUM-GER-DISP se escribe en las posiciones 23 a 32 de POS-GLOSA (10 caracteres).
   - POS-IND-FORZAR = 'N' (no se fuerza el posteo; el abono debe respetar las validaciones normales de SDMPOSTA).
8. Invocar 8200-LLAMA-POSTEO (que completa los campos restantes del área de posteo —fecha de proceso, fecha valor, canal SDU-CAN-VENTANILLA, sucursal, terminal, usuario, referencia, tipo y número de documento— y llama a SDMPOSTA). Si POS-COD-RETORNO es distinto de 0000: asignar CHQ-RC-ERROR-POSTEO (0800) a CHQG-COD-RETORNO, copiar POS-MENSAJE a CHQG-MENSAJE, y terminar.
9. Actualizar el estado del cheque en la base de datos ejecutando un UPDATE sobre CHQ_GERENCIA con las siguientes asignaciones: EST_GERENCIA = 'AN' y FEC_ESTADO = HV-FEC-EMISION (fecha de proceso de la llamada actual en formato ISO AAAA-MM-DD), con la condición WHERE NUM_CHEQUE_GER = HV-NUM-CHEQUE-GER.
10. Evaluar el SQLCODE resultante del UPDATE:
    - Si SQLCODE es distinto de 0: asignar CHQ-RC-ERROR-DB2 (0900) a CHQG-COD-RETORNO, el texto 'ERROR ANULANDO CHEQUE DE GERENCIA' a CHQG-MENSAJE, y ejecutar 9900-REGISTRA-ERROR (que registra el error en el log VSAM LOGSIDEP mediante SDULOGER con nivel 'E', código 'E0300' y los datos de contexto de la operación).
    - Si SQLCODE = 0: asignar 'AN' a CHQG-ESTADO, copiar WS-COM-ABONO a CHQG-TOTAL-CARGO (para que el llamador conozca el importe total devuelto), y asignar el texto 'CHEQUE DE GERENCIA ANULADO' a CHQG-MENSAJE.
<!-- rule-end -->

<!-- rule-start -->
### 12. Regla / Operacion - 4000-PAGAR (Proceso de pago / marca del cheque como cobrado - Regla RN-CHQ-42)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

1. Leer el cheque de la base de datos (ver regla 6000-LEER-GERENCIA). Si el resultado no es CHQ-RC-OK (0000), terminar.
2. Verificar que HV-EST-GERENCIA sea igual a 'VI'. Si no lo es: asignar CHQ-RC-ESTADO-INVALIDO (0400) a CHQG-COD-RETORNO, el texto 'CHEQUE DE GERENCIA NO ESTA VIGENTE' a CHQG-MENSAJE, y terminar.
3. Verificar que HV-FEC-EMISION no sea mayor que HV-FEC-VENCIM. Si HV-FEC-EMISION > HV-FEC-VENCIM: asignar CHQ-RC-ESTADO-INVALIDO (0400) a CHQG-COD-RETORNO, el texto 'CHEQUE DE GERENCIA VENCIDO' a CHQG-MENSAJE, y terminar.

   Nota tecnica sobre los valores comparados: HV-FEC-EMISION **no** contiene la fecha de proceso actual. En el paso 1000-INICIALIZAR, la fecha de proceso recibida en CHQG-FEC-PROCESO se convierte al formato ISO (AAAA-MM-DD) y se almacena en HV-FEC-EMISION. Sin embargo, antes de llegar al proceso de pago, la subrutina 6000-LEER-GERENCIA ejecuta una consulta SELECT sobre la tabla CHQ_GERENCIA que recupera la fecha de emision original del cheque mediante CHAR(FEC_EMISION, ISO) y la deposita en WS-FEC-EMISION-ORIG, **sin sobreescribir HV-FEC-EMISION**. Por lo tanto, en el momento de esta comparacion, HV-FEC-EMISION contiene la fecha de proceso de la llamada actual convertida a ISO, y HV-FEC-VENCIM contiene la fecha de vencimiento del cheque leida de la base de datos en formato ISO (AAAA-MM-DD). La comparacion lexicografica entre ambas cadenas es correcta para este formato porque el orden alfabetico coincide con el orden cronologico.

4. Ejecutar UPDATE sobre CHQ_GERENCIA: SET EST_GERENCIA = 'PA', FEC_ESTADO = HV-FEC-EMISION (fecha de proceso de la llamada actual en formato ISO), WHERE NUM_CHEQUE_GER = HV-NUM-CHEQUE-GER.
5. Si SQLCODE es distinto de 0: asignar CHQ-RC-ERROR-DB2 (0900) a CHQG-COD-RETORNO y ejecutar 9900-REGISTRA-ERROR. El campo CHQG-MENSAJE no se actualiza en este caso de error (queda con el valor que tenia antes del UPDATE, que corresponde al mensaje de inicializacion en espacios establecido en 1000-INICIALIZAR, salvo que un paso previo lo haya modificado).
6. Si SQLCODE = 0: asignar 'PA' a CHQG-ESTADO y el texto 'CHEQUE DE GERENCIA PAGADO' a CHQG-MENSAJE.
<!-- rule-end -->

<!-- rule-start -->
### 13. Regla / Operacion - 5000-CONSULTAR (Consulta del estado de un cheque de gerencia)
<!-- reviewed -->

_Reviewed_

**Algoritmo**

1. Ejecutar la lectura del cheque de la base de datos (ver regla 6000-LEER-GERENCIA), pasando el número de cheque recibido en CHQG-NUM-CHEQUE-GER. Si el código de retorno resultante no es CHQ-RC-OK (0000), terminar sin modificar ningún campo de salida.
2. Si la lectura fue exitosa (CHQG-COD-RETORNO = CHQ-RC-OK), copiar los siguientes campos leídos a los campos de salida correspondientes:
   - HV-EST-GERENCIA a CHQG-ESTADO.
   - HV-IMPORTE a CHQG-IMPORTE.
   - HV-MONEDA a CHQG-MONEDA.
   - HV-BENEFICIARIO a CHQG-BENEFICIARIO.
   - HV-COMISION a CHQG-COMISION.
   - HV-IGV a CHQG-IGV.

**Nota:** Los campos CHQG-TOTAL-CARGO y CHQG-FEC-VENCIM no se actualizan en la consulta. El llamador recibe el estado, importe, moneda, beneficiario, comisión e IGV, pero no el total ni la fecha de vencimiento. La fecha de vencimiento sí queda disponible en la variable interna HV-FEC-VENCIM como resultado secundario de la lectura, pero no se traslada a ningún campo de salida del área de comunicación (CHQ-AREA-GERENCIA) durante esta función. La operación de consulta no realiza ninguna modificación en la base de datos ni en ninguna otra estructura.

**Estado de la Regla:** Relevante para Modernización
<!-- rule-end -->

<!-- rule-start -->
### 14. Regla / Operacion - 6000-LEER-GERENCIA (Lectura comun del cheque de gerencia por numero)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

1. Copiar CHQG-NUM-CHEQUE-GER a HV-NUM-CHEQUE-GER.
2. Ejecutar la siguiente consulta SQL sobre la tabla CHQ_GERENCIA:
   - Columnas a recuperar: CTA_CARGO, MON_IMPORTE, COD_MONEDA, BENEFICIARIO, MON_COMISION, MON_IGV, EST_GERENCIA, la columna FEC_EMISION convertida a formato ISO (AAAA-MM-DD) mediante la funcion CHAR(FEC_EMISION, ISO), y la columna FEC_VENCIM convertida de la misma forma mediante CHAR(FEC_VENCIM, ISO).
   - Filtro: WHERE NUM_CHEQUE_GER = HV-NUM-CHEQUE-GER.
   - Destino de los valores recuperados, en el mismo orden en que se seleccionan: HV-CTA-CARGO, HV-IMPORTE, HV-MONEDA, HV-BENEFICIARIO, HV-COMISION, HV-IGV, HV-EST-GERENCIA, WS-FEC-EMISION-ORIG (recibe la fecha de emision original del cheque en formato ISO), HV-FEC-VENCIM (recibe la fecha de vencimiento en formato ISO).
3. Evaluar el SQLCODE mediante una estructura EVALUATE con tres ramas:
   - Si SQLCODE = 0: no realizar ninguna accion (instruccion CONTINUE); el codigo de retorno permanece sin modificacion, indicando exito.
   - Si SQLCODE = +100 (fila no encontrada): asignar CHQ-RC-NO-ENCONTRADO (valor 0300) a CHQG-COD-RETORNO y el texto literal **'CHEQUE DE GERENCIA NO EXISTE'** a CHQG-MENSAJE.
   - Para cualquier otro valor de SQLCODE (error de base de datos): asignar CHQ-RC-ERROR-DB2 (valor 0900) a CHQG-COD-RETORNO, el texto literal **'ERROR LEYENDO CHQ_GERENCIA'** a CHQG-MENSAJE, y ejecutar el proceso 9900-REGISTRA-ERROR para registrar el error en la bitacora del sistema.

**Notas sobre el contexto de uso de las variables resultantes**

- **WS-FEC-EMISION-ORIG** almacena la fecha en que fue emitido originalmente el cheque, en formato ISO (AAAA-MM-DD). Esta variable es utilizada exclusivamente por la operacion de anulacion (3000-ANULAR) para comparar si la fecha de emision original coincide con la fecha de proceso de la llamada actual, lo cual determina si se devuelve o no la comision e IGV al titular.
- **HV-FEC-VENCIM** almacena la fecha de vencimiento del cheque en formato ISO (AAAA-MM-DD). Es utilizada por la operacion de pago (4000-PAGAR) para verificar que la fecha de proceso actual no haya superado el vencimiento del cheque (180 dias calendario desde la emision).
- **HV-FEC-EMISION** no es afectada por este proceso de lectura. Este campo contiene la fecha de proceso de la llamada actual (convertida a formato ISO en el paso de inicializacion 1000-INICIALIZAR) y es la que se utiliza como fecha de referencia en las operaciones de actualizacion de la base de datos (campo FEC_ESTADO en los UPDATE de anulacion y pago).
<!-- rule-end -->

<!-- rule-start -->
### 15. Regla / Operacion - 8100-FECHA-A-ISO (Conversion de fecha de formato compacto a formato ISO)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

El campo `WS-FECHA-TRAB` tiene una vista alternativa (redefinición) llamada `WS-FECHA-TRAB-N` que descompone sus 8 caracteres en tres subcampos: `WS-FT-ANIO` (posiciones 1–4), `WS-FT-MES` (posiciones 5–6) y `WS-FT-DIA` (posiciones 7–8).

El campo `WS-FECHA-ISO` está definido con literales fijos `'-'` en las posiciones 5 y 8 (declarados como campos `FILLER` con valor `'-'`), por lo que solo es necesario mover las partes variables:

1. Copiar `WS-FT-ANIO` (4 caracteres del año) a `WS-FI-ANIO` (posiciones 1–4 de `WS-FECHA-ISO`).
2. Copiar `WS-FT-MES` (2 caracteres del mes) a `WS-FI-MES` (posiciones 6–7 de `WS-FECHA-ISO`; la posición 5 ya contiene `'-'` como valor fijo).
3. Copiar `WS-FT-DIA` (2 caracteres del día) a `WS-FI-DIA` (posiciones 9–10 de `WS-FECHA-ISO`; la posición 8 ya contiene `'-'` como valor fijo).

El resultado en `WS-FECHA-ISO` es una cadena de 10 caracteres con el formato `AAAA-MM-DD`.

Este párrafo es invocado en dos momentos distintos dentro del programa `CHQGEREN`:

- Durante la inicialización (párrafo `1000-INICIALIZAR`), para convertir la fecha de proceso recibida en `CHQG-FEC-PROCESO` —previamente copiada a `WS-FECHA-TRAB`— y dejar el resultado en `HV-FEC-EMISION`, que se usará como fecha de emisión en la inserción a la tabla `CHQ_GERENCIA`.
- Durante el registro del cheque (párrafo `2600-REGISTRAR-CHEQUE`), para convertir la fecha de vencimiento calculada por `SDUFECHA` —devuelta en `SDU-FE-FECHA-SAL`, copiada a `WS-FECHA-TRAB`— y dejar el resultado en `HV-FEC-VENCIM`, que se usará como fecha de vencimiento en la misma inserción.
<!-- rule-end -->

<!-- rule-start -->
### 16. Regla / Operacion - 8200-LLAMA-POSTEO (Preparacion y llamada al motor de posteo SDMPOSTA)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

Los siguientes campos se asignan siempre de forma fija en este proceso, sobreescribiendo cualquier valor previo:

1. POS-EMPRESA = 1.
2. POS-CUENTA = CHQG-CUENTA.
3. POS-PRODUCTO = SDC-MAE-CTA-PRODUCTO (obtenido de la última lectura exitosa a SDCMAEST).
4. POS-MONEDA = SDC-MAE-CTA-MONEDA (obtenido de la última lectura exitosa a SDCMAEST).
5. POS-FECHA-PROCESO = CHQG-FEC-PROCESO.
6. POS-FECHA-VALOR = CHQG-FEC-PROCESO.
7. POS-CANAL = SDU-CAN-VENTANILLA (valor constante 'VE', definido en SDUCONST).
8. POS-SUCURSAL = 0.
9. POS-TERMINAL = WS-NOM-PROGRAMA (el valor fijo 'CHQGEREN').
10. POS-USUARIO = CHQG-USUARIO.
11. POS-SUPERVISOR = espacios en blanco.
12. POS-REFERENCIA = WS-NUM-GER-DISP (número del cheque de gerencia, en formato numérico de 10 dígitos).
13. POS-DOC-TIPO = 'CG'.
14. POS-DOC-NUMERO = WS-NUM-GER-DISP (el mismo número del cheque de gerencia).
15. POS-LOTE = 0.
16. POS-BATCH-ID = espacios en blanco.
17. POS-IND-EXONERA-ITF = 'N' (la operación no está exonerada de ITF; el ITF será calculado y cobrado por SDMPOSTA).
18. POS-IND-SOLO-VALIDA = 'N' (se debe ejecutar el posteo real, no solo validar).
19. Si POS-IND-FORZAR no es igual a 'S', asignar 'N' a POS-IND-FORZAR. Si ya es 'S' (porque el llamador lo asignó explícitamente, como ocurre en el reverso de compensación dentro de 2500-CARGAR-CUENTA), ese valor se respeta y no se sobreescribe.
20. Invocar al módulo externo SDMPOSTA pasando AREA-POSTEO como único parámetro. SDMPOSTA realiza internamente la secuencia completa de posteo: valida la cuenta contra CUENTA_MAESTRO mediante SDCMAEST, valida el saldo disponible mediante SDMVALSA (solo en cargos y cuando POS-IND-FORZAR no es 'S'), calcula el ITF (0,005% del importe, con un mínimo cobrable de 0,01; exonerado si el producto es CTS o Cuenta Sueldo, o si el tipo de operación es abono de interés 'I001' o extorno 'E001'), calcula la comisión de ventanilla cuando corresponde, inserta el movimiento principal en la tabla SIDEP.MOVIMIENTO (con estado 'V'), inserta movimientos adicionales de secuencia 2 y 3 para el ITF y la comisión respectivamente si sus importes son mayores que cero, actualiza el saldo contable en CUENTA_MAESTRO mediante SDCMAEST con función 'AC', y genera el asiento contable mediante SDGASIEN. El resultado de la operación se devuelve en POS-COD-RETORNO (0000 = éxito) y POS-MENSAJE. En caso de error, POS-PROGRAMA-ERROR identifica el módulo que falló.
21. Inmediatamente después del retorno de SDMPOSTA, asignar 'N' a POS-IND-FORZAR, con independencia del valor que tenía antes de la llamada, para que el siguiente posteo no herede el indicador de forzado.

El llamador es responsable de haber asignado previamente los campos variables antes de invocar este proceso. Estos campos variables son: POS-SIGNO (signo de la operación: 'D' para débito o cargo, 'H' para crédito o abono), POS-TIPO-OPERACION (código de tipo de operación, por ejemplo SDU-OP-RETIRO para el cargo del importe, SDU-OP-COBRO-COMISION para el cargo de la comisión, SDU-OP-DEPOSITO para el abono en la anulación, y SDU-OP-REVERSO para el reverso de compensación), POS-IMPORTE (importe de la operación, siempre positivo), POS-GLOSA (descripción textual de hasta 40 caracteres) y POS-IND-FORZAR (indicador de forzado, que el llamador debe poner en 'S' únicamente para el reverso de compensación; en todos los demás casos debe llegar en 'N' o vacío, ya que el propio proceso lo normalizará a 'N' antes de llamar a SDMPOSTA).
<!-- rule-end -->

<!-- rule-start -->
### 17. Regla / Operacion - 9900-REGISTRA-ERROR (Registro de errores en la bitacora del sistema)
<!-- reviewed -->

_Reviewed_

**Estado de la Regla:** Relevante para Modernizacion

**Algoritmo**

1. Asignar el nivel de error `'E'` al campo SDU-LG-NIVEL.
2. Copiar WS-NOM-PROGRAMA (valor fijo `'CHQGEREN'`) a SDU-LG-PROGRAMA.
3. Copiar WS-PARRAFO-ACT (nombre del párrafo activo al momento del error, por ejemplo `'2000-EMITIR'`) a SDU-LG-PARRAFO.
4. Asignar el código de error fijo `'E0300'` a SDU-LG-COD-ERROR.
5. Copiar CHQG-MENSAJE (que ya contiene la descripción del error producido) a SDU-LG-GLOSA.
6. Copiar CHQG-CUENTA a SDU-LG-CUENTA.
7. Asignar espacios en blanco a SDU-LG-DOI (el documento de identidad no se registra en la bitácora de errores de este módulo).
8. Copiar CHQG-IMPORTE a SDU-LG-IMPORTE.
9. Copiar CHQG-USUARIO a SDU-LG-USUARIO.
10. Copiar WS-NOM-PROGRAMA (valor fijo `'CHQGEREN'`) a SDU-LG-TERMINAL.
11. Copiar SDU-CAN-VENTANILLA (valor fijo `'VE'`) a SDU-LG-CANAL.
12. Copiar CHQG-FEC-PROCESO a SDU-LG-FECHA.
13. Copiar el valor actual de SQLCODE a SDU-LG-SQLCODE.
14. Invocar al módulo externo SDULOGER pasando SDU-AREA-LOG como único parámetro. Este módulo escribe el registro en el archivo VSAM LOGSIDEP utilizando como clave compuesta la fecha del sistema, la hora, el nombre del programa y un contador secuencial interno. Si el archivo VSAM no está disponible en el momento de la escritura, SDULOGER degrada el registro a una instrucción DISPLAY en consola sin retornar ningún código de error al llamador, por lo que el programa CHQGEREN no puede detectar si la escritura en bitácora falló.

> **Nota de contexto:** Este párrafo es invocado exclusivamente ante errores de base de datos DB2 (SQLCODE distinto de cero) en las operaciones SQL del programa: obtención del número de cheque (párrafo 2400), inserción del registro de cheque (párrafo 2600), actualización del estado a anulado (párrafo 3000) y actualización del estado a pagado (párrafo 4000). En todos esos casos, antes de invocar a 9900-REGISTRA-ERROR, el código de retorno CHQG-COD-RETORNO ya ha sido establecido en CHQ-RC-ERROR-DB2 (valor `0900`) y CHQG-MENSAJE ya contiene el texto descriptivo del error, siendo ese mensaje el que se traslada al campo SDU-LG-GLOSA.
<!-- rule-end -->

---

## Extraction metadata

- **Main file:** cobol/CHQGEREN.cbl
- **Created:** 2026-11-08 15:59:28 UTC
- **Started:** 2026-11-08 16:11:38 UTC
- **Duration:** 00:46:43
- **LLM:** us.anthropic.claude-sonnet-4-6 (us.anthropic.claude-sonnet-4-6)
- **Context window:** 200000 tokens · **Max output:** 64000 tokens
- **Extraction prompt:** business_rules_extraction_cobol · **Reviewer prompt:** business_rules_reviewer_cobol
- **Token usage:** 1552714 total (1499025 input, 53689 output)

### Reference files (14)
Intended for the extraction; any excluded below were not submitted:
- cobol/NTFENCOL.cbl
- cobol/SDCMAEST.cbl
- cobol/SDMPOSTA.cbl
- cobol/SDMVALSA.cbl
- cobol/SDUFECHA.cbl
- cobol/SDULOGER.cbl
- copybook/CHQCONW.cpy
- copybook/CHQGERCW.cpy
- copybook/NTFIFCW.cpy
- copybook/SDCMAEW.cpy
- copybook/SDMPOSTW.cpy
- copybook/SDUCONST.cpy
- copybook/SDUFECHW.cpy
- copybook/SDULOGW.cpy
