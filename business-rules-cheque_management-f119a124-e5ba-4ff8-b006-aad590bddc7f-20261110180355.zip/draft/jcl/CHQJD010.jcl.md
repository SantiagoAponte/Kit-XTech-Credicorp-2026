# CHQJD010.jcl: Cadena Diaria de Cheques y Compensacion (CHQJD010)

## Overview

Este trabajo (job) es el proceso central diario del dominio de Cheques y Compensacion dentro del sistema SIDEP. Su proposito es ejecutar, en secuencia y de forma encadenada, todas las operaciones necesarias para cerrar el ciclo diario de cheques: emitir las chequeras pendientes de entrega, procesar los movimientos de la camara de compensacion (cheques entrantes, salientes y canjes vencidos), liquidar las multas y comisiones derivadas de los rechazos, y generar el archivo de respuesta ordenado que se envia a la camara compensadora externa.

El job actua como orquestador: cada paso depende del resultado del anterior, de modo que un error grave en cualquier etapa detiene la cadena para evitar que datos incompletos o incorrectos avancen al siguiente proceso. La cadena completa debe ejecutarse despues de que el job de interfaces CCEJD005 haya cargado los datos de la camara compensadora externa (CCE); ese job pertenece a otro dominio y es un prerequisito externo que no forma parte de este archivo.

Cada paso es reiniciable de forma independiente mediante el mecanismo de control BCTCHECK, con la excepcion de que el paso de liquidacion de rechazos (CHQRECHA) no debe reiniciarse sin revisar previamente el estado de la tabla CHQ_RECHAZO en la base de datos.

## Process Flow

```mermaid
flowchart TD
    A("Inicio del job CHQJD010")
    B{{"BORRSAL: Eliminar archivo<br/>de salida previo de camara"}}
    C{{"CHQCHEQR: Emision de chequeras<br/>solicitadas pendientes"}}
    D{"RC de CHQCHEQR<br/><= 4?"}
    E{{"CHQCAMAR: Procesamiento de<br/>camara de compensacion<br/>(entrantes, salientes, canjes)"}}
    F{"RC de CHQCAMAR<br/><= 4?"}
    G{{"CHQRECHA: Liquidacion de rechazos<br/>(multas, comisiones, reincidencia)"}}
    H{{"SORTSAL: Ordenamiento del archivo<br/>de respuesta por lote y tipo"}}
    I[("SIDEP.CHQ.CAMARA.ENVIO<br/>Archivo ordenado listo para envio")]
    Z("Fin - Archivo de respuesta<br/>disponible para envio a camara")
    ERR1("Cadena detenida<br/>Error grave en emision")
    ERR2("Cadena detenida<br/>Error grave en camara")

    A --> B
    B --> C
    C --> D
    D --> |"Si - continua"| E
    D --> |"No - RC mayor a 4"| ERR1
    E --> F
    F --> |"Si - continua"| G
    F --> |"No - RC mayor a 4"| ERR2
    G --> H
    H --> I
    I --> Z
```

<!-- general-rule-start -->

## General Business Rules:

### Prerequisito externo

Antes de ejecutar este job, el job CCEJD005 del dominio de Interfaces debe haber completado la carga de los archivos de la camara compensadora externa (CCE). Este job no verifica ese prerequisito de forma automatica; es responsabilidad operativa garantizar el orden de ejecucion.

### Paso preliminar: eliminacion del archivo de salida anterior (BORRSAL)

Antes de iniciar cualquier proceso de negocio, el job elimina el archivo temporal SIDEP.CHQ.CAMARA.SALIDA si existe de una ejecucion previa. Esto garantiza que el proceso de camara del dia comience con un archivo de salida limpio. Si este paso falla (codigo de retorno distinto de cero), el paso siguiente de emision de chequeras no se ejecuta.

### Paso 1: Emision de chequeras (CHQCHEQR)

Este paso ejecuta el programa CHQCHEQR contra la base de datos DB2 de produccion (DB2P), usando el plan de acceso CHQPLAN. Lee los parametros de configuracion del miembro CHQPARM de la libreria de parametros SIDEP.PARM. Recibe como dato de entrada la fecha de proceso 20261106 y el identificador de entorno PDI.

El programa localiza todas las solicitudes de chequeras que se encuentran pendientes de emision y las procesa, generando fisicamente las chequeras solicitadas. Si alguna solicitud es rechazada (por ejemplo, por datos incorrectos o saldo insuficiente), el programa termina con codigo de retorno 4. Si ocurre un error mas grave, termina con un codigo superior a 4.

**Regla de continuacion:** el paso siguiente (CHQCAMAR) solo se ejecuta si el codigo de retorno de CHQCHEQR es 4 o menor. Un codigo de retorno mayor a 4 detiene la cadena completa.

### Paso 2: Procesamiento de la camara de compensacion (CHQCAMAR)

Este paso ejecuta el programa CHQCAMAR, tambien contra DB2P con el plan CHQPLAN y los mismos parametros de fecha y entorno. Procesa tres tipos de movimientos de la camara compensadora:

- **Cheques entrantes:** cheques recibidos de otros bancos para su acreditacion o rechazo en las cuentas propias.
- **Cheques salientes:** cheques emitidos contra cuentas propias y presentados por otros bancos para su cobro.
- **Canjes vencidos:** cheques que han superado su plazo de presentacion y deben ser gestionados como vencidos.

Como resultado, el programa genera el archivo SIDEP.CHQ.CAMARA.SALIDA (registros de longitud fija de 100 bytes, formato FB), que contiene la respuesta a enviar a la camara compensadora. Este archivo se crea nuevo en este paso; si el paso falla y se reintenta, el archivo se elimina automaticamente para evitar datos parciales.

**Regla de continuacion:** los pasos siguientes (CHQRECHA y SORTSAL) solo se ejecutan si el codigo de retorno de CHQCAMAR es 4 o menor.

### Paso 3: Liquidacion de rechazos (CHQRECHA)

Este paso ejecuta el programa CHQRECHA con los mismos parametros de conexion y fecha. Para cada cheque rechazado durante el procesamiento de la camara, el programa calcula y registra:

- **Multa por rechazo:** cargo aplicado al titular de la cuenta por el rechazo del cheque.
- **Comision:** cargo por gestion del rechazo.
- **Reincidencia:** identificacion y tratamiento especial para cuentas con rechazos repetidos, que pueden implicar cargos adicionales o restricciones.

**Advertencia operativa:** este paso no debe reiniciarse de forma automatica sin revisar previamente el estado de la tabla CHQ_RECHAZO en la base de datos, ya que una ejecucion parcial previa podria haber registrado cargos que se duplicarian en un nuevo intento.

### Paso 4: Ordenamiento del archivo de respuesta (SORTSAL)

Este paso toma el archivo SIDEP.CHQ.CAMARA.SALIDA generado en el Paso 2 y lo ordena para producir una nueva version del archivo SIDEP.CHQ.CAMARA.ENVIO, que se agrega como una nueva generacion del conjunto de datos (generacion +1, lo que preserva las versiones anteriores).

El criterio de ordenamiento es el siguiente, aplicado en este orden de prioridad:

1. **Campo de lote (posiciones 2 a 7 del registro, 6 caracteres, orden ascendente):** los registros se agrupan por numero de lote de menor a mayor.
2. **Campo de tipo (posicion 1 del registro, 1 caracter, orden descendente):** dentro de cada lote, los registros de tipo "D" (debitos) aparecen antes que los de tipo "T" (transferencias u otros), ya que en orden descendente la letra "T" es posterior a "D" en el alfabeto y queda al final.

El archivo resultante tiene registros de longitud fija de 100 bytes (formato FB) y queda disponible para su envio a la camara compensadora mediante SFTP (proceso externo a este job, que reemplazo al envio por cinta magnetica que estuvo vigente hasta el ano 2012).

### Gestion del archivo de envio historico

El paso de ordenamiento escribe siempre en una nueva generacion del archivo SIDEP.CHQ.CAMARA.ENVIO, preservando las generaciones anteriores. Esto permite recuperar el archivo de cualquier dia anterior si fuera necesario para auditorias o reenvios.

### Nota sobre el envio fisico a la camara

Existe un paso comentado (ENVCINTA) que copiaba el archivo de respuesta a una cinta magnetica con el nombre CCE.CHQ.RESPUESTA para su envio fisico a la camara. Este mecanismo fue reemplazado por transferencia SFTP en el ano 2012 y el paso quedo deshabilitado de forma permanente en el codigo. No debe eliminarse del job por razones de trazabilidad historica.

<!-- general-rule-end -->

## Dependencies

El trabajo CHQJD010 depende de varios programas, utilidades del sistema, bibliotecas compartidas, archivos de parametros, bases de datos y conjuntos de datos. A continuacion se describen cada una de estas dependencias y su relevancia para el proceso de modernizacion.

El trabajo utiliza el motor de base de datos DB2 en su instancia de produccion (DB2P) para todos los pasos de negocio. Los tres programas de aplicacion se conectan a DB2 mediante el subsistema TSO/E (IKJEFT01), que actua como lanzador de programas Cobol o PL/I con acceso a DB2. Todos comparten el mismo plan de acceso a base de datos (CHQPLAN), lo que significa que cualquier cambio en los objetos de base de datos que ese plan cubre afecta a los tres programas simultaneamente.

Los programas de aplicacion residen en la biblioteca de carga SIDEP.LOADLIB, que tambien se declara como STEPLIB en cada paso. Esta biblioteca debe estar disponible y actualizada antes de ejecutar el trabajo.

El archivo de parametros SIDEP.PARM(CHQPARM) es leido por los tres programas de aplicacion. Contiene la fecha de proceso y el codigo de entidad (en el ejemplo, el valor literal pasado via SYSIN es "20261106PDI", que representa la fecha 06/11/2026 y el identificador "PDI"). Cualquier cambio en la logica de parametrizacion debe reflejarse en este miembro.

El conjunto de datos SIDEP.CHQ.CAMARA.SALIDA es un archivo secuencial de registros de longitud fija de 100 bytes (RECFM=FB, LRECL=100) que el paso CHQCAMAR genera y el paso SORTSAL consume. Es un dato transitorio entre pasos del mismo trabajo.

El conjunto de datos generacional SIDEP.CHQ.CAMARA.ENVIO(+1) es el archivo de salida final del paso de ordenamiento. Utiliza una estructura de grupos de datos generacionales (GDG), por lo que debe existir la definicion del grupo base en el catalogo del sistema antes de ejecutar el trabajo.

La utilidad SORT (paso SORTSAL) es un programa del sistema operativo z/OS utilizado para ordenar el archivo de respuesta. No es un programa de desarrollo propio; es una utilidad estandar del entorno mainframe.

La utilidad IEFBR14 (paso BORRSAL) es una utilidad nula del sistema z/OS cuyo unico proposito es ejecutar las instrucciones de disposicion de los archivos declarados en el paso, en este caso eliminar el archivo SIDEP.CHQ.CAMARA.SALIDA si existia de una ejecucion anterior.

El trabajo tiene una dependencia de orden con el trabajo externo CCEJD005, perteneciente al dominio de interfaces. Ese trabajo realiza la carga de los datos de la Camara de Compensacion Electronica (CCE) en la base de datos. CHQJD010 no lo invoca ni lo controla; simplemente debe ejecutarse despues de que CCEJD005 haya concluido con exito. Esta dependencia es operativa y no esta codificada en el propio trabajo.

Existe ademas un bloque de codigo inactivo correspondiente al paso ENVCINTA (comentado en el fuente). Ese paso utilizaba la utilidad IEBGENER para copiar el archivo de respuesta a una cinta fisica con destino CCE.CHQ.RESPUESTA. Segun la nota en el codigo, este mecanismo estuvo vigente hasta 2012 y fue reemplazado por transferencia SFTP. El trabajo actual no realiza el envio fisico; ese proceso ocurre fuera de este trabajo por un mecanismo SFTP no especificado en el fuente proporcionado.

| Dependencia | Descripcion | Tipo | Referencia | Relevancia para Modernizacion |
|---|---|---|---|---|
| IKJEFT01 | Lanzador de programas TSO/E que permite ejecutar programas Cobol/PL/I con acceso a DB2 desde un trabajo por lotes | Utilidad del sistema z/OS | Modulo del sistema TSO/E | Debe reemplazarse por el mecanismo de invocacion de programas del entorno destino (por ejemplo, llamada directa o contenedor de ejecucion por lotes) |
| DB2P | Instancia de produccion del motor de base de datos DB2 | Base de datos relacional | Subsistema DB2P | Debe identificarse el esquema y los objetos accedidos por CHQPLAN para migrarlos al motor de base de datos del entorno destino |
| CHQPLAN | Plan de acceso a DB2 que agrupa los paquetes de los tres programas de aplicacion | Plan DB2 | CHQPLAN en DB2P | Debe recompilarse o equivalerse en el entorno destino; cualquier cambio en tablas o indices afecta a los tres programas |
| CHQCHEQR | Programa de emision de chequeras solicitadas | Programa de aplicacion | SIDEP.LOADLIB(CHQCHEQR) | Debe migrarse o reescribirse; su codigo fuente no esta incluido en los archivos proporcionados |
| CHQCAMAR | Programa de procesamiento de la camara de compensacion | Programa de aplicacion | SIDEP.LOADLIB(CHQCAMAR) | Debe migrarse o reescribirse; su codigo fuente no esta incluido en los archivos proporcionados |
| CHQRECHA | Programa de liquidacion de rechazos, multas y comisiones | Programa de aplicacion | SIDEP.LOADLIB(CHQRECHA) | Debe migrarse o reescribirse; su codigo fuente no esta incluido en los archivos proporcionados |
| SIDEP.LOADLIB | Biblioteca de carga que contiene los modulos ejecutables de los tres programas de aplicacion | Biblioteca de ejecutables | SIDEP.LOADLIB | Debe reemplazarse por el repositorio de ejecutables del entorno destino |
| SIDEP.PARM(CHQPARM) | Miembro de parametros que contiene la fecha de proceso y el identificador de entidad | Archivo de parametros | SIDEP.PARM(CHQPARM) | Debe reemplazarse por el mecanismo de parametrizacion del entorno destino; el formato y el contenido deben documentarse con los programas que lo leen |
| SIDEP.CHQ.CAMARA.SALIDA | Archivo secuencial transitorio de 100 bytes por registro generado por CHQCAMAR y consumido por SORTSAL | Archivo de datos secuencial | SIDEP.CHQ.CAMARA.SALIDA | Debe reemplazarse por un mecanismo de transferencia de datos entre pasos del entorno destino (archivo temporal, tabla de base de datos o cola) |
| SIDEP.CHQ.CAMARA.ENVIO | Grupo de datos generacional (GDG) que almacena el archivo de respuesta ordenado listo para envio a la camara | Archivo de datos generacional (GDG) | SIDEP.CHQ.CAMARA.ENVIO | Debe reemplazarse por el mecanismo de archivos de salida del entorno destino; la logica de generaciones debe reproducirse si se requiere historial |
| SORT (utilidad) | Utilidad estandar de z/OS para ordenar registros de archivos secuenciales | Utilidad del sistema z/OS | PGM=SORT | Debe reemplazarse por la funcion de ordenamiento equivalente del entorno destino; la clave de ordenamiento es: campo de posicion 2 longitud 6 ascendente, luego campo de posicion 1 longitud 1 descendente |
| IEFBR14 | Utilidad nula de z/OS usada exclusivamente para eliminar el archivo SIDEP.CHQ.CAMARA.SALIDA al inicio del trabajo | Utilidad del sistema z/OS | PGM=IEFBR14 | Debe reemplazarse por la instruccion de borrado o inicializacion de archivo equivalente en el entorno destino |
| CCEJD005 | Trabajo externo del dominio de interfaces que carga los datos CCE en la base de datos antes de que este trabajo pueda ejecutarse | Trabajo por lotes externo (dependencia operativa) | JOB CCEJD005 - dominio de interfaces | Debe incorporarse como precondicion en el planificador de trabajos del entorno destino; no existe control programatico en CHQJD010 |
| IEBGENER (inactivo) | Utilidad de copia de archivos usada hasta 2012 para enviar la respuesta a la camara en cinta fisica; el paso esta comentado y no se ejecuta | Utilidad del sistema z/OS (inactiva) | Paso ENVCINTA (comentado) | No requiere migracion; el mecanismo de envio actual es SFTP y debe documentarse por separado fuera de este trabajo |

## Data Structure

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| SYSIN-DATE | Fecha de proceso | Alfanumerico | 8 | Fecha de ejecucion del proceso en formato AAAAMMDD. El valor concreto presente en el codigo es 20261106, correspondiente al 6 de noviembre de 2026. Se pasa como parametro de entrada a los programas CHQCHEQR, CHQCAMAR y CHQRECHA. | Si | N/A | El mismo valor de fecha se replica identicamente en los tres pasos de ejecucion (CHQCHEQR, CHQCAMAR y CHQRECHA). En una modernizacion, este valor deberia obtenerse dinamicamente de la fecha del sistema o de un parametro centralizado, en lugar de estar codificado de forma fija. | Si | Fecha de proceso |
| SYSIN-ENV | Entorno de proceso | Alfabetico | 3 | Codigo de entorno que acompana a la fecha en el parametro de entrada. El valor presente es PDI, que identifica el entorno de ejecucion (por ejemplo, produccion). Se concatena inmediatamente despues de la fecha, formando la cadena completa de 11 caracteres: 20261106PDI. | Si | N/A | Aparece en los tres pasos. En una modernizacion debe gestionarse como variable de entorno o parametro de configuracion separado de la fecha. | Si | Parametro de control |
| CAMSAL-REC | Registro de salida de camara | Alfanumerico | 100 | Registro de longitud fija de 100 bytes que conforma el archivo de respuesta a la Camara de Compensacion. Es producido por el programa CHQCAMAR y posteriormente ordenado. El byte 1 contiene el tipo de registro (campo TIPO-REG); los bytes 2 a 7 contienen el identificador de lote (campo LOTE-ID). | Si | N/A | El formato es de registros de longitud fija (RECFM=FB, LRECL=100). La estructura interna completa de los 100 bytes no se detalla en el JCL; debe obtenerse del copybook o diccionario de datos del programa CHQCAMAR. | Si | Registro de intercambio |
| TIPO-REG | Tipo de registro | Alfabetico | 1 | Primer byte de cada registro del archivo de salida de camara. Determina el orden de los registros dentro de cada lote al momento del ordenamiento. El valor D (detalle) se posiciona antes que el valor T (totales o trailer) en el archivo final de envio. | Si | N/A | La clave de ordenamiento secundario es este campo (posicion 1, longitud 1, orden descendente), lo que garantiza que D preceda a T dentro de cada lote. En una modernizacion, esta logica de ordenamiento debe replicarse explicitamente. | Si | Clave de ordenamiento |
| LOTE-ID | Identificador de lote | Alfanumerico | 6 | Bytes 2 a 7 de cada registro del archivo de salida de camara. Identifica el lote al que pertenece el registro. Es la clave de ordenamiento primaria del archivo de envio a la camara (orden ascendente). | Si | N/A | El ordenamiento final agrupa primero por LOTE-ID ascendente y luego por TIPO-REG descendente (D antes que T). En una modernizacion, ambas claves deben respetarse en el proceso de ordenamiento equivalente. | Si | Clave de ordenamiento |
| CHQPARM | Parametros del sistema CHQ | Alfanumerico | N/A | Miembro de parametros del sistema SIDEP dominio CHQ, almacenado en la libreria de parametros SIDEP.PARM bajo el nombre CHQPARM. Es referenciado por los tres programas principales (CHQCHEQR, CHQCAMAR y CHQRECHA) como fuente de configuracion del proceso. | Si | N/A | El contenido interno del miembro CHQPARM no se detalla en el JCL. En una modernizacion, su contenido debe relevarse directamente del archivo fuente para identificar todos los parametros de configuracion que controlan el comportamiento de los tres programas. | Si | Parametro de configuracion |

## Detailed Rules

<!-- rule-start -->
### 1. Rule / Operation - BORRSAL: Borrado del archivo de salida de camara
<!-- reviewed -->

_Reviewed_

**Rule Status:** Relevant for Modernization

**Algorithm**

El primer paso del proceso se ejecuta de forma incondicional al inicio del trabajo. Su única función es eliminar el archivo de salida de cámara si este existe de una ejecución anterior, dejando el entorno limpio antes de que comience el procesamiento real.

El archivo que se elimina es **SIDEP.CHQ.CAMARA.SALIDA**, que es el archivo intermedio donde el paso de cámara de compensación escribirá los registros de respuesta. Se define con formato de registro fijo bloqueado (RECFM=FB), longitud de registro de 100 bytes y un espacio inicial de 1 cilindro con extensión de 1 cilindro adicional.

La disposición del archivo (MOD,DELETE,DELETE) indica que se abre en modo de extensión y se borra al finalizar el paso tanto si este termina correctamente como si termina con error. Si el archivo no existía previamente, el paso simplemente no realiza ninguna acción sobre él. El programa utilizado (IEFBR14) es un utilitario estándar del sistema operativo que no ejecuta ninguna lógica de negocio por sí mismo; su único propósito es que el sistema operativo procese las definiciones de archivos adjuntas, ejecutando en este caso la eliminación.

El código de retorno de este paso es relevante para el paso inmediatamente siguiente: si este paso termina con un código de retorno distinto de cero, el paso **CHQCHEQR** (emisión de chequeras) no se ejecuta, y por extensión toda la cadena se detiene, ya que los pasos posteriores dependen a su vez del resultado de CHQCHEQR o de CHQCAMAR.

1. Ejecutar el paso BORRSAL de forma incondicional, sin ninguna condición previa.
2. Apuntar al archivo **SIDEP.CHQ.CAMARA.SALIDA** con disposición (MOD,DELETE,DELETE): abrirlo en modo extensión y marcarlo para borrado tanto en terminación normal como en terminación con error.
3. Si el archivo existe en el catálogo del sistema, eliminarlo del catálogo y liberar el espacio físico que ocupa.
4. Si el archivo no existe, no realizar ninguna acción adicional.
5. Registrar el código de retorno del paso. Si es distinto de cero, la cadena completa se interrumpe: el paso CHQCHEQR no se ejecuta y, en consecuencia, tampoco se ejecutan los pasos CHQCAMAR, CHQRECHA ni SORTSAL.
<!-- rule-end -->

<!-- rule-start -->
### 2. Rule / Operation - CHQCHEQR: Emision de chequeras solicitadas
<!-- reviewed -->

_Reviewed_

**Rule Status:** Relevant for Modernization

**Algorithm**

Este paso ejecuta el programa **CHQCHEQR** conectado a la base de datos **DB2P** bajo el plan **CHQPLAN**. Su función de negocio es procesar todas las solicitudes de chequeras pendientes y emitir las chequeras correspondientes.

Este paso solo se ejecuta si el paso anterior **BORRSAL** terminó con código de retorno igual a cero (`COND=(0,NE,BORRSAL)` se interpreta como: omitir este paso si el código de retorno de BORRSAL es distinto de cero). Si BORRSAL terminó con cualquier código distinto de cero, este paso se omite y la cadena se detiene.

El paso recibe como entrada un parámetro de fecha/entorno a través del archivo **SYSIN**, cuyo valor en la versión documentada es **20261106PDI**. Este valor se interpreta como la fecha de proceso (6 de noviembre de 2026) seguida del identificador de entorno (**PDI**). El programa también accede al archivo de parámetros generales del sistema a través de la DD **PARMCHQ**, que apunta al conjunto de datos **SIDEP.PARM(CHQPARM)**.

El código de retorno de este paso determina si la cadena puede continuar hacia el paso de cámara de compensación:
- Código **0**: todo correcto; la cadena continúa normalmente.
- Código **4**: hubo solicitudes rechazadas durante la emisión, pero el paso se considera exitoso a efectos de continuar la cadena. El paso siguiente (**CHQCAMAR**) se ejecuta igualmente, ya que su condición de omisión es `COND=(4,LT,CHQCHEQR)`, es decir, se omite solo si el código de retorno es estrictamente mayor que 4.
- Código **mayor que 4**: error grave. El paso **CHQCAMAR** y todos los pasos posteriores (**CHQRECHA** y **SORTSAL**) se omiten y la cadena se interrumpe.

La lógica interna de CHQCHEQR no está disponible en los archivos suministrados. Solo se conoce lo que el paso recibe: la fecha y entorno de proceso (**20261106PDI** vía SYSIN) y el archivo de parámetros (**CHQPARM**). El llamador trata un código de retorno de 4 como una condición de advertencia tolerable (solicitudes rechazadas) y cualquier valor superior como un error que impide continuar.

1. Verificar que el paso **BORRSAL** haya terminado con código de retorno igual a cero. Si el código de retorno de BORRSAL es distinto de cero, omitir este paso y detener la cadena.
2. Conectarse a la base de datos **DB2P** usando el plan **CHQPLAN**, cargando el programa desde la librería **SIDEP.LOADLIB**.
3. Leer el archivo de parámetros **SIDEP.PARM(CHQPARM)** a través de la DD **PARMCHQ**.
4. Leer el valor de **SYSIN**: **20261106PDI**, donde los primeros 8 caracteres son la fecha de proceso en formato AAAAMMDD (20261106 = 6 de noviembre de 2026) y los tres caracteres siguientes (**PDI**) identifican el entorno de ejecución.
5. Ejecutar el programa **CHQCHEQR** con esos parámetros. La lógica interna del programa no está disponible; se conoce únicamente que procesa solicitudes de chequeras pendientes y las emite.
6. Evaluar el código de retorno:
   - Si es **0**: continuar normalmente hacia el paso **CHQCAMAR**.
   - Si es **4**: registrar la condición de advertencia (solicitudes rechazadas) y permitir que la cadena continúe hacia **CHQCAMAR**, ya que un código de retorno de 4 no supera el umbral de corte (`4,LT` equivale a omitir solo si el código es estrictamente mayor que 4).
   - Si es **mayor que 4**: detener la cadena; los pasos **CHQCAMAR**, **CHQRECHA** y **SORTSAL** no se ejecutan.
<!-- rule-end -->

<!-- rule-start -->
### 3. Rule / Operation - CHQCAMAR: Procesamiento de la camara de compensacion
<!-- reviewed -->

_Reviewed_

**Rule Status:** Relevant for Modernization

**Algorithm**

Este paso ejecuta el programa **CHQCAMAR** conectado a la base de datos **DB2P** bajo el plan **CHQPLAN**, cargado desde la biblioteca **SIDEP.LOADLIB**. Su función de negocio es procesar la cámara de compensación del día, abarcando tres tipos de operaciones: cheques entrantes (recibidos de otras entidades), cheques salientes (enviados a otras entidades) y canjes vencidos.

Este paso solo se ejecuta si el paso **CHQCHEQR** terminó con código de retorno **estrictamente menor que 4** (es decir, 0, 1, 2 o 3). La condición de ejecución es `COND=(4,LT,CHQCHEQR)`, lo que significa que el paso se omite si el código de retorno de CHQCHEQR es **igual o mayor que 4**. Dicho de otro modo, un código de retorno igual a 4 en CHQCHEQR ya es suficiente para que este paso no se ejecute.

Al igual que el paso anterior, recibe como entrada el valor **20261106PDI** a través de SYSIN (fecha 6 de noviembre de 2026, entorno PDI) y accede al archivo de parámetros **SIDEP.PARM(CHQPARM)** a través de la DD **PARMCHQ**.

Este paso es el único que crea el archivo de salida **SIDEP.CHQ.CAMARA.SALIDA**, que fue eliminado en el paso BORRSAL. El archivo se crea con formato de registro fijo (RECFM=FB), longitud de registro de 100 bytes y un espacio inicial de 5 cilindros con extensión de 5 cilindros adicionales. Al finalizar el paso, si este terminó correctamente, el archivo queda catalogado en el sistema; si el paso falla, el archivo se elimina automáticamente.

El código de retorno de este paso determina si los pasos siguientes (CHQRECHA y SORTSAL) se ejecutan. Ambos pasos comparten la misma condición de ejecución `COND=(4,LT,CHQCAMAR)`, es decir, se omiten si el código de retorno de CHQCAMAR es **igual o mayor que 4**:

- **Código 0, 1, 2 o 3:** la cadena continúa hacia CHQRECHA y SORTSAL.
- **Código igual a 4 o mayor que 4:** error o advertencia no tolerable. Los pasos CHQRECHA y SORTSAL se omiten.

La lógica interna de CHQCAMAR no está disponible en los archivos suministrados. Se sabe que escribe registros de 100 bytes en el archivo SIDEP.CHQ.CAMARA.SALIDA y que los únicos códigos de retorno que permiten la continuación de la cadena son los estrictamente menores que 4.

1. Verificar que el paso CHQCHEQR haya terminado con código de retorno **estrictamente menor que 4** (0, 1, 2 o 3). Si el código fue igual a 4 o mayor, omitir este paso completamente.
2. Conectarse a la base de datos **DB2P** usando el plan **CHQPLAN**, cargando el programa desde la biblioteca **SIDEP.LOADLIB**.
3. Leer el archivo de parámetros **SIDEP.PARM(CHQPARM)** a través de la DD **PARMCHQ**.
4. Leer el valor de SYSIN: **20261106PDI** (fecha 20261106, entorno PDI).
5. Crear el archivo de salida **SIDEP.CHQ.CAMARA.SALIDA** con registros de longitud fija de 100 bytes, espacio inicial de 5 cilindros y extensión de 5 cilindros adicionales. Si el paso falla, este archivo debe eliminarse automáticamente; si concluye con éxito, queda catalogado.
6. Ejecutar el programa CHQCAMAR. La lógica interna no está disponible; se conoce que procesa cheques entrantes, cheques salientes y canjes vencidos, y escribe los resultados en el archivo de salida **SIDEP.CHQ.CAMARA.SALIDA**.
7. Evaluar el código de retorno:
   - Si es **estrictamente menor que 4** (0, 1, 2 o 3): la cadena continúa; los pasos CHQRECHA y SORTSAL se ejecutan.
   - Si es **igual a 4 o mayor que 4**: la cadena se interrumpe; los pasos CHQRECHA y SORTSAL se omiten.
<!-- rule-end -->

<!-- rule-start -->
### 4. Rule / Operation - CHQRECHA: Liquidacion de rechazos (multa, comision, reincidencia)
<!-- reviewed -->

_Reviewed_

**Rule Status:** Relevant for Modernization

Este paso ejecuta el programa **CHQRECHA** conectado a la base de datos **DB2P** bajo el plan **CHQPLAN**. Su función de negocio es liquidar las consecuencias económicas de los cheques rechazados durante el procesamiento de cámara: cálculo y aplicación de multas, cobro de comisiones y tratamiento de la reincidencia.

Este paso solo se ejecuta si el paso **CHQCAMAR** terminó con código de retorno **menor o igual a 4** (es decir, la condición de omisión es: si 4 es menor que el código de retorno de CHQCAMAR, el paso se omite). Si CHQCAMAR terminó con código de retorno mayor que 4, este paso no se ejecuta.

Recibe como entrada el valor **20261106PDI** a través de SYSIN — donde **20261106** representa la fecha de proceso y **PDI** identifica el entorno de ejecución — y accede al archivo de parámetros **SIDEP.PARM(CHQPARM)** a través de la DD **PARMCHQ**.

La documentación del trabajo advierte expresamente que **no se debe reiniciar este paso sin revisar previamente el estado de la tabla CHQ_RECHAZO**. Esto indica que el paso modifica datos en esa tabla de base de datos y que una ejecución duplicada o un reinicio sin control podría generar registros duplicados o liquidaciones incorrectas. Esta advertencia es un hallazgo crítico para la modernización: el proceso de reinicio debe incluir un mecanismo de verificación del estado de CHQ_RECHAZO antes de volver a ejecutar este paso.

La lógica interna de CHQRECHA no está disponible en los archivos suministrados. Se conoce que opera sobre la tabla **CHQ_RECHAZO**, aplica multas, comisiones y tratamiento de reincidencia a los cheques rechazados, y que acepta el código 4 como advertencia tolerable para la continuación de la cadena.

**Algorithm**

1. Verificar que el paso **CHQCAMAR** haya terminado con código de retorno **menor o igual a 4**. Si el código de retorno de CHQCAMAR fue mayor que 4, omitir completamente este paso.
2. Antes de ejecutar, si se trata de un reinicio, verificar manualmente el estado de la tabla **CHQ_RECHAZO** para determinar si el paso ya fue ejecutado parcial o totalmente en un intento anterior. No continuar sin esta verificación.
3. Conectarse a la base de datos **DB2P** usando el plan **CHQPLAN**, cargando el programa desde la biblioteca **SIDEP.LOADLIB**.
4. Leer el archivo de parámetros **SIDEP.PARM(CHQPARM)** a través de la DD **PARMCHQ**.
5. Leer el valor de SYSIN: **20261106PDI** (fecha de proceso **20261106**, entorno **PDI**).
6. Ejecutar el programa **CHQRECHA**. La lógica interna no está disponible en los archivos suministrados; se conoce que procesa los rechazos del día liquidando multas, comisiones y reincidencia, y que escribe o actualiza registros en la tabla **CHQ_RECHAZO**.
7. Evaluar el código de retorno de este paso:
   - Si es **0 o 4**: el paso completó correctamente o con advertencias tolerables. La cadena continúa normalmente.
   - Si es **mayor que 4**: el paso terminó en error. Sin embargo, el paso siguiente **SORTSAL** puede ejecutarse de todas formas, ya que su condición de omisión depende exclusivamente del código de retorno de **CHQCAMAR** y no del código de retorno de este paso (ver regla SORTSAL).
<!-- rule-end -->

<!-- rule-start -->
### 5. Rule / Operation - SORTSAL: Ordenacion del archivo de respuesta para envio a camara
<!-- reviewed -->

_Reviewed_

**Rule Status:** Relevant for Modernization

Este paso ejecuta el programa utilitario de ordenación **SORT** del sistema. Su función es tomar el archivo de salida generado por CHQCAMAR (**SIDEP.CHQ.CAMARA.SALIDA**) y producir una versión ordenada del mismo en una nueva generación del archivo generacional **SIDEP.CHQ.CAMARA.ENVIO**, lista para ser enviada a la cámara de compensación.

Este paso solo se ejecuta si el paso CHQCAMAR terminó con código de retorno igual o menor a 4. Si el código de retorno de CHQCAMAR fue mayor que 4, este paso se omite. La condición de ejecución depende exclusivamente de CHQCAMAR, no de CHQRECHA. Esto significa que SORTSAL puede ejecutarse aunque CHQRECHA haya fallado o no se haya ejecutado.

**Criterio de ordenación:** Los registros del archivo se ordenan aplicando dos claves de ordenación en secuencia:

1. **Primera clave (primaria):** Posición 2 a 7 del registro (6 bytes de longitud), tipo carácter (CH), orden ascendente (A). Según el contexto del proceso, este campo corresponde al número de lote o identificador de lote del cheque dentro del archivo de cámara.
2. **Segunda clave (secundaria):** Posición 1 a 1 del registro (1 byte de longitud), tipo carácter (CH), orden descendente (D). Este campo corresponde al tipo de registro. El comentario del JCL indica que los registros de tipo "D" deben aparecer antes que los de tipo "T". Sin embargo, dado que el criterio de ordenación es descendente y "T" tiene un valor ASCII mayor que "D", la ordenación descendente coloca primero los registros de tipo "T" y luego los de tipo "D". La implementación debe respetar el criterio de ordenación tal como está codificado (descendente), siendo el resultado real T antes que D dentro de cada grupo de lote. **Este punto debe ser aclarado con el área de negocio durante la modernización**, ya que existe una contradicción entre el comentario del JCL y el comportamiento real de la ordenación.

El archivo de entrada es **SIDEP.CHQ.CAMARA.SALIDA**, accedido en modo compartido y solo lectura, con registros de formato fijo bloqueado (RECFM=FB) y longitud de registro de 100 bytes. El archivo de salida es la siguiente generación del dataset generacional **SIDEP.CHQ.CAMARA.ENVIO** (generación +1), es decir, se crea una nueva versión del archivo manteniendo las versiones anteriores según la política del grupo generacional. El archivo de salida tiene formato de registro fijo bloqueado (RECFM=FB), longitud de registro de 100 bytes, y se asigna un espacio inicial de 5 cilindros con extensión de 5 cilindros adicionales, liberando el espacio no utilizado al cierre. Si el paso falla, el archivo de salida recién creado se elimina automáticamente.

Cabe señalar que el paso de envío físico a la cámara mediante cinta magnética (que copiaba el archivo **SIDEP.CHQ.CAMARA.ENVIO(0)** a la cinta **CCE.CHQ.RESPUESTA**) quedó deshabilitado cuando el envío migró a SFTP en 2012. Ese paso comentado no debe eliminarse del JCL como referencia histórica.

**Algorithm**

1. Verificar que el paso CHQCAMAR haya terminado con código de retorno igual o menor a 4. Si el código fue mayor que 4, omitir este paso completamente.
2. Leer todos los registros del archivo **SIDEP.CHQ.CAMARA.SALIDA** en modo compartido. Cada registro tiene una longitud fija de 100 bytes.
3. Ordenar los registros aplicando las siguientes claves en orden de prioridad:
   a. **Clave primaria:** Extraer los bytes en las posiciones 2 a 7 (inclusive) de cada registro (6 bytes). Ordenar estos valores en orden ascendente (de menor a mayor valor de cadena de caracteres). Este campo representa el identificador de lote del cheque en el archivo de cámara.
   b. **Clave secundaria:** Extraer el byte en la posición 1 de cada registro (1 byte). Ordenar este valor en orden descendente (de mayor a menor valor de cadena de caracteres). El efecto práctico es que, dentro de cada grupo definido por la clave primaria, los registros cuyo primer byte tiene mayor valor ASCII aparecerán primero. Dado que "T" tiene mayor valor ASCII que "D", los registros de tipo "T" precederán a los de tipo "D", en contradicción con el comentario del JCL que indica lo contrario. Este comportamiento debe ser validado con el área de negocio.
4. Escribir los registros ordenados en el archivo de salida **SIDEP.CHQ.CAMARA.ENVIO**, creando una nueva generación (+1) del grupo generacional, con formato de registro fijo bloqueado (RECFM=FB) y longitud de 100 bytes. Si el paso falla, eliminar automáticamente el archivo de salida recién creado.
<!-- rule-end -->

<!-- rule-start -->
### 6. Rule / Operation - ENVCINTA: Envio fisico a camara por cinta (paso inactivo)
<!-- reviewed -->

_Reviewed_

**Rule Status:** Irrelevant for Modernization

Este paso está completamente comentado en el código fuente y por lo tanto **no se ejecuta**. No forma parte del procesamiento activo del trabajo.

Históricamente, hasta el año 2012, el archivo de respuesta a la cámara de compensación se enviaba físicamente en cinta magnética. El paso copiaba el archivo **SIDEP.CHQ.CAMARA.ENVIO(0)** (la generación más reciente del grupo generacional) a una cinta con el nombre de conjunto de datos **CCE.CHQ.RESPUESTA**, manteniéndola con disposición `KEEP` tras la ejecución. A partir de 2012, el envío pasó a realizarse mediante SFTP, y este paso fue desactivado. El mecanismo actual de envío por SFTP no está representado en este trabajo JCL.

La documentación del trabajo incluye una nota explícita indicando que este paso **no debe ser eliminado**, posiblemente por razones de trazabilidad histórica o como referencia de la estructura del archivo de envío.

**Algorithm**

Este paso no tiene algoritmo activo. Su comportamiento histórico consistía en una copia directa del archivo de salida ordenado al soporte en cinta, sin transformación ni filtrado del contenido: el archivo **SIDEP.CHQ.CAMARA.ENVIO(0)**, generado y ordenado por el paso SORTSAL (registros de formato fijo bloqueado, longitud de registro 100 bytes), se copiaba íntegramente como archivo de destino **CCE.CHQ.RESPUESTA** en unidad de cinta, conservando la cinta tras la ejecución. El proceso de envío del archivo a la cámara de compensación se realiza actualmente mediante SFTP, fuera del alcance de este trabajo JCL.
<!-- rule-end -->

---

## Extraction metadata

- **Main file:** jcl/CHQJD010.jcl
- **Created:** 2026-11-08 15:59:28 UTC
- **Started:** 2026-11-08 15:59:28 UTC
- **Duration:** 00:39:06
- **LLM:** us.anthropic.claude-sonnet-4-6 (us.anthropic.claude-sonnet-4-6)
- **Context window:** 200000 tokens · **Max output:** 64000 tokens
- **Extraction prompt:** business_rules_extraction · **Reviewer prompt:** business_rules_reviewer
- **Token usage:** 53171 total (37143 input, 16028 output)
