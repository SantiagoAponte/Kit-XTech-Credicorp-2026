# 23-ddl-chq.sql: Definicion de Tablas del Dominio de Cheques y Compensacion (CHQ)

## Overview

Este archivo define la estructura de datos permanente del dominio CHQ (Cheques y Compensacion) dentro del sistema SIDEP (Sistema Integrado de Depositos) del Banco Andes del Peru. Su unico proposito es crear las tablas de base de datos, sus indices y los espacios de almacenamiento fisico que soportan todos los procesos relacionados con chequeras, cheques individuales, camara de compensacion, rechazos y cheques de gerencia.

El archivo no contiene logica de negocio ejecutable ni procedimientos; es una declaracion de estructuras. Las reglas de negocio que gobiernan el uso de estas tablas estan documentadas como comentarios de referencia dentro del propio archivo y se aplican en los modulos de proceso CHQVALCH y CHQGEREN, que son los unicos autorizados a leer y escribir estas tablas. Ningun otro dominio del sistema accede directamente a ellas.

El archivo establece seis tablas principales que cubren el ciclo de vida completo de un cheque: desde la solicitud de una chequera, su emision y entrega, la presentacion de cheques a camara de compensacion, el registro de rechazos con sus cargos asociados, hasta la emision y pago de cheques de gerencia. Las tablas se distribuyen en dos espacios de almacenamiento fisico (TSCHQ01 y TSCHQ02) dentro de la base de datos DBSIDEP, separando los datos maestros de chequeras de los datos transaccionales de mayor volumen.

## Process Flow

Este archivo define unicamente estructuras de datos (tablas e indices) y no ejecuta ningun proceso. No existe un flujo de proceso que diagramar.

<!-- general-rule-start -->

## General Business Rules:

### Espacios de Almacenamiento Fisico

Se crean dos espacios de almacenamiento (tablespaces) dentro de la base de datos DBSIDEP, ambos usando el grupo de almacenamiento SGSIDEP con bloqueo a nivel de fila y segmentos de 32 paginas:

- **TSCHQ01**: Espacio de menor volumen (espacio primario 7200, secundario 720, pool BP1). Aloja las tablas de datos maestros y de menor crecimiento: solicitudes de chequera, chequeras emitidas y cheques de gerencia.
- **TSCHQ02**: Espacio de mayor volumen (espacio primario 14400, secundario 1440, pool BP2). Aloja las tablas transaccionales de alto volumen: cheques individuales, presentaciones a camara y rechazos.

### Tabla CHQ_SOLICITUD - Solicitudes de Chequera

Registra cada pedido de chequera realizado por un cliente a traves de un canal o agencia. Cada solicitud tiene un numero unico (NUM_SOLICITUD, numerico de 9 digitos) que es su clave primaria.

Los campos principales son:
- **CTA_NUMERO** (14 caracteres): numero de cuenta corriente del solicitante.
- **CANT_CHEQUERAS** (entero corto, por defecto 1): cantidad de chequeras pedidas en la solicitud. La regla RN-CHQ-03 establece que el minimo es 1 y el maximo es 3.
- **FEC_SOLICITUD**: fecha en que se registro la solicitud.
- **CANAL** (2 caracteres): identificador del canal de atencion (por ejemplo, ventanilla, banca en linea).
- **COD_USUARIO** (8 caracteres): codigo del operador que registro la solicitud.
- **EST_SOLICITUD** (2 caracteres, por defecto 'SO'): estado actual de la solicitud. El valor inicial es 'SO' (solicitada).
- **COD_RECHAZO** (2 caracteres, opcional): codigo que explica por que fue rechazada la solicitud, si aplica.
- **MON_COSTO_BASE** (decimal 9,2, por defecto 0): importe base cobrado por la chequera antes de impuestos.
- **MON_IGV** (decimal 9,2, por defecto 0): monto del Impuesto General a las Ventas calculado sobre el costo base.
- **MON_COSTO_TOTAL** (decimal 9,2, por defecto 0): importe total cobrado al cliente, resultado de sumar MON_COSTO_BASE mas MON_IGV.
- **FEC_PROCESO** (opcional): fecha en que la solicitud fue procesada (aprobada o rechazada).

**Reglas de negocio asociadas:**
- RN-CHQ-01: Solo se admiten solicitudes para cuentas corrientes activas (producto 06).
- RN-CHQ-02: Una cuenta no puede tener mas de 2 chequeras en estado vigente (emitida 'EM' o entregada 'EN') al mismo tiempo.
- RN-CHQ-03: Cada solicitud puede incluir entre 1 y 3 chequeras.

Se crean dos indices: uno unico sobre NUM_SOLICITUD (busqueda directa) y uno compuesto sobre EST_SOLICITUD y NUM_SOLICITUD (para consultar solicitudes por estado).

### Tabla CHQ_CHEQUERA - Chequeras Emitidas

Registra cada chequera fisica emitida para una cuenta. La clave primaria es NUM_CHEQUERA (numerico de 9 digitos).

Los campos principales son:
- **CTA_NUMERO** (14 caracteres): cuenta a la que pertenece la chequera.
- **NUM_SOLICITUD** (numerico de 9 digitos): referencia a la solicitud que origino esta chequera.
- **NUM_INICIAL** y **NUM_FINAL** (numericos de 8 digitos): primer y ultimo numero de cheque incluidos en la chequera. La regla RN-CHQ-05 establece que la numeracion es correlativa por cuenta.
- **CANT_HOJAS** (entero corto, por defecto 25): cantidad de hojas (cheques) en la chequera. El valor estandar es 25.
- **EST_CHEQUERA** (2 caracteres): estado actual de la chequera. Los valores posibles son: SO (solicitada), EM (emitida), EN (entregada al cliente), AG (agotada), AN (anulada), BL (bloqueada).
- **FEC_EMISION**: fecha en que se emitio la chequera.
- **FEC_ENTREGA** (opcional): fecha en que se entrego fisicamente al cliente.
- **IND_GRATUITA** (1 caracter, por defecto 'N'): indica si la chequera es gratuita ('S') o tiene costo ('N'). La regla RN-CHQ-04 establece que la primera chequera de una cuenta no tiene costo.
- **COD_MONEDA** (3 caracteres): moneda de la chequera (por ejemplo, PEN, USD).

Se crean dos indices: uno unico sobre NUM_CHEQUERA y uno compuesto sobre CTA_NUMERO y EST_CHEQUERA (para consultar las chequeras activas de una cuenta).

### Tabla CHQ_CHEQUE - Hojas de Cheque Individuales

Registra un registro por cada hoja de cheque perteneciente a una chequera. La clave primaria es la combinacion de CTA_NUMERO y NUM_CHEQUE, lo que garantiza que un numero de cheque es unico dentro de una cuenta.

Los campos principales son:
- **CTA_NUMERO** (14 caracteres): cuenta a la que pertenece el cheque.
- **NUM_CHEQUE** (numerico de 8 digitos): numero impreso en la hoja de cheque.
- **NUM_CHEQUERA** (numerico de 9 digitos): referencia a la chequera a la que pertenece esta hoja.
- **EST_CHEQUE** (2 caracteres, por defecto 'DI'): estado actual del cheque. Los valores posibles son: DI (disponible), PR (presentado a cobro), PA (pagado), RE (rechazado), NP (orden de no pago vigente), AN (anulado).
- **MON_IMPORTE** (decimal 15,2, por defecto 0): importe por el que fue girado el cheque.
- **FEC_GIRO** (opcional): fecha en que el cliente emitio el cheque.
- **FEC_ESTADO** (opcional): fecha del ultimo cambio de estado.
- **COD_MOTIVO** (2 caracteres, opcional): codigo del motivo del ultimo cambio de estado (por ejemplo, motivo de rechazo).

**Regla de negocio asociada:**
- RN-CHQ-10: Un cheque en estado 'PA' (pagado) no puede volver a ser pagado. El estado pagado es terminal para el pago.

Se crean dos indices: uno unico sobre la clave primaria (CTA_NUMERO, NUM_CHEQUE) y uno sobre NUM_CHEQUERA (para consultar todos los cheques de una chequera).

### Tabla CHQ_PRESENTACION - Presentaciones a Camara de Compensacion

Registra cada cheque presentado al proceso de camara de compensacion interbancaria. La clave primaria es la combinacion de NUM_LOTE y NUM_SECUENCIA, que identifica univocamente un cheque dentro de un lote de compensacion.

Los campos principales son:
- **NUM_LOTE** (numerico de 6 digitos): identificador del lote de compensacion, agrupado por fecha de presentacion (regla RN-CHQ-20).
- **NUM_SECUENCIA** (numerico de 7 digitos): posicion del cheque dentro del lote.
- **TIP_ORIGEN** (1 caracter): indica la direccion del cheque en la compensacion. 'E' (entrante) significa que el cheque fue girado contra una cuenta del banco y lo presenta otro banco para cobro. 'S' (salida) significa que un cliente del banco deposito un cheque de otro banco.
- **FEC_PRESENTACION**: fecha en que el cheque ingreso a camara.
- **COD_BANCO** (3 caracteres): codigo del banco presentante o pagador, segun el tipo de origen.
- **CTA_NUMERO** (14 caracteres): cuenta contra la que se giro el cheque.
- **CTA_ABONO** (14 caracteres, opcional): cuenta a la que se abonara el importe si el cheque es pagado (aplica principalmente para tipo 'S').
- **NUM_CHEQUE** (numerico de 8 digitos): numero del cheque presentado.
- **MON_IMPORTE** (decimal 15,2): importe del cheque.
- **COD_MONEDA** (3 caracteres): moneda del cheque.
- **FEC_GIRO**: fecha de emision del cheque segun lo escrito en el documento.
- **IND_PLAZA** (1 caracter, por defecto 'L'): indica la plaza de compensacion, que determina el plazo de canje segun la regla RN-CHQ-21.
- **IND_FIRMA** (1 caracter, por defecto 'S'): indica si la firma del cheque fue verificada ('S' si, 'N' no).
- **IND_DEFECTO** (1 caracter, por defecto 'N'): indica si el cheque presenta algun defecto formal ('S' si, 'N' no).
- **EST_PRESENTACION** (2 caracteres, por defecto 'PE'): estado del proceso de compensacion. Los valores posibles son: PE (pendiente de resolver), PA (pagado), RE (rechazado), CP (canje pendiente de confirmar), AB (abonado en cuenta), DV (devuelto al banco presentante).
- **FEC_CANJE** (opcional): fecha en que se completo el canje.
- **COD_MOTIVO** (2 caracteres, opcional): codigo del motivo de rechazo o devolucion, si aplica.

**Reglas de negocio asociadas:**
- RN-CHQ-20: Los cheques se agrupan en lotes por fecha de presentacion.
- RN-CHQ-21: El plazo maximo para resolver el canje depende de la plaza: cheques propios (mismo banco) se resuelven el mismo dia (T+0); cheques de Lima se resuelven al dia habil siguiente (T+1); cheques de provincia se resuelven a los dos dias habiles siguientes (T+2).

Se crean dos indices: uno unico sobre la clave primaria (NUM_LOTE, NUM_SECUENCIA) y uno compuesto sobre TIP_ORIGEN, EST_PRESENTACION y FEC_PRESENTACION (para el procesamiento operativo por estado y fecha).

### Tabla CHQ_RECHAZO - Registro de Rechazos y Cargos

Registra cada cheque rechazado durante la compensacion, junto con los importes de multa, comision e IGV que corresponde cobrar al titular de la cuenta. La clave primaria es NUM_RECHAZO (numerico de 9 digitos).

Los campos principales son:
- **NUM_LOTE** y **NUM_SECUENCIA**: referencia al registro en CHQ_PRESENTACION que origino el rechazo.
- **CTA_NUMERO** (14 caracteres): cuenta del girador del cheque rechazado.
- **NUM_CHEQUE** (numerico de 8 digitos): numero del cheque rechazado.
- **COD_MOTIVO** (2 caracteres): codigo del motivo del rechazo. Los motivos con tratamiento especial son el 01 (fondos insuficientes), 02 y 08.
- **MON_CHEQUE** (decimal 15,2): importe del cheque rechazado.
- **COD_MONEDA** (3 caracteres): moneda del cheque.
- **FEC_RECHAZO**: fecha en que se registro el rechazo.
- **MON_MULTA** (decimal 11,2, por defecto 0): importe de la multa calculada. Segun la regla RN-CHQ-30, la multa se aplica unicamente cuando el motivo de rechazo es 01 (fondos insuficientes), y equivale al 5% del importe del cheque, con un minimo de 1% de la UIT vigente y un maximo de 5 UIT.
- **MON_COMISION** (decimal 9,2, por defecto 0): importe de la comision bancaria por rechazo. Segun la regla RN-CHQ-32, esta comision se cobra unicamente cuando el motivo de rechazo es 01, 02 u 08.
- **MON_IGV** (decimal 9,2, por defecto 0): monto del IGV calculado sobre MON_COMISION.
- **IND_COBRO** (1 caracter, por defecto 'X'): estado del cobro de los cargos. Los valores posibles son: X (aun no calculado), P (pendiente de cobro por saldo insuficiente), C (cobrado exitosamente), N (sin cargo, no aplica cobro), M (pasado a mora por haber transcurrido mas de 30 dias sin poder cobrarse).
- **FEC_COBRO** (opcional): fecha en que se efectuo el cobro de los cargos.
- **IND_NOTIFICADO** (1 caracter, por defecto 'N'): indica si se notifico al cliente sobre el rechazo ('S' si, 'N' no).

Se crean tres indices: uno unico sobre NUM_RECHAZO; uno compuesto sobre CTA_NUMERO, COD_MOTIVO y FEC_RECHAZO (para consultas por cuenta y motivo); y uno compuesto sobre IND_COBRO y NUM_RECHAZO (para el proceso de cobranza de cargos pendientes).

### Tabla CHQ_GERENCIA - Cheques de Gerencia

Registra los cheques de gerencia emitidos por el banco. A diferencia de los cheques personales, estos son emitidos por el propio banco con cargo a una cuenta del cliente solicitante. La clave primaria es NUM_CHEQUE_GER (numerico de 10 digitos).

Los campos principales son:
- **CTA_CARGO** (14 caracteres): cuenta del cliente a la que se debita el importe del cheque de gerencia mas los cargos.
- **MON_IMPORTE** (decimal 15,2): importe del cheque de gerencia.
- **COD_MONEDA** (3 caracteres): moneda del cheque (PEN o USD, dado que los minimos de comision se expresan en ambas monedas).
- **BENEFICIARIO** (texto variable hasta 40 caracteres): nombre del beneficiario a cuyo favor se emite el cheque.
- **MON_COMISION** (decimal 9,2, por defecto 0): comision cobrada por la emision. Segun la regla RN-CHQ-40, la comision es el 0.25% del importe del cheque, con un minimo de 15.00 PEN si el cheque es en soles, o un minimo de 5.00 USD si el cheque es en dolares.
- **MON_IGV** (decimal 9,2, por defecto 0): monto del IGV calculado sobre MON_COMISION.
- **FEC_EMISION**: fecha en que se emitio el cheque de gerencia.
- **FEC_VENCIM**: fecha de vencimiento del cheque. Segun la regla RN-CHQ-42, la vigencia es de 180 dias calendario contados desde la fecha de emision, por lo que FEC_VENCIM es igual a FEC_EMISION mas 180 dias.
- **EST_GERENCIA** (2 caracteres, por defecto 'VI'): estado del cheque de gerencia. Los valores posibles son: VI (vigente), PA (pagado), AN (anulado).
- **FEC_ESTADO** (opcional): fecha del ultimo cambio de estado.
- **COD_USUARIO** (8 caracteres): codigo del operador que emitio el cheque de gerencia.

Se crean dos indices: uno unico sobre NUM_CHEQUE_GER y uno compuesto sobre CTA_CARGO y EST_GERENCIA (para consultar los cheques de gerencia vigentes de una cuenta).

### Restriccion de Acceso entre Dominios

Una regla arquitectonica fundamental del sistema establece que ninguna tabla del dominio CHQ puede ser leida ni modificada directamente por modulos pertenecientes a otros dominios del sistema SIDEP. El acceso a estos datos esta centralizado exclusivamente en dos modulos de proceso: CHQVALCH (validacion y pago de cheques) y CHQGEREN (gestion de cheques de gerencia). Cualquier funcionalidad externa que requiera informacion de cheques debe invocar a estos modulos mediante llamada (CALL), nunca accediendo directamente a las tablas.

<!-- general-rule-end -->

## Dependencies

El archivo principal es un script DDL (definicion de estructura de datos) que no contiene logica de negocio propia en forma de procedimientos almacenados ni funciones. Su funcion es declarar las tablas, indices y espacios de almacenamiento que conforman el dominio CHQ dentro de la base de datos SIDEP. Por si solo no llama a programas externos ni consume APIs, pero su correcto funcionamiento depende de una serie de objetos de infraestructura de base de datos que deben existir previamente, y establece una dependencia de acceso con dos modulos externos que son los unicos autorizados a leer estas tablas.

La regla de dominio explicita en el encabezado del script establece que ningun otro dominio del sistema puede leer directamente las tablas CHQ. El acceso esta restringido a dos programas externos, identificados como CHQVALCH y CHQGEREN, que deben ser invocados mediante llamada (CALL). El script no contiene el codigo fuente de estos programas; solo declara la restriccion. La modernizacion debe respetar este encapsulamiento: cualquier componente que necesite datos de cheques debe hacerlo a traves de la interfaz que expongan esos dos modulos, no accediendo directamente a las tablas.

| Dependencia | Descripcion | Tipo | Referencia | Relevancia para la Modernizacion |
|---|---|---|---|---|
| DBSIDEP | Base de datos DB2 z/OS en la que se crean todos los objetos del dominio CHQ. Todas las tablas y tablespaces se definen dentro de esta base de datos. | Base de datos | DBSIDEP (DB2 z/OS) | La modernizacion debe crear o mapear una base de datos equivalente. El nombre DBSIDEP aparece en cada clausula IN de las tablas. |
| SGSIDEP | Storage Group de DB2 z/OS que define el grupo de volumenes de disco donde se almacenan fisicamente los datos. Se referencia en los dos tablespaces con la clausula USING STOGROUP. | Objeto de infraestructura DB2 | STOGROUP SGSIDEP | En una migracion a otra plataforma este objeto desaparece; su configuracion de capacidad (PRIQTY, SECQTY) debe traducirse a parametros de almacenamiento equivalentes en la plataforma destino. |
| TSCHQ01 | Tablespace de DB2 z/OS con tamano de segmento 32, bloqueo a nivel de fila y buffer pool BP1. Aloja las tablas CHQ_SOLICITUD, CHQ_CHEQUERA y CHQ_GERENCIA, que corresponden a datos de menor volumen y mayor frecuencia de consulta. Capacidad primaria 7200 unidades, secundaria 720. | Objeto de infraestructura DB2 | DBSIDEP.TSCHQ01 | Al migrar, los parametros de particionamiento y buffer deben revisarse segun la plataforma destino. La separacion fisica entre TSCHQ01 y TSCHQ02 puede ser relevante para decisiones de particionamiento o esquemas en la nueva plataforma. |
| TSCHQ02 | Tablespace de DB2 z/OS con tamano de segmento 32, bloqueo a nivel de fila y buffer pool BP2. Aloja las tablas CHQ_CHEQUE, CHQ_PRESENTACION y CHQ_RECHAZO, que corresponden a datos transaccionales de mayor volumen. Capacidad primaria 14400 unidades, secundaria 1440, el doble que TSCHQ01. | Objeto de infraestructura DB2 | DBSIDEP.TSCHQ02 | La mayor capacidad asignada refleja el volumen esperado de transacciones. La modernizacion debe considerar estrategias de escalado equivalentes para estas entidades. |
| BP1 | Buffer pool de DB2 z/OS asignado al tablespace TSCHQ01. Gestiona el cache de paginas en memoria para las tablas de menor volumen del dominio. | Objeto de infraestructura DB2 | BUFFERPOOL BP1 | Debe mapearse a la configuracion de cache o memoria de la plataforma destino. |
| BP2 | Buffer pool de DB2 z/OS asignado al tablespace TSCHQ02. Gestiona el cache de paginas en memoria para las tablas transaccionales de mayor volumen. | Objeto de infraestructura DB2 | BUFFERPOOL BP2 | Debe mapearse a la configuracion de cache o memoria de la plataforma destino, considerando el mayor volumen de datos que atiende. |
| CHQVALCH | Modulo externo que actua como unico punto de acceso autorizado a las tablas del dominio CHQ para operaciones de validacion de cheques. Se invoca mediante CALL. Su codigo fuente no forma parte de este archivo. | Modulo de aplicacion (llamada externa) | CHQVALCH (CALL) | La modernizacion debe identificar y documentar este modulo por separado. La interfaz que expone (parametros de entrada y salida) debe preservarse o reemplazarse de forma equivalente, ya que es la unica via de acceso al dominio para otros modulos del sistema. |
| CHQGEREN | Modulo externo que actua como unico punto de acceso autorizado a las tablas del dominio CHQ para operaciones relacionadas con cheques de gerencia. Se invoca mediante CALL. Su codigo fuente no forma parte de este archivo. | Modulo de aplicacion (llamada externa) | CHQGEREN (CALL) | Al igual que CHQVALCH, debe documentarse y modernizarse de forma independiente. Cualquier nuevo componente que requiera datos de cheques de gerencia debe continuar pasando por este modulo o por su equivalente modernizado. |

## Data Structure

La estructura de datos del dominio CHQ comprende seis tablas. A continuacion se describe cada una con todos sus campos.

---

### Tabla CHQ_SOLICITUD -- Solicitudes de Chequera

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| NUM_SOLICITUD | Numero de Solicitud | Numerico entero | 9 digitos | Identificador unico de la solicitud de chequera | Si | N/A | Clave primaria. Indice unico IXCHQSO1. Indice secundario IXCHQSO2 por EST_SOLICITUD + NUM_SOLICITUD | Si | Identificador |
| CTA_NUMERO | Numero de Cuenta | Texto fijo | 14 caracteres | Numero de la cuenta corriente que origina la solicitud. Solo cuentas de producto 06 activas (RN-CHQ-01) | Si | N/A | Debe corresponder a una cuenta corriente activa | Si | Referencia |
| CANT_CHEQUERAS | Cantidad de Chequeras | Numerico entero corto | N/A | Cantidad de chequeras solicitadas en un mismo pedido. Rango valido: 1 a 3 (RN-CHQ-03) | Si | 1 | Valor minimo 1, maximo 3 | Si | Cantidad |
| FEC_SOLICITUD | Fecha de Solicitud | Fecha | N/A | Fecha en que se registro la solicitud | Si | N/A | Formato fecha del sistema | No | Fecha |
| CANAL | Canal | Texto fijo | 2 caracteres | Codigo del canal o agencia que cargo la solicitud | Si | N/A | Identifica el origen de la operacion (banca en linea, agencia, etc.) | Si | Codigo |
| COD_USUARIO | Codigo de Usuario | Texto fijo | 8 caracteres | Codigo del operador que registro la solicitud | Si | N/A | Trazabilidad operativa | Si | Codigo |
| EST_SOLICITUD | Estado de la Solicitud | Texto fijo | 2 caracteres | Estado actual de la solicitud | Si | 'SO' | Valor inicial 'SO' (Solicitada). Indice secundario IXCHQSO2 | Si | Estado |
| COD_RECHAZO | Codigo de Rechazo | Texto fijo | 2 caracteres | Codigo que explica el motivo por el que la solicitud fue rechazada | No | NULL | Solo se completa si la solicitud es rechazada | Si | Codigo |
| MON_COSTO_BASE | Monto Costo Base | Numerico decimal | 9 enteros, 2 decimales | Importe de la comision por emision de chequera antes de impuestos | Si | 0 | Componente del costo total | Si | Importe |
| MON_IGV | Monto IGV | Numerico decimal | 9 enteros, 2 decimales | Importe del Impuesto General a las Ventas aplicado sobre el costo base | Si | 0 | Desglose de IGV incorporado en 2005 | Si | Importe |
| MON_COSTO_TOTAL | Monto Costo Total | Numerico decimal | 9 enteros, 2 decimales | Suma del costo base mas el IGV. Importe total cobrado al cliente | Si | 0 | MON_COSTO_BASE + MON_IGV | Si | Importe |
| FEC_PROCESO | Fecha de Proceso | Fecha | N/A | Fecha en que la solicitud fue procesada (aprobada o rechazada) | No | NULL | Se completa al resolver la solicitud | No | Fecha |

---

### Tabla CHQ_CHEQUERA -- Chequeras Emitidas

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| NUM_CHEQUERA | Numero de Chequera | Numerico entero | 9 digitos | Identificador unico de la chequera emitida | Si | N/A | Clave primaria. Indice unico IXCHQCQ1 | Si | Identificador |
| CTA_NUMERO | Numero de Cuenta | Texto fijo | 14 caracteres | Numero de la cuenta corriente a la que pertenece la chequera | Si | N/A | Indice secundario IXCHQCQ2 por CTA_NUMERO + EST_CHEQUERA | Si | Referencia |
| NUM_SOLICITUD | Numero de Solicitud | Numerico entero | 9 digitos | Referencia a la solicitud que origino esta chequera | Si | N/A | Vincula la chequera con CHQ_SOLICITUD | Si | Referencia |
| NUM_INICIAL | Numero Inicial | Numerico entero | 8 digitos | Primer numero de cheque de la chequera | Si | N/A | Numeracion correlativa por cuenta (RN-CHQ-05) | Si | Identificador |
| NUM_FINAL | Numero Final | Numerico entero | 8 digitos | Ultimo numero de cheque de la chequera | Si | N/A | Numeracion correlativa por cuenta (RN-CHQ-05) | Si | Identificador |
| CANT_HOJAS | Cantidad de Hojas | Numerico entero corto | N/A | Numero de hojas (cheques) que contiene la chequera | Si | 25 | Valor estandar de 25 hojas por chequera (RN-CHQ-05) | Si | Cantidad |
| EST_CHEQUERA | Estado de la Chequera | Texto fijo | 2 caracteres | Estado actual de la chequera. Valores: SO=Solicitada, EM=Emitida, EN=Entregada, AG=Agotada, AN=Anulada, BL=Bloqueada | Si | N/A | Maximo 2 chequeras en estado EM o EN por cuenta (RN-CHQ-02). Indice IXCHQCQ2 | Si | Estado |
| FEC_EMISION | Fecha de Emision | Fecha | N/A | Fecha en que se emitio fisicamente la chequera | Si | N/A | Fecha de produccion de la chequera | No | Fecha |
| FEC_ENTREGA | Fecha de Entrega | Fecha | N/A | Fecha en que la chequera fue entregada al cliente | No | NULL | Se completa al cambiar el estado a EN (Entregada) | No | Fecha |
| IND_GRATUITA | Indicador Gratuita | Texto fijo | 1 caracter | Indica si la chequera no tiene costo para el cliente | Si | 'N' | Valor 'S' si es la primera chequera de la cuenta (RN-CHQ-04) | Si | Indicador |
| COD_MONEDA | Codigo de Moneda | Texto fijo | 3 caracteres | Moneda en que esta denominada la chequera | Si | N/A | Ejemplo: PEN, USD | Si | Codigo |

---

### Tabla CHQ_CHEQUE -- Hojas de Cheque

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| CTA_NUMERO | Numero de Cuenta | Texto fijo | 14 caracteres | Numero de la cuenta corriente girataria del cheque | Si | N/A | Parte de la clave primaria compuesta. Indice unico IXCHQCH1 | Si | Referencia |
| NUM_CHEQUE | Numero de Cheque | Numerico entero | 8 digitos | Numero del cheque dentro de la cuenta | Si | N/A | Parte de la clave primaria compuesta. La combinacion CTA_NUMERO + NUM_CHEQUE es unica | Si | Identificador |
| NUM_CHEQUERA | Numero de Chequera | Numerico entero | 9 digitos | Chequera a la que pertenece esta hoja | Si | N/A | Indice secundario IXCHQCH2 | Si | Referencia |
| EST_CHEQUE | Estado del Cheque | Texto fijo | 2 caracteres | Estado actual de la hoja de cheque. Valores: DI=Disponible, PR=Presentado, PA=Pagado, RE=Rechazado, NP=Orden de No Pago, AN=Anulado | Si | 'DI' | Un cheque en estado PA no puede volver a pagarse (RN-CHQ-10) | Si | Estado |
| MON_IMPORTE | Monto Importe | Numerico decimal | 15 enteros, 2 decimales | Importe por el que fue girado el cheque | Si | 0 | Se completa en el momento de la presentacion o pago | Si | Importe |
| FEC_GIRO | Fecha de Giro | Fecha | N/A | Fecha en que el librador firmo y emitio el cheque | No | NULL | Fecha escrita en el documento por el cliente | No | Fecha |
| FEC_ESTADO | Fecha de Estado | Fecha | N/A | Fecha en que el cheque adquirio su estado actual | No | NULL | Se actualiza cada vez que cambia EST_CHEQUE | No | Fecha |
| COD_MOTIVO | Codigo de Motivo | Texto fijo | 2 caracteres | Codigo que explica el motivo del rechazo o anulacion | No | NULL | Solo aplica cuando EST_CHEQUE es RE o AN | Si | Codigo |

---

### Tabla CHQ_PRESENTACION -- Presentaciones a Camara de Compensacion

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| NUM_LOTE | Numero de Lote | Numerico entero | 6 digitos | Identificador del lote de compensacion. Los lotes se agrupan por fecha de presentacion (RN-CHQ-20) | Si | N/A | Parte de la clave primaria compuesta. Indice unico IXCHQPR1 | Si | Identificador |
| NUM_SECUENCIA | Numero de Secuencia | Numerico entero | 7 digitos | Posicion del cheque dentro del lote | Si | N/A | Parte de la clave primaria compuesta. La combinacion NUM_LOTE + NUM_SECUENCIA es unica | Si | Identificador |
| TIP_ORIGEN | Tipo de Origen | Texto fijo | 1 caracter | Indica la direccion del flujo del cheque. Valor 'E'=Entrante (girado contra el banco, presentado por otro banco); 'S'=Saliente (depositado por un cliente del banco) | Si | N/A | Determina el tratamiento contable y operativo. Indice IXCHQPR2 | Si | Indicador |
| FEC_PRESENTACION | Fecha de Presentacion | Fecha | N/A | Fecha en que el cheque fue presentado a la camara | Si | N/A | Base para el calculo del plazo de canje (RN-CHQ-21). Indice IXCHQPR2 | Si | Fecha |
| COD_BANCO | Codigo de Banco | Texto fijo | 3 caracteres | Codigo del banco que presenta o recibe el cheque en la camara | Si | N/A | Identifica la contraparte en la compensacion | Si | Codigo |
| CTA_NUMERO | Numero de Cuenta | Texto fijo | 14 caracteres | Numero de la cuenta corriente contra la que se giro el cheque | Si | N/A | Referencia a la cuenta debitada | Si | Referencia |
| CTA_ABONO | Cuenta de Abono | Texto fijo | 14 caracteres | Numero de la cuenta a la que se acredita el importe si el cheque es pagado | No | NULL | Aplica principalmente para cheques de tipo 'S' (Saliente) | Si | Referencia |
| NUM_CHEQUE | Numero de Cheque | Numerico entero | 8 digitos | Numero del cheque presentado | Si | N/A | Vincula con CHQ_CHEQUE | Si | Referencia |
| MON_IMPORTE | Monto Importe | Numerico decimal | 15 enteros, 2 decimales | Importe del cheque presentado a compensacion | Si | N/A | Debe coincidir con el importe registrado en CHQ_CHEQUE | Si | Importe |
| COD_MONEDA | Codigo de Moneda | Texto fijo | 3 caracteres | Moneda del importe del cheque | Si | N/A | Ejemplo: PEN, USD | Si | Codigo |
| FEC_GIRO | Fecha de Giro | Fecha | N/A | Fecha en que el librador emitio el cheque | Si | N/A | Se utiliza para validaciones de vigencia | No | Fecha |
| IND_PLAZA | Indicador de Plaza | Texto fijo | 1 caracter | Indica la plaza de compensacion para determinar el plazo de canje (RN-CHQ-21). Valores esperados: plaza propia, Lima, Provincia | Si | 'L' | Valor 'L' por defecto corresponde a Lima (T+1 habil). La plaza propia aplica T+0 y provincias T+2 habiles | Si | Indicador |
| IND_FIRMA | Indicador de Firma | Texto fijo | 1 caracter | Indica si la firma del cheque fue verificada | Si | 'S' | Valor 'S'=Si verificada. Parte de los controles de defecto | Si | Indicador |
| IND_DEFECTO | Indicador de Defecto | Texto fijo | 1 caracter | Indica si el cheque presenta algun defecto formal | Si | 'N' | Valor 'N'=Sin defecto. Un valor distinto puede motivar rechazo | Si | Indicador |
| EST_PRESENTACION | Estado de la Presentacion | Texto fijo | 2 caracteres | Estado del cheque en el proceso de compensacion. Valores: PE=Pendiente, PA=Pagado, RE=Rechazado, CP=Canje Pendiente, AB=Abonado, DV=Devuelto | Si | 'PE' | Indice secundario IXCHQPR2 | Si | Estado |
| FEC_CANJE | Fecha de Canje | Fecha | N/A | Fecha en que se debe completar el canje segun el plazo aplicable (RN-CHQ-21) | No | NULL | Se calcula a partir de FEC_PRESENTACION segun IND_PLAZA | Si | Fecha |
| COD_MOTIVO | Codigo de Motivo | Texto fijo | 2 caracteres | Codigo del motivo de rechazo o devolucion | No | NULL | Solo aplica cuando EST_PRESENTACION es RE o DV | Si | Codigo |

---

### Tabla CHQ_RECHAZO -- Cheques Rechazados y sus Cargos

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| NUM_RECHAZO | Numero de Rechazo | Numerico entero | 9 digitos | Identificador unico del registro de rechazo | Si | N/A | Clave primaria. Indice unico IXCHQRE1 | Si | Identificador |
| NUM_LOTE | Numero de Lote | Numerico entero | 6 digitos | Lote de compensacion al que pertenecia el cheque rechazado | Si | N/A | Vincula con CHQ_PRESENTACION | Si | Referencia |
| NUM_SECUENCIA | Numero de Secuencia | Numerico entero | 7 digitos | Secuencia dentro del lote del cheque rechazado | Si | N/A | Junto con NUM_LOTE identifica el registro en CHQ_PRESENTACION | Si | Referencia |
| CTA_NUMERO | Numero de Cuenta | Texto fijo | 14 caracteres | Cuenta corriente contra la que se giro el cheque rechazado | Si | N/A | Indice secundario IXCHQRE2 por CTA_NUMERO + COD_MOTIVO + FEC_RECHAZO | Si | Referencia |
| NUM_CHEQUE | Numero de Cheque | Numerico entero | 8 digitos | Numero del cheque rechazado | Si | N/A | Vincula con CHQ_CHEQUE | Si | Referencia |
| COD_MOTIVO | Codigo de Motivo | Texto fijo | 2 caracteres | Codigo que identifica la causa del rechazo. El motivo 01 genera multa del 5%. Los motivos 01, 02 y 08 generan comision de rechazo (RN-CHQ-30, RN-CHQ-32) | Si | N/A | Determina que cargos se aplican. Indice IXCHQRE2 | Si | Codigo |
| MON_CHEQUE | Monto del Cheque | Numerico decimal | 15 enteros, 2 decimales | Importe del cheque que fue rechazado | Si | N/A | Base de calculo para la multa del 5% (RN-CHQ-30) | Si | Importe |
| COD_MONEDA | Codigo de Moneda | Texto fijo | 3 caracteres | Moneda del importe del cheque rechazado | Si | N/A | Ejemplo: PEN, USD | Si | Codigo |
| FEC_RECHAZO | Fecha de Rechazo | Fecha | N/A | Fecha en que se produjo el rechazo del cheque | Si | N/A | Indice IXCHQRE2. Punto de partida para el seguimiento del cobro | Si | Fecha |
| MON_MULTA | Monto de Multa | Numerico decimal | 11 enteros, 2 decimales | Importe de la multa calculada. Solo aplica para motivo 01: 5% del importe del cheque, con minimo del 1% de la UIT y maximo de 5 UIT (RN-CHQ-30) | Si | 0 | Rango acotado por la UIT vigente. Cero si el motivo no genera multa | Si | Importe |
| MON_COMISION | Monto de Comision | Numerico decimal | 9 enteros, 2 decimales | Importe de la comision por rechazo. Solo aplica para motivos 01, 02 y 08 (RN-CHQ-32) | Si | 0 | Cero si el motivo no genera comision | Si | Importe |
| MON_IGV | Monto IGV | Numerico decimal | 9 enteros, 2 decimales | Impuesto General a las Ventas calculado sobre MON_COMISION | Si | 0 | Desglose de IGV sobre la comision de rechazo | Si | Importe |
| IND_COBRO | Indicador de Cobro | Texto fijo | 1 caracter | Estado del cobro de los cargos generados. Valores: X=Por calcular, P=Pendiente de cobro por saldo insuficiente, C=Cobrado, N=Sin cargo, M=Pasado a mora (mas de 30 dias sin cobrar) | Si | 'X' | Indice secundario IXCHQRE3 por IND_COBRO + NUM_RECHAZO | Si | Estado |
| FEC_COBRO | Fecha de Cobro | Fecha | N/A | Fecha en que se efectuo el cobro de los cargos | No | NULL | Solo se completa cuando IND_COBRO cambia a 'C' | No | Fecha |
| IND_NOTIFICADO | Indicador Notificado | Texto fijo | 1 caracter | Indica si se notifico al cliente sobre el rechazo y sus cargos | Si | 'N' | Valor 'S' una vez enviada la notificacion al cliente | Si | Indicador |

---

### Tabla CHQ_GERENCIA -- Cheques de Gerencia

| Field ID | Field Name | Data Type | Field Size | Description | Mandatory | Default Value | Additional Notes | Relevant for Modernization | Information Type |
|----------|------------|-----------|------------|-------------|-----------|---------------|------------------|----------------------------|------------------|
| NUM_CHEQUE_GER | Numero de Cheque de Gerencia | Numerico entero | 10 digitos | Identificador unico del cheque de gerencia | Si | N/A | Clave primaria. Indice unico IXCHQGE1 | Si | Identificador |
| CTA_CARGO | Cuenta de Cargo | Texto fijo | 14 caracteres | Cuenta corriente del cliente desde la que se debita el importe y la comision | Si | N/A | Indice secundario IXCHQGE2 por CTA_CARGO + EST_GERENCIA | Si | Referencia |
| MON_IMPORTE | Monto Importe | Numerico decimal | 15 enteros, 2 decimales | Importe por el que se emite el cheque de gerencia | Si | N/A | Base para el calculo de la comision (RN-CHQ-40) | Si | Importe |
| COD_MONEDA | Codigo de Moneda | Texto fijo | 3 caracteres | Moneda del cheque de gerencia | Si | N/A | Determina el minimo de comision aplicable: 15.00 PEN o 5.00 USD (RN-CHQ-40) | Si | Codigo |
| BENEFICIARIO | Beneficiario | Texto variable | Hasta 40 caracteres | Nombre del beneficiario a cuyo favor se emite el cheque | Si | N/A | Se imprime en el documento fisico | Si | Texto |
| MON_COMISION | Monto de Comision | Numerico decimal | 9 enteros, 2 decimales | Comision cobrada por la emision del cheque de gerencia: 0.25% del importe, con minimo de 15.00 PEN o 5.00 USD segun moneda (RN-CHQ-40) | Si | 0 | Se calcula antes del IGV | Si | Importe |
| MON_IGV | Monto IGV | Numerico decimal | 9 enteros, 2 decimales | Impuesto General a las Ventas calculado sobre MON_COMISION (RN-CHQ-40) | Si | 0 | Desglose de IGV sobre la comision | Si | Importe |
| FEC_EMISION | Fecha de Emision | Fecha | N/A | Fecha en que se emitio el cheque de gerencia | Si | N/A | Punto de partida para el calculo de la vigencia (RN-CHQ-42) | Si | Fecha |
| FEC_VENCIM | Fecha de Vencimiento | Fecha | N/A | Fecha limite de validez del cheque de gerencia: FEC_EMISION mas 180 dias calendario (RN-CHQ-42) | Si | N/A | Calculada al momento de la emision | Si | Fecha |
| EST_GERENCIA | Estado del Cheque de Gerencia | Texto fijo | 2 caracteres | Estado actual del cheque de gerencia. Valores: VI=Vigente, PA=Pagado, AN=Anulado | Si | 'VI' | Indice secundario IXCHQGE2 | Si | Estado |
| FEC_ESTADO | Fecha de Estado | Fecha | N/A | Fecha en que el cheque adquirio su estado actual | No | NULL | Se actualiza al pagar o anular el cheque | No | Fecha |
| COD_USUARIO | Codigo de Usuario | Texto fijo | 8 caracteres | Codigo del operador que emitio el cheque de gerencia | Si | N/A | Trazabilidad operativa | Si | Codigo |

## Detailed Rules

<!-- rule-start -->
### 1. Rule / Operation - RN-CHQ-01: Solo Cuenta Corriente Activa Puede Solicitar Chequera
<!-- reviewed -->

_Reviewed_

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Antes de insertar una fila en CHQ_SOLICITUD, verificar en el sistema de cuentas — que es externo a este dominio y solo es accesible a través de las interfaces CHQVALCH o CHQGEREN — que el valor de `CTA_NUMERO` corresponde a una cuenta cuyo código de producto (`PRODUCTO`) sea exactamente `06` (cuenta corriente).
2. Verificar adicionalmente que dicha cuenta se encuentre en estado activo en el momento de la solicitud.
3. Si alguna de las dos condiciones no se cumple, rechazar la solicitud y no insertar la fila en CHQ_SOLICITUD.
4. Si ambas condiciones se cumplen, registrar la nueva solicitud en CHQ_SOLICITUD con los siguientes valores iniciales obligatorios:
   - `CANT_CHEQUERAS`: cantidad de chequeras solicitadas; si no se indica explícitamente, toma el valor por defecto `1`. Este valor debe estar comprendido entre `1` y `3` inclusive (véase RN-CHQ-03).
   - `EST_SOLICITUD`: estado inicial de la solicitud, fijado en `'SO'` (solicitada).
   - `MON_COSTO_BASE`: importe base del costo, inicializado en `0`.
   - `MON_IGV`: importe del IGV sobre el costo, inicializado en `0`.
   - `MON_COSTO_TOTAL`: importe total del costo (base más IGV), inicializado en `0`.
   - `COD_RECHAZO` y `FEC_PROCESO`: quedan sin valor hasta que la solicitud sea procesada.
   - Los campos `NUM_SOLICITUD`, `CTA_NUMERO`, `FEC_SOLICITUD`, `CANAL` y `COD_USUARIO` son obligatorios y deben ser suministrados por el canal o agencia que origina la solicitud.
<!-- rule-end -->

<!-- rule-start -->
### 2. Rule / Operation - RN-CHQ-02: Maximo 2 Chequeras Vigentes por Cuenta
<!-- reviewed -->

_Reviewed_

En ningún momento puede existir más de 2 chequeras vigentes para una misma cuenta corriente.
Se consideran vigentes aquellas chequeras cuyo campo `EST_CHEQUERA` tenga el valor `'EM'` (emitida) o `'EN'` (entregada).

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Antes de emitir una nueva chequera para una cuenta (es decir, antes de insertar una fila en `CHQ_CHEQUERA` con `EST_CHEQUERA = 'EM'`), contar cuántas filas existen en `CHQ_CHEQUERA` donde `CTA_NUMERO` coincide con la cuenta en cuestión Y `EST_CHEQUERA` es igual a `'EM'` o `'EN'`.
2. Si el conteo es igual o mayor a 2, rechazar la emisión y no insertar la fila.
3. Si el conteo es menor a 2, permitir la emisión y registrar la nueva chequera en `CHQ_CHEQUERA` con los siguientes valores:
   - `NUM_CHEQUERA`: número identificador único de la chequera (clave primaria).
   - `CTA_NUMERO`: número de la cuenta corriente asociada (14 caracteres).
   - `NUM_SOLICITUD`: número de la solicitud de chequera que origina la emisión, referenciando la fila correspondiente en `CHQ_SOLICITUD`.
   - `NUM_INICIAL` y `NUM_FINAL`: rango de numeración correlativa de hojas asignado a esta chequera, de acuerdo con la regla RN-CHQ-05.
   - `CANT_HOJAS`: cantidad de hojas de la chequera; valor por defecto 25.
   - `EST_CHEQUERA`: se establece en `'EM'` (emitida) al momento de la inserción.
   - `FEC_EMISION`: fecha en que se emite la chequera.
   - `FEC_ENTREGA`: inicialmente sin valor (nulo); se completa cuando la chequera es entregada al cliente.
   - `IND_GRATUITA`: indicador de si la chequera es gratuita (`'S'`) o no (`'N'`); valor por defecto `'N'`, conforme a la regla RN-CHQ-04.
   - `COD_MONEDA`: código de la moneda asociada a la cuenta (3 caracteres).
<!-- rule-end -->

<!-- rule-start -->
### 3. Rule / Operation - RN-CHQ-03: Entre 1 y 3 Chequeras por Solicitud
<!-- reviewed -->

_Reviewed_

**Regla de Negocio RN-CHQ-03: Entre 1 y 3 Chequeras por Solicitud**

Cada solicitud de chequera debe incluir al menos 1 chequera y como máximo 3 chequeras.
Este límite se controla mediante el campo `CANT_CHEQUERAS` de la tabla `CHQ_SOLICITUD`, el cual es de tipo entero corto (`SMALLINT`), no admite nulos y tiene un valor por defecto de 1.

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Al registrar una nueva fila en `CHQ_SOLICITUD`, verificar que el valor del campo `CANT_CHEQUERAS` sea un número entero mayor o igual a 1 y menor o igual a 3.
2. Si el valor es 0, negativo, o mayor que 3, rechazar la operación.
3. Si no se especifica valor para `CANT_CHEQUERAS`, aplicar automáticamente el valor por defecto de 1.
4. El campo `CANT_CHEQUERAS` no puede ser nulo; toda solicitud debe tener siempre un valor explícito o el valor por defecto asignado.
5. Esta regla aplica en el contexto de una solicitud (`EST_SOLICITUD` con valor por defecto `'SO'`), que corresponde a una cuenta corriente activa de producto 06 (según RN-CHQ-01), y está sujeta también a la restricción de máximo 2 chequeras vigentes (estados `'EM'` o `'EN'`) por cuenta (según RN-CHQ-02).
<!-- rule-end -->

<!-- rule-start -->
### 4. Rule / Operation - RN-CHQ-04: Primera Chequera de la Cuenta es Gratuita
<!-- reviewed -->

_Reviewed_

**Rule / Operation - RN-CHQ-04: Primera Chequera de la Cuenta es Gratuita**

- La primera chequera emitida para una cuenta corriente no tiene costo para el cliente.
- Esta condición se registra mediante el campo `IND_GRATUITA` en la tabla `CHQ_CHEQUERA`, que puede tomar el valor `'S'` (gratuita) o `'N'` (con costo). El valor por defecto definido en la tabla es `'N'`.

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Al momento de emitir una chequera (insertar un registro en `CHQ_CHEQUERA`), verificar si existen filas previas en `CHQ_CHEQUERA` para el mismo valor de `CTA_NUMERO`, en cualquier estado (incluyendo los estados `'AN'` anulada y `'BL'` bloqueada, además de `'SO'` solicitada, `'EM'` emitida, `'EN'` entregada y `'AG'` agotada).
2. Si no existe ninguna fila previa para esa cuenta, se trata de la primera chequera: asignar `IND_GRATUITA = 'S'`. En este caso, los campos `MON_COSTO_BASE`, `MON_IGV` y `MON_COSTO_TOTAL` en el registro correspondiente de `CHQ_SOLICITUD` deben quedar en `0.00` (sus valores por defecto en la tabla son `0` para los tres campos).
3. Si ya existe al menos una fila previa para esa cuenta en `CHQ_CHEQUERA`, la chequera no es gratuita: asignar `IND_GRATUITA = 'N'` y aplicar el cálculo de costos según corresponda, actualizando `MON_COSTO_BASE`, `MON_IGV` y `MON_COSTO_TOTAL` en `CHQ_SOLICITUD` con los importes resultantes.
4. El campo `CANT_HOJAS` de la chequera emitida se inicializa en `25` hojas por defecto, conforme a la regla RN-CHQ-05. El campo `COD_MONEDA` se toma del registro de la cuenta corriente asociada (`CTA_NUMERO`), que debe corresponder al producto `06` en estado activo (conforme a RN-CHQ-01).
<!-- rule-end -->

<!-- rule-start -->
### 5. Rule / Operation - RN-CHQ-05: Numeracion Correlativa y 25 Hojas por Chequera
<!-- reviewed -->

_Reviewed_

**Rule Status:** Relevant for Modernization

**Algorithm**

La tabla `CHQ_CHEQUERA` almacena una fila por cada chequera emitida. Cada chequera queda vinculada a una cuenta corriente mediante `CTA_NUMERO` y a su solicitud de origen mediante `NUM_SOLICITUD`. Los campos `NUM_INICIAL` y `NUM_FINAL` delimitan el rango correlativo de números de cheque que corresponden a esa chequera. El campo `CANT_HOJAS` registra la cantidad de hojas; su valor por defecto es **25**. El campo `COD_MONEDA` identifica la moneda de la chequera. El campo `EST_CHEQUERA` refleja el estado de la chequera y puede tomar los valores: `SO` (solicitada), `EM` (emitida), `EN` (entregada), `AG` (agotada), `AN` (anulada) y `BL` (bloqueada). El campo `IND_GRATUITA` indica si la chequera es gratuita (`S`) o no (`N`), con valor por defecto `N`; la primera chequera de una cuenta es gratuita (regla RN-CHQ-04). Los campos `FEC_EMISION` y `FEC_ENTREGA` registran las fechas de emisión y entrega, respectivamente.

La tabla `CHQ_CHEQUE` almacena una fila por cada hoja de chequera. Cada fila se identifica por la combinación de `CTA_NUMERO` y `NUM_CHEQUE`. El campo `EST_CHEQUE` indica el estado del cheque individual y puede tomar los valores: `DI` (disponible), `PR` (presentado), `PA` (pagado), `RE` (rechazado), `NP` (orden de no pago) y `AN` (anulado); su valor por defecto es `DI`. El campo `MON_IMPORTE` registra el importe con valor por defecto `0`. Los campos `FEC_GIRO`, `FEC_ESTADO` y `COD_MOTIVO` son opcionales en el momento de la creación.

1. Al emitir una nueva chequera para una cuenta (registrar una fila en `CHQ_CHEQUERA`):
   - a. Obtener el valor máximo de `NUM_FINAL` de todas las filas existentes en `CHQ_CHEQUERA` donde `CTA_NUMERO` coincide con la cuenta. Si no existe ninguna fila previa para esa cuenta, el número inicial será el definido por la configuración del sistema (valor de arranque).
   - b. Asignar `NUM_INICIAL` = (máximo `NUM_FINAL` previo) + 1.
   - c. Asignar `NUM_FINAL` = `NUM_INICIAL` + `CANT_HOJAS` − 1. Con el valor por defecto de 25 hojas: `NUM_FINAL` = `NUM_INICIAL` + 24.
2. Por cada número de cheque en el rango [`NUM_INICIAL`, `NUM_FINAL`], registrar una fila en `CHQ_CHEQUE` con los siguientes valores:
   - `CTA_NUMERO`: número de cuenta de la chequera.
   - `NUM_CHEQUE`: número correlativo dentro del rango.
   - `NUM_CHEQUERA`: identificador de la chequera recién emitida.
   - `EST_CHEQUE`: `'DI'` (disponible).
   - `MON_IMPORTE`: `0`.
   - `FEC_GIRO`, `FEC_ESTADO` y `COD_MOTIVO` quedan sin valor en el momento de la creación.
<!-- rule-end -->

<!-- rule-start -->
### 6. Rule / Operation - RN-CHQ-10: Un Cheque Pagado No Puede Pagarse Dos Veces
<!-- reviewed -->

_Reviewed_

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Antes de procesar el pago de un cheque, localizar la fila en la tabla CHQ_CHEQUE donde los campos `CTA_NUMERO` (número de cuenta) y `NUM_CHEQUE` (número de cheque) coincidan con el cheque a pagar. Estos dos campos conforman la clave primaria de la tabla.
2. Verificar que el valor del campo `EST_CHEQUE` (estado del cheque) en dicha fila NO sea `'PA'` (pagado). Los estados posibles que puede tener un cheque son: `'DI'` (disponible), `'PR'` (presentado), `'PA'` (pagado), `'RE'` (rechazado), `'NP'` (orden de no pago) y `'AN'` (anulado). El valor por defecto al crear un cheque es `'DI'`.
3. Si `EST_CHEQUE` es igual a `'PA'`, rechazar la operación de pago sin modificar ningún dato de la fila.
4. Si `EST_CHEQUE` no es `'PA'`, continuar con el proceso de pago. Al registrar el pago, actualizar en la fila correspondiente de CHQ_CHEQUE los siguientes campos:
   - `EST_CHEQUE`: establecer en `'PA'`.
   - `FEC_ESTADO`: registrar la fecha en que se efectúa el pago.
   - `MON_IMPORTE`: registrar el importe pagado (valor numérico de hasta 15 dígitos con 2 decimales).
   - `COD_MOTIVO`: campo disponible para registrar el motivo asociado al estado, si corresponde.
5. La tabla CHQ_CHEQUE también almacena el campo `FEC_GIRO` (fecha de giro del cheque) y el campo `NUM_CHEQUERA` (número de chequera a la que pertenece el cheque), los cuales son datos de identificación del instrumento y no se modifican durante el proceso de pago.
<!-- rule-end -->

<!-- rule-start -->
### 7. Rule / Operation - RN-CHQ-20: Lotes por Fecha de Presentacion en Camara
<!-- reviewed -->

_Reviewed_

**Rule / Operation - RN-CHQ-20: Lotes por Fecha de Presentacion en Camara**

- Los cheques presentados a la cámara de compensación se agrupan en lotes identificados por `NUM_LOTE` en la tabla `CHQ_PRESENTACION`.
- Cada lote corresponde a una fecha de presentación (`FEC_PRESENTACION`) específica.
- Dentro de cada lote, cada cheque tiene un número de secuencia único (`NUM_SECUENCIA`).
- Cada registro de `CHQ_PRESENTACION` representa un cheque presentado a cámara e incluye los siguientes datos: tipo de origen (`TIP_ORIGEN`, valor `E` para cheque entrante —girado contra el propio banco y presentado por otro banco— o `S` para cheque de salida —depositado por un cliente propio—), código de banco presentador (`COD_BANCO`), número de cuenta girada (`CTA_NUMERO`), número de cuenta de abono (`CTA_ABONO`), número de cheque (`NUM_CHEQUE`), importe (`MON_IMPORTE`), moneda (`COD_MONEDA`), fecha de giro (`FEC_GIRO`), indicador de plaza (`IND_PLAZA`, valor por defecto `L`), indicador de firma (`IND_FIRMA`, valor por defecto `S`), indicador de defecto (`IND_DEFECTO`, valor por defecto `N`), estado de la presentación (`EST_PRESENTACION`, valor por defecto `PE` — pendiente), fecha de canje (`FEC_CANJE`) y código de motivo (`COD_MOTIVO`).

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Al registrar un cheque en cámara de compensación (insertar en `CHQ_PRESENTACION`):
   a. Determinar el `NUM_LOTE` correspondiente a la `FEC_PRESENTACION` del día. Si ya existe un lote abierto para esa fecha, usar su `NUM_LOTE`. Si no existe, crear un nuevo lote asignando un `NUM_LOTE` nuevo. El campo `NUM_LOTE` es de tipo numérico de hasta 6 dígitos enteros.
   b. Asignar `NUM_SECUENCIA` como el siguiente número correlativo dentro del lote (máximo `NUM_SECUENCIA` existente para ese `NUM_LOTE` más 1, o 1 si es el primero). El campo `NUM_SECUENCIA` es de tipo numérico de hasta 7 dígitos enteros.
   c. El par (`NUM_LOTE`, `NUM_SECUENCIA`) identifica de forma única cada presentación y constituye la clave primaria de `CHQ_PRESENTACION`. Existe un índice único `IXCHQPR1` sobre estos dos campos. Adicionalmente, existe un índice `IXCHQPR2` sobre (`TIP_ORIGEN`, `EST_PRESENTACION`, `FEC_PRESENTACION`) para facilitar la consulta de presentaciones por tipo, estado y fecha.
   d. El estado inicial de toda presentación recién registrada es `PE` (pendiente). Los estados posibles durante el ciclo de vida de la presentación son: `PE` pendiente, `PA` pagado, `RE` rechazado, `CP` canje pendiente, `AB` abonado y `DV` devuelto.
<!-- rule-end -->

<!-- rule-start -->
### 8. Rule / Operation - RN-CHQ-21: Plazo de Canje segun Plaza
<!-- reviewed -->

_Reviewed_

**Rule / Operation - RN-CHQ-21: Plazo de Canje segun Plaza**

El plazo para el canje (pago o devolución) de un cheque presentado a cámara de compensación depende de la plaza de origen del cheque, indicada por el campo `IND_PLAZA` en la tabla `CHQ_PRESENTACION`. El valor por defecto de `IND_PLAZA` es `'L'` (Lima), lo que significa que, salvo indicación expresa, toda presentación se considera de plaza Lima.

Los plazos definidos son los siguientes:

- **Plaza propia** (`IND_PLAZA = 'P'`): el canje ocurre el mismo día de presentación (T+0).
- **Lima** (`IND_PLAZA = 'L'`, valor por defecto): el canje ocurre al día hábil siguiente a la presentación (T+1 hábil).
- **Provincias** (cualquier valor de `IND_PLAZA` distinto de `'P'` y `'L'`): el canje ocurre a los dos días hábiles siguientes a la presentación (T+2 hábiles).

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Al registrar una presentación en `CHQ_PRESENTACION`, se asignan los siguientes valores iniciales en el registro:
   - `IND_PLAZA`: valor proporcionado en el momento del registro; si no se indica, toma el valor por defecto `'L'` (Lima).
   - `IND_FIRMA`: valor por defecto `'S'`.
   - `IND_DEFECTO`: valor por defecto `'N'`.
   - `EST_PRESENTACION`: valor por defecto `'PE'` (pendiente).
   - `FEC_CANJE`: se calcula según el paso siguiente y se registra en este campo; inicialmente puede quedar nulo hasta que se calcule.
   - `COD_MOTIVO`: inicialmente nulo; se asigna solo en caso de rechazo.

2. Leer el valor de `IND_PLAZA` del registro de presentación y calcular `FEC_CANJE` de la siguiente manera:
   - Si `IND_PLAZA = 'P'` (plaza propia): `FEC_CANJE = FEC_PRESENTACION` (mismo día, T+0).
   - Si `IND_PLAZA = 'L'` (Lima): `FEC_CANJE` = primer día hábil posterior a `FEC_PRESENTACION` (T+1 hábil). Para determinar días hábiles, se excluyen sábados, domingos y feriados bancarios del calendario del sistema.
   - Para cualquier otro valor de `IND_PLAZA` (provincias): `FEC_CANJE` = segundo día hábil posterior a `FEC_PRESENTACION` (T+2 hábiles), aplicando la misma exclusión de días no hábiles.

3. Registrar el valor calculado en el campo `FEC_CANJE` de `CHQ_PRESENTACION`.

4. Las presentaciones se agrupan por fecha de presentación en lotes, identificados por `NUM_LOTE`. Cada presentación dentro de un lote se identifica de forma única por la combinación de `NUM_LOTE` y `NUM_SECUENCIA`.

5. El campo `TIP_ORIGEN` indica la dirección del cheque en la cámara:
   - `'E'` (entrante): el cheque fue girado contra el propio banco y fue presentado por otro banco.
   - `'S'` (salida): el cheque fue depositado por un cliente propio en el banco.

6. Los estados posibles de una presentación (`EST_PRESENTACION`) a lo largo de su ciclo de vida son: `'PE'` (pendiente), `'PA'` (pagado), `'RE'` (rechazado), `'CP'` (canje pendiente), `'AB'` (abonado) y `'DV'` (devuelto).
<!-- rule-end -->

<!-- rule-start -->
### 9. Rule / Operation - RN-CHQ-30: Multa del 5% por Motivo 01 con Limites en UIT
<!-- reviewed -->

_Reviewed_

- Cuando un cheque es rechazado por el motivo con código `'01'` (sin fondos), se aplica una multa equivalente al 5% del importe del cheque, sujeta a límites expresados en UIT.
- Esta multa tiene un mínimo equivalente al 1% de la UIT vigente y un máximo equivalente a 5 UIT vigentes.
- El resultado se registra en el campo `MON_MULTA` de la tabla `CHQ_RECHAZO`.
- Para los demás motivos de rechazo, el campo `MON_MULTA` toma el valor por defecto de 0.00, tal como lo establece la definición de la tabla `CHQ_RECHAZO` (`MON_MULTA DECIMAL(11,2) NOT NULL DEFAULT 0`).
- La regla complementaria RN-CHQ-32 establece que la comisión de rechazo (`MON_COMISION`) se aplica únicamente para los motivos `'01'`, `'02'` y `'08'`, y que dicha comisión también puede llevar IGV (`MON_IGV`), ambos campos registrados igualmente en `CHQ_RECHAZO`.
- El indicador de cobro `IND_COBRO` se inicializa con el valor `'X'` (por calcular) al crear el registro, y el indicador de notificación `IND_NOTIFICADO` se inicializa en `'N'` (no notificado).

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Al insertar una fila en `CHQ_RECHAZO`, verificar si `COD_MOTIVO` es igual a `'01'`.
2. Si `COD_MOTIVO` es `'01'`:
   a. Obtener el valor vigente de la UIT del sistema (valor externo a este dominio, conforme a la regla de dominio que indica que ningún otro dominio lee directamente estas tablas y el acceso se realiza vía los módulos autorizados).
   b. Calcular la multa bruta: `MULTA_BRUTA = MON_CHEQUE * 0.05` (es decir, el 5% del importe del cheque registrado en `MON_CHEQUE`).
   c. Calcular el mínimo permitido: `MINIMO = UIT * 0.01` (el 1% de la UIT vigente).
   d. Calcular el máximo permitido: `MAXIMO = UIT * 5` (cinco veces la UIT vigente).
   e. Aplicar los límites y asignar el valor al campo `MON_MULTA` de `CHQ_RECHAZO`:
      - Si `MULTA_BRUTA < MINIMO`, entonces `MON_MULTA = MINIMO`.
      - Si `MULTA_BRUTA > MAXIMO`, entonces `MON_MULTA = MAXIMO`.
      - Si `MULTA_BRUTA` está entre `MINIMO` y `MAXIMO` (inclusive en ambos extremos), entonces `MON_MULTA = MULTA_BRUTA`.
3. Si `COD_MOTIVO` es distinto de `'01'`, asignar `MON_MULTA = 0.00` (valor por defecto definido en la tabla `CHQ_RECHAZO`).
4. Independientemente del motivo, registrar en `CHQ_RECHAZO` los siguientes campos de identificación y trazabilidad del rechazo:
   - `NUM_RECHAZO`: número identificador único del rechazo.
   - `NUM_LOTE` y `NUM_SECUENCIA`: referencia al lote y secuencia de la presentación en cámara de compensación (tabla `CHQ_PRESENTACION`).
   - `CTA_NUMERO`: número de cuenta asociada al cheque rechazado (14 caracteres).
   - `NUM_CHEQUE`: número del cheque rechazado.
   - `COD_MOTIVO`: código del motivo de rechazo (2 caracteres).
   - `MON_CHEQUE`: importe del cheque rechazado.
   - `COD_MONEDA`: código de la moneda del cheque (3 caracteres).
   - `FEC_RECHAZO`: fecha en que se produce el rechazo.
   - `MON_COMISION`: comisión de rechazo aplicable según RN-CHQ-32 (motivos `'01'`, `'02'` y `'08'`); valor por defecto 0.00.
   - `MON_IGV`: IGV sobre la comisión de rechazo; valor por defecto 0.00.
   - `IND_COBRO`: indicador del estado de cobro de la multa y comisión; se inicializa en `'X'` (por calcular). Los valores posibles son: `'X'` por calcular, `'P'` pendiente de cobro por saldo insuficiente, `'C'` cobrado, `'N'` sin cargo, `'M'` pasado a mora (más de 30 días).
   - `FEC_COBRO`: fecha de cobro efectivo; se deja sin valor hasta que se produzca el cobro.
   - `IND_NOTIFICADO`: indicador de notificación al cliente; se inicializa en `'N'` (no notificado).
<!-- rule-end -->

<!-- rule-start -->
### 10. Rule / Operation - RN-CHQ-32: Comision de Rechazo Solo para Motivos 01, 02 y 08
<!-- reviewed -->

_Reviewed_

**Rule Status:** Relevant for Modernization

**Algorithm**

La regla RN-CHQ-32 establece que la comisión por rechazo de cheque únicamente se cobra cuando el motivo del rechazo corresponde a uno de los siguientes códigos: `'01'`, `'02'` o `'08'`. Para cualquier otro motivo de rechazo, no se aplica comisión.

Los importes resultantes — comisión e IGV — se almacenan en los campos `MON_COMISION` y `MON_IGV` de la tabla `CHQ_RECHAZO`.

La tabla `CHQ_RECHAZO` registra cada rechazo con los siguientes datos: número de rechazo (`NUM_RECHAZO`), lote y secuencia de presentación (`NUM_LOTE`, `NUM_SECUENCIA`), cuenta girada (`CTA_NUMERO`), número de cheque (`NUM_CHEQUE`), motivo de rechazo (`COD_MOTIVO`), importe del cheque rechazado (`MON_CHEQUE`), moneda (`COD_MONEDA`), fecha de rechazo (`FEC_RECHAZO`), importe de multa (`MON_MULTA`, con valor por defecto 0), importe de comisión (`MON_COMISION`, con valor por defecto 0), importe de IGV (`MON_IGV`, con valor por defecto 0), indicador de cobro (`IND_COBRO`, con valor por defecto `'X'`), fecha de cobro (`FEC_COBRO`), e indicador de notificación al cliente (`IND_NOTIFICADO`, con valor por defecto `'N'`).

El indicador `IND_COBRO` puede tomar los siguientes valores: `'X'` (por calcular), `'P'` (pendiente de cobro por saldo insuficiente), `'C'` (cobrado), `'N'` (sin cargo) y `'M'` (pasado a mora, cuando han transcurrido más de 30 días).

El procesamiento al registrar un rechazo es el siguiente:

1. Al insertar una fila en `CHQ_RECHAZO`, verificar si `COD_MOTIVO` es igual a `'01'`, `'02'` o `'08'`.
2. Si `COD_MOTIVO` es uno de esos tres valores:
   - a. Obtener el importe de comisión de rechazo vigente del sistema (tarifa externa a este dominio).
   - b. Asignar `MON_COMISION` con dicho importe.
   - c. Calcular `MON_IGV` aplicando la tasa de IGV vigente sobre `MON_COMISION`. La tasa de IGV es un parámetro externo; el campo `MON_IGV` existe en la tabla desde la modificación del 2005-01-31 según el historial del archivo DDL.
   - d. El indicador `IND_COBRO` se inicializa en `'X'` (por calcular) según el valor por defecto de la tabla, y posteriormente se actualiza según el resultado del intento de cobro: `'C'` si el cobro se efectúa con éxito, `'P'` si el saldo es insuficiente, `'N'` si se determina que no corresponde cargo, o `'M'` si han transcurrido más de 30 días sin que se haya podido cobrar.
3. Si `COD_MOTIVO` no es `'01'`, `'02'` ni `'08'`, asignar `MON_COMISION` = 0.00 y `MON_IGV` = 0.00. En este caso, `IND_COBRO` se inicializa igualmente en `'X'` por defecto, aunque no haya importe a cobrar.

Nótese que la multa del 5% regulada por la regla RN-CHQ-30 es independiente de esta comisión y se aplica exclusivamente al motivo `'01'` (fondo insuficiente), con un mínimo del 1% de la UIT y un máximo de 5 UIT, registrándose en el campo `MON_MULTA` de la misma tabla `CHQ_RECHAZO`.
<!-- rule-end -->

<!-- rule-start -->
### 11. Rule / Operation - Ciclo de Estados del Indicador de Cobro (IND_COBRO) en CHQ_RECHAZO
<!-- reviewed -->

_Reviewed_

**Business Rule for Review:**

#### 11. Rule / Operation - Ciclo de Estados del Indicador de Cobro (IND_COBRO) en CHQ_RECHAZO

- El campo `IND_COBRO` en la tabla `CHQ_RECHAZO` registra el estado del proceso de cobro de la multa y/o comisión generada por el rechazo de un cheque.
- Los valores posibles y su significado son:
  - `'X'`: por calcular (estado inicial por defecto, pendiente de determinación del importe).
  - `'P'`: pendiente de cobro, porque el saldo de la cuenta es insuficiente para cubrir el cargo.
  - `'C'`: cobrado exitosamente.
  - `'N'`: sin cargo (no aplica cobro).
  - `'M'`: pasado a mora, cuando han transcurrido más de 30 días desde el rechazo sin que se haya podido cobrar.

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Al insertar una fila en `CHQ_RECHAZO`, los campos de importes se inicializan con los siguientes valores por defecto: `MON_MULTA` = 0, `MON_COMISION` = 0, `MON_IGV` = 0, e `IND_COBRO` = `'X'`. El campo `IND_NOTIFICADO` se inicializa en `'N'`. Los campos `FEC_COBRO` y `COD_MOTIVO` no reciben valor por defecto y quedan sin asignar hasta que corresponda registrarlos. Cada fila queda identificada de forma única por `NUM_RECHAZO` y referenciada al lote y secuencia de cámara mediante `NUM_LOTE` y `NUM_SECUENCIA`, a la cuenta girada mediante `CTA_NUMERO` y al número de cheque mediante `NUM_CHEQUE`.
2. El cálculo de los importes a cobrar sigue las siguientes reglas de negocio del dominio:
   - La multa (`MON_MULTA`) aplica únicamente cuando el motivo de rechazo (`COD_MOTIVO`) es `'01'` (fondos insuficientes), y se calcula como el 5% del importe del cheque (`MON_CHEQUE`), sujeto a un mínimo equivalente al 1% de la UIT y a un máximo equivalente a 5 UIT.
   - La comisión de rechazo (`MON_COMISION`) aplica únicamente cuando `COD_MOTIVO` es `'01'`, `'02'` o `'08'`.
   - Sobre la comisión calculada se determina el IGV correspondiente (`MON_IGV`).
3. Una vez calculados `MON_MULTA`, `MON_COMISION` y `MON_IGV`, se intenta debitar el importe total (`MON_MULTA` + `MON_COMISION` + `MON_IGV`) de la cuenta identificada por `CTA_NUMERO`:
   - Si el débito es exitoso: actualizar `IND_COBRO` = `'C'` y registrar `FEC_COBRO` con la fecha en que se realizó el cobro.
   - Si el saldo es insuficiente: actualizar `IND_COBRO` = `'P'`.
   - Si no corresponde cobro (motivo exento de multa y comisión): actualizar `IND_COBRO` = `'N'`.
4. Para los registros con `IND_COBRO` = `'P'`, un proceso periódico (cuya lógica es externa a este dominio, accesible únicamente a través de las interfaces `CHQVALCH` o `CHQGEREN`) verifica si han transcurrido más de 30 días desde `FEC_RECHAZO`. Si la diferencia entre la fecha actual y `FEC_RECHAZO` supera los 30 días y el estado sigue siendo `'P'`, se actualiza `IND_COBRO` = `'M'`.
5. Los registros de `CHQ_RECHAZO` pueden consultarse de forma eficiente por cuenta, motivo y fecha de rechazo (combinación de `CTA_NUMERO`, `COD_MOTIVO`, `FEC_RECHAZO`), así como por estado de cobro y número de rechazo (combinación de `IND_COBRO`, `NUM_RECHAZO`), para facilitar el procesamiento periódico de cobros pendientes y el seguimiento de mora.
<!-- rule-end -->

<!-- rule-start -->
### 12. Rule / Operation - RN-CHQ-40: Comision por Emision de Cheque de Gerencia
<!-- reviewed -->

_Reviewed_

**Rule Status:** Relevant for Modernization

La emisión de un cheque de gerencia genera una comisión equivalente al 0.25% del importe del cheque, con un mínimo según la moneda del instrumento. Los mínimos son: 15.00 PEN (soles peruanos) o 5.00 USD (dólares americanos). Adicionalmente, sobre la comisión calculada se aplica el IGV. Los importes se registran en los campos `MON_COMISION` y `MON_IGV` de la tabla `CHQ_GERENCIA`.

El estado inicial del cheque de gerencia al momento de su emisión es `VI` (Vigente), registrado en el campo `EST_GERENCIA`. La vigencia del instrumento es de 180 días calendario a partir de la fecha de emisión (`FEC_EMISION`), y la fecha de vencimiento resultante se almacena en `FEC_VENCIM`.

**Algorithm**

1. Al emitir un cheque de gerencia (insertar un registro en `CHQ_GERENCIA`):
   a. Calcular la comisión bruta: `COMISION_BRUTA = MON_IMPORTE * 0.0025` (es decir, el 0.25% del importe del cheque).
   b. Determinar el mínimo según `COD_MONEDA`:
      - Si `COD_MONEDA = 'PEN'`: `MINIMO = 15.00`.
      - Si `COD_MONEDA = 'USD'`: `MINIMO = 5.00`.
      - No se contemplan otras monedas en la definición del dominio; únicamente están previstas las dos anteriores.
   c. Aplicar el mínimo: si `COMISION_BRUTA < MINIMO`, entonces `MON_COMISION = MINIMO`; de lo contrario, `MON_COMISION = COMISION_BRUTA`.
   d. Calcular `MON_IGV` aplicando la tasa de IGV vigente sobre `MON_COMISION`. (La tasa es un parámetro externo al dominio.)
   e. Registrar el nuevo cheque de gerencia con los siguientes valores en `CHQ_GERENCIA`:
      - `MON_COMISION`: comisión calculada según los pasos anteriores (valor por defecto 0 si aún no se ha calculado).
      - `MON_IGV`: IGV calculado sobre la comisión (valor por defecto 0 si aún no se ha calculado).
      - `EST_GERENCIA`: `'VI'` (Vigente), valor por defecto en la inserción.
      - `FEC_VENCIM`: fecha resultante de sumar 180 días calendario a `FEC_EMISION`.
      - `FEC_ESTADO`: sin valor en la inserción inicial (se registrará cuando el estado cambie).
      - Los demás campos obligatorios del registro son: `NUM_CHEQUE_GER` (identificador único del cheque de gerencia), `CTA_CARGO` (cuenta a debitar), `MON_IMPORTE` (importe del cheque), `COD_MONEDA`, `BENEFICIARIO` (nombre del beneficiario, hasta 40 caracteres) y `COD_USUARIO` (usuario que emite el cheque).
<!-- rule-end -->

<!-- rule-start -->
### 13. Rule / Operation - RN-CHQ-42: Vigencia de 180 Dias para Cheque de Gerencia
<!-- reviewed -->

_Reviewed_

**Rule / Operation - RN-CHQ-42: Vigencia de 180 Días para Cheque de Gerencia**

- Un cheque de gerencia tiene una vigencia de 180 días calendario contados desde su fecha de emisión.
- La fecha de vencimiento se registra en el campo `FEC_VENCIM` de la tabla `CHQ_GERENCIA`.
- Transcurrido ese plazo sin que el cheque haya sido pagado, el cheque se considera vencido.

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Al insertar una fila en `CHQ_GERENCIA`, se registran y calculan los siguientes campos:
   - `NUM_CHEQUE_GER`: identificador numérico único del cheque de gerencia (hasta 10 dígitos, sin decimales).
   - `CTA_CARGO`: número de cuenta (14 caracteres) contra la que se carga el cheque.
   - `MON_IMPORTE`: importe del cheque (hasta 15 dígitos con 2 decimales).
   - `COD_MONEDA`: código de moneda (3 caracteres).
   - `BENEFICIARIO`: nombre del beneficiario (texto variable de hasta 40 caracteres).
   - `MON_COMISION`: comisión aplicada al cheque; su valor por defecto es 0.00. Según la regla RN-CHQ-40, corresponde al 0,25 % del importe, con un mínimo de 15,00 PEN o 5,00 USD según la moneda, más IGV.
   - `MON_IGV`: monto del IGV correspondiente a la comisión; su valor por defecto es 0.00.
   - `FEC_EMISION`: fecha del día de emisión del cheque.
   - `FEC_VENCIM`: se calcula como `FEC_EMISION` más 180 días calendario, sin excluir fines de semana ni feriados; se cuentan todos los días del calendario.
   - `EST_GERENCIA`: estado del cheque; se asigna el valor `'VI'` (vigente) como valor inicial por defecto.
   - `FEC_ESTADO`: fecha de último cambio de estado; no se asigna valor en la inserción inicial (queda nula).
   - `COD_USUARIO`: código del usuario (8 caracteres) que registra el cheque.

2. Los únicos estados válidos para `EST_GERENCIA` son: `'VI'` (vigente), `'PA'` (pagado) y `'AN'` (anulado).

3. El acceso a los datos de `CHQ_GERENCIA` se realiza exclusivamente a través del módulo `CHQGEREN`. Ningún otro dominio lee directamente esta tabla. La verificación de si la fecha actual supera `FEC_VENCIM` para cheques con `EST_GERENCIA = 'VI'`, así como la acción a tomar ante el vencimiento (anulación, notificación u otra), es responsabilidad de la lógica de negocio que consume este dominio a través de `CHQGEREN`.
<!-- rule-end -->

<!-- rule-start -->
### 14. Rule / Operation - Ciclo de Estados de CHQ_SOLICITUD (EST_SOLICITUD)
<!-- reviewed -->

_Reviewed_

**Rule / Operation - Ciclo de Estados de CHQ_SOLICITUD (EST_SOLICITUD)**

- El campo `EST_SOLICITUD` en la tabla `CHQ_SOLICITUD` registra el estado del proceso de solicitud de chequera a lo largo de su ciclo de vida.
- El valor por defecto al crear la solicitud es `'SO'` (solicitada), asignado automáticamente por la definición de la columna.
- El campo `COD_RECHAZO` (de tipo `CHAR(2)`, admite nulo) almacena el código del motivo en caso de que la solicitud sea rechazada; permanece nulo mientras la solicitud no haya sido rechazada.

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Al insertar una fila en `CHQ_SOLICITUD`, asignar los siguientes valores iniciales:
   - `EST_SOLICITUD` = `'SO'` (solicitada), por defecto.
   - `CANT_CHEQUERAS` = `1`, por defecto (válido entre 1 y 3 según la regla RN-CHQ-03).
   - `MON_COSTO_BASE` = `0`, por defecto.
   - `MON_IGV` = `0`, por defecto.
   - `MON_COSTO_TOTAL` = `0`, por defecto.
   - `COD_RECHAZO` = nulo, por defecto.
   - `FEC_PROCESO` = nulo, por defecto (se completa al procesar la solicitud).
   - Los campos `NUM_SOLICITUD`, `CTA_NUMERO`, `FEC_SOLICITUD`, `CANAL` y `COD_USUARIO` son obligatorios y deben ser suministrados por el proceso que crea la solicitud.

2. El acceso a los datos de este dominio está restringido exclusivamente a los módulos `CHQVALCH` (validación de cheques) y `CHQGEREN` (cheques de gerencia), conforme a la regla de dominio establecida. Ningún otro dominio del sistema puede leer ni modificar directamente las tablas del dominio `CHQ`.

3. El proceso de evaluación de la solicitud (ejecutado a través de `CHQVALCH`) actualiza `EST_SOLICITUD` según el resultado:
   - Si la solicitud es aprobada y se procede a emitir las chequeras: `EST_SOLICITUD` se actualiza a un valor distinto de `'SO'`, conforme a la lógica de emisión gestionada por `CHQVALCH`. Los estados posibles para una chequera emitida, definidos en la tabla relacionada `CHQ_CHEQUERA`, son: `'SO'` (solicitada), `'EM'` (emitida), `'EN'` (entregada), `'AG'` (agotada), `'AN'` (anulada) y `'BL'` (bloqueada); la transición exacta de `EST_SOLICITUD` hacia estos estados la determina `CHQVALCH`.
   - Si la solicitud es rechazada: `EST_SOLICITUD` se actualiza al valor de rechazo correspondiente y se registra el código del motivo en `COD_RECHAZO` (`CHAR(2)`).

4. Al procesar la solicitud (sea aprobación o rechazo), registrar en `FEC_PROCESO` la fecha en que se ejecutó el proceso; este campo permanece nulo hasta ese momento.

5. Los índices definidos sobre `CHQ_SOLICITUD` permiten las siguientes búsquedas eficientes:
   - Por `NUM_SOLICITUD` (clave primaria, índice único `IXCHQSO1`).
   - Por `EST_SOLICITUD` y `NUM_SOLICITUD` combinados (índice `IXCHQSO2`), lo que facilita la consulta de todas las solicitudes en un estado determinado ordenadas por número de solicitud.
<!-- rule-end -->

<!-- rule-start -->
### 15. Rule / Operation - Ciclo de Estados de CHQ_CHEQUERA (EST_CHEQUERA)
<!-- reviewed -->

_Reviewed_

**Business Rule for Review:**

El campo `EST_CHEQUERA` en la tabla `CHQ_CHEQUERA` controla el ciclo de vida de cada chequera emitida dentro del dominio CHQ (Cheques y Compensación) del sistema SIDEP.

Los valores posibles de `EST_CHEQUERA` son exactamente los siguientes seis códigos de dos caracteres:
- `SO` — Solicitada
- `EM` — Emitida
- `EN` — Entregada al cliente
- `AG` — Agotada (sin hojas disponibles)
- `AN` — Anulada
- `BL` — Bloqueada

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Al insertar una fila en `CHQ_CHEQUERA`, el campo `EST_CHEQUERA` no tiene valor por defecto definido en el DDL, por lo que debe proporcionarse explícitamente en el momento de la inserción. El valor inicial que corresponda a la emisión es `EM`. Junto con `EST_CHEQUERA`, los siguientes campos son obligatorios y no admiten nulo: `NUM_CHEQUERA` (clave primaria, tipo numérico de 9 dígitos sin decimales), `CTA_NUMERO` (número de cuenta, 14 caracteres), `NUM_SOLICITUD` (referencia a la solicitud de origen), `NUM_INICIAL` (primer número de hoja, numérico de 8 dígitos), `NUM_FINAL` (último número de hoja, numérico de 8 dígitos), `COD_MONEDA` (código de moneda, 3 caracteres) y `FEC_EMISION` (fecha de emisión). El campo `CANT_HOJAS` tiene valor por defecto de 25 hojas por chequera (regla RN-CHQ-05). El campo `IND_GRATUITA` tiene valor por defecto `N`; se establece en `S` únicamente cuando es la primera chequera emitida para la cuenta (regla RN-CHQ-04). Los campos `FEC_ENTREGA` y `COD_MONEDA` admiten nulo en el momento de la inserción según corresponda.

2. Las transiciones de estado válidas son:
   - De `EM` a `EN`: cuando la chequera es entregada físicamente al cliente. En este momento se registra la fecha de entrega en el campo `FEC_ENTREGA`.
   - De `EN` a `AG`: cuando todos los cheques de la chequera han sido utilizados, es decir, cuando no quedan hojas en estado `DI` (disponible) en la tabla `CHQ_CHEQUE` para el valor de `NUM_CHEQUERA` correspondiente.
   - De `EM` o `EN` a `BL`: cuando se bloquea la chequera por instrucción del cliente o del banco.
   - De cualquier estado activo a `AN`: cuando se anula la chequera.

3. La regla RN-CHQ-02 —que establece un máximo de 2 chequeras vigentes por cuenta— se evalúa considerando únicamente las chequeras cuyo `EST_CHEQUERA` sea `EM` (emitida) o `EN` (entregada). Los estados `SO`, `AG`, `AN` y `BL` no se contabilizan para este límite.

4. El acceso a la tabla `CHQ_CHEQUERA` está restringido al dominio CHQ. Ningún otro dominio del sistema lee directamente esta tabla; el acceso externo se realiza exclusivamente a través de los servicios `CHQVALCH` (validación de cheques) y `CHQGEREN` (cheques de gerencia).
<!-- rule-end -->

<!-- rule-start -->
### 16. Rule / Operation - Ciclo de Estados de CHQ_CHEQUE (EST_CHEQUE)
<!-- reviewed -->

_Reviewed_

**Rule / Operation - Ciclo de Estados de CHQ_CHEQUE (EST_CHEQUE)**

- El campo `EST_CHEQUE` en la tabla `CHQ_CHEQUE` registra el estado de cada hoja de cheque individual.
- Los valores posibles son: `'DI'` (disponible), `'PR'` (presentado), `'PA'` (pagado), `'RE'` (rechazado), `'NP'` (orden de no pago), `'AN'` (anulado).
- El valor por defecto al crear la hoja es `'DI'`.

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Al insertar una fila en `CHQ_CHEQUE` (al emitir la chequera), asignar los siguientes valores iniciales:
   - `EST_CHEQUE` = `'DI'`
   - `MON_IMPORTE` = `0`
   - Los campos `FEC_GIRO`, `FEC_ESTADO` y `COD_MOTIVO` quedan sin valor (nulos).
   - El campo `NUM_CHEQUERA` debe referenciar la chequera a la que pertenece la hoja, y la clave primaria de cada fila está compuesta por `CTA_NUMERO` (número de cuenta, 14 caracteres) y `NUM_CHEQUE` (número de cheque, hasta 8 dígitos).

2. Las transiciones de estado permitidas son:
   - De `'DI'` a `'PR'`: cuando el cheque es presentado a cobro o a cámara de compensación. Registrar `FEC_ESTADO` con la fecha de presentación.
   - De `'PR'` a `'PA'`: cuando el cheque es pagado. Registrar `FEC_ESTADO` con la fecha de pago y `MON_IMPORTE` con el importe cobrado (valor decimal de hasta 15 dígitos con 2 decimales). La regla RN-CHQ-10 prohíbe explícitamente que un cheque que ya se encuentra en estado `'PA'` vuelva a transicionar a ese mismo estado, impidiendo el doble pago.
   - De `'PR'` a `'RE'`: cuando el cheque es rechazado. Registrar `COD_MOTIVO` con el código de rechazo (2 caracteres) y `FEC_ESTADO` con la fecha del rechazo.
   - De `'DI'` a `'NP'`: cuando se registra una orden de no pago sobre el cheque.
   - De `'DI'` o `'PR'` a `'AN'`: cuando el cheque es anulado.

3. El campo `FEC_GIRO` se registra con la fecha en que el cheque fue girado por el titular; su valor es nulo hasta que dicha información sea conocida o informada durante el proceso de presentación o pago.

4. Ningún otro dominio del sistema accede directamente a la tabla `CHQ_CHEQUE`; toda lectura o modificación de sus datos debe realizarse exclusivamente a través de los servicios `CHQVALCH` (validación de cheques) o `CHQGEREN` (cheques de gerencia).
<!-- rule-end -->

<!-- rule-start -->
### 17. Rule / Operation - Ciclo de Estados de CHQ_PRESENTACION (EST_PRESENTACION)
<!-- reviewed -->

_Reviewed_

**Rule / Operation - Ciclo de Estados de CHQ\_PRESENTACION (EST\_PRESENTACION)**

- El campo `EST_PRESENTACION` en la tabla `CHQ_PRESENTACION` registra el estado de cada cheque dentro del proceso de cámara de compensación.
- Los valores posibles son: `'PE'` (pendiente), `'PA'` (pagado), `'RE'` (rechazado), `'CP'` (canje pendiente), `'AB'` (abonado), `'DV'` (devuelto).
- El valor por defecto al registrar la presentación es `'PE'`.

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Al insertar una fila en `CHQ_PRESENTACION`, los siguientes campos reciben sus valores por defecto si no se especifican explícitamente:
   - `EST_PRESENTACION` = `'PE'` (pendiente).
   - `IND_PLAZA` = `'L'` (plaza Lima).
   - `IND_FIRMA` = `'S'` (firma verificada).
   - `IND_DEFECTO` = `'N'` (sin defecto formal).
   Los campos `FEC_CANJE` y `COD_MOTIVO` se dejan sin valor (nulos) en el momento de la inserción.

2. Cada presentación queda identificada por la combinación de `NUM_LOTE` y `NUM_SECUENCIA`, que forman la clave primaria. Los lotes se organizan por fecha de presentación (`FEC_PRESENTACION`), conforme a la regla RN-CHQ-20.

3. El campo `TIP_ORIGEN` determina la naturaleza del cheque presentado y condiciona el ciclo de estados:
   - `'E'` — cheque entrante: girado contra el propio banco y presentado por otro banco en cámara.
   - `'S'` — cheque de salida: depositado por un cliente del banco en otra entidad.

4. Las transiciones de estado dependen del tipo de origen y del resultado del proceso de canje:
   - Para cheques entrantes (`TIP_ORIGEN = 'E'`):
     - De `'PE'` a `'PA'`: cuando el banco autoriza el pago del cheque.
     - De `'PE'` a `'RE'`: cuando el banco rechaza el cheque. Se registra `COD_MOTIVO` con el código de rechazo. Este evento genera una fila en la tabla `CHQ_RECHAZO`.
   - Para cheques de salida (`TIP_ORIGEN = 'S'`):
     - De `'PE'` a `'CP'`: cuando el cheque entra en proceso de canje dentro del plazo definido por la regla RN-CHQ-21 (propio T+0, Lima T+1 hábil, provincia T+2 hábiles), determinado por el valor de `IND_PLAZA`.
     - De `'CP'` a `'AB'`: cuando el banco emisor confirma el pago y se abona en la cuenta identificada por `CTA_ABONO`.
     - De `'CP'` a `'DV'`: cuando el banco emisor devuelve el cheque sin pagar.
   - En las transiciones que implican rechazo o devolución, se registra la fecha en `FEC_CANJE` y el motivo en `COD_MOTIVO`.

5. Los campos `IND_FIRMA` e `IND_DEFECTO` reflejan condiciones formales del cheque en el momento de la presentación: `IND_FIRMA` indica si la firma ha sido verificada (`'S'`/`'N'`) e `IND_DEFECTO` indica si el cheque presenta algún defecto formal (`'N'` sin defecto / `'S'` con defecto). Estos indicadores pueden influir en la decisión de pago o rechazo, pero la lógica de evaluación reside en el módulo de validación de cheques (CHQVALCH).

6. El acceso a la tabla `CHQ_PRESENTACION` —al igual que al resto de las tablas del dominio CHQ— está restringido exclusivamente a los módulos CHQVALCH y CHQGEREN. Ningún otro dominio del sistema accede directamente a estas tablas.
<!-- rule-end -->

<!-- rule-start -->
### 18. Rule / Operation - Ciclo de Estados de CHQ_GERENCIA (EST_GERENCIA)
<!-- reviewed -->

_Reviewed_

**Business Rule for Review — Ciclo de Estados de CHQ_GERENCIA (EST_GERENCIA)**

- El campo `EST_GERENCIA` en la tabla `CHQ_GERENCIA` registra el estado de cada cheque de gerencia.
- Los valores posibles son: `'VI'` (vigente), `'PA'` (pagado), `'AN'` (anulado).
- El valor por defecto al emitir el cheque es `'VI'`, definido como valor predeterminado de la columna.

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Al insertar una fila en `CHQ_GERENCIA`, los valores iniciales asignados son:
   - `EST_GERENCIA` = `'VI'` (vigente), por valor por defecto de la columna.
   - `FEC_ESTADO` = nulo, dado que la columna no tiene valor por defecto y no es obligatoria, por lo que queda sin fecha de cambio de estado al momento de la emisión.
   - `MON_COMISION` = `0` (valor por defecto).
   - `MON_IGV` = `0` (valor por defecto).
   - Los campos `NUM_CHEQUE_GER`, `CTA_CARGO`, `MON_IMPORTE`, `COD_MONEDA`, `BENEFICIARIO`, `FEC_EMISION`, `FEC_VENCIM` y `COD_USUARIO` son obligatorios y deben ser provistos por quien registra el cheque.
   - La fecha de vencimiento `FEC_VENCIM` se establece sumando 180 días calendario a `FEC_EMISION`, conforme a la regla RN-CHQ-42.
   - La comisión se calcula como el 0,25 % del importe (`MON_IMPORTE`), con un mínimo de 15,00 PEN o 5,00 USD según la moneda (`COD_MONEDA`), más IGV, conforme a la regla RN-CHQ-40.

2. Las transiciones de estado permitidas son:
   - De `'VI'` a `'PA'`: cuando el cheque de gerencia es presentado y pagado. Se actualiza `EST_GERENCIA` = `'PA'` y `FEC_ESTADO` con la fecha del pago.
   - De `'VI'` a `'AN'`: cuando el cheque de gerencia es anulado, ya sea por solicitud del cliente o por vencimiento transcurridos los 180 días calendario (RN-CHQ-42). Se actualiza `EST_GERENCIA` = `'AN'` y `FEC_ESTADO` con la fecha de la anulación.

3. Un cheque en estado `'PA'` o `'AN'` no puede volver a estado `'VI'` ni transitar a ningún otro estado; ambos son estados finales.

4. La búsqueda de cheques de gerencia por cuenta y estado se realiza mediante el índice `IXCHQGE2`, que indexa las columnas `CTA_CARGO` y `EST_GERENCIA` de la tabla `CHQ_GERENCIA`. El acceso directo a esta tabla solo está permitido a través de los programas `CHQVALCH` y `CHQGEREN`; ningún otro dominio del sistema lee directamente estas tablas.
<!-- rule-end -->

<!-- rule-start -->
### 19. Rule / Operation - Regla de Dominio: Acceso Exclusivo via CHQVALCH y CHQGEREN
<!-- reviewed -->

_Reviewed_

**Regla de Dominio: Acceso Exclusivo via CHQVALCH y CHQGEREN**

- Ningún componente externo al dominio CHQ puede leer ni modificar directamente las tablas de este dominio. Las tablas protegidas por esta regla son exactamente las siguientes seis: `CHQ_SOLICITUD`, `CHQ_CHEQUERA`, `CHQ_CHEQUE`, `CHQ_PRESENTACION`, `CHQ_RECHAZO` y `CHQ_GERENCIA`.
- Todo acceso a los datos de cheques debe realizarse únicamente a través de las interfaces `CHQVALCH` (validación y procesamiento de cheques) y `CHQGEREN` (cheques de gerencia), mediante llamada (CALL).

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Durante la modernización, cualquier componente que necesite consultar o modificar datos del dominio CHQ debe hacerlo invocando los servicios `CHQVALCH` o `CHQGEREN`, según corresponda: `CHQVALCH` para operaciones de validación y procesamiento de cheques ordinarios (incluyendo chequeras, cheques, presentaciones a cámara y rechazos), y `CHQGEREN` para operaciones sobre cheques de gerencia.
2. No se deben crear accesos directos (consultas directas, vistas expuestas, interfaces de tabla) a ninguna de las seis tablas del dominio desde otros dominios o componentes externos.
3. Las tablas del dominio CHQ residen en los tablespaces `TSCHQ01` y `TSCHQ02` dentro de la base de datos `DBSIDEP`. Las tablas `CHQ_SOLICITUD`, `CHQ_CHEQUERA` y `CHQ_GERENCIA` se almacenan en `TSCHQ01`; las tablas `CHQ_CHEQUE`, `CHQ_PRESENTACION` y `CHQ_RECHAZO` se almacenan en `TSCHQ02`. Esta separación física es parte del diseño del dominio y debe tenerse en cuenta al planificar la migración de datos.
4. La lógica interna de `CHQVALCH` y `CHQGEREN` no está contenida en este archivo fuente; su comportamiento exacto debe obtenerse de sus propios fuentes. Lo que sí se establece en este archivo es que son los únicos puntos de entrada autorizados al dominio CHQ, y que ningún otro dominio accede a estas tablas directamente.
<!-- rule-end -->

<!-- rule-start -->
### 20. Rule / Operation - Estructura de Costos en CHQ_SOLICITUD (MON_COSTO_BASE, MON_IGV, MON_COSTO_TOTAL)
<!-- reviewed -->

_Reviewed_

**Rule / Operation - Estructura de Costos en CHQ_SOLICITUD (MON_COSTO_BASE, MON_IGV, MON_COSTO_TOTAL)**

Cada solicitud de chequera registra el desglose del costo cobrado al cliente: costo base, IGV y costo total. Estos tres campos pertenecen a la tabla `CHQ_SOLICITUD` y se definen con valor por defecto `0`, lo que cubre el caso de la primera chequera gratuita (RN-CHQ-04).

**Rule Status:** Relevant for Modernization

**Algorithm**

1. Al registrar una solicitud de chequera en `CHQ_SOLICITUD`, los campos de costo se inicializan con su valor por defecto `0` para los tres campos: `MON_COSTO_BASE`, `MON_IGV` y `MON_COSTO_TOTAL`.
2. Al procesar la solicitud, calcular el costo según las tarifas vigentes del sistema (externas a este dominio):
   - `MON_COSTO_BASE`: importe de la comisión por emisión de chequera antes de impuestos.
   - `MON_IGV`: importe del IGV calculado sobre `MON_COSTO_BASE`, aplicando la tasa de IGV vigente. El desglose del IGV en comisiones fue incorporado al modelo a partir del 31 de enero de 2005.
   - `MON_COSTO_TOTAL`: suma de `MON_COSTO_BASE` más `MON_IGV`.
3. Si la chequera corresponde al caso gratuito (RN-CHQ-04, primera chequera de la cuenta, indicado por `IND_GRATUITA = 'S'` en `CHQ_CHEQUERA`), los tres campos de costo en `CHQ_SOLICITUD` permanecen en `0.00`.
4. Los valores calculados se registran en `CHQ_SOLICITUD` al momento de aprobar y procesar la solicitud. En ese mismo momento se registra la fecha de proceso en el campo `FEC_PROCESO`, que permanece nulo mientras la solicitud no ha sido procesada.
5. El estado de la solicitud (`EST_SOLICITUD`) se inicializa con el valor por defecto `'SO'` (solicitada) al momento de la creación del registro. El campo `COD_RECHAZO` es opcional y solo se registra cuando la solicitud es rechazada.
6. Ningún otro dominio del sistema accede directamente a `CHQ_SOLICITUD`; el acceso se realiza exclusivamente a través de los módulos autorizados `CHQVALCH` y `CHQGEREN`.
<!-- rule-end -->

---

## Extraction metadata

- **Main file:** db2/23-ddl-chq.sql
- **Created:** 2026-11-08 15:59:28 UTC
- **Started:** 2026-11-08 15:59:28 UTC
- **Duration:** 00:57:15
- **LLM:** us.anthropic.claude-sonnet-4-6 (us.anthropic.claude-sonnet-4-6)
- **Context window:** 200000 tokens · **Max output:** 64000 tokens
- **Extraction prompt:** business_rules_extraction · **Reviewer prompt:** business_rules_reviewer
- **Token usage:** 162675 total (125596 input, 37079 output)
